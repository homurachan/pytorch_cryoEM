# Implemented modifications

## Python 3.10-only modernization

* Replaced Python 2 print statements, `xrange`, `raw_input`, and old
  exception syntax. Integer divisions used for indices were made explicit.
* Preserved one scientifically consequential Python 2 arithmetic behavior: the
  upstream Gaussian expression `exp(-1/2 * r^2)` evaluates as `exp(-r^2)` in
  Python 2.7. This is the default `legacy-python2` kernel mode. An explicit
  `intended-half` mode is also provided for `exp(-0.5*r^2)`.
* Replaced `Tkinter`, `ttk`, and old file/message dialog imports with Python 3
  `tkinter` imports.
* Replaced `docopt` with the standard-library `argparse` while retaining the
  historical `--noguiSingle` and `--noguiSplit` spellings.
* Replaced removed NumPy scalar aliases and deprecated SciPy namespace paths.
* Added the capitalization shim `ResMap_sphericalProfile.py` for Linux/source
  compatibility.

## MRC implementation

* Replaced the handwritten MRC2000 binary reader/writer with `mrcfile`.
* The output remains float32 and preserves voxel size, origin, start indices,
  axis mapping, unit-cell angles, labels, and an extended header when it can be
  safely retained.

## CPU stages retained

* SciPy mask construction, Gaussian blur, binary morphology, and city-block
  distance transforms.
* NumPy FFT pre-whitening and the original polynomial whitening model.
* Original low-pass detection and SciPy cubic-spline downsampling.
* NumPy/SciPy basis construction, SVD rank decisions, eigenvalues, sorting,
  Ruben/Farebrother CDF, and Benjamini-Yekutieli FDR loop.
* Tkinter GUI, Matplotlib plots, and classic Chimera command generation.

## PyTorch low-rank core

For each window, define `D = diag(sqrt(kernel))` and weighted model `B = D A`.
The legacy likelihood statistic is

```text
y^T D (P_B - P_constant) D y.
```

The projector difference has rank at most 16. An SVD produces an orthonormal
basis `U_detail`, and the statistic is evaluated exactly as

```text
sum_j (f_j^T y)^2, where f_j = D U_detail[:, j].
```

Each `f_j` is reshaped into a 3-D correlation kernel. PyTorch `conv3d` evaluates
all overlapping windows in slabs. No dense `m x m` LRS matrix is created.

The background matrix

```text
D (I - P_DAd) D
```

is likewise evaluated as weighted centered-patch energy minus squared
projection-filter responses. Non-overlapping starts and all-mask block
selection match the legacy rolling-window flow.

## Large-volume memory changes

* LRS output is computed in Z slabs with halo supplied by slicing the input.
* Filter channels are batched and immediately reduced to one sum-of-squares
  channel.
* CUDA OOM automatically retries the current slab at half the Z depth.
* Mask centers are stored as one flattened vector rather than three full
  coordinate vectors; int32 is used when the cubic volume size permits it.
* No full float32 LRS volume or full assigned bool volume is retained; passing
  flattened indices update the result and mask in place.

## Deliberately unchanged behavior

* Cubic-volume-only assumption.
* Fixed 9-voxel edge backoff.
* Legacy negative-index wrapping when the radius exceeds that backoff.
* Original interpolation choices.
* Original FDR ordering and harmonic-constant convention.
* Actual upstream Python 2 Gaussian-kernel arithmetic by default.
