"""Create the classic UCSF Chimera command file used by ResMap."""

from __future__ import annotations

import os
import subprocess as sp
from typing import Callable, Iterable, Sequence, Union

import numpy as np


def createChimeraScript(
    inputFileName: str,
    Mbegin: float,
    Mmax: float,
    N: int,
    animated: bool = False,
) -> str:
    fname, ext = os.path.splitext(inputFileName)
    basename = os.path.basename(inputFileName)
    basename_raw, _ = os.path.splitext(basename)
    new_file_name = fname + "_resmap_chimera.cmd"

    n = int(N)
    prefix = "" if animated else "# "
    colors = ["blue", "cyan", "green", "yellow", "orange", "red"]
    values = np.linspace(float(Mbegin), float(Mmax), len(colors))
    color_str = "".join(
        "%.2f,%s:" % (value, color) for value, color in zip(values, colors)
    )
    color_str += "%.2f,gray" % (values[-1] + 0.01)

    with open(new_file_name, "w", encoding="utf-8") as handle:
        handle.write("# Color a map by local resolution computed by ResMap\n")
        handle.write("# Initial script concept courtesy of Tom Goddard, UCSF.\n\n")
        handle.write("# Open both volumes and hide the ResMap volume.\n")
        handle.write("set bg_color white\n")
        handle.write("open #0 {}\n".format(basename))
        handle.write("open #1 {}_resmap{}\n".format(basename_raw, ext))
        handle.write("volume #1 hide\n\n")
        handle.write("# Color the original map with the ResMap output.\n")
        handle.write("scolor #0 volume #1 cmap " + color_str + "\n\n\n\n")

        handle.write("# OPTIONAL: ResMap Slice Animation.\n\n")
        handle.write(
            "# Show midway slice of the original map with contour level below "
            "the minimum map value.\n"
        )
        handle.write(prefix + "volume #0 planes z,{} step 1 level -1 style surface\n\n".format(n // 2))
        handle.write(
            "# Show a smooth transparent contour surface indicating the "
            "structure boundaries.\n"
        )
        handle.write(prefix + "vop gaussian #0 sDev 5 model #2\n")
        handle.write(prefix + "volume #2 level 0.02 step 1 color .9,.7,.7,.5\n\n")
        handle.write("# Zoom out a bit and tilt to a viewing angle.\n")
        handle.write(prefix + "turn x -45\n")
        handle.write(prefix + "turn y -30\n")
        handle.write(prefix + "turn z -30\n")
        handle.write(prefix + "scale 0.5\n\n")
        handle.write("# Cycle through planes from N/2 to 4N/5 to N/5 and back.\n")
        handle.write(prefix + "volume #0 planes z,{},{},0.25\n".format(n // 2, 4 * n // 5))
        handle.write(prefix + "wait {}\n".format(4 * int(4 * n // 5 - n // 2)))
        handle.write(prefix + "volume #0 planes z,{},{},0.25\n".format(4 * n // 5, n // 5))
        handle.write(prefix + "wait {}\n".format(4 * int(4 * n // 5 - n // 5)))
        handle.write(prefix + "volume #0 planes z,{},{},0.25\n".format(n // 5, n // 2))

    return new_file_name


def try_alternatives(cmd: str, locations: Sequence[object], args: Sequence[str]) -> int:
    command = [None]
    command.extend(args)
    for path in locations:
        if callable(path):
            path = path()
        command[0] = os.path.join(str(path), cmd)
        try:
            return int(sp.call(command))
        except OSError:
            continue
    raise OSError('command "{}" not found in locations list'.format(cmd))


__all__ = ["createChimeraScript", "try_alternatives"]
