#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m py_compile ResMap*.py
pytest -q
