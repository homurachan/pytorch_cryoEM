"""NumPy/SciPy spectral processing retained from the ResMap workflow."""

from __future__ import annotations

from time import time
from typing import Dict, Tuple

import numpy as np
from scipy import signal

from ResMap_helpers import createRmatrix
from ResMap_sphericalprofile import sphericalAverage


def _normalized_fourier_amplitude(fourier_data: np.ndarray) -> np.ndarray:
    amplitude = np.abs(fourier_data).astype(np.float64, copy=False)
    amplitude = amplitude - float(np.min(amplitude))
    maximum = float(np.max(amplitude))
    if maximum <= 0.0 or not np.isfinite(maximum):
        return np.zeros_like(amplitude, dtype=np.float64)
    return amplitude / maximum


def createPreWhiteningFilter(**kwargs: object) -> Dict[str, np.ndarray]:
    epsilon = 1e-10
    spectrum = np.asarray(kwargs.get("spectrum"), dtype=np.float64)
    elbow_angstrom = float(kwargs.get("elbowAngstrom", 0.0))
    ramp_weight = float(kwargs.get("rampWeight", 1.0))
    voxel_size = float(kwargs.get("vxSize", 0.0))
    n = int(kwargs.get("n", 0))
    if spectrum.ndim != 1 or spectrum.size < 3:
        raise ValueError("pre-whitening requires a one-dimensional spectrum")
    if elbow_angstrom <= 0.0 or voxel_size <= 0.0 or n <= 0:
        raise ValueError("invalid pre-whitening parameters")

    radius = createRmatrix(n)
    xpoly = np.arange(1, spectrum.size + 1, dtype=np.float64)
    ypoly = np.log(np.sqrt(np.maximum(spectrum, epsilon)))
    sampling_frequency = 1.0 / voxel_size
    frequency_index = 1.0 / (
        sampling_frequency / 2.0 * np.linspace(epsilon, 1.0, xpoly.size)
    )
    index_elbow = int(np.argmin((frequency_index - elbow_angstrom) ** 2))
    index_start = int(np.argmin((frequency_index - 1.05 * elbow_angstrom) ** 2))
    index_nyquist = float(xpoly[-1])

    weights = np.asarray(
        np.bitwise_and(xpoly > index_elbow, xpoly < index_nyquist),
        dtype=np.float32,
    )
    weights += 0.5 * np.asarray(
        np.bitwise_and(xpoly > index_start, xpoly <= index_elbow),
        dtype=np.float32,
    )
    if np.count_nonzero(weights) < 3:
        # Preserve the polynomial form while avoiding a singular weighted fit
        # for tiny synthetic test volumes.
        weights = np.ones_like(xpoly, dtype=np.float32)

    pcoef = np.polynomial.polynomial.polyfit(xpoly, ypoly, 2, w=weights)
    peval = np.polynomial.polynomial.polyval(xpoly, pcoef)
    radius = radius.astype(np.float64, copy=False)
    radius[radius < index_start] = index_start
    radius[radius > index_nyquist] = index_nyquist
    whitening_filter = np.exp(
        np.polynomial.polynomial.polyval(radius, -ramp_weight * pcoef)
    )
    return {
        "peval": np.asarray(peval),
        "pcoef": np.asarray(pcoef),
        "pWfilter": np.asarray(whitening_filter, dtype=np.float32),
    }


def createPreWhiteningFilterFinal(**kwargs: object) -> Dict[str, np.ndarray]:
    epsilon = 1e-10
    spectrum = np.asarray(kwargs.get("spectrum"), dtype=np.float64)
    pcoef = np.asarray(kwargs.get("pcoef"), dtype=np.float64)
    elbow_angstrom = float(kwargs.get("elbowAngstrom", 0.0))
    ramp_weight = float(kwargs.get("rampWeight", 1.0))
    voxel_size = float(kwargs.get("vxSize", 0.0))
    n = int(kwargs.get("n", 0))
    cube_size = int(kwargs.get("cubeSize", 0))
    if n <= 0 or cube_size <= 1 or voxel_size <= 0.0:
        raise ValueError("invalid full-volume pre-whitening parameters")

    radius = createRmatrix(n).astype(np.float64, copy=False)
    xpoly = np.arange(1, spectrum.size + 1, dtype=np.float64)
    sampling_frequency = 1.0 / voxel_size
    frequency_index = 1.0 / (
        sampling_frequency / 2.0 * np.linspace(epsilon, 1.0, xpoly.size)
    )
    index_start = int(np.argmin((frequency_index - 1.05 * elbow_angstrom) ** 2))
    index_nyquist = float(xpoly[-1])
    radius[radius < index_start] = index_start
    radius[radius > index_nyquist] = index_nyquist
    radius = radius / (float(n) / float(cube_size - 1))
    whitening_filter = np.exp(
        np.polynomial.polynomial.polyval(radius, -ramp_weight * pcoef)
    )
    return {"pWfilter": np.asarray(whitening_filter, dtype=np.float32)}


def preWhitenVolumeSoftBG(**kwargs: object) -> Dict[str, np.ndarray]:
    print("\n= Pre-whitening")
    start = time()
    n = int(kwargs.get("n", 0))
    elbow_angstrom = float(kwargs.get("elbowAngstrom", 0.0))
    background_spectrum = np.asarray(kwargs.get("dataBGSpect"))
    data_fourier = np.asarray(kwargs.get("dataF"))
    soft_background_mask = np.asarray(kwargs.get("softBGmask"), dtype=np.float32)
    voxel_size = float(kwargs.get("vxSize", 0.0))
    ramp_weight = float(kwargs.get("rampWeight", 1.0))

    filter_result = createPreWhiteningFilter(
        n=n,
        spectrum=background_spectrum,
        elbowAngstrom=elbow_angstrom,
        rampWeight=ramp_weight,
        vxSize=voxel_size,
    )
    filtered_fourier = filter_result["pWfilter"] * data_fourier
    data_pw_spectrum = (
        sphericalAverage(_normalized_fourier_amplitude(filtered_fourier) ** 2)
        + 1e-10
    )
    data_pw = np.real(np.fft.ifftn(np.fft.ifftshift(filtered_fourier)))

    data_pw_background = data_pw * soft_background_mask
    data_pw_background_fourier = np.fft.fftshift(np.fft.fftn(data_pw_background)).astype(
        np.complex64
    )
    data_pw_background_spectrum = (
        sphericalAverage(
            _normalized_fourier_amplitude(data_pw_background_fourier) ** 2
        )
        + 1e-10
    )
    minutes, seconds = divmod(time() - start, 60)
    print("  :: Time elapsed: %d minutes and %.2f seconds" % (minutes, seconds))
    return {
        "dataPW": np.asarray(data_pw, dtype=np.float32),
        "dataPWSpect": np.asarray(data_pw_spectrum),
        "dataPWBGSpect": np.asarray(data_pw_background_spectrum),
        "peval": filter_result["peval"],
        "pcoef": filter_result["pcoef"],
    }


def preWhitenCube(**kwargs: object) -> Dict[str, np.ndarray]:
    print("\n= Pre-whitening the Cubes")
    start = time()
    n = int(kwargs.get("n", 0))
    voxel_size = float(kwargs.get("vxSize", 0.0))
    elbow_angstrom = float(kwargs.get("elbowAngstrom", 0.0))
    ramp_weight = float(kwargs.get("rampWeight", 1.0))
    data_fourier = np.asarray(kwargs.get("dataF"))
    background_fourier = np.asarray(kwargs.get("dataBGF"))
    background_spectrum = np.asarray(kwargs.get("dataBGSpect"))

    filter_result = createPreWhiteningFilter(
        n=n,
        spectrum=background_spectrum,
        elbowAngstrom=elbow_angstrom,
        rampWeight=ramp_weight,
        vxSize=voxel_size,
    )
    filtered_data = filter_result["pWfilter"] * data_fourier
    data_pw_spectrum = (
        sphericalAverage(_normalized_fourier_amplitude(filtered_data) ** 2) + 1e-10
    )
    data_pw = np.real(np.fft.ifftn(np.fft.ifftshift(filtered_data)))

    filtered_background = filter_result["pWfilter"] * background_fourier
    background_pw_spectrum = (
        sphericalAverage(_normalized_fourier_amplitude(filtered_background) ** 2)
        + 1e-10
    )
    background_pw = np.real(np.fft.ifftn(np.fft.ifftshift(filtered_background)))
    minutes, seconds = divmod(time() - start, 60)
    print("  :: Time elapsed: %d minutes and %.2f seconds" % (minutes, seconds))
    return {
        "dataPW": np.asarray(data_pw, dtype=np.float32),
        "dataBGPW": np.asarray(background_pw, dtype=np.float32),
        "dataPWSpect": np.asarray(data_pw_spectrum),
        "dataPWBGSpect": np.asarray(background_pw_spectrum),
        "peval": filter_result["peval"],
        "pcoef": filter_result["pcoef"],
    }


def displayPreWhitening(**kwargs: object) -> Tuple[float, float]:
    """Display the legacy interactive pre-whitening inspection window."""
    import matplotlib.pyplot as plt
    from matplotlib.widgets import Button, Slider

    elbow_angstrom = float(kwargs.get("elbowAngstrom", 0.0))
    ramp_weight = float(kwargs.get("rampWeight", 1.0))
    data_spectrum = np.asarray(kwargs.get("dataSpect"))
    background_spectrum = np.asarray(kwargs.get("dataBGSpect"))
    peval = np.asarray(kwargs.get("peval"))
    data_pw_spectrum = np.asarray(kwargs.get("dataPWSpect"))
    background_pw_spectrum = np.asarray(kwargs.get("dataPWBGSpect"))
    voxel_size = float(kwargs.get("vxSize", 0.0))
    data_slice = np.asarray(kwargs.get("dataSlice"))
    data_pw_slice = np.asarray(kwargs.get("dataPWSlice"))
    xpoly = np.arange(1, background_spectrum.size + 1)

    figure = plt.figure(figsize=(18, 9))
    figure.suptitle(
        "\nResMap Pre-Whitening Interface (beta)",
        fontsize=20,
        color="#104E8B",
        fontweight="bold",
    )
    axis_spectrum = plt.subplot2grid((2, 3), (0, 0), colspan=2)
    axis_input = plt.subplot2grid((2, 3), (1, 0))
    axis_output = plt.subplot2grid((2, 3), (1, 1))
    axis_text = plt.subplot2grid((2, 3), (1, 2))
    axis_button = plt.axes([0.67, 0.025, 0.23, 0.05])

    ok_color = "seagreen"
    update_color = "firebrick"
    button = Button(axis_button, label="Continue", color=ok_color, hovercolor=ok_color)

    def close_figure(_event: object) -> None:
        plt.close(figure)

    button.on_clicked(close_figure)
    elbow_axis = plt.axes([0.7, 0.65, 0.2, 0.03], facecolor="lightgoldenrodyellow")
    elbow_slider = Slider(
        elbow_axis,
        "Angstrom",
        2.1 * voxel_size,
        100.0,
        valinit=elbow_angstrom,
    )
    ramp_axis = plt.axes([0.7, 0.55, 0.2, 0.03], facecolor="lightgoldenrodyellow")
    ramp_slider = Slider(ramp_axis, "Ramp Weight", 0.0, 1.0, valinit=ramp_weight)

    def something_changed(_value: float) -> None:
        axis_button.clear()
        updated = Button(
            axis_button,
            label="Click here to Update",
            color=update_color,
            hovercolor=update_color,
        )
        updated.on_clicked(close_figure)
        figure.canvas.draw_idle()

    elbow_slider.on_changed(something_changed)
    ramp_slider.on_changed(something_changed)

    axis_text.set_title("INSTRUCTIONS", color="#104E8B", fontweight="bold")
    axis_text.get_xaxis().set_visible(False)
    axis_text.get_yaxis().set_visible(False)
    axis_text.text(
        0.5,
        0.5,
        "Please check that the green line\nis as straight as possible,\n"
        "at least in the high frequencies.\n\nIf not, adjust the sliders\n"
        "and press Update.\n\nIf satisfied, press Continue.",
        horizontalalignment="center",
        verticalalignment="center",
        fontsize=14,
        transform=axis_text.transAxes,
    )

    axis_spectrum.plot(xpoly, data_spectrum, lw=2, label="Input Map")
    axis_spectrum.plot(xpoly, background_spectrum, lw=2, label="Background")
    axis_spectrum.plot(
        xpoly, np.exp(peval) ** 2, lw=2, linestyle="dashed", label="Fitted Line"
    )
    axis_spectrum.plot(xpoly, data_pw_spectrum, lw=2, label="Pre-Whitened Map")
    axis_spectrum.plot(
        xpoly, background_pw_spectrum, lw=2, label="Pre-Whitened Background"
    )
    sampling_frequency = 1.0 / voxel_size
    tick_count = max(2, int(xpoly.size / 6))
    angstrom_ticks = 1.0 / (
        sampling_frequency / 2.0 * np.linspace(1e-2, 1.0, tick_count)
    )
    axis_spectrum.set_xticks(np.linspace(1, xpoly.size, angstrom_ticks.size))
    axis_spectrum.set_xticklabels(["%.1f" % member for member in angstrom_ticks])
    concatenated = np.concatenate(
        (
            data_spectrum,
            background_spectrum,
            data_pw_spectrum,
            background_pw_spectrum,
        )
    )
    positive = concatenated[concatenated > 0]
    if positive.size:
        axis_spectrum.set_ylim((float(np.min(positive)), float(np.max(positive))))
    axis_spectrum.set_ylabel("Power Spectrum (|f|^2)")
    axis_spectrum.set_xlabel("Angstrom")
    axis_spectrum.set_yscale("log")
    axis_spectrum.grid(linestyle="dotted")
    axis_spectrum.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.0)

    axis_input.imshow(data_slice, cmap=plt.cm.gray, interpolation="nearest")
    axis_output.imshow(data_pw_slice, cmap=plt.cm.gray, interpolation="nearest")
    axis_input.set_title("Middle Slice of Input Map")
    axis_output.set_title("Middle Slice of Pre-Whitened Map")
    plt.show()
    return float(elbow_slider.val), float(ramp_slider.val)


def displayPowerSpectrum(*args: object) -> None:
    import matplotlib.pyplot as plt

    figure = plt.figure(1)
    axis = figure.add_subplot(111)
    for item in args:
        _, power_spectrum = calculatePowerSpectrum(item.matrix)
        n = int(power_spectrum.size)
        xpoly = np.arange(1, n + 1)
        axis.plot(xpoly, power_spectrum, label=item.name)
        sampling_frequency = 1.0 / float(item.data_step[0])
        tick_count = max(2, int(xpoly.size / 6))
        values = 1.0 / (
            sampling_frequency / 2.0 * np.linspace(1e-2, 1.0, tick_count)
        )
        axis.set_xticks(np.linspace(1, xpoly.size, values.size))
        axis.set_xticklabels(["%.1f" % member for member in values])
    axis.set_yscale("log")
    axis.grid(linestyle="dotted")
    axis.set_ylabel("Power Spectrum (|f|^2)")
    axis.set_xlabel("Frequency")
    axis.legend(loc=3)
    plt.show()


def isPowerSpectrumLPF(dataPowerSpectrum: np.ndarray) -> Dict[str, object]:
    spectrum = np.asarray(dataPowerSpectrum, dtype=np.float64)
    if spectrum.size < 5 or np.any(spectrum <= 0.0):
        return {"outcome": False, "factor": 0.0}
    diff_log_spectrum = np.diff(np.log(spectrum))
    peak_indices = signal.find_peaks_cwt(
        -diff_log_spectrum, np.arange(1, 10), min_snr=2
    )
    if len(peak_indices) == 0:
        return {"outcome": False, "factor": 0.0}
    max_index = int(np.max(peak_indices))
    if max_index >= spectrum.size - 3:
        return {"outcome": False, "factor": 0.0}
    mean = float(np.mean(diff_log_spectrum[max_index + 2 :]))
    variance = float(np.var(diff_log_spectrum[max_index + 2 :]))
    threshold = 1e-4
    if abs(mean) < threshold and variance < threshold:
        return {
            "outcome": True,
            "factor": float(max_index - 1) / float(spectrum.size),
        }
    return {"outcome": False, "factor": 0.0}


def calculatePowerSpectrum(data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    data_fourier = np.fft.fftshift(np.fft.fftn(np.asarray(data))).astype(np.complex64)
    normalized = _normalized_fourier_amplitude(data_fourier)
    spectrum = sphericalAverage(normalized ** 2) + 1e-10
    return data_fourier, np.asarray(spectrum)


__all__ = [
    "createPreWhiteningFilter",
    "createPreWhiteningFilterFinal",
    "preWhitenVolumeSoftBG",
    "preWhitenCube",
    "displayPreWhitening",
    "displayPowerSpectrum",
    "isPowerSpectrumLPF",
    "calculatePowerSpectrum",
]
