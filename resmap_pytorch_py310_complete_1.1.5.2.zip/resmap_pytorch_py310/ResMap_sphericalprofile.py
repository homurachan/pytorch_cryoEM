"""Spherical profiling utilities for cubic ResMap volumes."""

from __future__ import annotations

from typing import Optional, Sequence

import numpy as np


def sum_by_group(values: np.ndarray, groups: np.ndarray) -> np.ndarray:
    """Sum values sharing the same integer group label."""
    values_arr = np.asarray(values).reshape(-1)
    groups_arr = np.asarray(groups).reshape(-1)
    if values_arr.size != groups_arr.size:
        raise ValueError("values and groups must contain the same number of items")
    order = np.argsort(groups_arr)
    sorted_groups = groups_arr[order]
    sorted_values = np.asarray(values_arr[order], dtype=np.float64)
    sorted_values.cumsum(out=sorted_values)
    index = np.ones(len(sorted_groups), dtype=bool)
    index[:-1] = sorted_groups[1:] != sorted_groups[:-1]
    result = sorted_values[index]
    result[1:] -= result[:-1]
    return result


def sphericalAverage(
    image: np.ndarray, center: Optional[Sequence[float]] = None, binsize: float = 1.0
) -> np.ndarray:
    """Calculate the legacy ResMap spherically averaged radial profile.

    ResMap assumes a cubic array. ``center`` is accepted for API compatibility;
    the historical implementation always used the fractional cube center.
    """
    image_arr = np.asarray(image)
    if image_arr.ndim != 3 or not (
        image_arr.shape[0] == image_arr.shape[1] == image_arr.shape[2]
    ):
        raise ValueError("sphericalAverage expects a cubic 3-D array")
    if binsize <= 0:
        raise ValueError("binsize must be positive")

    n = int(image_arr.shape[0])
    # Preserve the original coordinate convention exactly.
    x, y, z = np.mgrid[
        -n / 2.0 : n / 2.0 : complex(0, n),
        -n / 2.0 : n / 2.0 : complex(0, n),
        -n / 2.0 : n / 2.0 : complex(0, n),
    ]
    radius = np.asarray(np.sqrt(x * x + y * y + z * z), dtype=np.float32)

    nbins = int(np.round(((n / 2.0) - 1.0) / float(binsize)))
    if nbins < 1:
        return np.asarray([], dtype=np.float64)
    maxbin = nbins * float(binsize)
    bins = np.linspace(0.0, maxbin, nbins)
    whichbin = np.digitize(radius.ravel(), bins)
    nr = np.bincount(whichbin)[1:]
    sums = sum_by_group(image_arr.ravel(), whichbin)

    length = min(sums.size, nr.size)
    profile = np.full(length, np.nan, dtype=np.float64)
    nonzero = nr[:length] > 0
    profile[nonzero] = sums[:length][nonzero] / nr[:length][nonzero]
    return profile


__all__ = ["sum_by_group", "sphericalAverage"]
