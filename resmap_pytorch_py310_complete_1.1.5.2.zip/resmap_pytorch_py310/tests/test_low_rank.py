import numpy as np

from ResMap_torch import (
    build_dense_reference_matrices,
    build_low_rank_model,
    compute_background_variance,
    compute_lrs_valid_volume,
    extract_lrs_for_mask,
    extract_lrs_for_mask_flat,
    legacy_mask_window_indices,
)


def test_low_rank_matrices_match_legacy_dense_quadratic_forms():
    model = build_low_rank_model(current_resolution=4.4, voxel_size=2.0)
    lambda_diff, lambda_detail = build_dense_reference_matrices(model)

    lrs_rows = model.lrs_filters.reshape(model.lrs_rank, -1).astype(np.float64)
    detail_rows = model.background_filters.reshape(model.detail_rank, -1).astype(
        np.float64
    )
    lambda_diff_low_rank = lrs_rows.T @ lrs_rows
    lambda_detail_low_rank = np.diag(model.kernel.reshape(-1)) - detail_rows.T @ detail_rows

    np.testing.assert_allclose(lambda_diff_low_rank, lambda_diff, rtol=2e-6, atol=3e-8)
    np.testing.assert_allclose(lambda_detail_low_rank, lambda_detail, rtol=2e-6, atol=1e-8)
    assert model.lrs_rank <= 16
    assert model.detail_rank <= 16


def test_kernel_mode_defaults_to_actual_upstream_python2_division():
    legacy = build_low_rank_model(current_resolution=4.4, voxel_size=2.0)
    intended = build_low_rank_model(
        current_resolution=4.4,
        voxel_size=2.0,
        kernel_mode="intended-half",
    )

    assert legacy.kernel_mode == "legacy-python2"
    assert legacy.gaussian_exponent_coefficient == 1.0
    assert intended.kernel_mode == "intended-half"
    assert intended.gaussian_exponent_coefficient == 0.5
    # For the same coordinates, exp(-r^2) == exp(-0.5*r^2)^2.
    np.testing.assert_allclose(
        legacy.kernel, intended.kernel * intended.kernel, rtol=2e-6, atol=1e-7
    )

def test_conv3d_lrs_matches_dense_patch_reference_on_cpu():
    model = build_low_rank_model(current_resolution=4.4, voxel_size=2.0)
    lambda_diff, _ = build_dense_reference_matrices(model)
    rng = np.random.default_rng(10)
    data = rng.normal(size=(17, 17, 17)).astype(np.float32)
    valid = compute_lrs_valid_volume(
        data,
        model,
        device="cpu",
        z_chunk=4,
        channels_per_batch=3,
    )

    for start in ((0, 0, 0), (2, 3, 4), (12, 12, 12)):
        z, y, x = start
        patch = data[
            z : z + model.win_size,
            y : y + model.win_size,
            x : x + model.win_size,
        ].reshape(-1).astype(np.float64)
        reference = float(patch @ lambda_diff @ patch)
        np.testing.assert_allclose(valid[start], reference, rtol=2e-5, atol=2e-6)


def test_pytorch_background_variance_matches_dense_reference():
    model = build_low_rank_model(current_resolution=4.4, voxel_size=2.0)
    _, lambda_detail = build_dense_reference_matrices(model)
    rng = np.random.default_rng(11)
    data = rng.normal(size=(17, 17, 17)).astype(np.float32)
    mask = np.ones_like(data, dtype=bool)

    result = compute_background_variance(data, mask, model, device="cpu")
    values = []
    w = model.win_size
    for z in range(0, data.shape[0] - w + 1, w):
        for y in range(0, data.shape[1] - w + 1, w):
            for x in range(0, data.shape[2] - w + 1, w):
                patch = data[z : z + w, y : y + w, x : x + w].reshape(-1).astype(
                    np.float64
                )
                patch -= patch.mean()
                values.append(float(patch @ lambda_detail @ patch / np.trace(lambda_detail)))

    np.testing.assert_allclose(result.variance, np.mean(values), rtol=3e-6, atol=2e-7)
    assert result.number_of_blocks == len(values)


def test_legacy_negative_window_indices_wrap_from_end():
    mask = np.zeros((25, 25, 25), dtype=bool)
    mask[9, 9, 9] = True
    centers, wrapped = legacy_mask_window_indices(mask, radius=10, valid_shape=(5, 5, 5))
    np.testing.assert_array_equal(centers[:, 0], [9, 9, 9])
    np.testing.assert_array_equal(wrapped[:, 0], [4, 4, 4])

def test_flat_lrs_gather_matches_reference_including_legacy_wrap():
    valid = np.arange(5 ** 3, dtype=np.float32).reshape(5, 5, 5)
    mask = np.zeros((25, 25, 25), dtype=bool)
    mask[9, 9, 9] = True   # start=-1 -> wraps to valid index 4
    mask[10, 10, 10] = True  # start=0
    mask[12, 11, 13] = True

    centers, values_reference = extract_lrs_for_mask(
        valid, mask, radius=10, variance=2.0
    )
    center_flat, values_flat = extract_lrs_for_mask_flat(
        valid, mask, radius=10, variance=2.0, index_chunk=2
    )

    expected_flat = np.ravel_multi_index(tuple(centers), mask.shape)
    np.testing.assert_array_equal(center_flat, expected_flat)
    np.testing.assert_allclose(values_flat, values_reference, rtol=0.0, atol=0.0)

