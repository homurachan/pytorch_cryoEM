import numpy as np

from ResMap_spectrumTools import (
    calculatePowerSpectrum,
    preWhitenVolumeSoftBG,
)


def test_numpy_fft_power_spectrum_and_prewhitening_are_finite():
    rng = np.random.default_rng(30)
    data = rng.normal(size=(25, 25, 25)).astype(np.float32)
    soft_mask = np.ones_like(data, dtype=np.float32)
    data_fourier, spectrum = calculatePowerSpectrum(data)
    result = preWhitenVolumeSoftBG(
        n=25,
        elbowAngstrom=10.0,
        dataBGSpect=spectrum,
        dataF=data_fourier,
        softBGmask=soft_mask,
        vxSize=2.0,
        rampWeight=1.0,
    )
    assert spectrum.ndim == 1
    assert np.all(np.isfinite(spectrum))
    assert result["dataPW"].shape == data.shape
    assert np.all(np.isfinite(result["dataPW"]))
