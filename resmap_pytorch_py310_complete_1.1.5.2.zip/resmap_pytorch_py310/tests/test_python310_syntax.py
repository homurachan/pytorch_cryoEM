import ast
from pathlib import Path


def test_runtime_sources_parse_with_python310_grammar():
    root = Path(__file__).resolve().parents[1]
    for path in sorted(root.glob("ResMap*.py")):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path), feature_version=(3, 10))
