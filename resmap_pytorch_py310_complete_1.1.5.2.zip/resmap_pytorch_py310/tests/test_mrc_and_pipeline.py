from pathlib import Path

import mrcfile
import numpy as np

from ResMap_algorithm import ResMap_algorithm
from ResMap_fileIO import MRC_Data, write_mrc2000_grid_data


def _write(path: Path, data: np.ndarray, voxel_size: float = 2.0) -> None:
    with mrcfile.new(path, overwrite=True) as handle:
        handle.set_data(np.asarray(data, dtype=np.float32))
        handle.voxel_size = voxel_size
        handle.header.origin.x = 1.25
        handle.header.origin.y = -2.5
        handle.header.origin.z = 3.75
        handle.header.nxstart = 4
        handle.header.nystart = 5
        handle.header.nzstart = 6


def test_mrc_roundtrip_preserves_spatial_header(tmp_path: Path):
    input_path = tmp_path / "input.mrc"
    output_path = tmp_path / "output.mrc"
    data = np.arange(11 ** 3, dtype=np.float32).reshape(11, 11, 11)
    _write(input_path, data, voxel_size=1.37)

    volume = MRC_Data(str(input_path))
    volume.matrix = np.full_like(volume.matrix, 7.0, dtype=np.float32)
    write_mrc2000_grid_data(volume, str(output_path))

    with mrcfile.open(output_path, permissive=True) as handle:
        np.testing.assert_allclose(handle.data, 7.0)
        np.testing.assert_allclose(
            [handle.voxel_size.x, handle.voxel_size.y, handle.voxel_size.z],
            [1.37, 1.37, 1.37],
            rtol=1e-6,
        )
        np.testing.assert_allclose(
            [handle.header.origin.x, handle.header.origin.y, handle.header.origin.z],
            [1.25, -2.5, 3.75],
        )
        assert int(handle.header.nxstart) == 4
        assert int(handle.header.nystart) == 5
        assert int(handle.header.nzstart) == 6


def test_single_volume_pipeline_writes_result(tmp_path: Path):
    n = 33
    rng = np.random.default_rng(20)
    z, y, x = np.mgrid[:n, :n, :n]
    center = (n - 1) / 2.0
    radius = np.sqrt((x - center) ** 2 + (y - center) ** 2 + (z - center) ** 2)
    data = rng.normal(0.0, 0.25, size=(n, n, n)) + 2.0 * np.exp(-(radius / 5.0) ** 2)
    mask = (radius < 8.0).astype(np.float32)

    input_path = tmp_path / "synthetic.mrc"
    mask_path = tmp_path / "mask.mrc"
    _write(input_path, data)
    _write(mask_path, mask)
    input_mrc = MRC_Data(str(input_path))
    mask_mrc = MRC_Data(str(mask_path))

    result = ResMap_algorithm(
        inputFileName=str(input_path),
        data=input_mrc,
        vxSize=2.0,
        pValue=0.05,
        minRes=4.4,
        maxRes=4.4,
        stepRes=1.0,
        dataMask=mask_mrc,
        prewhiten="off",
        device="cpu",
        zChunk=4,
        convChannels=4,
        skipLPFTest=True,
        graphicalOutput=False,
        chimeraLaunch=False,
        createChimera=False,
        writeOutput=True,
    )

    output_path = Path(result["output_path"])
    assert output_path.exists()
    assert result["resolution_map"].shape == (n, n, n)
    assert len(result["iterations"]) == 1
    with mrcfile.open(output_path, permissive=True) as handle:
        assert handle.data.shape == (n, n, n)
        np.testing.assert_allclose(float(handle.voxel_size.x), 2.0)
        np.testing.assert_allclose(float(handle.header.origin.x), 1.25)


def test_split_volume_pipeline_uses_difference_map_noise(tmp_path: Path):
    n = 41
    rng = np.random.default_rng(21)
    z, y, x = np.mgrid[:n, :n, :n]
    center = (n - 1) / 2.0
    radius = np.sqrt((x - center) ** 2 + (y - center) ** 2 + (z - center) ** 2)
    signal = 1.5 * np.exp(-(radius / 6.0) ** 2)
    half1 = signal + rng.normal(0.0, 0.3, size=(n, n, n))
    half2 = signal + rng.normal(0.0, 0.3, size=(n, n, n))
    mask = (radius < 13.0).astype(np.float32)

    half1_path = tmp_path / "half1.mrc"
    half2_path = tmp_path / "half2.mrc"
    mask_path = tmp_path / "mask.mrc"
    _write(half1_path, half1)
    _write(half2_path, half2)
    _write(mask_path, mask)

    result = ResMap_algorithm(
        inputFileName1=str(half1_path),
        inputFileName2=str(half2_path),
        data1=MRC_Data(str(half1_path)),
        data2=MRC_Data(str(half2_path)),
        vxSize=2.0,
        pValue=0.05,
        minRes=4.4,
        maxRes=4.4,
        stepRes=1.0,
        dataMask=MRC_Data(str(mask_path)),
        prewhiten="off",
        device="cpu",
        zChunk=8,
        convChannels=4,
        skipLPFTest=True,
        graphicalOutput=False,
        chimeraLaunch=False,
        createChimera=False,
        writeOutput=False,
    )
    iteration = result["iterations"][0]
    assert iteration["background_blocks"] > 0
    assert iteration["variance"] > 0.0
