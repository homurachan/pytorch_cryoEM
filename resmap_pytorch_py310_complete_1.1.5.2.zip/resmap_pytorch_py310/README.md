# ResMap Python 3.10 + PyTorch/CUDA port

This is a complete, directly runnable Python 3 rewrite of the public ResMap
1.1.5 workflow for cubic cryo-EM maps. It keeps the legacy CPU preprocessing,
pre-whitening, statistical distribution, FDR loop, plots, and UCSF Chimera
output, while replacing the dominant dense local quadratic forms with exact
low-rank `torch.nn.functional.conv3d` operations.

## What runs where

| Stage | Implementation |
|---|---|
| MRC/CCP4 data and header | `mrcfile` + NumPy |
| Mask, morphology, distance transforms | SciPy |
| Gaussian filtering | SciPy |
| Pre-whitening FFT | NumPy FFT |
| Basis construction and SVD/rank | NumPy float64 |
| LRS evaluation | PyTorch `conv3d`, CUDA or CPU |
| Background variance | PyTorch pooling + `conv3d` |
| Small eigenproblem, Ruben distribution, sorting, BY-FDR | NumPy/SciPy CPU |
| GUI, plots, Chimera command file | Tkinter/Matplotlib, legacy behavior |

The dense `m x m` matrices are never formed in normal execution. The full
weighted model has only 17 columns. After removing the constant direction, the
LRS quadratic form has rank at most 16 and is evaluated as the sum of squares
of at most 16 convolution responses.

## Preserved legacy assumptions

* Input maps must be cubic. Non-cubic tomography volumes are intentionally not
  supported.
* The particle mask retains the fixed 9-voxel edge backoff.
* When a later window radius is larger than nine, NumPy-style negative rolling
  window indices still wrap from the end; positive out-of-range indices still
  raise an error, matching the practical legacy behavior.
* Low-pass-filtered maps still use SciPy cubic-spline `ndimage.zoom`, and the
  final result uses first-order `map_coordinates` exactly as in the old flow.
* The Ruben/Farebrother distribution and Benjamini-Yekutieli iteration order
  are retained.
* The default Gaussian kernel reproduces the actual Python 2.7 evaluation of
  the upstream expression `exp(-1/2 * r^2)`. Because the upstream module does
  not enable true division, `-1/2` evaluates to `-1`; therefore the compatibility
  default is `exp(-r^2)`. The optional `--kernelMode intended-half` selects the
  conventional mathematical form `exp(-0.5*r^2)`.

## Installation with Python 3.10

Create an environment and install a CUDA-enabled PyTorch build appropriate for
the machine first. Then install the remaining dependencies and this source:

```bash
python3.10 -m venv resmap310
source resmap310/bin/activate
python -m pip install --upgrade pip
# Install the desired CUDA-enabled PyTorch build first.
python -m pip install numpy scipy matplotlib mrcfile pytest
python -m pip install -e . --no-deps
```

Tkinter is part of many Python distributions. On Linux it may require a system
package such as `python3-tk`. Command-line use does not require opening the GUI.

## Command-line examples

Single map, using the MRC header voxel size and the first available CUDA GPU:

```bash
python ResMap.py --noguiSingle map.mrc --device cuda:0
```

Split-half mode with an explicit mask:

```bash
python ResMap.py --noguiSplit half1.mrc half2.mrc \
    --maskVol mask.mrc --device cuda:0
```

Explicit parameters:

```bash
python ResMap.py --noguiSingle map.mrc \
    --vxSize 1.2 --pVal 0.05 --minRes 2.7 --maxRes 8.0 --stepRes 0.5 \
    --device cuda:0 --zChunk 32 --convChannels 4 --prewhiten auto \
    --kernelMode legacy-python2
```

Run `python ResMap.py --help` for all options.

### Pre-whitening modes

* `--prewhiten auto`: perform one pass with the legacy initial elbow and ramp;
  this is the command-line default and is suitable for headless GPU nodes.
* `--prewhiten interactive`: retain the Matplotlib slider interface.
* `--prewhiten off`: skip pre-whitening, mainly for already whitened inputs,
  diagnostics, and equivalence tests.

The GUI uses interactive pre-whitening by default, as legacy ResMap did.

### Gaussian-kernel compatibility

The command-line and GUI default to `legacy-python2`. This mode reproduces the
actual Python 2.7 arithmetic of the public upstream source. Use
`--kernelMode intended-half` only when deliberately testing the likely intended
Gaussian coefficient. The two modes are not expected to produce identical
thresholds or local-resolution maps, so record the selected mode in methods and
regression tests.

### Memory controls

`--zChunk` controls how many valid output Z planes are evaluated per LRS slab.
The default is 32. If CUDA reports out-of-memory, the implementation
automatically halves the current slab down to one plane. `--convChannels`
controls how many low-rank filters are evaluated together; lowering it from 4
to 2 or 1 reduces CUDA peak memory.

TF32 is disabled by default to make comparison with the CPU reference easier.
Use `--allowTF32` only after numerical validation on the target GPU.

## Tests

```bash
pytest -q
```

The tests verify:

* the low-rank matrices against the legacy dense quadratic forms;
* `conv3d` LRS values against dense per-patch evaluation;
* PyTorch background variance against the dense reference;
* fixed-9 edge/negative-index behavior;
* MRC voxel size, origin, and start-index preservation;
* single-volume and split-half end-to-end paths;
* NumPy FFT pre-whitening;
* both Gaussian-kernel conventions and the Python 2-compatible default.

See `VALIDATION.md` for the validation status and limitations of this build.

## Upstream attribution and redistribution

This port follows the ResMap method and public ResMap 1.1.5 behavior. Please
read `UPSTREAM_NOTICE.md` before redistributing it. The upstream source states a
CC BY-NC-ND 3.0 license; this archive is intended for private research and
validation unless separate permission is obtained from the original authors.
