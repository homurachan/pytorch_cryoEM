# Validation status

## Completed in the build environment

The available environment used Python 3.13, NumPy 2.3.5, SciPy 1.17.0,
Matplotlib 3.10.8, mrcfile 1.5.4, and PyTorch 2.10.0 CPU.

Eleven automated tests pass:

```text
11 passed
```

The tests include both single-map and split-half end-to-end runs, and verify
that the default kernel reproduces the public Python 2 source's integer-division
behavior while the optional intended-half mode remains available.

The built wheel was also installed into an isolated target directory. Its
console entry point, module imports, help/version handling, and a complete
single-map CLI run from the installed wheel all passed.

All Python source and test files parse with the Python 3.10 grammar. The build
environment itself did not contain a Python 3.10 interpreter, so the runtime
test suite was executed under Python 3.13 with dependencies whose declared
minimum versions support Python 3.10.

## Numerical equivalence checks

For representative models:

Using the default `legacy-python2` Gaussian kernel:

* 5 x 5 x 5 window: the largest elementwise discrepancy between the low-rank
  LRS matrix and the dense reference was approximately `7.4e-9`; the background
  matrix discrepancy was approximately `1.6e-8`.
* 11 x 11 x 11 window: the corresponding discrepancies were approximately
  `1.9e-9` and `1.6e-9`.
* Random-patch `torch.conv3d` LRS values matched direct dense evaluation to the
  expected float32 accumulation precision.
* PyTorch non-overlapping background variance matched direct dense block
  evaluation to about `3e-8` absolute error in the test case.

These are algebraic equivalence tests, not comparisons against a particular
experimental ResMap output map. A real-data regression comparison against
ResMap 1.1.5 is still recommended before publication use.

## CUDA limitation of this build session

No CUDA device was available in the build environment. Therefore:

* the exact code path used on CUDA was exercised through PyTorch CPU `conv3d`;
* device parsing, CUDA guards, TF32 controls, deterministic controls, slab
  retry logic, and compilation were checked;
* actual NVIDIA GPU execution, speed, peak VRAM, and cuDNN-specific numerical
  variation were not measured here.

On the target GPU, first compare a small or cropped map using default TF32-off
settings. Then compare per-iteration variance, thresholds, assigned voxel
counts, and the final local-resolution map before enabling TF32.
