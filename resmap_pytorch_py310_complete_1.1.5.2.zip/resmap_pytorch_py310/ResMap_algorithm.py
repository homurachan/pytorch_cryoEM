"""Python 3.10 / PyTorch implementation of the ResMap local-resolution flow.

CPU responsibilities deliberately remain with NumPy/SciPy. The two dominant
local quadratic-form evaluations are exact low-rank PyTorch ``conv3d``
computations, suitable for CUDA GPUs.
"""

from __future__ import annotations

import os
import sys
from collections import OrderedDict
from pathlib import Path
from time import time
from typing import Dict, Optional, Tuple

import numpy as np
from scipy import ndimage, signal
from scipy.optimize import minimize_scalar

from ResMap_fileIO import MRC_Data, write_mrc2000_grid_data
from ResMap_helpers import (
    array_outer_product,
    createRmatrix,
    evaluateRuben,
    rubenPython,
    update_progress,
)
from ResMap_spectrumTools import (
    calculatePowerSpectrum,
    createPreWhiteningFilterFinal,
    displayPreWhitening,
    isPowerSpectrumLPF,
    preWhitenCube,
    preWhitenVolumeSoftBG,
)
from ResMap_toChimera import createChimeraScript, try_alternatives
from ResMap_torch import (
    build_low_rank_model,
    compute_background_variance,
    compute_lrs_valid_volume,
    extract_lrs_for_mask_flat,
    resolve_torch_device,
)


def _elapsed(start: float) -> str:
    minutes, seconds = divmod(time() - start, 60)
    return "%d minutes and %.2f seconds" % (minutes, seconds)


def _legacy_hamming_3d(size: int) -> np.ndarray:
    """Construct the same Hamming array expression used by ResMap 1.1.5."""
    hamming_1d = signal.windows.hamming(int(size))
    hamming_2d = array_outer_product(hamming_1d, hamming_1d)
    return array_outer_product(hamming_2d, hamming_2d)


def _validate_cube(data: np.ndarray, label: str) -> None:
    if data.ndim != 3:
        raise ValueError("%s must be a 3-D array" % label)
    if not (data.shape[0] == data.shape[1] == data.shape[2]):
        raise ValueError(
            "%s must be cubic; non-cubic/tomographic volumes are intentionally "
            "outside this port's scope (shape=%r)" % (label, data.shape)
        )


def _load_inputs(kwargs: Dict[str, object]) -> Tuple[
    bool, str, Optional[str], MRC_Data, Optional[MRC_Data], np.ndarray, Optional[np.ndarray]
]:
    input_name = kwargs.get("inputFileName")
    input_name_1 = kwargs.get("inputFileName1")
    input_name_2 = kwargs.get("inputFileName2")
    data_mrc = kwargs.get("data")
    data_mrc_1 = kwargs.get("data1")
    data_mrc_2 = kwargs.get("data2")

    if input_name:
        path = os.path.abspath(os.path.expanduser(str(input_name)))
        if not isinstance(data_mrc, MRC_Data):
            data_mrc = MRC_Data(path, "ccp4")
        data = np.asarray(data_mrc.matrix, dtype=np.float32).copy()
        data -= np.mean(data, dtype=np.float64)
        _validate_cube(data, "input volume")
        return False, path, None, data_mrc, None, data, None

    if input_name_1 and input_name_2:
        path_1 = os.path.abspath(os.path.expanduser(str(input_name_1)))
        path_2 = os.path.abspath(os.path.expanduser(str(input_name_2)))
        if not isinstance(data_mrc_1, MRC_Data):
            data_mrc_1 = MRC_Data(path_1, "ccp4")
        if not isinstance(data_mrc_2, MRC_Data):
            data_mrc_2 = MRC_Data(path_2, "ccp4")
        first = np.asarray(data_mrc_1.matrix, dtype=np.float32)
        second = np.asarray(data_mrc_2.matrix, dtype=np.float32)
        if first.shape != second.shape:
            raise ValueError("split volumes must have identical shapes")
        _validate_cube(first, "split volume 1")
        _validate_cube(second, "split volume 2")
        data = np.asarray(0.5 * (first + second), dtype=np.float32)
        data_difference = np.asarray(0.5 * (first - second), dtype=np.float32)
        return True, path_1, path_2, data_mrc_1, data_mrc_2, data, data_difference

    raise ValueError("provide either inputFileName or both inputFileName1/inputFileName2")


def _test_and_downsample_lpf(
    data: np.ndarray,
    data_difference: Optional[np.ndarray],
    voxel_size: float,
    skip_lpf_test: bool,
) -> Tuple[np.ndarray, Optional[np.ndarray], float, float, np.ndarray, np.ndarray]:
    """Run the original low-pass test and original cubic-spline downsampling."""
    n = int(data.shape[0])
    subvolume_size = 160
    if skip_lpf_test:
        data_fourier, power_spectrum = calculatePowerSpectrum(data)
        lpf_test = {"outcome": False, "factor": 0.0}
    elif n > subvolume_size:
        middle = n // 2
        half = subvolume_size // 2
        middle_cube = data[
            middle - half : middle + half,
            middle - half : middle + half,
            middle - half : middle + half,
        ]
        middle_cube = middle_cube * _legacy_hamming_3d(subvolume_size)
        data_fourier, power_spectrum = calculatePowerSpectrum(middle_cube)
        lpf_test = isPowerSpectrumLPF(power_spectrum)
    else:
        data_fourier, power_spectrum = calculatePowerSpectrum(data)
        lpf_test = isPowerSpectrumLPF(power_spectrum)

    lpf_factor = 0.0
    if bool(lpf_test["outcome"]):
        lpf_factor = round(float(lpf_test["factor"]) / 0.01) * 0.01
        if not 0.0 < lpf_factor < 1.0:
            print(
                "WARNING: the LPF detector returned an unusable factor %.4f; "
                "continuing without downsampling." % lpf_factor
            )
            lpf_factor = 0.0
        else:
            print("The volume appears low-pass filtered; downsampling by %.2f." % lpf_factor)
            # scipy.ndimage.zoom defaults to order=3, matching the original cubic spline.
            data = ndimage.zoom(data, lpf_factor, mode="reflect")
            if data_difference is not None:
                data_difference = ndimage.zoom(
                    data_difference, lpf_factor, mode="reflect"
                )
            voxel_size = float(voxel_size) / lpf_factor
    else:
        print("The volume does not appear to be low-pass filtered.")

    return (
        np.asarray(data, dtype=np.float32),
        None
        if data_difference is None
        else np.asarray(data_difference, dtype=np.float32),
        float(voxel_size),
        float(lpf_factor),
        data_fourier,
        power_spectrum,
    )


def _prepare_mask(
    data: np.ndarray,
    data_mask_input: object,
    lpf_factor: float,
    split_volume: bool,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n = int(data.shape[0])
    radius = createRmatrix(n)
    inside_sphere = radius < n / 2.0 - 1.0

    if isinstance(data_mask_input, MRC_Data):
        mask_source = np.asarray(data_mask_input.matrix)
    elif isinstance(data_mask_input, np.ndarray):
        mask_source = np.asarray(data_mask_input)
    else:
        mask_source = None

    if mask_source is None:
        blurred = ndimage.gaussian_filter(data, float(n) * 0.02)
        maximum = float(np.max(blurred))
        data_mask = blurred > maximum * 5e-2
    else:
        _validate_cube(mask_source, "mask volume")
        if lpf_factor == 0.0:
            data_mask = np.asarray(mask_source, dtype=bool)
        else:
            interpolated = ndimage.zoom(mask_source, lpf_factor, mode="reflect")
            interpolated = ndimage.gaussian_filter(interpolated, float(n) * 0.02)
            data_mask = interpolated > float(np.max(interpolated)) * 5e-2
        if data_mask.shape != data.shape:
            raise ValueError(
                "mask shape %r does not match processed volume shape %r"
                % (data_mask.shape, data.shape)
            )

    if split_volume:
        edge_box = np.zeros((n, n, n), dtype=bool)
        edge_box[9:-9, 9:-9, 9:-9] = True
        mask = np.bitwise_and(data_mask, edge_box)
    else:
        # Deliberately retain the fixed 9-voxel backoff requested by the user.
        mask = np.bitwise_and(data_mask, radius < n / 2.0 - 9.0)

    if not np.any(mask):
        raise RuntimeError("particle mask is empty after the legacy edge backoff")
    return (
        np.asarray(mask, dtype=bool),
        np.asarray(data_mask, dtype=bool),
        np.asarray(inside_sphere, dtype=bool),
        radius,
    )


def _interactive_or_single_pass(
    mode: str,
    result: Dict[str, np.ndarray],
    data_spectrum: np.ndarray,
    background_spectrum: np.ndarray,
    voxel_size: float,
    input_slice: np.ndarray,
    output_slice: np.ndarray,
    elbow: float,
    ramp: float,
) -> Tuple[float, float, bool]:
    if mode != "interactive":
        return elbow, ramp, False
    new_elbow, new_ramp = displayPreWhitening(
        elbowAngstrom=elbow,
        rampWeight=ramp,
        dataSpect=data_spectrum,
        dataBGSpect=background_spectrum,
        peval=result["peval"],
        dataPWSpect=result["dataPWSpect"],
        dataPWBGSpect=result["dataPWBGSpect"],
        vxSize=voxel_size,
        dataSlice=input_slice,
        dataPWSlice=output_slice,
    )
    changed = (new_elbow != elbow) or (new_ramp != ramp)
    return float(new_elbow), float(new_ramp), bool(changed)


def _show_prewhitening_slices(data: np.ndarray, data_pw: np.ndarray) -> None:
    import matplotlib.pyplot as plt

    n = int(data.shape[0])
    figure, axes = plt.subplots(2, 4, figsize=(18, 9))
    figure.suptitle(
        "Pre-Whitening Results", fontsize=14, color="#104E8B", fontweight="bold"
    )
    positions = [3 * n // 9, 4 * n // 9, 5 * n // 9, 6 * n // 9]
    input_min, input_max = float(np.min(data)), float(np.max(data))
    output_min, output_max = float(np.min(data_pw)), float(np.max(data_pw))
    for column, position in enumerate(positions):
        axes[0, column].imshow(
            data[position],
            vmin=input_min,
            vmax=input_max,
            cmap=plt.cm.gray,
            interpolation="nearest",
        )
        axes[1, column].imshow(
            data_pw[position],
            vmin=output_min,
            vmax=output_max,
            cmap=plt.cm.gray,
            interpolation="nearest",
        )
        axes[0, column].set_title("Slice %d" % position)
        axes[1, column].set_title("Slice %d" % position)
    axes[0, 0].set_ylabel("Input Volume")
    axes[1, 0].set_ylabel("Pre-whitened Volume")
    plt.show()


def _prewhiten(
    data: np.ndarray,
    data_difference: Optional[np.ndarray],
    data_mask: np.ndarray,
    inside_sphere: np.ndarray,
    voxel_size: float,
    split_volume: bool,
    mode: str,
    graphical_output: bool,
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
    mode = str(mode).lower()
    if mode not in {"interactive", "auto", "off"}:
        raise ValueError("prewhiten must be 'interactive', 'auto', or 'off'")
    if mode == "off":
        print("Pre-whitening disabled by request.")
        return data, data_difference

    n = int(data.shape[0])
    elbow = max(10.0, 2.1 * voxel_size)
    ramp = 1.0

    if n > 160:
        print("Computing largest particle/background cubes for pre-whitening.")
        particle_distance = ndimage.distance_transform_cdt(
            data_mask, metric="taxicab"
        )
        if split_volume:
            width_box = int(np.max(particle_distance))
            outside_distance = None
        else:
            outside = np.logical_and(np.logical_not(data_mask), inside_sphere)
            outside_distance = ndimage.distance_transform_cdt(
                outside, metric="taxicab"
            )
            width_box = int(
                min(np.max(particle_distance), np.max(outside_distance))
            )
        half_width = int(np.floor(width_box / 2.0))
        cube_size = 2 * half_width
        if cube_size < 4:
            raise RuntimeError(
                "pre-whitening could not find a sufficiently large all-particle "
                "and all-background cube"
            )

        inside_center = np.asarray(
            np.unravel_index(np.argmax(particle_distance), (n, n, n)), dtype=int
        )
        # Preserve the conservative legacy edge clamp.
        inside_center = np.maximum(inside_center, cube_size)
        inside_center = np.minimum(inside_center, n - cube_size)
        slices_inside = tuple(
            slice(int(center - half_width), int(center + half_width))
            for center in inside_center
        )
        cube_inside = np.asarray(data[slices_inside], dtype=np.float32)
        if cube_inside.shape != (cube_size, cube_size, cube_size):
            raise RuntimeError("legacy pre-whitening particle cube extraction failed")

        if split_volume:
            if data_difference is None:
                raise RuntimeError("split-volume difference map is missing")
            cube_outside = np.asarray(data_difference[slices_inside], dtype=np.float32)
        else:
            assert outside_distance is not None
            outside_center = np.asarray(
                np.unravel_index(np.argmax(outside_distance), (n, n, n)), dtype=int
            )
            slices_outside = tuple(
                slice(int(center - half_width), int(center + half_width))
                for center in outside_center
            )
            cube_outside = np.asarray(data[slices_outside], dtype=np.float32)
        if cube_outside.shape != (cube_size, cube_size, cube_size):
            raise RuntimeError("legacy pre-whitening background cube extraction failed")

        hamming = _legacy_hamming_3d(cube_size)
        cube_inside_windowed = cube_inside * hamming
        cube_outside_windowed = cube_outside * hamming
        data_fourier, data_spectrum = calculatePowerSpectrum(cube_inside_windowed)
        background_fourier, background_spectrum = calculatePowerSpectrum(
            cube_outside_windowed
        )
        del particle_distance, outside_distance

        while True:
            result = preWhitenCube(
                n=cube_size,
                vxSize=voxel_size,
                elbowAngstrom=elbow,
                rampWeight=ramp,
                dataF=data_fourier,
                dataBGF=background_fourier,
                dataBGSpect=background_spectrum,
            )
            new_elbow, new_ramp, changed = _interactive_or_single_pass(
                mode,
                result,
                data_spectrum,
                background_spectrum,
                voxel_size,
                cube_inside_windowed[cube_size // 2],
                result["dataPW"][cube_size // 2],
                elbow,
                ramp,
            )
            elbow, ramp = new_elbow, new_ramp
            if not changed:
                break

        print("Pre-whitening full volume with NumPy FFT.")
        full_fourier, full_spectrum = calculatePowerSpectrum(data)
        final_filter = createPreWhiteningFilterFinal(
            n=n,
            cubeSize=cube_size,
            spectrum=full_spectrum,
            pcoef=result["pcoef"],
            elbowAngstrom=elbow,
            rampWeight=ramp,
            vxSize=voxel_size,
        )["pWfilter"]
        data_pw = np.real(
            np.fft.ifftn(np.fft.ifftshift(final_filter * full_fourier))
        ).astype(np.float32)
        difference_pw: Optional[np.ndarray] = None
        if split_volume:
            assert data_difference is not None
            difference_fourier, _ = calculatePowerSpectrum(data_difference)
            difference_pw = np.real(
                np.fft.ifftn(np.fft.ifftshift(final_filter * difference_fourier))
            ).astype(np.float32)
        if mode == "interactive" or graphical_output:
            _show_prewhitening_slices(data, data_pw)
        return data_pw, difference_pw

    # Small-volume path: soft background in single-volume mode, difference map
    # in split-volume mode. FFTs remain NumPy as requested.
    if split_volume:
        if data_difference is None:
            raise RuntimeError("split-volume difference map is missing")
        background_data = data_difference
        soft_background_mask = None
    else:
        box_element = np.ones((5, 5, 5), dtype=bool)
        dilated_mask = ndimage.binary_dilation(
            data_mask, structure=box_element, iterations=3
        )
        dilated_mask = np.logical_and(dilated_mask, inside_sphere)
        soft_background_mask = ndimage.gaussian_filter(
            np.asarray(np.logical_not(dilated_mask), dtype=np.float32),
            float(n) * 0.02,
        )
        background_data = data * soft_background_mask

    data_fourier, data_spectrum = calculatePowerSpectrum(data)
    background_fourier, background_spectrum = calculatePowerSpectrum(background_data)
    while True:
        if split_volume:
            result = preWhitenCube(
                n=n,
                vxSize=voxel_size,
                elbowAngstrom=elbow,
                rampWeight=ramp,
                dataF=data_fourier,
                dataBGF=background_fourier,
                dataBGSpect=background_spectrum,
            )
        else:
            assert soft_background_mask is not None
            result = preWhitenVolumeSoftBG(
                n=n,
                elbowAngstrom=elbow,
                dataBGSpect=background_spectrum,
                dataF=data_fourier,
                softBGmask=soft_background_mask,
                vxSize=voxel_size,
                rampWeight=ramp,
            )
        new_elbow, new_ramp, changed = _interactive_or_single_pass(
            mode,
            result,
            data_spectrum,
            background_spectrum,
            voxel_size,
            data[n // 2],
            result["dataPW"][n // 2],
            elbow,
            ramp,
        )
        elbow, ramp = new_elbow, new_ramp
        if not changed:
            break

    data_pw = np.asarray(result["dataPW"], dtype=np.float32)
    if split_volume:
        difference_pw = np.asarray(result["dataBGPW"], dtype=np.float32)
    else:
        difference_pw = data_difference
    return data_pw, difference_pw


def _uncorrected_and_fdr_thresholds(
    lrs_values: np.ndarray,
    eigenvalues: np.ndarray,
    mask_count: int,
    p_value: float,
) -> Tuple[float, float, int]:
    if eigenvalues.size == 0:
        raise RuntimeError("no non-zero LRS eigenvalues survived truncation")
    alpha = 1.0 - float(p_value)
    minimization = minimize_scalar(evaluateRuben, args=(alpha, eigenvalues))
    threshold_uncorrected = float(minimization.x)

    sorted_values = np.sort(np.asarray(lrs_values, dtype=np.float32))
    kmax = int(np.sum(sorted_values > threshold_uncorrected))
    if kmax == 0:
        return threshold_uncorrected, sys.float_info.max, 0

    kpoint = int(sorted_values.size - kmax)
    mask_sum = float(np.float32(mask_count))
    mask_sum_integer = int(mask_sum)
    if mask_sum_integer <= 1:
        harmonic_constant = 1.0
    else:
        # Deliberately preserve ResMap's range(1, maskSum), i.e. H_(m-1).
        harmonic_constant = float(
            np.sum(1.0 / np.arange(1, mask_sum_integer, dtype=np.float64))
        )
    if harmonic_constant <= 0.0:
        harmonic_constant = 1.0

    if kmax == 1:
        threshold_fdr = float(sorted_values[kpoint])
        return threshold_uncorrected, threshold_fdr, kmax

    step = max(1, int(np.ceil(kmax / min(5e2, float(kmax)))))
    threshold_fdr = float(sorted_values[kpoint])
    for k in range(1, kmax, step):
        result = rubenPython(eigenvalues, float(sorted_values[kpoint + k]))
        target = 1.0 - (
            float(p_value)
            * ((kmax - k) / (mask_sum * harmonic_constant))
        )
        threshold_fdr = float(sorted_values[kpoint + k])
        if result[2] > target:
            break
    return threshold_uncorrected, threshold_fdr, kmax


def _show_results(
    data_original: np.ndarray,
    resolution_map: np.ndarray,
    current_resolution: float,
    min_resolution: float,
    max_resolution: float,
    histogram: OrderedDict,
) -> None:
    import matplotlib.pyplot as plt

    n = int(data_original.shape[0])
    positions = [3 * n // 9, 4 * n // 9, 5 * n // 9, 6 * n // 9]
    figure, axes = plt.subplots(2, 2)
    figure.suptitle(
        "Slices Through Input Volume",
        fontsize=14,
        color="#104E8B",
        fontweight="bold",
    )
    data_min, data_max = float(np.min(data_original)), float(np.max(data_original))
    for axis, position in zip(axes.ravel(), positions):
        axis.imshow(
            data_original[position],
            vmin=data_min,
            vmax=data_max,
            cmap=plt.cm.gray,
            interpolation="nearest",
        )
        axis.set_title("Slice %d" % position)

    masked = np.ma.masked_where(
        resolution_map > current_resolution, resolution_map, copy=True
    )
    figure_result, result_axes = plt.subplots(2, 2)
    figure_result.suptitle(
        "Slices Through ResMap Results",
        fontsize=14,
        color="#104E8B",
        fontweight="bold",
    )
    image = None
    for axis, position in zip(result_axes.ravel(), positions):
        image = axis.imshow(
            masked[position],
            vmin=min_resolution,
            vmax=max_resolution,
            cmap=plt.cm.jet,
            interpolation="nearest",
        )
        axis.set_title("Slice %d" % position)
    if image is not None:
        color_axis = figure_result.add_axes([0.9, 0.1, 0.03, 0.8])
        figure_result.colorbar(image, cax=color_axis)

    histogram_figure = plt.figure()
    histogram_figure.suptitle(
        "Histogram of ResMap Results",
        fontsize=14,
        color="#104E8B",
        fontweight="bold",
    )
    histogram_axis = histogram_figure.add_subplot(111)
    labels = list(histogram.keys())
    values = list(histogram.values())
    histogram_axis.bar(range(len(labels)), values, align="center")
    histogram_axis.set_xlabel("Resolution (Angstroms)")
    histogram_axis.set_xticks(range(len(labels)))
    histogram_axis.set_xticklabels(labels)
    histogram_axis.set_ylabel("Number of Voxels")
    plt.show()


def ResMap_algorithm(**kwargs: object) -> Dict[str, object]:
    """Compute a local-resolution map using CPU preprocessing and PyTorch LRS."""
    begin = time()
    print("== BEGIN Resolution Map Calculation ==")

    voxel_size = float(kwargs.get("vxSize", 0.0))
    p_value = float(kwargs.get("pValue", 0.05))
    min_resolution = float(kwargs.get("minRes", 0.0))
    max_resolution = float(kwargs.get("maxRes", 0.0))
    step_resolution = float(kwargs.get("stepRes", 1.0))
    data_mask_input = kwargs.get("dataMask", 0)
    graphical_output = bool(kwargs.get("graphicalOutput", False))
    chimera_launch = bool(kwargs.get("chimeraLaunch", False))
    _noise_diagnostics = bool(kwargs.get("noiseDiagnostics", False))

    device_requested = str(kwargs.get("device", "auto"))
    z_chunk = int(kwargs.get("zChunk", 32))
    convolution_channels = int(kwargs.get("convChannels", 4))
    prewhiten_mode = str(kwargs.get("prewhiten", "interactive"))
    allow_tf32 = bool(kwargs.get("allowTF32", False))
    deterministic = bool(kwargs.get("deterministic", False))
    pinv_rcond = float(kwargs.get("pinvRcond", 1e-15))
    kernel_mode = str(kwargs.get("kernelMode", "legacy-python2"))
    skip_lpf_test = bool(kwargs.get("skipLPFTest", False))
    write_output = bool(kwargs.get("writeOutput", True))
    create_chimera = bool(kwargs.get("createChimera", True))

    if voxel_size <= 0.0:
        raise ValueError("voxel size must be positive")
    if p_value <= 0.0 or p_value > 0.05:
        raise ValueError("pValue must be in (0, 0.05]")
    if min_resolution < 0.0 or max_resolution < 0.0:
        raise ValueError("resolution limits cannot be negative")
    if step_resolution < 0.25:
        raise ValueError("stepRes must be at least 0.25 Angstrom")
    if z_chunk < 1 or convolution_channels < 1:
        raise ValueError("zChunk and convChannels must be positive integers")

    split_volume, input_path, input_path_2, data_mrc, data_mrc_2, data, data_difference = _load_inputs(
        kwargs
    )
    voxel_size_original = voxel_size
    device_resolved = resolve_torch_device(device_requested)
    print("PyTorch compute device: %s" % device_resolved)

    print("\n= Testing Whether the Input Volume has been Low-pass Filtered")
    lpf_start = time()
    (
        data,
        data_difference,
        voxel_size,
        lpf_factor,
        _lpf_fourier,
        _lpf_spectrum,
    ) = _test_and_downsample_lpf(
        data, data_difference, voxel_size, skip_lpf_test
    )
    # The LPF Fourier arrays are diagnostics only and can be large.
    del _lpf_fourier, _lpf_spectrum
    print("  :: Time elapsed: " + _elapsed(lpf_start))

    if min_resolution <= 2.2 * voxel_size:
        min_resolution = round((2.2 * voxel_size) / 0.1) * 0.1
    current_resolution = float(min_resolution)
    if max_resolution == 0.0:
        max_resolution = round((4.0 * voxel_size) / 0.5) * 0.5
    if max_resolution < min_resolution:
        raise ValueError(
            "maxRes %.3f is below effective minRes %.3f"
            % (max_resolution, min_resolution)
        )

    print("\n= Computing Mask Separating Particle from Background")
    mask_start = time()
    mask, data_mask, inside_sphere, _radius_matrix = _prepare_mask(
        data, data_mask_input, lpf_factor, split_volume
    )
    del _radius_matrix
    old_mask_count = int(np.sum(mask))
    print("Initial particle-mask voxels: %d" % old_mask_count)
    print("  :: Time elapsed: " + _elapsed(mask_start))

    data, data_difference = _prewhiten(
        data=data,
        data_difference=data_difference,
        data_mask=data_mask,
        inside_sphere=inside_sphere,
        voxel_size=voxel_size,
        split_volume=split_volume,
        mode=prewhiten_mode,
        graphical_output=graphical_output,
    )

    print("\n=======================================================================")
    print("|                     ResMap Computation BEGINS                       |")
    print("=======================================================================")
    n = int(data.shape[0])
    resolution_total = np.zeros_like(data, dtype=np.float32)
    resolution_histogram: OrderedDict[str, int] = OrderedDict()
    iteration_details = []

    if split_volume:
        fixed_noise_mask = mask.copy()
        if data_difference is None:
            raise RuntimeError("split-volume difference map is missing")
        noise_data = data_difference
    else:
        fixed_noise_mask = np.logical_and(inside_sphere, np.logical_not(mask))
        noise_data = data
    # These full-volume masks are no longer needed after pre-whitening and
    # construction of the fixed variance-estimation mask.
    del data_mask, inside_sphere

    more_to_process = True
    while more_to_process:
        print("\n\n= Calculating Local Resolution for %.2f Angstroms" % current_resolution)
        level_start = time()
        model = build_low_rank_model(
            current_resolution=current_resolution,
            voxel_size=voxel_size,
            pinv_rcond=pinv_rcond,
            kernel_mode=kernel_mode,
        )
        print(
            "winSize = %d; LRS rank = %d; background rank = %d; kernel = %s"
            % (
                model.win_size,
                model.lrs_rank,
                model.detail_rank,
                model.kernel_mode,
            )
        )

        print("Estimating variance from non-overlapping blocks with PyTorch...")
        variance_start = time()
        variance_result = compute_background_variance(
            noise_data,
            fixed_noise_mask,
            model,
            device=str(device_resolved),
            channels_per_batch=convolution_channels,
            allow_tf32=allow_tf32,
            deterministic=deterministic,
        )
        variance = float(variance_result.variance)
        print(
            "variance = %.6f from %d blocks"
            % (variance, variance_result.number_of_blocks)
        )
        print("  :: Time elapsed: " + _elapsed(variance_start))

        print("Calculating Likelihood Ratio Statistic with torch.conv3d...")
        lrs_start = time()
        valid_lrs = compute_lrs_valid_volume(
            data,
            model,
            device=str(device_resolved),
            z_chunk=z_chunk,
            channels_per_batch=convolution_channels,
            allow_tf32=allow_tf32,
            deterministic=deterministic,
            progress_callback=update_progress,
        )
        center_flat, lrs_vector = extract_lrs_for_mask_flat(
            valid_lrs, mask, model.radius, variance
        )
        del valid_lrs
        print("  :: Time elapsed: " + _elapsed(lrs_start))

        print("Calculating uncorrected and Benjamini-Yekutieli FDR thresholds...")
        threshold_start = time()
        threshold_uncorrected, threshold_fdr, kmax = _uncorrected_and_fdr_thresholds(
            lrs_vector,
            model.lrs_eigenvalues_ruben,
            int(np.sum(mask)),
            p_value,
        )
        print(
            "uncorrected threshold = %.6g; FDR threshold = %.6g; candidates = %d"
            % (threshold_uncorrected, threshold_fdr, kmax)
        )
        print("  :: Time elapsed: " + _elapsed(threshold_start))

        # Update only passing mask centers by flattened index. This is exactly
        # equivalent to constructing the legacy dense LRS volume, while avoiding
        # another 360 MiB float volume and a 90 MiB bool volume at box 448.
        passed_flat = center_flat[lrs_vector > threshold_fdr]
        resolution_total.reshape(-1)[passed_flat] += current_resolution
        mask.reshape(-1)[passed_flat] = False
        assigned_count = int(passed_flat.size)
        new_mask_count = old_mask_count - assigned_count
        print("Number of voxels assigned in this iteration = %d" % assigned_count)
        resolution_histogram[str(current_resolution)] = assigned_count

        iteration_details.append(
            {
                "resolution": float(current_resolution),
                "window_size": int(model.win_size),
                "lrs_rank": int(model.lrs_rank),
                "background_rank": int(model.detail_rank),
                "kernel_mode": model.kernel_mode,
                "gaussian_exponent_coefficient": float(
                    model.gaussian_exponent_coefficient
                ),
                "variance": variance,
                "background_blocks": int(variance_result.number_of_blocks),
                "threshold_uncorrected": threshold_uncorrected,
                "threshold_fdr": threshold_fdr,
                "candidate_count": int(kmax),
                "assigned_count": int(assigned_count),
                "remaining_count": int(new_mask_count),
                "elapsed_seconds": float(time() - level_start),
            }
        )

        if assigned_count < n and new_mask_count < n ** 2:
            print("We have probably covered all voxels of interest.")
            more_to_process = False
        old_mask_count = new_mask_count
        if current_resolution >= max_resolution:
            print("We have reached MaxRes = %.2f." % max_resolution)
            more_to_process = False
        # Avoid carrying hundreds of megabytes of per-level indexing into the
        # next variance/LRS iteration for 256--448 cubic maps.
        del center_flat, lrs_vector, passed_flat
        current_resolution += step_resolution

    resolution_total[resolution_total == 0] = 100.0
    resolution_masked = np.ma.masked_where(
        resolution_total > current_resolution, resolution_total, copy=True
    )
    if int(np.ma.count(resolution_masked)) == 0:
        mean_resolution = float("nan")
        median_resolution = float("nan")
    else:
        mean_resolution = float(np.ma.mean(resolution_masked))
        median_resolution = float(np.ma.median(resolution_masked))
    print("\n  MEAN RESOLUTION in MASK = %.2f" % mean_resolution)
    print("MEDIAN RESOLUTION in MASK = %.2f" % median_resolution)

    if split_volume:
        data_original = np.asarray(data_mrc.matrix)
        old_n = int(data_mrc.data_size[0])
    else:
        data_original = np.asarray(data_mrc.matrix)
        old_n = int(data_mrc.data_size[0])

    if lpf_factor > 0.0:
        old_coordinates = np.mgrid[
            0 : n - 1 : complex(0, old_n),
            0 : n - 1 : complex(0, old_n),
            0 : n - 1 : complex(0, old_n),
        ]
        resolution_total = ndimage.map_coordinates(
            resolution_total, old_coordinates, order=1, mode="nearest"
        )
        resolution_total[resolution_total <= min_resolution] = min_resolution
        resolution_total[resolution_total > current_resolution] = 100.0

    base, extension = os.path.splitext(input_path)
    output_path = base + "_resmap" + extension
    if write_output:
        output_mrc = data_mrc.copy()
        output_mrc.matrix = np.asarray(resolution_total, dtype=np.float32)
        write_mrc2000_grid_data(output_mrc, output_path)
        print("\nRESULT WRITTEN to MRC file: " + output_path)

    chimera_script: Optional[str] = None
    if create_chimera:
        chimera_script = createChimeraScript(
            input_path,
            min_resolution,
            max_resolution,
            int(resolution_total.shape[0]),
            animated=True,
        )
        print("CHIMERA SCRIPT WRITTEN to: " + chimera_script)

    if chimera_launch and chimera_script is not None:
        locations = [
            "",
            "/Applications/Chimera.app/Contents/MacOS/",
            "/usr/local/bin/",
            "C:\\Program Files\\Chimera\\bin\\",
            "C:\\Program Files\\Chimera 1.6\\bin\\",
            "C:\\Program Files\\Chimera 1.7\\bin\\",
            "C:\\Program Files\\Chimera 1.8\\bin\\",
            "C:\\Program Files (x86)\\Chimera\\bin\\",
        ]
        try:
            try_alternatives("chimera", locations, ["--send", chimera_script])
        except OSError:
            print(
                "WARNING: ResMap could not find/launch UCSF Chimera; load the "
                "generated command file manually."
            )

    if graphical_output:
        _show_results(
            data_original,
            np.asarray(resolution_total),
            current_resolution,
            min_resolution,
            max_resolution,
            resolution_histogram,
        )

    total_seconds = float(time() - begin)
    print("\nTOTAL :: Time elapsed: " + _elapsed(begin))
    return {
        "output_path": output_path if write_output else None,
        "chimera_script": chimera_script,
        "resolution_map": np.asarray(resolution_total, dtype=np.float32),
        "mean_resolution": mean_resolution,
        "median_resolution": median_resolution,
        "effective_voxel_size": float(voxel_size),
        "original_voxel_size": float(voxel_size_original),
        "effective_min_resolution": float(min_resolution),
        "effective_max_resolution": float(max_resolution),
        "lpf_factor": float(lpf_factor),
        "device": str(device_resolved),
        "kernel_mode": (
            iteration_details[0]["kernel_mode"] if iteration_details else kernel_mode
        ),
        "iterations": iteration_details,
        "total_seconds": total_seconds,
    }


__all__ = ["ResMap_algorithm"]
