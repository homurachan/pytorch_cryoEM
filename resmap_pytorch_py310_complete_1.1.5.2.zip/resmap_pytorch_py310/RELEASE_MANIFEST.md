# Release manifest

## Runtime modules

- `ResMap.py`: Python 3 CLI and Tkinter front end.
- `ResMap_algorithm.py`: preserved ResMap workflow and CPU/GPU dispatch.
- `ResMap_torch.py`: low-rank model construction, CUDA/CPU `conv3d` LRS, and
  PyTorch background-variance estimation.
- `ResMap_fileIO.py`: `mrcfile`-based MRC/CCP4 reader and writer.
- `ResMap_spectrumTools.py`: NumPy FFT pre-whitening and legacy plotting.
- `ResMap_helpers.py`: radius grids, Ruben/Farebrother distribution, and
  steerable directions.
- `ResMap_blocks.py`: legacy-compatible rolling-window helper for references.
- `ResMap_sphericalprofile.py`: spherical radial averaging.
- `ResMap_sphericalProfile.py`: case-compatible import shim.
- `ResMap_toChimera.py`: classic UCSF Chimera command generation.

## Installation and validation

- `pyproject.toml`, `requirements.txt`, `environment.yml`
- `README.md`, `README_CN.md`, `MODIFICATIONS.md`, `VALIDATION.md`, `UPSTREAM_NOTICE.md`
- `tests/` and `run_tests.sh`
- `dist/resmap_pytorch_py310-1.1.5.2-py3-none-any.whl`

The obsolete bundled `docopt.py` is intentionally absent because the CLI now
uses Python's standard `argparse` module. Upstream PyInstaller commands are not
retained because a CUDA-enabled PyTorch installation is environment-specific;
the source tree and wheel are the supported deliverables in this build.
