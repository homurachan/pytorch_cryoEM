# Upstream attribution and license notice

This project is a Python 3 / PyTorch port designed to reproduce the behavior of
ResMap 1.1.5 by Alp Kucukelbir and collaborators.

Please cite the original method when using it scientifically:

A. Kucukelbir, F. J. Sigworth, and H. D. Tagare, "Quantifying the local
resolution of cryo-EM density maps," Nature Methods 11, 63-65 (2014).

The public upstream source identifies its license as Creative Commons
Attribution-NonCommercial-NoDerivs 3.0 (CC BY-NC-ND 3.0). That license can
restrict distribution of modified versions. This archive is supplied for
private, non-commercial research, testing, and local migration. Obtain legal
advice or written permission from the original authors before public
redistribution, publication of binaries, or integration into another released
software package.

No warranty is provided. This notice is not legal advice.
