"""Stride-window helpers retained for compatibility with ResMap utilities."""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import numpy as np


def rolling_window(
    array: np.ndarray,
    window: Sequence[int],
    asteps: Optional[Sequence[int]] = None,
    wsteps: Optional[Sequence[int]] = None,
    axes: Optional[Sequence[int]] = None,
    toend: bool = True,
) -> np.ndarray:
    """Return a strided view containing rolling windows.

    The API is compatible with the helper bundled with legacy ResMap. The main
    GPU path no longer relies on this function, but it remains available for
    diagnostics and reference tests.
    """
    a = np.asarray(array)
    window_t = tuple(int(v) for v in window)

    if axes is None:
        axes_t = tuple(range(a.ndim))
    else:
        axes_t = tuple(int(v) for v in axes)
    if len(window_t) != len(axes_t):
        raise ValueError("window and axes must have the same length")

    if asteps is None:
        asteps_t = (1,) * len(axes_t)
    else:
        asteps_t = tuple(int(v) for v in asteps)
    if wsteps is None:
        wsteps_t = (1,) * len(axes_t)
    else:
        wsteps_t = tuple(int(v) for v in wsteps)
    if len(asteps_t) != len(axes_t) or len(wsteps_t) != len(axes_t):
        raise ValueError("asteps and wsteps must match axes")
    if any(v <= 0 for v in asteps_t + wsteps_t):
        raise ValueError("all step sizes must be positive")

    out_shape = list(a.shape)
    out_strides = list(a.strides)
    window_shape = []
    window_strides = []

    for axis, width, astep, wstep in zip(axes_t, window_t, asteps_t, wsteps_t):
        if axis < 0:
            axis += a.ndim
        if axis < 0 or axis >= a.ndim:
            raise ValueError("axis out of range")
        effective_width = (width - 1) * wstep + 1
        if width <= 0 or effective_width > a.shape[axis]:
            raise ValueError("window does not fit array")
        out_shape[axis] = 1 + (a.shape[axis] - effective_width) // astep
        out_strides[axis] *= astep
        window_shape.append(width)
        window_strides.append(a.strides[axis] * wstep)

    if toend:
        shape = tuple(out_shape + window_shape)
        strides = tuple(out_strides + window_strides)
    else:
        # Interleave each rolling dimension with its window dimension.
        shape_list = list(out_shape)
        stride_list = list(out_strides)
        offset = 0
        for axis, width, stride in zip(axes_t, window_shape, window_strides):
            insert_at = axis + 1 + offset
            shape_list.insert(insert_at, width)
            stride_list.insert(insert_at, stride)
            offset += 1
        shape = tuple(shape_list)
        strides = tuple(stride_list)

    return np.lib.stride_tricks.as_strided(a, shape=shape, strides=strides)


__all__ = ["rolling_window"]
