"""Helper functions for the Python 3 / PyTorch ResMap implementation.

The mathematical definitions follow the public ResMap 1.1.5 implementation,
while the code in this file is a Python 3.10-compatible rewrite.
"""

from __future__ import annotations

import sys
from typing import Optional, Sequence, Tuple

import numpy as np
from scipy.stats import norm


def createRmatrix(n: int) -> np.ndarray:
    """Create the cubic radius matrix used by the original ResMap code."""
    n = int(n)
    x, y, z = np.asarray(
        np.mgrid[
            -n / 2.0 : n / 2.0 : complex(0, n),
            -n / 2.0 : n / 2.0 : complex(0, n),
            -n / 2.0 : n / 2.0 : complex(0, n),
        ],
        dtype=np.float32,
    )
    return np.asarray(np.sqrt(x * x + y * y + z * z), dtype=np.float32)


def array_outer_product(
    A: np.ndarray, B: np.ndarray, result: Optional[np.ndarray] = None
) -> np.ndarray:
    """Compute the outer product in the final two dimensions.

    This intentionally preserves the behavior of the helper in ResMap 1.1.5,
    including the way it is used to construct the legacy 3-D Hamming window.
    """
    A = np.asarray(A)
    B = np.asarray(B)
    if A.shape[:-1] != B.shape[:-1]:
        raise ValueError("A and B must have identical leading dimensions")
    if result is None:
        result = np.zeros(A.shape + B.shape[-1:], dtype=A.dtype)
    if A.ndim == 1:
        result[:, :] = np.outer(A, B)
    else:
        for idx in range(A.shape[0]):
            array_outer_product(A[idx, ...], B[idx, ...], result[idx, ...])
    return result


def update_progress(amount_done: float) -> None:
    """Print a simple in-place progress bar."""
    amount = min(1.0, max(0.0, float(amount_done)))
    text = "\rProgress: [{0:50s}] {1:.1f}%".format(
        "#" * int(amount * 50), amount * 100.0
    )
    print(text, end="", flush=True)
    if amount >= 1.0:
        print("")


def evaluateRuben(c: float, alpha: float, weights: np.ndarray) -> float:
    """Objective used when numerically locating a Ruben-distribution quantile."""
    evaluated = rubenPython(weights, c)
    return float(np.abs(alpha - evaluated[2]))


def rubenPython(
    weights: Sequence[float],
    c: float,
    mult: Optional[Sequence[float]] = None,
    delta: Optional[Sequence[float]] = None,
    mode: float = 1.0,
    maxit: int = 100000,
    eps: float = 1e-5,
) -> Tuple[float, int, float]:
    """Ruben/Farebrother CDF for a positive weighted chi-square sum.

    This is a Python 3 port of the numerical routine used by ResMap 1.1.5.
    The return tuple is ``(density, fault_code, cdf)``.
    """
    weights_arr = np.asarray(weights, dtype=np.float32).reshape(-1)
    n = int(weights_arr.size)
    gamma = np.zeros_like(weights_arr, dtype=np.float32)
    theta = np.ones_like(weights_arr, dtype=np.float32)
    alist = np.asarray([], dtype=np.float32)
    blist = np.asarray([], dtype=np.float32)

    if mult is None:
        mult_arr = np.ones_like(weights_arr, dtype=np.float32)
    else:
        mult_arr = np.asarray(mult, dtype=np.float32).reshape(-1)
    if delta is None:
        delta_arr = np.zeros_like(weights_arr, dtype=np.float32)
    else:
        delta_arr = np.asarray(delta, dtype=np.float32).reshape(-1)

    if mult_arr.size != n or delta_arr.size != n:
        raise ValueError("mult and delta must have the same length as weights")

    c = float(c)
    maxit = int(maxit)
    eps = float(eps)
    if n < 1 or c <= 0.0 or maxit < 1 or eps <= 0.0:
        return (0.0, 2, -2.0)

    tol = -200.0
    bbeta = float(np.min(weights_arr))
    summ = float(np.max(weights_arr))
    if (
        bbeta <= 0.0
        or summ <= 0.0
        or np.any(mult_arr < 1.0)
        or np.any(delta_arr < 0.0)
    ):
        return (0.0, -1, -7.0)

    if mode > 0.0:
        bbeta = float(mode) * bbeta
    else:
        bbeta = 2.0 / (1.0 / bbeta + 1.0 / summ)

    k = 0.0
    summ = 1.0
    sum1 = 0.0
    for i in range(n):
        hold = bbeta / float(weights_arr[i])
        gamma[i] = 1.0 - hold
        summ = summ * (hold ** float(mult_arr[i]))
        sum1 = sum1 + float(delta_arr[i])
        k = k + float(mult_arr[i])

    ao = float(np.exp(0.5 * (np.log(summ) - sum1)))
    if ao <= 0.0:
        return (0.0, 1, 0.0)

    z = c / bbeta
    if np.mod(k, 2) == 0:
        i_start = 2
        lans = -0.5 * z
        dans = float(np.exp(lans))
        pans = 1.0 - dans
    else:
        i_start = 1
        lans = -0.5 * (z + np.log(z)) - np.log(np.sqrt(np.pi / 2.0))
        dans = float(np.exp(lans))
        pans = float(norm.cdf(np.sqrt(z)) - norm.cdf(-np.sqrt(z)))

    k = k - 2.0
    for j in range(i_start, int(k + 2), 2):
        if lans < tol:
            lans = lans + np.log(z / float(j))
            dans = float(np.exp(lans))
        else:
            dans = dans * z / float(j)
        pans = pans - dans

    prbty = pans
    dnsty = dans
    eps2 = eps / ao
    aoinv = 1.0 / ao
    summ = aoinv - 1.0
    ifault = 4

    for m in range(1, maxit):
        sum1 = 0.5 * float(
            np.sum(
                theta * gamma * mult_arr
                + float(m) * delta_arr * (theta - (theta * gamma))
            )
        )
        theta = theta * gamma

        blist = np.append(blist, np.float32(sum1))
        if m > 1:
            sum1 = sum1 + float(np.dot(blist[:-1], alist[::-1]))
        sum1 = sum1 / float(m)
        alist = np.append(alist, np.float32(sum1))

        k = k + 2.0
        if lans < tol:
            lans = lans + np.log(z / k)
            dans = float(np.exp(lans))
        else:
            dans = dans * z / k

        pans = pans - dans
        summ = summ - sum1
        dnsty = dnsty + dans * sum1
        term = pans * sum1
        prbty = prbty + term

        if prbty < -aoinv:
            return (0.0, 3, -3.0)
        if abs(pans * summ) < eps and abs(term) < eps2:
            ifault = 0
            break

    dnsty = ao * dnsty / (bbeta + bbeta)
    prbty = ao * prbty
    if prbty < 0.0 or prbty > 1.0:
        ifault = ifault + 5
        res = 1e10
    else:
        if dnsty < 0.0:
            ifault = ifault + 6
        res = prbty
    return (float(dnsty), int(ifault), float(res))


def make3DsteerableDirections(
    x: np.ndarray, y: np.ndarray, z: np.ndarray
) -> np.ndarray:
    """Generate the 16 direction fields used by the ResMap local model."""
    dirs = np.zeros(x.shape + (16,), dtype=np.result_type(x, y, z, np.float64))

    # Six rotations for the second-order terms.
    v = np.asarray([1.0, 0.0, (np.sqrt(5.0) + 1.0) / 2.0], dtype=np.float64)
    v /= np.linalg.norm(v)
    dirs[:, :, :, 0] = x * v[0] + y * v[1] + z * v[2]
    dirs[:, :, :, 1] = x * v[1] + y * v[2] + z * v[0]
    dirs[:, :, :, 2] = x * v[2] + y * v[0] + z * v[1]
    v[2] = -v[2]
    dirs[:, :, :, 3] = x * v[0] + y * v[1] + z * v[2]
    dirs[:, :, :, 4] = x * v[1] + y * v[2] + z * v[0]
    dirs[:, :, :, 5] = x * v[2] + y * v[0] + z * v[1]

    # Ten rotations for the third-order terms.
    v = np.asarray(
        [1.0, (np.sqrt(5.0) + 1.0) / 2.0, 2.0 / (np.sqrt(5.0) + 1.0)],
        dtype=np.float64,
    )
    v /= np.linalg.norm(v)
    dirs[:, :, :, 6] = x * v[0] + y * v[1] + z * v[2]
    dirs[:, :, :, 7] = x * v[1] + y * v[2] + z * v[0]
    dirs[:, :, :, 8] = x * v[2] + y * v[0] + z * v[1]
    v[1] = -v[1]
    dirs[:, :, :, 9] = x * v[0] + y * v[1] + z * v[2]
    dirs[:, :, :, 10] = x * v[1] + y * v[2] + z * v[0]
    dirs[:, :, :, 11] = x * v[2] + y * v[0] + z * v[1]

    inv_sqrt3 = 1.0 / np.sqrt(3.0)
    dirs[:, :, :, 12] = inv_sqrt3 * (x + y + z)
    dirs[:, :, :, 13] = inv_sqrt3 * (-x + y + z)
    dirs[:, :, :, 14] = inv_sqrt3 * (x - y + z)
    dirs[:, :, :, 15] = inv_sqrt3 * (-x - y + z)
    return dirs


__all__ = [
    "createRmatrix",
    "array_outer_product",
    "update_progress",
    "evaluateRuben",
    "rubenPython",
    "make3DsteerableDirections",
]
