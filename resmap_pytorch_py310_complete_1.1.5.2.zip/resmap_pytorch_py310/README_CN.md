# ResMap Python 3.10 + PyTorch/CUDA 版

版本：`1.1.5.2-py310-torch`

这是基于公开 ResMap 1.1.5 工作流程重写的 Python 3.10-only 版本。MRC、mask、形态学、Gaussian blur、预白化 FFT、特征值、Ruben 分布、排序与 FDR 保留在 NumPy/SciPy；最耗时的 LRS 和背景方差改成 PyTorch。LRS 不再生成 `m × m` 稠密矩阵，而是用最多 16 个低秩 3D kernel，通过 `torch.nn.functional.conv3d` 在 GPU 或 CPU 上计算。

## 安装

建议先建立 Python 3.10 环境，并安装与目标显卡驱动匹配的 CUDA 版 PyTorch：

```bash
conda create -n resmap310 python=3.10 -y
conda activate resmap310
# 先按目标机器的 CUDA/驱动情况安装 PyTorch
pip install numpy scipy matplotlib mrcfile
pip install ./dist/resmap_pytorch_py310-1.1.5.2-py3-none-any.whl --no-deps
```

也可以直接在源码目录中安装：

```bash
pip install -e . --no-deps
```

GUI 需要 Tkinter；Ubuntu/Debian 通常还需要系统包 `python3-tk`。纯命令行运行不需要打开 GUI。

## 使用

单个 map：

```bash
python ResMap.py --noguiSingle input.mrc --device cuda:0
```

两个 half map：

```bash
python ResMap.py --noguiSplit half1.mrc half2.mrc --device cuda:0
```

带 mask 和显式参数：

```bash
python ResMap.py --noguiSingle input.mrc \
  --maskVol mask.mrc \
  --vxSize 1.2 --pVal 0.05 \
  --minRes 2.7 --maxRes 8.0 --stepRes 0.5 \
  --device cuda:0 --zChunk 32 --convChannels 4 \
  --prewhiten auto --kernelMode legacy-python2
```

不带 `--noguiSingle` 或 `--noguiSplit` 时打开 Tkinter GUI。

## Gaussian kernel 的兼容模式

上游 Python 2 源码写的是：

```python
np.exp(-1/2 * (x**2 + y**2 + z**2))
```

因为该模块没有启用 true division，Python 2.7 实际把 `-1/2` 计算为 `-1`。因此本版本默认：

```text
--kernelMode legacy-python2
```

也就是严格复现实际运行过的 `exp(-r²)`。另提供：

```text
--kernelMode intended-half
```

用于显式测试通常数学意义下的 `exp(-0.5r²)`。两种模式可能得到不同的统计阈值和局部分辨率图，正式比较时不要混用。

## 显存参数

- `--zChunk`：每次处理的有效 Z 平面数，默认 32。CUDA OOM 时程序会自动减半重试，直到 1。
- `--convChannels`：每次同时计算的低秩 kernel 数，默认 4。显存不足时可改成 2 或 1。
- `--allowTF32`：默认关闭。完成 CPU/旧版结果比较后再考虑开启。
- `--deterministic`：要求 cuDNN 尽量采用确定性卷积路径。

对于 256–448 的立方体，推荐先使用：

```text
--zChunk 32 --convChannels 4
```

若显存不足，再降低为 `--zChunk 16 --convChannels 2`。

## 保留的旧版行为

- 只支持立方体 map；没有加入非立方体 tomo 支持。
- mask 到边界仍固定回退 9 voxels。
- 当窗口半径大于 9 时，仍保留旧版 NumPy 负索引回绕行为。
- LPF 检测后的下采样仍使用 SciPy cubic spline；最终恢复尺寸仍使用一阶 `map_coordinates`。
- Ruben/Farebrother 分布与 Benjamini–Yekutieli FDR 的计算顺序保持旧版流程。
- MRC 输出为 float32，并尽量保留 voxel size、origin、start indices、axis mapping、cell angles、labels 和 extended header。

## 验证状态

当前自动测试为 `11 passed`，包括：低秩矩阵对稠密参考、CPU `conv3d` 对逐 patch 计算、背景方差、固定 9-voxel 索引行为、MRC header、单图与 half-map 端到端路径、NumPy FFT 预白化，以及两种 Gaussian kernel 模式。

构建环境没有 NVIDIA GPU，因此没有在这里实测 CUDA 速度、峰值显存和 cuDNN 数值差异。第一次在目标 GPU 上运行时，建议先用裁剪的小 map，并比较每轮 variance、FDR threshold、assigned voxel count 和最终 map。

## 许可证提醒

公开上游源码声明 CC BY-NC-ND 3.0。修改版的公开再分发可能受到 NoDerivs 条款限制。本压缩包适合作为私人、非商业研究和本地验证版本；公开发布或并入其他公开项目之前，应取得原作者书面许可或适用的重新授权。
