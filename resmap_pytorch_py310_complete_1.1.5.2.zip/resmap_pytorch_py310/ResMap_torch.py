"""Low-rank PyTorch kernels for the computationally intensive ResMap steps.

The legacy implementation explicitly formed dense ``m x m`` quadratic-form
matrices for a window containing ``m = win_size**3`` voxels.  The model has at
most 17 columns, so those matrices admit exact low-rank factorizations.  This
module constructs those factorizations in NumPy float64 and evaluates them with
PyTorch ``conv3d`` on CUDA or CPU.
"""

from __future__ import annotations

import math
import warnings
from dataclasses import dataclass
from typing import Callable, Dict, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn.functional as F

from ResMap_helpers import make3DsteerableDirections


@dataclass(frozen=True)
class LowRankResMapModel:
    current_resolution: float
    voxel_size: float
    radius: int
    win_size: int
    kernel_mode: str
    gaussian_exponent_coefficient: float
    kernel: np.ndarray
    design_matrix: np.ndarray
    lrs_filters: np.ndarray
    background_filters: np.ndarray
    background_trace: float
    lrs_eigenvalues_all: np.ndarray
    lrs_eigenvalues_ruben: np.ndarray
    full_rank: int
    detail_rank: int

    @property
    def number_of_points(self) -> int:
        return int(self.win_size ** 3)

    @property
    def lrs_rank(self) -> int:
        return int(self.lrs_filters.shape[0])


@dataclass(frozen=True)
class BackgroundVarianceResult:
    variance: float
    number_of_blocks: int
    mean_wrss: float
    min_wrss: float
    max_wrss: float


def _svd_basis(matrix: np.ndarray, rcond: float) -> Tuple[np.ndarray, np.ndarray, int]:
    u, s, _ = np.linalg.svd(np.asarray(matrix, dtype=np.float64), full_matrices=False)
    if s.size == 0 or s[0] == 0.0:
        return u[:, :0], s, 0
    rank = int(np.count_nonzero(s > float(rcond) * float(s[0])))
    return u[:, :rank], s, rank


def build_low_rank_model(
    current_resolution: float,
    voxel_size: float,
    pinv_rcond: float = 1e-15,
    kernel_mode: str = "legacy-python2",
) -> LowRankResMapModel:
    """Build the exact low-rank representation for one resolution level.

    ``legacy-python2`` reproduces the Gaussian kernel that the upstream source
    actually evaluates under Python 2.7.  The source expression is
    ``exp(-1/2 * r_squared)`` without ``from __future__ import division``; its
    integer division therefore makes ``-1/2 == -1``.  ``intended-half`` uses
    the conventional mathematical interpretation ``exp(-0.5 * r_squared)``.
    """
    current_resolution = float(current_resolution)
    voxel_size = float(voxel_size)
    if current_resolution <= 0.0 or voxel_size <= 0.0:
        raise ValueError("current_resolution and voxel_size must be positive")
    if pinv_rcond <= 0.0:
        raise ValueError("pinv_rcond must be positive")

    normalized_kernel_mode = str(kernel_mode).strip().lower()
    if normalized_kernel_mode == "legacy-python2":
        gaussian_exponent_coefficient = 1.0
    elif normalized_kernel_mode == "intended-half":
        gaussian_exponent_coefficient = 0.5
    else:
        raise ValueError(
            "kernel_mode must be 'legacy-python2' or 'intended-half'"
        )

    radius = int(np.ceil(0.5 * current_resolution / voxel_size))
    win_size = 2 * radius + 1
    scale = (2.0 * np.pi / current_resolution) * np.sqrt(2.0 / 5.0)
    x, y, z = scale * np.mgrid[
        -radius * voxel_size : radius * voxel_size : complex(0, win_size),
        -radius * voxel_size : radius * voxel_size : complex(0, win_size),
        -radius * voxel_size : radius * voxel_size : complex(0, win_size),
    ]
    dirs = make3DsteerableDirections(x, y, z)
    squared_radius = x * x + y * y + z * z
    kernel = np.exp(
        -gaussian_exponent_coefficient * squared_radius
    ).reshape(-1).astype(np.float64)
    d_sqrt = np.sqrt(kernel)

    number_of_points = int(kernel.size)
    design = np.zeros((number_of_points, 17), dtype=np.float64)
    design[:, 0] = 1.0
    for i in range(6):
        direction = dirs[:, :, :, i].reshape(-1)
        design[:, i + 1] = 4.0 * direction * direction - 2.0
    for i in range(6, 16):
        direction = dirs[:, :, :, i].reshape(-1)
        design[:, i + 1] = direction ** 3 - 2.254 * direction

    # Full weighted model. B = D A, and B B+ is the Euclidean projector onto
    # its column space. The constant-only weighted basis is q0 = D1 / ||D1||.
    weighted_full = d_sqrt[:, None] * design
    full_basis, _, full_rank = _svd_basis(weighted_full, pinv_rcond)
    if full_rank < 1:
        raise RuntimeError("weighted ResMap design matrix unexpectedly has rank zero")

    q0 = d_sqrt / np.linalg.norm(d_sqrt)
    projected_q0 = full_basis @ (full_basis.T @ q0)
    projection_error = float(np.linalg.norm(projected_q0 - q0))
    if projection_error > 1e-8:
        raise RuntimeError(
            "constant basis was lost by the SVD rank threshold "
            "(projection error %.3e)" % projection_error
        )

    # The LRS matrix is D(P_full-P_constant)D. Project the full basis onto the
    # orthogonal complement of q0 and orthonormalize it. This leaves at most 16
    # directions, and is algebraically identical to the dense matrix.
    residual_basis = full_basis - q0[:, None] * (q0 @ full_basis)[None, :]
    lrs_basis, residual_s, lrs_rank = _svd_basis(residual_basis, pinv_rcond)
    # Numerical round-off can leave a spurious tiny singular direction. Since
    # residual_basis is a projector factor, meaningful singular values are ~1.
    if residual_s.size:
        stable_rank = int(np.count_nonzero(residual_s > 1e-10))
        lrs_basis = lrs_basis[:, :stable_rank]
        lrs_rank = stable_rank
    if lrs_rank > 16:
        raise RuntimeError("LRS rank exceeded the 16 non-constant model terms")

    lrs_filter_rows = (d_sqrt[:, None] * lrs_basis).T
    lrs_filters = lrs_filter_rows.reshape(
        lrs_rank, win_size, win_size, win_size
    ).astype(np.float32)

    if lrs_rank:
        gram = lrs_filter_rows @ lrs_filter_rows.T
        eigenvalues_all = np.abs(np.linalg.eigvalsh(gram)).astype(np.float64)
        max_eigenvalue = float(np.max(eigenvalues_all))
        eigenvalues_ruben = eigenvalues_all[
            eigenvalues_all > max_eigenvalue * 1e-1
        ]
    else:
        eigenvalues_all = np.asarray([], dtype=np.float64)
        eigenvalues_ruben = np.asarray([], dtype=np.float64)

    # The background-noise matrix is D(I-P_detail)D. Its quadratic form is
    # weighted energy minus squared responses to these projection filters.
    weighted_detail = d_sqrt[:, None] * design[:, 1:17]
    detail_basis, _, detail_rank = _svd_basis(weighted_detail, pinv_rcond)
    bg_filter_rows = (d_sqrt[:, None] * detail_basis).T
    background_filters = bg_filter_rows.reshape(
        detail_rank, win_size, win_size, win_size
    ).astype(np.float32)
    background_trace = float(np.sum(kernel) - np.sum(bg_filter_rows ** 2))
    if not np.isfinite(background_trace) or background_trace <= 0.0:
        raise RuntimeError("invalid trace for background variance model")

    return LowRankResMapModel(
        current_resolution=current_resolution,
        voxel_size=voxel_size,
        radius=radius,
        win_size=win_size,
        kernel_mode=normalized_kernel_mode,
        gaussian_exponent_coefficient=gaussian_exponent_coefficient,
        kernel=kernel.reshape(win_size, win_size, win_size).astype(np.float32),
        design_matrix=design,
        lrs_filters=lrs_filters,
        background_filters=background_filters,
        background_trace=background_trace,
        lrs_eigenvalues_all=eigenvalues_all,
        lrs_eigenvalues_ruben=eigenvalues_ruben,
        full_rank=full_rank,
        detail_rank=detail_rank,
    )


def build_dense_reference_matrices(
    model: LowRankResMapModel,
) -> Tuple[np.ndarray, np.ndarray]:
    """Construct the legacy dense matrices for tests on small windows only."""
    kernel = np.asarray(model.kernel, dtype=np.float64).reshape(-1)
    design = np.asarray(model.design_matrix, dtype=np.float64)
    details = design[:, 1:17]
    constant = design[:, :1]
    d_sqrt = np.sqrt(kernel)
    d_matrix = np.diag(d_sqrt)
    w_matrix = np.diag(kernel)

    h_detail = details @ np.linalg.pinv(d_matrix @ details) @ d_matrix
    lambda_detail = w_matrix - w_matrix @ h_detail

    h_full = design @ np.linalg.pinv(d_matrix @ design) @ d_matrix
    weighted_constant = d_matrix @ constant
    h_constant = (
        constant
        @ (weighted_constant.T / (np.linalg.norm(weighted_constant) ** 2))
        @ d_matrix
    )
    lambda_full = w_matrix - w_matrix @ h_full
    lambda_constant = w_matrix - w_matrix @ h_constant
    lambda_diff = lambda_constant - lambda_full
    return lambda_diff, lambda_detail


def resolve_torch_device(device: str = "auto") -> torch.device:
    """Resolve ``auto``, ``cpu``, ``cuda`` or ``cuda:N`` safely."""
    requested = str(device).strip().lower()
    if requested == "auto":
        return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if requested == "cuda":
        requested = "cuda:0"
    resolved = torch.device(requested)
    if resolved.type == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA was requested, but torch.cuda.is_available() is False")
        index = 0 if resolved.index is None else int(resolved.index)
        if index < 0 or index >= torch.cuda.device_count():
            raise RuntimeError(
                "CUDA device index %d is unavailable; detected %d device(s)"
                % (index, torch.cuda.device_count())
            )
        resolved = torch.device("cuda", index)
    return resolved


def configure_torch_backend(
    device: torch.device,
    allow_tf32: bool = False,
    deterministic: bool = False,
) -> None:
    """Configure CUDA precision/reproducibility for scientific comparison."""
    if device.type != "cuda":
        return
    torch.backends.cuda.matmul.allow_tf32 = bool(allow_tf32)
    torch.backends.cudnn.allow_tf32 = bool(allow_tf32)
    if deterministic:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
    else:
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.deterministic = False


def _torch_weight_batches(
    filters: np.ndarray,
    device: torch.device,
    channels_per_batch: int,
) -> Tuple[torch.Tensor, ...]:
    channels_per_batch = max(1, int(channels_per_batch))
    weights = []
    for start in range(0, int(filters.shape[0]), channels_per_batch):
        stop = min(int(filters.shape[0]), start + channels_per_batch)
        part = np.ascontiguousarray(filters[start:stop, None, :, :, :], dtype=np.float32)
        weights.append(torch.as_tensor(part, dtype=torch.float32, device=device))
    return tuple(weights)


def compute_lrs_valid_volume(
    data: np.ndarray,
    model: LowRankResMapModel,
    device: str = "auto",
    z_chunk: int = 32,
    channels_per_batch: int = 4,
    allow_tf32: bool = False,
    deterministic: bool = False,
    progress_callback: Optional[Callable[[float], None]] = None,
) -> np.ndarray:
    """Evaluate the unnormalized LRS quadratic form at all valid windows.

    The result shape is ``(n-win+1, n-win+1, n-win+1)`` and matches the first
    three dimensions of the legacy overlapping-window view.
    """
    data_arr = np.asarray(data, dtype=np.float32, order="C")
    if data_arr.ndim != 3 or not (
        data_arr.shape[0] == data_arr.shape[1] == data_arr.shape[2]
    ):
        raise ValueError("LRS computation expects a cubic 3-D array")
    win = int(model.win_size)
    if min(data_arr.shape) < win:
        raise ValueError("the local window is larger than the input volume")
    if model.lrs_rank < 1:
        raise RuntimeError("the LRS model has no non-constant directions")

    torch_device = resolve_torch_device(device)
    configure_torch_backend(torch_device, allow_tf32, deterministic)
    weight_batches = _torch_weight_batches(
        model.lrs_filters, torch_device, channels_per_batch
    )

    out_shape = tuple(int(v - win + 1) for v in data_arr.shape)
    output = np.empty(out_shape, dtype=np.float32)
    requested_chunk = max(1, int(z_chunk))
    z0 = 0

    with torch.inference_mode():
        while z0 < out_shape[0]:
            chunk = min(requested_chunk, out_shape[0] - z0)
            while True:
                z1 = z0 + chunk
                slab_np = np.ascontiguousarray(data_arr[z0 : z1 + win - 1, :, :])
                try:
                    slab = torch.as_tensor(
                        slab_np, dtype=torch.float32, device=torch_device
                    )[None, None, :, :, :]
                    accumulator: Optional[torch.Tensor] = None
                    for weights in weight_batches:
                        responses = F.conv3d(slab, weights, stride=1, padding=0)
                        contribution = torch.sum(responses * responses, dim=1)
                        if accumulator is None:
                            accumulator = contribution
                        else:
                            accumulator.add_(contribution)
                        del responses, contribution
                    if accumulator is None:
                        raise RuntimeError("no LRS filters were constructed")
                    output[z0:z1, :, :] = (
                        accumulator[0].detach().to("cpu").numpy().astype(np.float32, copy=False)
                    )
                    del slab, accumulator
                    break
                except RuntimeError as exc:
                    is_oom = "out of memory" in str(exc).lower()
                    if torch_device.type == "cuda" and is_oom and chunk > 1:
                        # Release every potentially live CUDA tensor before the
                        # retry.  Keeping an accumulator or response referenced
                        # would make empty_cache() ineffective after an OOM.
                        slab = None
                        accumulator = None
                        responses = None
                        contribution = None
                        torch.cuda.empty_cache()
                        chunk = max(1, chunk // 2)
                        warnings.warn(
                            "CUDA memory was insufficient; reducing LRS z-chunk to %d"
                            % chunk,
                            RuntimeWarning,
                        )
                        continue
                    raise
            z0 = z1
            if progress_callback is not None:
                progress_callback(float(z0) / float(out_shape[0]))

    return output


def legacy_mask_window_indices(
    mask: np.ndarray,
    radius: int,
    valid_shape: Sequence[int],
) -> Tuple[np.ndarray, np.ndarray]:
    """Map mask centers to legacy rolling-window indices.

    Negative indices deliberately wrap from the end, preserving ResMap 1.1.5's
    fixed 9-voxel edge backoff even if a later window radius exceeds nine.
    """
    mask_arr = np.asarray(mask, dtype=bool)
    centers = np.asarray(np.where(mask_arr), dtype=np.int64)
    starts = centers - int(radius)
    wrapped = starts.copy()
    for axis, size_value in enumerate(valid_shape):
        size = int(size_value)
        coords = starts[axis]
        if np.any(coords >= size) or np.any(coords < -size):
            bad = int(coords[(coords >= size) | (coords < -size)][0])
            raise IndexError(
                "legacy window index %d is outside valid range [-%d, %d)"
                % (bad, size, size)
            )
        wrapped[axis] = np.where(coords < 0, coords + size, coords)
    return centers, wrapped


def extract_lrs_for_mask(
    valid_lrs: np.ndarray,
    mask: np.ndarray,
    radius: int,
    variance: float,
) -> Tuple[np.ndarray, np.ndarray]:
    """Gather normalized LRS values at mask centers using legacy indexing."""
    if not np.isfinite(variance) or variance <= 0.0:
        raise ValueError("variance must be finite and positive")
    centers, wrapped = legacy_mask_window_indices(mask, radius, valid_lrs.shape)
    values = valid_lrs[tuple(wrapped)] / (float(variance) + 1e-10)
    return centers, np.asarray(values, dtype=np.float32)



def extract_lrs_for_mask_flat(
    valid_lrs: np.ndarray,
    mask: np.ndarray,
    radius: int,
    variance: float,
    index_chunk: int = 5_000_000,
) -> Tuple[np.ndarray, np.ndarray]:
    """Memory-efficient normalized LRS gathering for large cubic masks.

    Only one flattened center-index vector is retained. Coordinate conversion
    and legacy negative-index wrapping are processed in chunks, avoiding the
    three full int64 arrays returned by ``np.where`` for a 256--448 cube.
    """
    if not np.isfinite(variance) or variance <= 0.0:
        raise ValueError("variance must be finite and positive")
    mask_arr = np.asarray(mask, dtype=bool, order="C")
    if mask_arr.ndim != 3 or not (
        mask_arr.shape[0] == mask_arr.shape[1] == mask_arr.shape[2]
    ):
        raise ValueError("mask must be a cubic 3-D array")
    valid_arr = np.asarray(valid_lrs, dtype=np.float32, order="C")
    if valid_arr.ndim != 3:
        raise ValueError("valid_lrs must be 3-D")

    n = int(mask_arr.shape[0])
    valid_shape = tuple(int(v) for v in valid_arr.shape)
    index_dtype = (
        np.int32 if mask_arr.size <= np.iinfo(np.int32).max else np.int64
    )
    center_flat = np.flatnonzero(mask_arr.reshape(-1)).astype(index_dtype, copy=False)
    values = np.empty(center_flat.size, dtype=np.float32)
    n2 = n * n
    chunk_size = max(1, int(index_chunk))
    valid_flat = valid_arr.reshape(-1)

    for begin in range(0, center_flat.size, chunk_size):
        end = min(center_flat.size, begin + chunk_size)
        flat = center_flat[begin:end]
        z = flat // n2
        remainder = flat - z * n2
        y = remainder // n
        x = remainder - y * n
        coordinates = (z, y, x)
        wrapped_coordinates = []
        for coordinate, size in zip(coordinates, valid_shape):
            start = coordinate - int(radius)
            invalid = np.logical_or(start >= size, start < -size)
            if np.any(invalid):
                bad = int(start[np.flatnonzero(invalid)[0]])
                raise IndexError(
                    "legacy window index %d is outside valid range [-%d, %d)"
                    % (bad, size, size)
                )
            wrapped_coordinates.append(np.where(start < 0, start + size, start))
        vz, vy, vx = wrapped_coordinates
        gathered_index = (vz * valid_shape[1] + vy) * valid_shape[2] + vx
        values[begin:end] = valid_flat[gathered_index] / (float(variance) + 1e-10)

    return center_flat, values

def compute_background_variance(
    data: np.ndarray,
    block_mask: np.ndarray,
    model: LowRankResMapModel,
    device: str = "auto",
    channels_per_batch: int = 4,
    allow_tf32: bool = False,
    deterministic: bool = False,
) -> BackgroundVarianceResult:
    """Estimate noise variance from non-overlapping all-mask blocks on PyTorch."""
    data_arr = np.asarray(data, dtype=np.float32, order="C")
    mask_arr = np.asarray(block_mask, dtype=bool, order="C")
    if data_arr.shape != mask_arr.shape or data_arr.ndim != 3:
        raise ValueError("data and block_mask must be same-shaped 3-D arrays")
    if not (
        data_arr.shape[0] == data_arr.shape[1] == data_arr.shape[2]
    ):
        raise ValueError("background variance expects a cubic volume")

    win = int(model.win_size)
    if min(data_arr.shape) < win:
        raise ValueError("the local window is larger than the input volume")

    torch_device = resolve_torch_device(device)
    configure_torch_backend(torch_device, allow_tf32, deterministic)
    kernel_np = np.ascontiguousarray(model.kernel[None, None, :, :, :], dtype=np.float32)
    kernel_sum = float(np.sum(model.kernel, dtype=np.float64))
    filter_sums = np.sum(
        model.background_filters.reshape(model.detail_rank, -1), axis=1, dtype=np.float64
    ).astype(np.float32)
    filter_batches = _torch_weight_batches(
        model.background_filters, torch_device, channels_per_batch
    )

    with torch.inference_mode():
        volume = torch.as_tensor(data_arr, dtype=torch.float32, device=torch_device)[
            None, None, :, :, :
        ]
        mask_volume = torch.as_tensor(
            mask_arr, dtype=torch.bool, device=torch_device
        ).to(dtype=torch.float32)[None, None, :, :, :]
        kernel_weight = torch.as_tensor(
            kernel_np, dtype=torch.float32, device=torch_device
        )

        # avg_pool3d with no padding has exactly the same starts and output shape
        # as the legacy non-overlapping rolling windows.
        means = F.avg_pool3d(volume, kernel_size=win, stride=win)
        mask_means = F.avg_pool3d(mask_volume, kernel_size=win, stride=win)
        weighted_sum = F.conv3d(volume, kernel_weight, stride=win, padding=0)
        weighted_square_sum = F.conv3d(
            volume * volume, kernel_weight, stride=win, padding=0
        )
        weighted_centered_energy = (
            weighted_square_sum
            - 2.0 * means * weighted_sum
            + means * means * kernel_sum
        )

        projection_energy = torch.zeros_like(weighted_centered_energy)
        offset = 0
        for weights in filter_batches:
            count = int(weights.shape[0])
            responses = F.conv3d(volume, weights, stride=win, padding=0)
            sums = torch.as_tensor(
                filter_sums[offset : offset + count],
                dtype=torch.float32,
                device=torch_device,
            ).view(1, count, 1, 1, 1)
            responses = responses - means * sums
            projection_energy.add_(torch.sum(responses * responses, dim=1, keepdim=True))
            offset += count
            del responses, sums

        wrss = weighted_centered_energy - projection_energy
        # An all-ones block has mean 1. The half-count tolerance distinguishes
        # it from a block missing even one voxel without requiring exact FP equality.
        all_inside = mask_means > (1.0 - 0.5 / float(win ** 3))
        selected = wrss[all_inside]
        if selected.numel() == 0:
            raise RuntimeError(
                "no non-overlapping %dx%dx%d blocks are fully inside the noise mask"
                % (win, win, win)
            )
        sigma2 = selected / float(model.background_trace)
        variance_tensor = torch.mean(sigma2)
        result = BackgroundVarianceResult(
            variance=float(variance_tensor.detach().cpu().item()),
            number_of_blocks=int(selected.numel()),
            mean_wrss=float(torch.mean(selected).detach().cpu().item()),
            min_wrss=float(torch.min(selected).detach().cpu().item()),
            max_wrss=float(torch.max(selected).detach().cpu().item()),
        )

    if not np.isfinite(result.variance) or result.variance <= 0.0:
        raise RuntimeError(
            "background variance is not positive (%.6g); check the mask and input maps"
            % result.variance
        )
    return result


__all__ = [
    "LowRankResMapModel",
    "BackgroundVarianceResult",
    "build_low_rank_model",
    "build_dense_reference_matrices",
    "resolve_torch_device",
    "configure_torch_backend",
    "compute_lrs_valid_volume",
    "legacy_mask_window_indices",
    "extract_lrs_for_mask",
    "extract_lrs_for_mask_flat",
    "compute_background_variance",
]
