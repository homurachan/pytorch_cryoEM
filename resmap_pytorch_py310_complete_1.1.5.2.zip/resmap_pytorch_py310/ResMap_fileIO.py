"""MRC/CCP4 input and output through :mod:`mrcfile`.

This module replaces ResMap's legacy binary parser while retaining the small
``MRC_Data`` interface expected by the GUI and algorithm.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional, Sequence, Tuple

import mrcfile
import numpy as np


class MRC_Data:
    """In-memory MRC volume plus the header fields needed by ResMap."""

    def __init__(self, path: str, file_type: str = "ccp4") -> None:
        del file_type  # Kept for source-level compatibility.
        self.path = os.path.abspath(os.path.expanduser(str(path)))
        self.name = os.path.basename(self.path)
        with mrcfile.open(self.path, mode="r", permissive=True) as handle:
            if handle.data is None:
                raise ValueError("MRC file does not contain an image array")
            self.matrix = np.asarray(handle.data).copy()
            self.header = handle.header.copy()
            try:
                self.extended_header = np.asarray(handle.extended_header).copy()
            except Exception:
                self.extended_header = np.asarray([], dtype=np.uint8)

            voxel = handle.voxel_size
            self.data_step = (
                float(voxel.x),
                float(voxel.y),
                float(voxel.z),
            )
            self.data_size = (
                int(handle.header.nx),
                int(handle.header.ny),
                int(handle.header.nz),
            )

        # mrcfile stores arrays in Z,Y,X order. ResMap works on cubic arrays, so
        # the distinction does not alter the local-resolution calculation.
        if self.matrix.ndim != 3:
            raise ValueError(
                "ResMap expects a 3-D MRC volume; got shape %r" % (self.matrix.shape,)
            )

    @property
    def voxel_size(self) -> Tuple[float, float, float]:
        return self.data_step

    def copy(self) -> "MRC_Data":
        clone = object.__new__(MRC_Data)
        clone.path = self.path
        clone.name = self.name
        clone.matrix = np.asarray(self.matrix).copy()
        clone.header = self.header.copy()
        clone.extended_header = np.asarray(self.extended_header).copy()
        clone.data_step = tuple(self.data_step)
        clone.data_size = tuple(self.data_size)
        return clone


def _copy_scalar_header_fields(source: Any, destination: Any) -> None:
    """Copy non-size metadata that remains meaningful for a derived map."""
    scalar_fields = (
        "nxstart",
        "nystart",
        "nzstart",
        "mapc",
        "mapr",
        "maps",
        "ispg",
        "nversion",
    )
    for field in scalar_fields:
        try:
            destination[field] = source[field]
        except Exception:
            pass

    for axis in ("x", "y", "z"):
        try:
            setattr(destination.origin, axis, getattr(source.origin, axis))
        except Exception:
            pass

    # Preserve unit-cell angles, labels, and the generic extra bytes. Cell
    # lengths are recomputed from voxel size and output dimensions below.
    for axis in ("alpha", "beta", "gamma"):
        try:
            setattr(destination.cellb, axis, getattr(source.cellb, axis))
        except Exception:
            pass
    try:
        destination.extra[:] = source.extra[:]
    except Exception:
        pass
    try:
        destination.nlabl = source.nlabl
        destination.label[:] = source.label[:]
    except Exception:
        pass


def write_mrc2000_grid_data(mrcdata: MRC_Data, path: str) -> str:
    """Write ``mrcdata.matrix`` as float32 while retaining spatial metadata."""
    output_path = os.path.abspath(os.path.expanduser(str(path)))
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    matrix = np.asarray(mrcdata.matrix, dtype=np.float32, order="C")
    if matrix.ndim != 3:
        raise ValueError("Only 3-D arrays can be written as a ResMap result")

    with mrcfile.new(output_path, overwrite=True) as handle:
        handle.set_data(matrix)
        _copy_scalar_header_fields(mrcdata.header, handle.header)

        vx, vy, vz = (float(v) for v in mrcdata.data_step)
        if vx > 0.0 and vy > 0.0 and vz > 0.0:
            handle.voxel_size = (vx, vy, vz)

        # Extended headers are uncommon for reconstructed maps. Preserve one
        # when mrcfile can safely accept it; failure does not invalidate the map.
        ext = np.asarray(getattr(mrcdata, "extended_header", np.asarray([])))
        if ext.size:
            try:
                handle.set_extended_header(ext.copy())
            except Exception:
                pass

        handle.update_header_from_data()
        # update_header_from_data may reset cell dimensions, so restore spacing.
        if vx > 0.0 and vy > 0.0 and vz > 0.0:
            handle.voxel_size = (vx, vy, vz)
        handle.update_header_stats()
        handle.flush()

    return output_path


__all__ = ["MRC_Data", "write_mrc2000_grid_data"]
