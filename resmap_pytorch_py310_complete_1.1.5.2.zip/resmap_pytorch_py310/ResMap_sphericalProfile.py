"""Compatibility shim for the capitalization used by ResMap 1.1.5."""
from ResMap_sphericalprofile import sphericalAverage, sum_by_group

__all__ = ["sphericalAverage", "sum_by_group"]
