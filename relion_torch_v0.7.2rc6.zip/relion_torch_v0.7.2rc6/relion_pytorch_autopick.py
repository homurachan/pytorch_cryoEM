#!/usr/bin/env python3
"""Run directly from an extracted release, without installing the package."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from relion_torch.cli.autopick import main
if __name__ == '__main__':
    main()
