# 0.7.2rc6 — local admission and coarse scoring

- Share the local posterior byte formula between planning and admission;
  reserve 1/16 width/feedback slack inside the existing global memory limit.
- Separate coarse-width feedback from fine outliers so an unusually broad fine
  posterior does not collapse the next iteration's local coarse batch size.
- Check exact local support before image preparation. Grow from live headroom
  without consuming reserved projection storage; otherwise split unchanged
  candidates and reuse Class3D's existing batch-scoped angular support.
- Prepare coarse observation/CTF inputs and contiguous device IDs once per
  batch; reuse schedules across classes without repeated host union sorting.
- Add local coarse setup/inputs/score/weights/threshold timing. Stream elapsed
  time includes queue/idle effects; host waits must not be read as kernel time.
- Keep the previous coarse-sharing auto threshold after a forced-sharing A/B
  test remained slower. No scientific parameter or mandatory dependency change.

# 0.7.2rc5 — Class3D wide local execution

- Expand fine geometry only for retained parents, preserving original IDs.
- Reuse one vectorized particle/orientation schedule across classes.
- Add bounded, reuse-gated coarse projection sharing and explicit A/B control.
- Add budgeted cooperative Class3D global coarse windows with commit-safe
  fallback; retain the existing auto/combine window policies.
- Package the rc5 wheel inside the full archive and fix install_local.cmd.
- Validate existing real particles on Windows CUDA, rc4 checkpoint continuation,
  map/STAR equivalence and execution regressions. See validation/class3d_rc5/.

# 0.7.2rc4 — reuse-aware global fine execution

Candidate based on rc3, revised using the supplied server timing evidence.
Projector storage is normalized once after FFT, removing a full padded-model
copy at every fused dispatch. This benefits both global and local CUDA kernels.
The default retains the byte-bounded fine cache and accelerates only missing
projection rows. Existing dense/sparse scoring and tensor statistics reuse
those projections. An oversized bank no longer forces direct fused scoring.
No candidates or precision are removed.

- `--global-fine-mode auto` selects hybrid for eligible oversized CUDA fine
  banks; `hybrid` forces it, `cached` restores rc2, and `stream` retains rc3's
  explicit low-memory path.
- `--global-fine-statistics auto|tensor|fused` independently selects statistics
  for hybrid/stream. Auto uses tensor for hybrid and fused for stream.
- Hybrid retains the planned cache grant, using more memory than stream.
  A speedup on every GPU or dataset is not guaranteed.
- Existing checkpoints, bounded fallback and OOM recovery remain supported.
  Override saved cached/stream settings with `--global-fine-mode auto`.

See `HYBRID_FINE_EXECUTION.txt` and `validation/hybrid_fine/`. The following
sections are historical; rc3's automatic stream policy is superseded.

## 0.7.2rc3

- Separate global coarse retention from batch-scoped fine projection/scoring/statistics.
- Select bounded fine execution for oversized fine banks with guarded CUDA kernels.
- Account for coarse and fine storage under one grant, including posterior rebalancing and OOM release.
- Add continuation overrides global-fine-mode/global-fine-mib and lifetime cache counters.
- Preserve rc2 execution with global-fine-mode=cached; keep local and combine execution unchanged.

# v0.7.2rc2 — 2026-10-31

- Separate requested parameters, per-iteration plans and transient OOM limits.
- Add commit-driven recovery probes at E-step boundaries and decay temporary
  planner pressure after a clean E-step.
- Add cooperative coarse projection tiles across bounded particle microbatches,
  preserving the original per-microbatch arithmetic and full posterior selection.
- Account for retained coarse states, prepared images and shifted score inputs
  within an explicit window grant from unused planned GPU headroom.
- Preserve transactional accumulation through window/fine failures; isolate
  ordinary posterior-budget splits from actual CUDA allocation failures.
- Keep global cache, local streaming and combine defocus schedules distinct;
  share recovery diagnostics and retain existing CLI/checkpoint compatibility.
- No new runtime dependencies or numerical kernels. Known reconstruction
  repeatability limitations are not fixed by this execution release.

# v0.7.0 — 2026-10-18

- Preserve v0.6.2 combine-refine, read-only metadata fixes and existing commands.
- Merge the separate v0.6.0 RELION 3.1 auto-picking implementation.
- Add dynamic micrograph scheduling with one spawn worker per CUDA device.
- Preserve cross-micrograph Gaussian draws, including partial resume; centralize summaries and failure/abort handling.
- Add cross-version and real process/CPU/CUDA regression coverage; no new runtime dependency.

## 0.5.17

- Add bounded dense orientation-tile reuse across particles with unchanged candidate rectangles.
- Prepare shifted real/imag inputs once and reduce score intermediates and projection gather copies.
- Add host block-ID projection access without per-tile GPU readback.
- Grow posterior budgets with optional rounded slack; retain live admission and exact-demand fallback.
- Add dense-fine-execution auto/reference for continued and fresh runs; retain old CC scorer.
- Keep dense/sparse selection, all Triton kernels, scientific parameters and old checkpoints.

## 0.5.16

- Separate single-particle posterior budget admission from real CUDA OOM backoff.
- Support repeated growth using live headroom, including empty projection caches.
- Reserve both posterior passes, planned non-projection work and allocator safety margins.
- Rebuild owned bounded cache slabs under a reduced limit without permanently shrinking batch/work limits.
- Propagate grown budgets to recreated local engines; reject stale outer projection-bank handles.
- Add growth/denial diagnostics and repeated-particle, half-isolation, pressure and cache-rebuild regressions.
- Keep v0.5.15 scientific inputs, kernels, defaults and old checkpoint compatibility.

## 0.5.15

- Fix deferred Auto-refine global projection banks to use the coarse likelihood grid with adaptive oversampling.
- Share coarse grid selection between the bank builder, local/class3d callers and memory planner; retain current-size weighted sums and reconstruction.
- Preserve no-oversampling and strict-highres behavior and explicit bank-size overrides.
- Record actual coarse/fine/weighted-sum sizes and full/active coarse payload metadata in timing reports.
- Add deferred versus explicit/eager likelihood, candidate-support, cache-payload, real-half driver and memory-planning regression coverage.
- Keep v0.5.14 controls, default disabled local projection reuse and old checkpoint loading. Global convergence trajectories may change because coarse likelihood inputs are corrected.

## 0.5.14

- Fuse shared Fourier point-group symmetrization for all non-C1 groups, including standalone reconstruct.
- Expose skip-gridding/no-skip-gridding in Class3D/auto-refine and propagate through final/unfiltered/RPC maps.
- Cache bounded blob multipliers or fuse large-volume geometry; reuse FP64 and complex input workspaces; batch finite-check readback.
- Share SSNR geometry/statistics within each map, memoize identical results, release sample caches before FFTs, remove duplicate copies and slab readbacks.
- Fuse global coarse-score epilogues and FP32 raw weights; preserve GEMMs, cache, scans/sort/threshold behavior and precision policies.
- Enable the existing guarded 3D insertion kernel on global search and add separate global/reconstruction detail timing.
- Retain local-projection-reuse off, gold-standard halves, low-resolution join order and old checkpoints.

## 0.5.13

- Cache bounded C1 direction geometry and use conservative spatial preselection
  followed by exact angular support, with full-scan boundary/nearest fallbacks.
- Budget indexed fine tiles independently of legacy image gathers; retain the
  old chunk size for safe failure recovery and explicit A/B comparisons.
- Hoist weighted reconstruction inputs per batch, reuse host statistics
  schedules, avoid identity gathers, fuse private numerator/denominator inputs.
- Add all-call fine scoring/posterior/statistics/backprojection timing totals
  with batch-bounded event ownership and no extra per-tile synchronization.
- Keep scientific support, reconstruction, shared preread, half isolation,
  default disabled local projection reuse and older checkpoint compatibility.

## 0.5.12

- Read fine-score observations, CTF/noise and phase tables by GPU indices;
  fuse phase application into scoring instead of materializing parent gathers
  and shifted images before every tile. Preserve posterior/child ordering.
- Prepare bounded parent/class schedules once per particle batch, retaining
  projector-pool limits and the original direct fused path as a fallback.
- Default local projection reuse to off, including CLI checkpoint continuation.
  Add `--local-fine-inputs auto|off` for isolated execution comparisons.
- Add numerical kernel, strided input, oversampling, metadata-readback,
  partial-tile recovery, full-iteration and old-checkpoint regression coverage.

## 0.5.11

- Combine bounded shared local projections with fused Gaussian scoring;
  partition oversized reusable unions instead of silently losing sharing.
- Fuse FP32 residual-to-shell and scale-moment reductions into compact private
  outputs, with retained precision/fallback behavior for other modes.
- Fuse local 3D Fourier insertion, with private startup validation and compile
  preflight. Never replay a possibly committed atomic grid update on failure.
- Preserve global search, CC scoring, reconstruction preweighting, symmetry,
  gold-standard half separation, and the single shared preread cache.
- Add independent execution overrides, CUDA/interpreter numerical tests,
  end-to-end local classification/refinement and checkpoint compatibility checks.

## 0.5.10

- Fill a single shared raw-particle cache at coordinator startup when permanent
  workers and preread are enabled. All workers and both half slots attach by
  descriptor, validate image identities, and read bounded batches without disk
  rereads or private full-cache copies. Only the owner unlinks the allocation.
- Preserve half row mapping, observation corrections, iteration state and
  single-process/no-preread paths; expose actual worker cache use in timing.
- Report estimated resolution instead of current pixel count in Class2D,
  Class3D and auto-refine iteration summaries, including coordinator output.
- Add the requested separator at every iteration start, including continuation.
- Add shared-memory ownership, failure cleanup, repeated-iteration and resumed
  spawn-worker regression coverage for classification and odd/even half groups.

## 0.5.9

- Native MWTCF hard selection from half1 downsampled Fourier weights; shared
  downsampling/FSC functions and native solvent-FSC precedence.
- Auto-refine first-iteration force-converge and independent use-all-data control;
  compatible CLI aliases, checkpoint persistence and continuation overrides.
- Class3D per-iteration posterior-weighted unfiltered maps through public
  reconstruction, before MAP/SIRM/solvent processing, with empty-class handling.
- Remove redundant standalone particle STAR output; preserve FSC spectra.
- Protect CPU reconstruction RPC inputs from shared-storage Hermitian mutation.
- Independent scalar MWTCF oracle, actual first-final/continuation runs, exact
  export-toggle invariance, and serial/permanent-worker output comparisons.

## 0.5.8

- Shared native SIRM compact Fourier constraints in Class3D, independent
  auto-refine half M-steps, final combined map and standalone reconstruct.
- Native FSC calibration, squared reliability mixing, positivity, optional
  real-space mask and histogram threshold; no final real-space constraint.
- Per-class SSNR for Class3D instead of the native missing/class-1 half FSC.
- Correct odd mask origins, empty histogram bins and constant-map handling.
- Enable/disable/configure SIRM on continuation; preserve independent half
  unfiltered outputs and exact unchanged-SIRM continuation.
- Standalone Cn/Dn/T/O/I1-I4 via shared Fourier numerator/weight symmetry.
- Public Fourier resize/window and spectrum IO helpers; validate shell indices.
- Preserve permanent workers and nonzero optical corrections without new libraries.
- Scalar NumPy oracle, symmetry, resume, ordinary unfiltered and CPU-worker tests.

## 0.5.7

- Shared beam-tilt and arbitrary odd/even Zernike phase evaluation across
  Class2D, Class3D, auto-refine, CTF refinement and optical reconstruction.
- Correct masked/unmasked particle Fourier data for odd aberrations;
  include even aberrations in scalar and batched CTF calculation.
- Remove obsolete Class2D/Class3D aberration rejection, retaining explicit
  guards for unsupported magnification/MTF in those two tasks.
- Remove duplicate auto-refine odd demodulation after common preparation.
- Correct Class2D reference seed insertion and share the preprocessing byte
  budget for optics maps, keyed by coefficients/grid/device/dtype.
- Test physical coma/trefoil/fifth-order phases, even CTF modes, mixed optics,
  I3/K=3/order=3, local/CC/premultiplied paths, permanent workers and continuation.
- CTF refinement CLI reports the installed package version.

## 0.5.6

- Permanent per-device spawn workers for Class2D, Class3D and auto-refine.
- Dynamic particle tasks with shared frozen models and raw sufficient-statistic reduction.
- Concurrent independent half groups for even device counts; sequential independent slots for odd counts.
- Topology-independent continuation, worker error propagation, PID and per-worker timing reports.
- GPU dispatch for spectra, global M-step, unregularized and final joined reconstruction.
- Fusion-specific coarse tiles with bounded fallback; adaptive cold backprojection-cache bypass.
- Fourier-size-aware backprojection blocks and explicit local setup timing.
- CPU subprocess parity and release validation; CUDA hardware tests remain conditional.

## 0.5.5

- Rotational point groups Cn/Dn/T/O/I1-I4 with RELION 3.1.4 conventions.
- Original HEALPix identity preserved across asymmetric and batch-local grids.
- Independent half Fourier numerator/weight symmetrisation before FSC.
- Symmetry-aware pose changes, local priors, checkpoints and memory estimates.
- Multi-request batch projection retention; expanded automatic local work tiles.
- Optional fused CUDA interpolation/scoring and residual/scale statistics with
  runtime self-checks and explicit fallback/required modes.

# v0.5.4

- Share compact local sampling and bounded batch-scoped projection execution
  between Class3D and auto-refine. Deduplicate Gaussian coarse angles per class,
  score each generated block immediately, and preserve particle-specific factors.
- Reuse a single bounded slab without cross-batch projection residency. Fine and
  current-size statistics use the same lazy provider and preserve full planes.
- Add local-projection-mode (stream/cached) and local-projection-mib, including
  continuation overrides, automatic planning, counters and OOM behavior.
- Streaming fine evaluates retained parents with the existing sparse scorer;
  CC keeps its established scoring chunks. No scientific support is truncated.
- Avoid global Cartesian orientation tables in streaming Class3D, including
  compact sampling STAR metadata (directions and psi in separate blocks).
- Preserve global, fixed-pose, Class2D and CTF paths; no new dependencies.

# v0.5.3

- Replace the new-run default 2048 MiB projection ceiling by -1, meaning the
  planned automatic/manual budget; preserve explicit caps and OOM backoff.
- Include explicit ceilings in planning and prefer complete global fine banks
  over larger execution tiles/batches where feasible. Preserve bounded fallback.
- Prevent optional coarse active copies from breaking a complete fine bank.
- Report full fine demand and planned capacity; persist the final applied plan.
- Add order-2/order-3 geometry, memory-pressure, cache-residency, real half-flow
  and legacy-checkpoint tests. No changes to scientific support or convergence.
- For continuation from 0.5.2, --auto_cache_mib -1 removes the saved old ceiling;
  an omitted override retains it and prints an explanatory message.

# v0.5.2

- Add bounded global-ID projection reuse across local batches, with capacity-
  bounded host lookup and separate E-step/half/optics ownership.
- Replace local Cartesian unions by exact selected direction/psi pairs.
- Persist OOM execution ceilings and observe the actual local engine posterior.
- Schedule by local angular centres and optics, preserving source rows/probes.
- Reuse orientation-major statistics and grouped backprojection; retain parent
  accumulation for positive strict-highres to avoid preweight amplification.
- Batch equal-count local Gaussian scoring and defer bounded metadata readbacks.
- Add optimized/reference execution switches, continuation overrides and actual
  cache/work counters. No runtime dependency or CTF fitter change.
- Include reference numerical comparisons, fault injection, installed-wheel
  tests and complete console workflow. Real CUDA validation remains pending.

# v0.5.1

- Bind each iteration's Fourier sizes before updating angular sampling; retain
  coarse size through both half E-steps and their internal refreshes.
- Separate the initial non-helical MPI leader convergence grid from the
  refined follower grid, and checkpoint both roles explicitly.
- Select fixed accuracy probes from the native initial randomized/stable-optics
  half-1 order, reusing the shared C RNG and accuracy evaluator. Preserve the
  native seed-zero bypass and validate saved row identities on continuation.
- Migrate v0.5.0 checkpoints from their initial configuration; add coarse-size
  and accuracy-probe-count timing fields. No runtime dependencies added.
- Include targeted integration/regression checks and installed-wheel tests.
  CUDA and real-data/native executable comparison remain pending.

# v0.5.0

- Add C1, K=1, single-body SPA auto-refine with sequential independent halves
  on one CPU/CUDA device and explicit worker/device transport boundaries.
- Port half FSC, optional solvent-corrected FSC and low-resolution joining,
  automatic angular/translation sampling, resolution/convergence control,
  unfiltered half output and final joined MAP reconstruction/model statistics.
- Add dual-model continuation with exact particle numeric state and RNG.
- Use existing optics corrections throughout prediction, scoring and insertion;
  add bounded local sampling tables while preserving HEALPix child identities.
- Fix shared FSC Fourier coverage to count supported individual Fourier voxels,
  and align nondefault FSC-prior fudge with the native call sequence.
- Reuse extracted Class3D E/M functions; preserve classification resolution
  semantics and the 0.4.3 CTF fitting implementation. No new dependencies.
- Add CPU integration/regression tests and an installed-CLI smoke script.
  Real CUDA/data/native executable comparisons remain pending.

# v0.4.3

- Create a private CTF statistics spill directory only on the first block that
  actually exceeds the host cache budget; RAM-only units never create it.
- Preserve per-unit cleanup on success and exceptions, disk fallback, direct
  path-based statistics API, numerical precision and scientific checkpoints.
- Test no temporary-directory calls without spills, lazy mixed-cache creation,
  single-directory reuse, result identity and cleanup after a disk-write failure.
- Include analysis of the supplied RTX 4090 timing; no GPU performance changes
  beyond eliminating unused filesystem directories, and no new dependency.

# v0.4.2

- Add optional CTF --timing and --timing_samples, reusing the shared bounded
  CUDA event backend. No algorithm or optimizer changes; no new dependency.
- Record all-call inclusive/exclusive wall timing, sampled CUDA stream timing,
  logical transfers, reference-cache counters and particle/objective evaluations.
- Attribute preparation, image I/O/FFT, projection, stats transfers/spill,
  objective/gradient, optimizer overhead, global fits and output.
- Write incremental per-unit JSONL and cumulative JSON/TXT with run identifiers,
  explicit asynchronous timing semantics and interrupted/failed run reports.
- Exclude profiling options from scientific checkpoint signatures.
- Test on/off result identity, event bounds/device/sync/conversion, no-op mode,
  spill counters, continuation and partial reports. CUDA runtime test included.

# v0.4.1

- Reuse the shared owned/writable NumPy conversion for optical metadata, CTF
  fitting parameters, particle origins and Euler angles under pandas CoW.
- Evaluate only pending independent particles in L-BFGS line searches; skip
  unrelated statistics blocks and select host rows before transfer to CUDA.
- Add per-unit preparation/optimization times, statistics cache footprint and
  spill counts, objective/particle evaluation counts and bounded-search status.
- Add batch start/completion and throttled within-batch progress with host RSS,
  CUDA allocated/reserved memory and allocator retry counts. No cache flushing.
- Print the active minimum fitting resolution; retain the 30 Angstrom defocus
  default and existing --kmin/--kmin_defocus behavior.
- Test pandas CoW, pending-row/full-objective parity, bounded failed searches,
  46-unit statistics release and fitting-frequency support. No new dependency.

# v0.4.0

- Add executable CTF refinement, modular f/p/m parameter fitting, original
  estimator-specific half-map routing, and optics-group global fits for full
  2x2 magnification, beam tilt, odd and even Zernike aberrations.
- Enforce missing-micrograph restrictions and preservation of astigmatism,
  phase, B-factor, CTF scale and independent Cs, even during magnification fits.
- Add shared optical observation model, Zernike/tilt conversions, projection
  gradients, bounded independent-particle L-BFGS and micrograph L-BFGS.
- Aggregate global fits across all batches without inventing micrograph groups.
  Bound projection work, half-map residency, open stacks and host fit statistics.
- Provide verified stage continuation, STAR output, JSON/HTML and MRC diagnostics.
- Integrate the shared optical model with standalone common-grid 3D reconstruction.
- Preserve prior Class3D corrections; add exact STAR float roundtrips and literal
  Windows path handling. Runtime dependencies are unchanged.

# v0.3.9

- Shared full-RFFT CC support, including DC, conjugate x=0 points and image
  corner power; Gaussian masks and noise-statistic conventions are preserved.
- Shared strict-highres likelihood sizes across coarse/fine, local, single-pass
  and fixed-pose entry points. M-step projections and phases remain current-size.
- Shared squared low-pass window for CC+ini_high model spectra, applied before
  Class3D seed copying; migrate missing spectra in legacy first-CC checkpoints.
- Update CC memory estimates, retain bounded caches and uncommitted OOM retries.
- Add independent formula, integration, continuation and Class2D regressions.

# v0.3.7

- Adaptive global coarse score blocks and prepared CTF/noise-weighted observations;
  shared-reference matrix products avoid per-particle prediction materialization.
- Keep complete coarse banks; plan a fine working-set reserve for partial banks,
  replacing FIFO with vectorized second-chance replacement.
- Bounded cross-class Euler inverse cache, non-synchronizing inverse error checks
  on the known Euler path, cached output geometry, larger bounded projection batches.
- Persistent contiguous fine projection cache and direct active-pixel cache gathers.
- Packed global-direction statistical accumulation with budget-aware capacity and
  flush-before-evict behavior, plus diagnostic counters and execution tile override.
- Scientific formulas/support retained; cross-release floating-point order may differ.
- No additional dependencies; Triton opportunities documented, no Triton backend added.

# v0.3.4 — C1 Class3D local angular search

- Add sigma_ang/rot/tilt/psi (new-run defaults -1), checkpointed local/global state and continuation controls; Class3D support cutoff is 3 sigma.
- Resolve explicit angular priors, missing entries and native 999 sentinels per coordinate; refresh fallback centres from each completed iteration.
- Add shared C1 support selection (sphere, rot-only meridian plane, tilt-only, periodic psi), normalized truncated priors and nearest-point fallback.
- Score only supported particle/orientation pairs in bounded batched tiles; size coarse posteriors from local support and preserve full global IDs through fine sampling, statistics and backprojection.
- Use native local orientation priors instead of learned class/direction PDFs, while preserving dead-class and seed restrictions.
- Preserve 0.3.3 execution optimizations; add indexed contiguous projection gathers with lazy fill and a bounded fallback.
- Test local support, full-grid numerical oracle, CC/Gaussian, all fine-score modes, end-to-end statistics, continuations and global regression. CPU validation only on this host.

# v0.3.3 — Class3D bounded execution optimizations

- Reserve contiguous coarse projection banks and optional active-frequency banks in the existing projection-cache budget; preserve lazy fallback and generation invalidation.
- Coalesce translation parents by particle/class/orientation using shared phase-basis/statistics primitives; add a packed orientation cache with batched eviction/gridding.
- Compact exact-zero weights out of coarse sorting, retaining original totals, thresholds, ties and a dense fallback.
- Resolve class support before scoring; avoid discarded Gaussian scores in global/adaptive first-iteration CC. CC debug diff2 now stores negative correlation.
- Extract reusable execution modules for future SPA refinement; preserve Class2D behavior and checkpoint/CLI compatibility.
- Add numerical, bounded-memory, initialization, restart and packaging validation. CUDA performance has not been measured in the CPU build environment.

# v0.3.2 — Class3D continuation sampling

- Allow explicit continuation changes to HEALPix/psi/oversampling/translation sampling with native joint direction-prior reset; retain unchanged-sampling restarts.

# v0.3.1 — shared Class2D / Class3D algorithm fixes

- Share the corrected Class2D scale sums with Class3D: posterior weights and DVP > 3, without inverse-noise weighting, with the previous scale removed from XA/AA.
- Share initial reference spectra and data-versus-prior: stored half-spectrum coefficient counts, tau2_fudge in initial tau2, particle-weighted mean noise variance, and the 3D geometry factor.
- Add high-frequency particle power once per image for noise and norm; remove Class3D's extra retained-posterior-mass factor.
- Derive fresh-run noise groups from explicit group names or micrographs, as in RELION 3.1, for both Class2D and Class3D. Preserve saved numeric group IDs during continuation and preserve input particle row order.
- Load the Windows C runtime explicitly for seed/subset initialization; retain the existing Linux libc path.
- Add independent formula regressions, grouping tests, and Class2D/Class3D multi-iteration scale/continuation checks. Make the existing Class3D fixture use CTF-filtered forward projections so its scale tests have physically consistent observations.
- Keep CLI options, cache/performance choices, checkpoint format and C1-only capability boundaries.

# v0.3.0 — C1 SPA Class3D

- Add independent C1 Class3D runner and CLI, 3D sampling/masking/initial lowpass and single-map seed control.
- Reuse batch 2D observations, FP32 likelihood, norm/scale/noise, adaptive fine scorer/cost model, reconstruction, subset and source-row facilities.
- Add lazy bounded projection/projector caches, 3D grouped slabs and bounded RAM spill of backprojection grids.
- Add posterior-driven batch splitting without deleting hypotheses.
- Add atomic iteration checkpoints and own optimiser-STAR pointer continuation; preserve sampling, source-row and subset state.
- Add tests and explicit capability/memory limits. Do not silently claim symmetry/local search, gold-standard auto-refine or multi-GPU support.

## 0.2.17
- Replace the Class2D fine scorer's fixed `density >= 0.35` auto switch with a deterministic dense-vs-sparse execution cost model.
- Estimate dense work from exact active `(particle,class,coarse-orientation)` blocks, complete translation rectangles, active Fourier pixels, dense GEMM block fill and expected GEMM calls.
- Estimate sparse work from retained parent/child counts and bounded sparse tile calls; dense workspace feasibility remains a hard `candidate-work-mib` constraint.
- Preserve explicit `--fine-score-mode dense` and `--fine-score-mode sparse` behavior unchanged; first-iteration CC remains on the reference sparse scorer.
- Add fine-cost timing counters and regression tests for the 71k/K100 mid-density crossover that motivated this release.

## 0.2.16
- Add cross-class late sparse-parent supertiles for Class2D auto mode, reusing the v0.2.15 coarse-grid marker and preserving parent order/statistical formulas.
- Keep explicit `--weighted-sum-layout parent` on the v0.2.15 class-fragmented path for A/B comparisons.

## 0.2.15
- Class2D grouped backprojection workspace now keeps all K class banks resident whenever bounded memory permits.
- Replaced the fixed 50% orientation-major density gate with a translation-reuse cost model (~26.8% crossover for the common 21x4 translation geometry); explicit orientation mode bypasses the cost comparison.
- Orientation scheduling transfers one dense compact marker D2H and only parent IDs/group counts H2D, rebuilding slots/rows/angular IDs on GPU.
- Fine adaptive prior packing follows FP32 weight precision instead of allocating the large packed prior in float64.
- Class2D data STAR output is restored through an immutable source-row mapping.

## 0.2.14

- Give Class2D orientation-major weighted sums a dedicated integer-only iterator; do not materialise parent-sized reference/phase/angle/translation Fourier tensors before grouping.
- Add an orientation-aware workspace planner whose tile limit scales with compressed fine-orientation rows instead of retained translation parents.
- Merge consecutive particle/orientation groups from the same class into bounded supertiles, independent of the parent `candidate_chunk_size`.
- Pack complex phase, active phase power, mass and translation moments into one shared FP32 RHS and evaluate each supertile with one large GEMM.
- Keep sparse/low-reuse batches on the mature parent-major path and leave generic Class3D/auto-refine execution unchanged.
- Add supertile/workspace/GEMM counters and regression tests proving the dedicated path bypasses the parent iterator.

## 0.2.13

- Add Class2D-only orientation-major weighted sums: retained translations are grouped by particle/class/fine orientation before noise, scale, offset and backprojection statistics.
- Reuse one grouped weight matrix and weighted phase for Class2D statistics and numerator/denominator contributions; bounded parent-major fallback remains available.
- Default Class2D hypothesis-weight arithmetic to RELION-accelerator-style float32 (maximum exponent shifted to +50; values below -88 become exact zero).
- Default hot Class2D weighted statistics to float32, converting to float64 only at model-update/API boundaries; generic alignment remains float64 by default for Class3D/auto-refine.
- Add `--weighted-sum-layout`, `--weight-precision` and `--accumulation-precision` controls plus orientation-major timing/counters.
- Preserve the v0.2.12 parent-major route for explicit A/B comparisons and for future Class3D/auto-refine integration.

## 0.2.12

- Reuse FP32 prediction power and cross terms across noise and scale updates.
- Restrict the statistics phase to active Fourier pixels on premerged tiles.
- Aggregate individually clamped FP32 residuals in a bounded per-batch FP64
  particle/pixel buffer, then reduce shells; retain radial-order fallback.
- Direct 2-D MRCS output and indexed model references, retaining individual 3-D MRCs.
- Remove Class2D per-class pre/postprocess writes and stack/model readback/rewrite.
- Emit seed/continuation stacks and pass in-memory 2-D seeds to the optimiser;
  read indexed STAR reference slices directly instead of unpacking temporary MRCs.
- Add statistic-order control, detailed reduction/output timing and I/O counters.
- Preserve candidate scheduling, subset schedule, expected accuracy and startup math.

## 0.2.11

- Compact host/device candidate metadata, bounded regular-grid scheduling and group-aligned tiles.
- Launch-aware early weight coalescing with shared-phase fallback.
- Shared batched startup Fourier pass for native reference initialization and initial noise spectra.
- Optional native RELION 3.1 fast_subsets schedule, bounded indexed I/O and checkpointed order.
- Startup timing plus complete per-batch scheduling phase breakdown.
- Existing full-data behavior remains the default; no new runtime dependencies.

# 0.2.10

- Share `prepare_particle_batch` and batched CTF wrapper, bounded geometry cache.
- Match ROUND's C++ double-literal promotion at float32 half-grid boundaries.
- Reuse weighted phase for masked/unmasked images; coalesce weights before gridding contributions.
- Plan cache/flush/tile budgets dynamically; persist bounded sums only within the E-step.
- Add v029 compatibility mode, independent execution controls, detailed sampled host/CUDA timing.
- 433 CPU tests pass; 38 CUDA tests skipped. Full numerical/performance report included.

# 0.2.9

- Static 2D gridding indices (batched + singleton geometry); no dynamic nonzero
  inside the cached insertion path. Original fallback preserved under budgets.
- Stable exact-zero-parent pruning, bounded candidate tiles and integer mask reuse.
- LRU-bounded weighted class/orientation backprojection sums (disable separately).
- Geometry-agnostic dense/sparse fine score execution, auto density and memory
  fallback, original parent/child mapping and posterior selection. CC scoring
  stays on original layout to protect near-tied winner behavior.
- New timing counters, explicit v028 compatibility mode and continuation controls.
- Unchanged _prepare, initialization, I/O, reconstruction and dependency list.
- Numerical caveat documented: regrouping is not bitwise and weak-class maps can
  amplify small grid differences. New validation report separates this from the
  former v028 exact comparison contract.

# 0.2.8

- Evaluate retained_weights once per Class2D compute batch, not once per tile.
- Reuse existing coarse/fine translation phases during sufficient-statistic accumulation.
- Add bounded active Fourier views to the shared expectation engine; opt-in from Class2D only.
- Cache 2D backprojection inverse/grid/Hermitian/neighbour geometry per iteration across classes.
- Preserve chunk/pixel/corner insertion order and use the original path for singleton orientation chunks.
- Build stable class selections once per batch; snapshot frozen normalization/scale scalars once per E-step.
- Add optimized/reference execution modes, bounded cache controls, and synchronized optional stage timings.
- Keep 0.2.7 I/O and existing scientific configurations intact; allow execution options on continuation.
- Add 23 passing tests and 9 CUDA-only tests; full suite 327 passed, 10 skipped without CUDA.
- Include independent original-version CPU parity comparisons and reproducible benchmark scripts/results.

# 0.2.7

- Default to seek/read of selected particle slices; retain optional explicit mmap backend.
- Unify particle stack caches with bounded LRU, early eviction, header/size/index validation, and preserved error causes.
- Add optional CPU raw-image pre-read, independent disk batch and raw device pool controls, and optional raw-RAM budget.
- Reuse one Class2D dataset/store from initialization through all iterations; preserve only raw images between iterations.
- Stage shared 2D/3D alignment inputs in bounded pools; stream legacy sufficient statistics without retaining every particle Fourier image.
- Keep scientific kernels, particle ordering, E-step compute batch boundaries, and frozen-noise conventions unchanged.
- Persist execution options/statistics; support continuation from old checkpoints without new I/O fields.
- Add 46 I/O tests (45 pass, 1 CUDA skip); complete suite: 304 pass, 1 skip.
- Add independent old/new parity and low-FD reproduction tools with recorded results.

# 0.2.6

- Mask source Fourier disk/sphere before bilinear/trilinear interpolation.
- Implement finite signed Nyquist/zero-halo neighbor reads, no periodic leakage.
- Separate source current_size from output size; rebuild on shrink/growth.
- Invalidate scalar/dense/fine caches on source generation changes.
- Bind source support across Class2D, shared 3D alignment, fixed-pose backends.
- Resolve reference-free automatic ini_high before initial reconstruction;
  preserve explicit settings and persist effective value through CC/checkpoints.
- Add 41 independent numerical/lifecycle/integration tests (259 total).

# 0.2.5

- Own writable NumPy norm/spectrum buffers before Torch conversion.
- Class2D default accuracy trials 10; diagnostic metadata Euler handling and
  physical CTF application match the pinned RELION 3.1 diagnostic routine.
- Explicit pre/post-M-step current-resolution and per-class resolution logging,
  distinct from the current/coarse Fourier support size.
- STAR writer specifies nan instead of <NA>; legacy missing-value reading and
  the dependency-free writer are covered by regression tests.
- Preserve actual Class2D psi-only E-step, native/debug prior modes, DC/MAP and
  empty-class state. No new posterior temperature or scale factor.

# 0.2.4

- Fix native Class2D coarse translation-prior distance scaling; keep transforms unchanged.
- Add an opt-in dimensionally consistent debug prior and matching sigma-offset centre.
- Default to GPU log-priors/max-shift conversion; expose CPU evidence normalization for diagnostics.
- Persist prior modes and reject silent conflicting continuation flags.
- Separate DC-inclusive per-class reporting from working resolution scheduling.
- Return undefined completeness for the native shell-zero reporting boundary.
- Retain all 0.2.3 regression coverage and add targeted numerical/integration tests.

# 0.2.3

- Restore M-step DC; propagate minres_map; stop silent numerical fallback.
- Correct positive-Nyquist Fourier window/coordinate semantics.
- Implement the Class2D correction/sampling/init/CC/solvent/checkpoint state machine.
- Add norm/scale and class-offset statistics to a shared moment accumulator.
- Add explicit CTF states and common-grid multiple optics handling.
- Add same-version exact continuation and native STAR parameter import.
- Add 22 new tests (163 total), including 25-round unequal K=4 and 10+15 restart.
- Explicitly reject unimplemented heterogeneous/higher-order optical corrections.

# Changelog

## 0.1.12

- Extended the dense global-search architecture to a batched sparse
  coarse-to-fine pipeline for `--oversampling > 0`.
- Reused a coarse-size projection bank and matrix likelihood for the first
  pass, then expanded only raw-weight significant parent tiles.
- Added vectorized fine NEST/psi/translation child tables, per-batch unions of
  required fine orientation blocks, and iteration-local fine projection caches.
- Scored fine current-size children by batched matrix products while inheriting
  the exact coarse-parent prior and retaining RELION's coarse reported
  `rlnNrOfSignificantSamples`.
- Added sparse fine-pass posterior-moment noise updates, translation-linear
  weighted images, particle/orientation aggregation and batched compact-grid
  backprojection.
- Reused cached fine translation phase tables between scoring and maximization.
- Matched RELION traversal order for base and oversampled translations and for
  higher-order HEALPix child face coordinates; added actual fine orientation IDs.
- Added startup reporting of the effective particle diameter and pixel radius.
  No empirical likelihood-temperature correction is applied; strict comparisons
  must use the same `--particle-diameter` in RELION and PyTorch.
- Added sparse-versus-legacy, projection-cache, child-order, batch-invariance and
  end-to-end adaptive-oversampling regressions.  The complete suite now contains
  123 passing tests.

## 0.1.11

- Replaced posterior-`>0` significant-sample counting with RELION 3.1's
  unnormalised raw-weight path: subtract the minimum squared difference, apply
  the 700-log-unit exponent cutoff, multiply exact priors in float64, sort only
  positive weights, cross `adaptive_fraction * sumweight` with a strict `>`,
  and retain all original hypotheses tied at or above the resulting threshold.
- Preserved RELION's separately reported number of sorted coarse samples, so
  `rlnNrOfSignificantSamples` is no longer controlled by float32 posterior
  underflow and is ready to drive adaptive child generation.
- Replaced literal multiplication by a soft mask with exact
  `softMaskOutsideMap` semantics for `--zero-mask`: weighted average background
  replacement and raised-cosine blending.  Applied the same blending geometry
  to the noisy-solvent path and to iteration-zero noise estimation.
- Made oversampled direction/psi/translation children inherit the complete
  coarse-parent prior instead of recalculating a different prior on the fine
  grid.
- Matched first-iteration CC state flow: hard best hypothesis, Pmax one, one
  significant sample, CC-valued per-particle contribution, mean-CC model
  likelihood, unchanged noise spectrum and no expected-accuracy pass.
- Disabled adaptive oversampling under `--skip-align` or `--skip-rotate`, and
  stopped writing an iteration model when `--skip-maximize` is active.
- Matched initial model serialization: the it000 general block writes an
  infinite current resolution and current image size zero, while class rows
  retain the initial DVP-derived estimated resolution.
- Corrected strict-high-resolution flow: strict cutoff controls likelihood
  scoring, while the Gaussian DLL normalizer, high-resolution Xi² boundary,
  residual-noise update and weighted sums remain tied to the working current
  size.
- Applied the same stored-half-plane initial noise, exact masking, raw class
  significance, projector-space tau² and dead-class rules to the fixed-pose
  multi-class EM backend.
- Added RELION class-prior mean normalisation for multi-class DLL parity and CLI
  aliases for `--maskedge`, `--random-seed` and `--random_seed`.
- Added a 16-test 0.1.11 freeze-parity module; the complete suite now contains
  116 passing tests.

## 0.1.10

- Replaced the iteration working reference tau² with the radial power spectrum
  of the exact padded, gridding-corrected and projector-normalised Fourier
  volume used for likelihood projections.
- Matched RELION's projector-space accumulation convention: current-size
  `r_max`, padded-radius rounding, `ROUND(radius/padding_factor)` shells,
  `|F|²/2`, and one count per stored RFFT coefficient.
- Kept the existing raw-map spectrum exclusively for the `it000`
  initialisation state; each expectation/MAP iteration now receives the
  freshly rebuilt projector-space tau² and writes it to `model_class_N`.
- Added RELION-style pre-expectation estimates of rotational and translational
  assignment accuracy, using up to 100 particles by default, with
  `--expected-accuracy-trials` and `--skip-expected-accuracy` controls.
- Added `rlnSpectralOrientabilityContribution`, non-zero
  `rlnAccuracyRotations`/`rlnAccuracyTranslationsAngst`, and
  `model_pdf_orient_class_N` STAR serialization.
- Combined the in-memory conditional direction PDF with the separate class
  prior, divided the resulting joint orientation prior by its RELION-style
  global mean, and serialized the joint class/direction probability in model
  STAR files.
- Added exact projector-power, installed-iteration-tau², accuracy-state and
  model-serialization regressions.

## 0.1.9

- Matched RELION 3.1 iteration-zero noise estimation on the stored RFFT
  half-plane: every stored coefficient and shell count is used once, without
  Hermitian multiplicity weighting; particle and average-image spectra are
  combined as `0.5 * (mean_particle_power - average_image_power)`.
- Added RELION-style repair of negative initial-noise shells: copy the previous
  positive shell when available, otherwise scan forward to the first positive
  shell, while leaving exact zeros unchanged.
- Added an oversampling-zero dense global-search path that precomputes one
  current-size projection bank per class and iteration and reuses it for all
  particles.
- Vectorised Fourier projection over orientation chunks and generated the exact
  RELION current-size circular output directly, instead of generating an
  original-size rectangular plane and discarding most coefficients.
- Replaced per-orientation residual construction with a matrix likelihood over
  particle batches, classes, orientations and translations.
- Removed hypothesis-level Python loops and CUDA `.item()` synchronisations
  from dense posterior normalisation, significant-sample selection, class and
  direction statistics, and offset-variance accumulation.
- Collapsed translations before residual-noise and M-step accumulation using
  posterior moments and `sum_t w_t X_t`, so each retained orientation is
  backprojected once rather than once per translation.
- Extended the validated compact backprojector to accept current-size Fourier
  planes and to map/splat orientation batches.
- Connected `--batch-size`, `--orientation-chunk-size`, and
  `--backprojector-chunk-size` to the production global-search path.
- Added dense-versus-legacy likelihood, noise, backprojection, projection-bank,
  direct-projector and end-to-end regression tests.

## 0.1.8

- Corrected all windowed Fourier translation phases to use the original image
  size as the physical frequency denominator in expectation, residual-noise
  accumulation and maximization.
- Restricted the per-particle Gaussian DLL normalizer to the independent
  current-size circular `Mresol_fine` support while retaining the full-size
  high-resolution particle-only term.
- Applied the RELION soft circular mask to iteration-zero particle and average
  power spectra under `--zero-mask`.
- Connected the alignment backprojector denominator to `updateSSNRarrays()`
  before MAP reconstruction and wrote reference sigma², tau², SSNR, Fourier
  completeness and voxel-weighted overall completeness to model STAR files.
- Froze sigma² across each E/M iteration; installed residual noise only after
  reconstruction, including the class-independent particle-power extension
  above current size.
- Updated posterior-weighted sigma offset, particle records, class/direction
  priors and the next iteration's current/coarse Fourier sizes.
- Made `--oversampling 0` a true single current-size expectation pass and made
  oversampled NEST children inherit their coarse direction prior.
- Passed tau², tau² fudge, class normalization and Pipe--Menon iteration count
  through the validated reconstruction adapter.
- Added RELION 3.1 alignment-state regression tests.

## 0.1.7

- Added the shared alignment expectation engine with translation-only, 2-D psi,
  3-D global and coarse/fine two-pass search modes.
- Added NEST HEALPix/RELION sampling, old-offset DONT_WRAP handling, orientation
  and translation priors, first-iteration CC, pose-dependent M-step and
  `--skip-maximize` diagnostics.
- Added the class-independent high-resolution particle term to dLL accounting
  and allowed class priors to become exactly zero.
- Kept the validated 0.1.6 projector, compact backprojector and reconstruction
  path as the numerical backend.
- Repacked release r2 fixes the concrete `FourierBackprojector.accumulate()`
  adapter call and makes package/runtime version metadata consistently 0.1.7.

## 0.1.6

- Replaced the full `padding_factor * original_size` Fourier accumulator with
  RELION 3.1's compact odd projector/backprojector grid,
  `2 * (ROUND(padding_factor * r_max) + 1) + 1`.
- Ran backprojection, Hermitian completion, SSNR/MAP statistics and Pipe--Menon
  preweighting on that compact periodic domain.
- Replaced Fourier decimation with RELION's active reconstruction route:
  compact Fourier windowing into the full even padded grid, padded inverse FFT,
  and central real-space crop to the original box.
- Reproduced `TabFtBlob`: 10,000 samples over `[0, 0.5)`, the analytical
  order-zero Kaiser--Bessel Fourier value, and truncating table lookup without
  interpolation.
- Reproduced the direct-index blob coordinates and retained
  `original_size * padding_factor` as their physical frequency denominator.
- Reproduced RELION 3.1 `softMaskOutsideMap`, including its radius, three-pixel
  cosine edge, weighted-average background and exact boundary comparisons.
- Added regression tests for compact grid dimensions, logical-frequency
  transfer, blob-table lookup, padded-IFFT/crop equivalence, corner masking and
  finite low-current-size Class3D reconstruction.

## 0.1.5

- Fixed the pandas/mmap metadata path so every NumPy array passed to
  `torch.as_tensor` is an explicit writable, C-contiguous copy.
- Matched RELION 3.1's Pipe--Menon numerical safeguards: the recursively
  updated preweight is retained in float64, the blob-convolution correction is
  floored at `1e-6`, and the applied single-precision preweight is capped at
  `1e20`.
- Bound each fixed-pose backprojector, SSNR calculation and reconstruction to
  the iteration's working `current_size` instead of extending the sparse
  weighted sums to the original-box Nyquist sphere.
- Carried the iteration-specific `current_size` into the Fourier backprojector
  and restricted backprojection, SSNR, MAP regularisation, Pipe--Menon
  preweighting and Fourier output to RELION's corresponding `max_r2` support.
- Corrected MAP-prior handling so every strictly positive tau² is used instead
  of treating values below the generic `1e-8` epsilon as zero.
- Added finite-value checks at weighted-sum, preweight, Fourier-map,
  real-space-map, model-validation, and MRC-write boundaries.
- Added regressions for the non-writable NumPy warning and for float32
  Class3D reconstructions under extremely sparse Fourier coverage.

## 0.1.4

- Rebuilt the package from the clean v0.1.2-fix source tree.
- Corrected reference tau² to use the projector gridding pre-correction and
  padding-factor dimensional normalisation (p² for Class2D, p³ for Class3D).
- Added RELION-style complex-Gaussian normalisation to
  `rlnLogLikeliContribution`.
- Made model `rlnLogLikelihood` the double-precision sum of per-particle dLL.
- Added optional per-iteration `*_dll_components.npz` diagnostics.
- Added regression tests for the former ~80 Å initial-PSNR failure and dLL
  self-consistency.

## 0.1.2

- Rebuilt from the clean v0.1.1 tree; removed the rejected parallel
  `relion31_*` fixed-pose path.
- Restored the validated `norm="forward"` FFT convention throughout particle,
  reference, noise and reconstruction paths.
- Added a 256x256 regression preventing the former `N²` noise-power inflation.
- Added RELION-style `it000` data/model output before expectation iteration 1.
- Added analytic initial tau²/data-versus-prior initialization and PSNR-shell
  selection.
- Separated PSNR resolution, working current size and strict user cutoff.
- Kept particle diameter exclusively in the masking path.
- Added RELION-style soft particle masks, zero masking and deterministic
  group-coloured noisy solvent.
- Corrected maximization order: update residual noise/statistics and
  `updateSSNRarrays()` before MAP reconstruction.
- Added class/group model statistics and high-precision spectra.

## 0.1.1

- Added RELION current-resolution/current-size scheduling.
- Replaced continuous likelihood cutoff with rounded Mresol shells.
- Added per-`rlnGroupNumber` noise spectra.
- Reproduced initial noise factor two and average-image subtraction.
- Excluded DC and redundant `x=0,y<0` Fourier coefficients from likelihoods.
- Added inverse-noise M-step weighting.
- Added shared `updateSSNRarrays()`-style spectra and tau² state.
- Added class posterior-mass normalisation to iterative reconstruction.
- Added RELION-style model class/group STAR blocks.
- Increased STAR floating-point output precision.
- Fixed `rlnNrOfSignificantSamples`.

## 0.1.0

- Initial Phase 1/2/3/5 package.

## 0.2.0

- Rebuilt the Class2D front end from the frozen 0.1.12 source.
- Added multi-class 2-D EM, `--skip-align`, K-image reference stacks,
  deterministic initialization, continuation, class stacks and class matching.
- Removed the malformed generated foundation modules and explicitly gated
  unimplemented norm/scale/automatic-sampling state.

## 0.2.1

- Fixed the 2-D projector and backprojector to invert the complete 3x3 RELION
  Euler matrix before extracting the in-plane 2x2 block.  The 3-D paths were
  audited and already used the complete inverse.
- Added RELION-style near-empty-class preservation: classes with zero old prior
  or accumulated Fourier weight <= 1e-6 keep their previous reference and
  spectral state instead of being reconstructed from negligible weights.
- Separated the just-completed iteration's working resolution/size from the
  newly estimated next-iteration resolution in model STAR serialization.
- Allowed per-class estimated resolution to reach the Nyquist shell while
  retaining RELION's Nyquist-excluding current-resolution scheduling scan.
- Kept the Class2D wrapper's first-iteration CC default enabled, as requested;
  continued runs still disable it through the existing iteration-offset gate.
- Added non-zero-rot/tilt 2-D geometry, 3-D regression, empty-class, current
  state, and Nyquist tests.  The full suite now contains 136 passing tests.

## 0.2.2

- Reproduced RELION 3.1's three-state empty-class lifecycle: reconstruct when
  the previous class probability and Fourier weight are positive, preserve the
  previous reference when only the Fourier weight is empty, and clear the map
  once the previous class probability has become exactly zero.
- Kept empty-class spectral state unchanged on the clearing iteration; the
  following expectation setup obtains zero projector-space tau2 from the zero
  reference, matching RELION's state order.
- Preserved float64 raw-weight posterior reductions for class occupancy across
  legacy, dense and sparse adaptive expectation paths, preventing tiny positive
  classes from being rounded away before the lifecycle gate.
- Continued to serialise the last stored per-class estimated resolution for an
  empty class instead of replacing it by an artificial infinite resolution.
- Added regression tests for the preserve/preserve/clear sequence, float64-only
  posterior mass, zero-projector tau2 installation on the following iteration,
  empty-class model-spectrum serialisation, and separation of float64 PDF state
  from float32 projection banks.  The full suite contains 141 passing tests.
