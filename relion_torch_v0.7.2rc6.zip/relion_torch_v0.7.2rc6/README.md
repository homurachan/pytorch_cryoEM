# 0.7.2rc6 — local admission and coarse scoring

Based on rc5 and its server iterations 22-29. Local posterior planning and
runtime admission now use the same byte estimate, including local metadata.
The automatic local plan reserves modest width slack and honors coarse-width
feedback above 2 GiB within the whole-process budget. Fine outliers retain a
separate bounded feedback policy. Actual support is checked before image
preparation; Class3D retries reuse their batch-scoped angular support.

Coarse scoring prepares observation/CTF inputs once per batch and uploads a
contiguous particle/position/orientation schedule once for all classes. New
timing fields separate local setup, scoring, posterior weights and threshold
selection. No search candidate, prior, precision setting or Triton arithmetic
has been removed or changed. Larger admitted batches can change floating-point
rounding; see the numerical comparisons in validation/local_admission_rc6/.

Existing commands and rc5 checkpoints work unchanged. Use a fresh output prefix
for comparison and retain your scientific settings, including sigma_ang.
See LOCAL_ADMISSION_v0.7.2rc6.txt for measured results, controls and limitations.

# 0.7.2rc5 — bounded Class3D wide local execution

Based on rc4. Fine angular tables now expand only retained parents, while
preserving the original orientation IDs and local priors. One vectorized
particle/orientation schedule serves the classes in a batch. Optional coarse
projection sharing requires sufficient reuse; it never persists across batches.
Class3D also gains a budgeted cooperative coarse window when a global bank
does not fit. Existing CUDA execution, fallback and checkpoint formats remain.

Existing commands work unchanged. Resume the same rc4 checkpoint with a new
output prefix for comparison. Keep your scientific search settings, including
`--sigma_ang 15`. No new mandatory dependency is introduced.

See `CLASS3D_WIDE_LOCAL_EXECUTION.txt` and `validation/class3d_rc5/` for controls,
measured performance, numerical comparisons and known baseline test failures.
The complete ZIP includes the wheel required by `install_local.cmd`.
Earlier release notes below are historical.

# 0.7.2rc4 — reuse-aware global fine execution

Candidate based on rc3, revised using the supplied server timing evidence.
Projector storage is normalized once after FFT, removing a full padded-model
copy at every fused dispatch. This benefits both global and local CUDA kernels.
The default retains the byte-bounded fine cache and accelerates only missing
projection rows. Existing dense/sparse scoring and tensor statistics reuse
those projections. An oversized bank no longer forces direct fused scoring.
No candidates or precision are removed.

- `--global-fine-mode auto` selects hybrid for eligible oversized CUDA fine
  banks; `hybrid` forces it, `cached` restores rc2, and `stream` retains rc3's
  explicit low-memory path.
- `--global-fine-statistics auto|tensor|fused` independently selects statistics
  for hybrid/stream. Auto uses tensor for hybrid and fused for stream.
- Hybrid retains the planned cache grant, using more memory than stream.
  A speedup on every GPU or dataset is not guaranteed.
- Existing checkpoints, bounded fallback and OOM recovery remain supported.
  Override saved cached/stream settings with `--global-fine-mode auto`.

See `HYBRID_FINE_EXECUTION.txt` and `validation/hybrid_fine/`. The following
sections are historical; rc3's automatic stream policy is superseded.

# 0.7.2rc3 — bounded global fine execution

Release candidate based on 0.7.2rc2. Global coarse search and global fine
search now have separate projection storage lifetimes and share one memory grant.
When the coarse bank fits but the full fine bank does not, CUDA with Triton
uses batch-scoped fine projection/scoring/statistics instead of replacing a
large cross-batch fine cache. Full candidate support and posterior selection
remain unchanged; floating-point reduction order can change poses near ties.

- `--global-fine-mode auto` is the default; `cached` restores rc2 fine execution.
  `stream` explicitly requests bounded streaming, including the eager fallback.
- `--global-fine-mib 512` caps the reusable fine buffer within the existing
  projection budget. It is not extra memory and does not cap posterior support.
- CPU, local search, first-iteration CC, fixed poses, strict-highres, combine,
  and reference execution retain their existing paths. Automatic selection also
  requires a complete coarse bank and an available optional Triton backend.
- A kernel compilation/validation failure uses the existing bounded PyTorch
  fallback. No new mandatory dependency. Real OOM retries only uncommitted work;
  rc2's recovery policy remains in place.
- The experimental cross-batch fine windows and factored dense scorer tested
  during development are not included: they did not improve measured runtime.

See `GLOBAL_FINE_EXECUTION.txt` and `validation/global_fine/` for validation,
commands, limitations and rollback. This does not fix the previously observed
full-size local reconstruction repeatability issue or certify final convergence.

# 0.7.2rc2 — bounded execution and recoverable memory backoff

Experimental execution-layer refactor based on 0.7.2rc1. See
`EXECUTION_REFACTOR.txt` and `validation/execution_refactor/` for scope and evidence.

- Global CUDA auto-refine: cooperative orientation tiles across bounded particle
  microbatches when neither the GPU nor host can retain the complete coarse bank.
  Every particle still uses the complete global posterior and adaptive threshold.
- New `--global-window-mib` ceiling (default 2048 MiB; 0 disables windows).
  This is an upper bound, not a reservation: admission uses unused planned
  headroom and a conservative live-payload estimate. Full-cache and local paths
  retain their existing schedules. The option is also a continuation override.
- Actual CUDA OOM: release speculative work, retry only uncommitted particles,
  then reconsider batch/cache/workspace limits at safe E-step boundaries after
  successful commits. Execution failures no longer permanently write zero cache
  capacity into the following iterations' configuration.
- Auto-refine and combine-refine share the recovery policy. Local search keeps
  exact per-batch admission so one broad posterior does not throttle unrelated
  batches. The scalar/reference backend and all scientific settings remain.
- This does not implement Bayesian polishing, alter reconstruction kernels, or
  claim to eliminate operating-system paging from unrelated memory pressure.
  The previously observed full-size local reconstruction repeatability issue
  is still unresolved. Do not treat this candidate as final scientific validation.

# 0.7.2rc1 — bounded global coarse projection reuse

Experimental cache optimization based on 0.7.1. When a complete global coarse
projection bank does not fit the GPU cache, retain a fixed GPU prefix and use
a separate bounded pinned-host bank for the remaining full complex64 planes.
No orientations, translations, pixels, or posterior candidates are removed.
Projection generation, scoring, and reconstruction formulas are unchanged.

- `--coarse-cache-policy auto` (default): fixed GPU rows plus host backing when
  the remaining bank fits its budget and system RAM headroom permits it.
- `--coarse-cache-policy fixed`: fixed GPU rows only, no host projection bank.
- `--coarse-cache-policy clock`: restore the 0.7.1 coarse-cache replacement path.
- `--coarse-host-cache-mib 1024`: separate retained host payload cap per engine;
  zero disables host backing. PyTorch's pinned allocator can reserve more RAM
  than the live payload. Windows Shared GPU Memory includes this intentional
  pinned allocation; its increase alone does not imply VRAM oversubscription.
- `--auto-cache-mib 0` still disables both GPU and host projection retention.

The host bank is not used when the coarse bank fits GPU cache, or in the
default streaming local-search path. It is discarded on source invalidation,
cache release, or OOM backoff. Host allocation failure falls back to fixed GPU
retention. Each worker has its own cap; aggregate host RAM scales with workers.

Known limitation: the previously observed full-size local reconstruction
repeatability anomaly is NOT fixed in this experimental version. Finite maps
and identical particle poses do not certify scientific correctness. This
release specifically addresses coarse-cache thrashing and needs separate
validation before scientific production use.

Windows: unpack the full package and use the included `.cmd` launchers with
the existing CUDA-enabled Python environment. See `CACHE_OPTIMIZATION.txt`.

---

# RELION-Torch v0.7.1 — Windows CUDA performance and reference fixes

Complete source distribution with all 17 command names, a matching wheel,
Windows launchers, regression tests and retained historical documentation.
Read **使用说明_v0.7.1.html** first. Current verification is in
**validation/v071/**; documents for older versions describe historical runs.

Use the existing Python environment that has CUDA-enabled PyTorch. No driver
or PyTorch replacement is needed:

```powershell
.\check_cuda.cmd
.\relion_torch_class2d.cmd --help
.\relion_torch_reconstruct.cmd --help
```

Direct Python launcher: `python launch_relion_torch.py COMMAND [OPTIONS]`.
Optional local virtual environment: `install_local.cmd` (shares the selected
Python's installed dependencies, installs only this wheel without dependencies).
To choose a Python explicitly, set `RELION_TORCH_PYTHON` to its executable path.

Changes: vectorized initial-noise repair across shells/groups; bounded CTF CUDA
reference building and fitting-statistics cache; positive-only stable LoG
candidate sorting; native RELION ISPG=0 volume recognition with explicit
`--ref_dim 2|3`; standalone fused insertion (`--gridding-backend auto`);
optional ordered 3D insertion (`--global-gridding ordered`,
`--local-gridding ordered`, or standalone `--gridding-backend ordered`).

Ordered insertion removes contended floating-point atomics in that stage.
Repeatability requires fixed inputs, seed, device, batching and worker schedule;
it is not a cross-hardware or multi-GPU bitwise guarantee. Default `auto` keeps
the faster existing atomic path. CTF execution options are excluded from the
scientific checkpoint signature; old checkpoints remain loadable.

## Historical v0.7.0 and earlier documentation

# RELION-Torch v0.7.0 — 0.6.2 merge and multi-GPU auto-picking

Complete distribution based on the supplied v0.6.2 checkpoint, with v0.6.0
auto-picking merged in. All 15 existing commands and v0.6.2 numerical modules
are retained; two auto-picking command names are added. No new runtime dependency.

See [Chinese installation and usage](RELEASE_v0.7.0_zh.md),
[compatibility audit](COMPATIBILITY_v0.7.0_zh.md), and
[current test report](TEST_REPORT_v0.7.0_zh.md).

```bash
python3 -m pip install --no-deps --force-reinstall dist/relion_torch-0.7.0-py3-none-any.whl
relion_pytorch_autopick --help
# Add --devices 0,1 to a picking command: one micrograph per GPU at a time.
```

Dynamic spawn workers keep one GPU each. The main process preserves the legacy
Gaussian stream and writes combined job output. CPU multi-process and real
single-GPU tests passed; this host has one GPU, so physical two-GPU execution
is an explicit untested boundary, with a hardware test supplied.

Historical instructions and test claims below belong to their original releases.
Use the v0.7.0 installation command for this merged package.

## Historical v0.6.2 documentation

# RELION-Torch v0.6.2 — writable combine metadata

Patch release on the verified v0.6.1 source. Copy the small defocus anchor and
astigmatism metadata arrays before passing them to torch, fixing the
non-writable NumPy warning under pandas Copy-on-Write. Three conversions in
two combine modules are changed; the scientific calculations and v0.6.1
optimization defaults are preserved. All 15 command names remain available.

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.6.2-py3-none-any.whl
python -c "import relion_torch; print(relion_torch.__version__, relion_torch.__file__)"
```

See [patch notes](READONLY_FIX_v0.6.2_zh.md),
[complete guide](COMBINE_REFINE_v0.6.2_zh.md), and [checkpoint](CHECKPOINT.md).
Current patch validation is in `validation/v062/`: all combine tests, including
warning-as-error Copy-on-Write reproduction and exact writable/read-only run
comparisons, installed-package checks and genuine v0.6.1 checkpoint continuation.
Earlier full-suite reports are historical. Physical CUDA was unavailable.

## Historical v0.6.1 release notes

# RELION-Torch v0.6.1 — bounded joint refinement optimization

Complete runnable release based on the published v0.6.0 distribution; all 15
console names retained. This version contracts joint defocus/translation
statistics before 3D insertion, allows existing guarded gridding with an
independent scoring cutoff, isolates failed posterior estimates, and reuses
fine geometry, projections and candidate CTFs across bounded defocus blocks.

See [Chinese usage guide](COMBINE_REFINE_v0.6.1_zh.md),
[release notes](RELEASE_v0.6.1_zh.md), [source audit](SOURCE_AUDIT_v0.6.1.md),
and [checkpoint](CHECKPOINT.md).

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.6.1-py3-none-any.whl
relion_torch_auto_combine_refine --help
```

Use the existing compatible PyTorch/CUDA environment. New defaults are
`--combine-execution optimized --combine-accumulation auto
--combine-defocus-chunk 4`. Auto contracts only with skip-gridding enabled;
iterative preweighting retains conservative accumulation unless explicitly
requested. `--combine-execution reference` preserves the v0.6.0 execution path.
Scientific support, priors, the full joint posterior, half identities and the
explicit scoring cutoff are preserved. Ordinary commands keep their defaults.

Current validation is in `validation/v061/`; older records are historical.
This host has CPU-only PyTorch. GPU speed, physical multi-GPU, GPU memory peaks,
and map quality on experimental data require same-checkpoint validation.

## Historical v0.6.0 release notes

# RELION-Torch v0.6.0 — independent 3D auto combine refinement

Complete runnable distribution based on the verified v0.5.17 checkpoint. Adds
`relion_torch_auto_combine_refine` while retaining all 12 existing commands.
See [Chinese usage guide](COMBINE_REFINE_v0.6.0_zh.md),
[release notes](RELEASE_v0.6.0_zh.md), and [checkpoint](CHECKPOINT.md).

Start from a converged ordinary auto-refine checkpoint (default reported
resolution 6 A or better). Broad local 5D coarse support feeds one 6D fine
posterior over orientation, translation and mean defocus. Set the scoring
high-frequency cutoff explicitly. Reconstruction uses the full box, with
candidate-specific CTF/CTF-squared weighted sums and independent half models.
Point-group symmetry, optics, optimized shared scorers, projection caches,
memory recovery, persistent workers and restart support are reused.

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.6.0-py3-none-any.whl
relion_torch_auto_combine_refine --help
```

Use an existing compatible PyTorch environment; the wheel does not bundle
PyTorch or CUDA. CPU and synthetic-data validation is recorded under
`validation/v060/`. Physical GPU speed, multi-GPU accuracy and experimental map
quality remain unverified. Prior release notes below are historical evidence,
not new validation of v0.6.0.

## Historical v0.5.17 release notes

# RELION-Torch v0.5.17 — bounded dense fine-score reuse

Complete runnable v0.5.16-based distribution, all 12 entry points retained.
See [Chinese release notes](RELEASE_v0.5.17_zh.md).

- Keep auto/dense GEMMs; share bounded projection tiles across particles when
  overlap and workspace allow. Preserve each particle's candidate rectangle.
- Avoid dense block ID roundtrips and single-class gather copies; prepare shifted
  real/imag inputs once and reuse score temporaries.
- Grow posterior budgets with optional 12.5%/64 MiB slack, falling back to exact
  demand when necessary. Preserve live allocator checks and true-OOM recovery.
- Use --fine-score-mode auto --dense-fine-execution auto, including when resuming
  a checkpoint saved by a sparse test. --dense-fine-execution reference selects
  the previous dense scorer for A/B, without rolling back other improvements.
- Shared preread, half isolation, coarse/fine grids, reconstruction and Triton
  kernels are unchanged. Local projection reuse remains off by default.

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.5.17-py3-none-any.whl
```

Use the existing CUDA/PyTorch/Triton environment. See validation/VALIDATION_v0.5.17.json.
No physical CUDA was available: CPU tests establish functional behavior and
operation-count changes, not real GPU speedup or experimental map quality.

## Historical 0.5.16 release notes

# RELION-Torch v0.5.16 — repeated posterior budget recovery

Complete runnable distribution based on v0.5.15, including all 12 commands.
See [Chinese release notes](RELEASE_v0.5.16_zh.md).

- Grow a broad single-particle posterior repeatedly using live CUDA headroom,
  even when projection storage is empty. Keep both posterior passes and other
  planned workspaces within the allocator/percentage limits and safety reserve.
- Rebuild bounded projection caches when necessary. Budget-only recovery does
  not trigger persistent OOM backoff; true CUDA OOM retains its recovery path.
- Preserve candidate support, scientific parameters, half separation, shared
  preread and v0.5.15 coarse/fine sizing. New diagnostics identify budget growth.
- Manual budgets remain manual. All command names and defaults are unchanged.

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.5.16-py3-none-any.whl
```

Use the existing CUDA/PyTorch/Triton environment. See
[validation](validation/VALIDATION_v0.5.16.json) for final installed-package checks.
No physical CUDA GPU was available; CPU kernels plus simulated memory observations
verify recovery logic, not experimental-data speed or physical GPU memory peaks.

## Historical 0.5.15 release notes

# RELION-Torch v0.5.15 — Auto-refine coarse/fine Fourier grid correction

Complete runnable distribution based on v0.5.14, including all 12 commands.
See [Chinese release notes](RELEASE_v0.5.15_zh.md).

- Deferred Auto-refine coarse banks use `coarse_size` when oversampling is enabled.
- Without oversampling, score at current likelihood size; strict-highres restricts
  both likelihood passes. Weighted sums and reconstruction retain `current_size`.
- The projection bank and memory planner now share the same coarse grid rule.
  Timing records expose actual coarse/fine likelihood sizes and planned payloads.
- Existing global fusion, gridding, symmetry, shared preread and skip-gridding
  controls are preserved. Local projection reuse remains off by default.
- Old checkpoints can be resumed. Correcting the coarse likelihood can change
  selected fine candidates, subsequent poses and the convergence trajectory;
  bitwise agreement with the previous erroneous coarse-size path is not expected.

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.5.15-py3-none-any.whl
```

Use the existing CUDA/PyTorch/Triton environment. Validation and limitations are
in [validation](validation/VALIDATION_v0.5.15.json). This build host has no physical
CUDA GPU: CPU functional tests do not establish server speedup or GPU memory peaks.

## Historical 0.5.14 release notes

# RELION-Torch v0.5.14 - shared symmetry, reconstruction and global-search optimization

Complete runnable distribution based on v0.5.13; all 12 commands and old
checkpoint continuation are preserved. See [Chinese release notes](RELEASE_v0.5.14_zh.md).

- Shared fused Fourier point-group summation for every supported non-C1 group,
  also used by standalone reconstruct. Original interpolation/support rules remain.
- Class3D/auto-refine expose --skip-gridding (default false) and --no-skip-gridding,
  including worker RPCs and final maps. Standalone reconstruct already supported it.
- Reuse blob geometry, FP64 preweight/FFT-input workspaces and SSNR statistics;
  batch finite-check readback and drop redundant copies/intermediate arrays.
- Fuse global coarse-score epilogues and FP32 raw weights, retaining GEMMs,
  shared projection caches, traversal scans, sorting and threshold/tie rules.
  Extend the existing preflight-guarded 3D insertion to global search.
- Add coarse projection/score/posterior and reconstruction detail intervals.

CUDA switches (auto/off/required): --symmetry-backend, --reconstruction-backend,
--global-fusion, --global-gridding. Local projection reuse stays off.

```bash
python -m pip install --no-deps --force-reinstall dist/relion_torch-0.5.14-py3-none-any.whl
```

Use the existing CUDA/PyTorch/Triton environment. Full evidence is in
[validation](validation/VALIDATION_v0.5.14.json) and the [source audit](SOURCE_AUDIT_v0.5.14.md).
CPU tests, Triton interpretation and offline sm_86/sm_89 compilation do not
establish physical-GPU performance or multi-GPU numerical equivalence.

## Historical 0.5.13 release notes

# RELION-Torch v0.5.13 — exact local candidates and bounded GPU input pipelines

Complete runnable distribution based on v0.5.12, with all 12 commands and
checkpoint continuation preserved.

- Exact C1 spherical-cap preselection using cached sorted direction geometry.
  Final priors, cutoff decisions, nearest-point fallback and global ordering
  follow the reference path. Other symmetry/one-axis modes keep that path.
- Indexed fine-score tiles use a separate workspace model; failed tiles are
  recomputed with the original bounded fallback chunks before any statistics.
- Batch-owned statistical factors and a fused private numerator/denominator
  kernel reduce preparation before 3D gridding. Existing insertion, atomic
  failure rules and reconstruction preweighting are unchanged.
- Fine input preparation, scoring, posterior, statistics and backprojection
  have all-call host/stream timing totals. Events are drained at existing
  synchronized batch boundaries; there are no added per-tile waits.

Defaults: `local-projection-reuse off`, `local-fine-inputs auto`.
New independent A/B switches (all default `auto`): `--local-candidate-search`,
`--local-fine-chunking`, `--local-statistics-inputs`; each also accepts `off`.

Install `dist/relion_torch-0.5.13-py3-none-any.whl` into the existing PyTorch
CUDA environment with `python -m pip install --no-deps --force-reinstall`.
See [Chinese release notes](RELEASE_v0.5.13_zh.md), [source audit](SOURCE_AUDIT_v0.5.13.md)
and [validation](validation/VALIDATION_v0.5.13.json). CPU tests, Triton CPU
interpretation and offline CUDA compilation are not physical GPU validation
or an end-to-end speedup measurement.

## Historical 0.5.12 release notes

# RELION-Torch v0.5.12 — indexed fine-score inputs

Complete distribution based on 0.5.11, preserving all commands, checkpoint
continuation, shared preread and existing reconstruction/symmetry behavior.

- Local fine scoring reads observations, CTF/noise and phase tables by GPU
  indices, avoiding parent-sized gathers and materialized shifted images.
- Parent/class schedules are prepared once per particle batch instead of
  reading fine-block indices back to the CPU before every score tile.
- Local projection reuse defaults to **off**, including CLI continuation from
  an older checkpoint. Explicit `--local-projection-reuse auto` retains the
  existing opt-in shared path. Statistics reduction and gridding stay auto.
- `--local-fine-inputs off` restores the previous input preparation for A/B
  timing; `--local-fusion off` retains the original unfused reference path.
- No candidate truncation, posterior-rule changes or precision reductions.

Install `dist/relion_torch-0.5.12-py3-none-any.whl` into the existing PyTorch
CUDA environment using `python -m pip install --no-deps --force-reinstall`.
See [Chinese installation and testing instructions](RELEASE_v0.5.12_zh.md),
[source audit](SOURCE_AUDIT_v0.5.12.md), and
[validation record](validation/VALIDATION_v0.5.12.json).
The build host has no available CUDA GPU: interpreter execution and offline
PTX/cubin compilation do not establish physical-GPU correctness or speedup.

## Historical 0.5.11 release notes

# RELION-Torch v0.5.11 — shared local projection and fused statistics/insertion

Complete distribution based on 0.5.10, including shared preread, all commands,
checkpoint continuation, and existing reconstruction/symmetry behavior.

- Local Gaussian search combines the existing batch-scoped projection slab
  with fused scoring. Repeated angles are interpolated once per retained row;
  oversized reusable unions split into bounded tiles. Low reuse stays direct.
- Local noise/scale statistics reduce into shell sums and scalar moments in
  the kernel, avoiding three full orientation-by-frequency output arrays.
- Local FP32 3D Fourier insertion fuses coordinate mapping, Hermitian folding,
  trilinear coefficients and grid updates. This is separate from RELION's
  `skip_gridding`, which skips iterative reconstruction preweighting.
- Defaults are automatic. Disable individual additions with
  `--local-projection-reuse off --local-statistics-reduction off --local-gridding off`.
  The existing `--local-fusion off` disables all local fused kernels.

Install `dist/relion_torch-0.5.11-py3-none-any.whl` into the existing PyTorch
environment. CUDA fusion requires a compatible Triton installation; no new
mandatory dependencies. See [Chinese release and testing instructions](RELEASE_v0.5.11_zh.md),
[source audit](SOURCE_AUDIT_v0.5.11.md), and [validation record](validation/VALIDATION_v0.5.11.json).
CPU regression, actual kernel interpretation, and offline CUDA compilation
are separate validation layers. This release has no physical GPU benchmark
from the build host; run the supplied CUDA tests on the deployment server.

## Historical 0.5.10 release notes

# RELION-Torch v0.5.10 — shared particle preread and iteration display

Complete distribution based on 0.5.9. All previous functionality is included;
no new dependencies or changes to the scoring/reconstruction algorithms.

- With `--devices` and `--preread-images`, one coordinator-owned raw float32
  cache is shared by all permanent workers, both auto-refine halves, and the
  coordinator. Particles are read directly into shared memory, not copied from
  a full private cache. No per-worker full-image allocation is made.
- Class2D, Class3D and auto-refine iteration summaries show `resolution=... A`.
  Each new iteration starts with `=============================`.
- Worker timing includes `particle_io` with shared-cache identity, private
  cache bytes, preread passes and cumulative disk-read batches.

Install `dist/relion_torch-0.5.10-py3-none-any.whl` in the existing PyTorch
environment. See [Chinese installation and usage](RELEASE_v0.5.10_zh.md),
[source audit](SOURCE_AUDIT_v0.5.10.md), and
[installed-wheel validation](validation/VALIDATION_v0.5.10.json).

Linux shared preread uses `/dev/shm`; it must have enough free space for the
single raw cache. `--preread-max-gib` limits that cache, not all process memory.
Worker models, metadata, bounded input batches and GPU workspaces are still
private. Without `--devices`, existing private preread behavior is preserved.
Physical CUDA/multi-GPU and NFS performance require hardware-side validation.

## Historical 0.5.9 release notes

# RELION-Torch v0.5.9 — native MWTCF and posterior unfiltered outputs

Complete distribution based on 0.5.8, preserving SIRM, optical corrections and
permanent device workers. No new dependencies.

- Auto-refine: `--do_mwtcf --mwtcf 0.5` uses native half1-weight FSC selection.
- `--force-converge` can finish a new run at iteration 1 with all final outputs.
- `--use-all-data` uses full-box Fourier support without forcing convergence.
- Class3D: `--write-unfil-map` writes posterior-weighted unfiltered maps each iteration.
- Standalone reconstruct no longer emits particle metadata STAR; split FSC STAR remains.

Install `dist/relion_torch-0.5.9-py3-none-any.whl`, or `python -m pip install .`.
See [Chinese installation and usage](RELEASE_v0.5.9_zh.md),
[source audit](SOURCE_AUDIT_v0.5.9.md), and
[installed-wheel validation](validation/VALIDATION_v0.5.9.json).
The implementation was validated on CPU, including permanent workers; real CUDA
and multi-GPU validation requires suitable hardware.

## Historical 0.5.8 release notes

# RELION-Torch v0.5.8 — shared SIRM and point-group reconstruction

Complete distribution based on 0.5.7. Class3D and auto-refine share the native
SIRM compact Fourier iteration with standalone reconstruct. Original raw weights
determine reliability; the last iteration is unconstrained. Independent unfiltered
half maps remain ordinary reconstructions. Standalone reconstruct now supports
Cn/Dn/T/O/I1-I4 using the same numerator/denominator symmetry operation as Class3D.
Existing optics and permanent workers are retained. No new dependencies.

Install `dist/relion_torch-0.5.8-py3-none-any.whl`, or `python -m pip install .`.
Add `--SIRM --thres_SIRM 0.3 --iter_SIRM 30` to Class3D or auto-refine.
Standalone reconstruction additionally accepts `--SIRM_weight_star Weight.star`
and `--sym I3`. New and continued tasks are supported; see the continuation
instructions before choosing a checkpoint.

See [中文安装和 SIRM 用法](RELEASE_v0.5.8_zh.md),
[source audit and intentional corrections](SOURCE_AUDIT_v0.5.8.md), and
[validation](validation/VALIDATION_v0.5.8.json).
The Class3D SIRM reliability uses per-class SSNR; auto-refine retains native
SIRM half-FSC calibration. Directional priors and MWTCF are separate features
and are not introduced by `--SIRM`. CUDA hardware validation remains conditional.

## Historical 0.5.7 release notes

# RELION-Torch v0.5.7 — shared beam-tilt and higher-order aberrations

Complete distribution based on 0.5.6. Class2D, Class3D, auto-refine and CTF
refinement share beam-tilt/Zernike parsing and optical phase conventions.
Alignment preparation demodulates odd aberrations exactly once; even
aberrations enter the common CTF gamma. Supports mixed optics groups,
batched/scalar preparation, local/global scoring and permanent workers.
Optics maps share the bounded preprocessing cache. No new dependencies.

Install `dist/relion_torch-0.5.7-py3-none-any.whl`, or `python -m pip install .`.
Nonzero `rlnBeamTiltX/Y`, `rlnOddZernike` and `rlnEvenZernike` are consumed
automatically; the existing Class3D command needs no new flags.
See [中文安装和修复说明](RELEASE_v0.5.7_zh.md),
[source audit](SOURCE_AUDIT_v0.5.7.md), and [validation](validation/VALIDATION_v0.5.7.json).
CPU validation is included; CUDA hardware validation remains conditional.

## Historical 0.5.6 release notes

# RELION-Torch v0.5.6 — permanent multi-GPU workers

Complete distribution based on 0.5.5. Class2D, Class3D and gold-standard auto-refine
support permanent per-device processes via `--devices 0,1`. Particle tasks share
frozen iteration models; raw Fourier sums and sufficient statistics are reduced
before model updates. Local fusion tiles and low-hit backprojection caches use
bounded adaptive execution. No new required dependencies.

Install `dist/relion_torch-0.5.6-py3-none-any.whl`, or `python -m pip install .`.
See [中文安装和多 GPU 说明](RELEASE_v0.5.6_zh.md),
[source audit](SOURCE_AUDIT_v0.5.6.md), and [validation](validation/VALIDATION_v0.5.6.json).
This build is validated on CPU; target CUDA and multi-GPU speed remain unmeasured.

## Historical 0.5.5 release notes

# RELION-Torch v0.5.5 — point groups and fused local execution

Complete distribution based on 0.5.4. Adds Cn, Dn, T, O, I1-I4 to shared
Class3D/Auto-refine sampling, priors, Fourier reconstruction and convergence.
Local execution retains multiple projection blocks through statistics, expands
CUDA batches/work tiles within budget, and optionally fuses interpolation with
Gaussian scoring and residual/scale statistics using Triton supplied by supported
PyTorch CUDA environments. CPU and unavailable-backend fallbacks are included.

Install `dist/relion_torch-0.5.5-py3-none-any.whl`, or `python -m pip install .`.
See [中文安装、续跑和性能说明](RELEASE_v0.5.5_zh.md),
[source audit](SOURCE_AUDIT_v0.5.5.md), and [validation](validation/VALIDATION_v0.5.5.json).
CUDA execution and real-data speed must be validated on the target GPU.

## Historical 0.5.4 release notes

# RELION-Torch v0.5.4 — shared streaming local projections

Complete package based on 0.5.3, with a shared local projection execution path
for Class3D angular priors and gold-standard auto-refine. It compacts actual
candidates, deduplicates requests, scores coarse blocks immediately, expands
retained fine parents, and reuses a bounded batch-scoped projection buffer.
No new runtime dependencies. Global search and CTF refinement remain available.

Install `dist/relion_torch-0.5.4-py3-none-any.whl` in the existing environment.
See [usage and timing (中文)](LOCAL_PROJECTION_v0.5.4_zh.md),
[source audit](SOURCE_AUDIT_v0.5.4.md), and
[validation](validation/VALIDATION_v0.5.4.json).
Local searches default to `--local_projection_mode stream` with a 128 MiB
retained buffer limit; `cached` provides the previous execution path for A/B tests.
Scientific sampling and convergence rules are retained. Floating-point operation
order can differ. CUDA performance must be measured on the target hardware.

## Historical 0.5.3 release notes

# RELION-Torch v0.5.3 — restore automatic fine-projection cache planning

Complete package based on 0.5.2. Removes the new-run default 2 GiB ceiling that
overrode automatic GPU planning. Global auto-refine can prefer a complete fine
bank over larger tiles/batches; plans now report coarse and fine separately.
Explicit cache limits, allocator guards and persistent OOM backoff remain.

Install `dist/relion_torch-0.5.3-py3-none-any.whl`, or run
`python relion_pytorch_auto_refine.py --help` from this directory.
Read [the 0.5.3 fix and continuation guide (中文)](AUTO_REFINE_v0.5.3_zh.md),
[source audit](SOURCE_AUDIT_v0.5.3.md), and
[validation](validation/VALIDATION_v0.5.3.json).

New runs default to `--auto_cache_mib -1` (use planned budget). When continuing
a 0.5.2 checkpoint, explicitly add that flag to remove its saved 2048 MiB cap.
Zero disables projection residency; positive values keep explicit MiB ceilings.
No new dependencies or changes to scientific sampling/convergence formulas.
GPU performance and real large-data validation remain pending.

## Historical v0.5.2 release notes

# RELION-Torch v0.5.2 — bounded auto-refine execution

Complete executable source and wheel based on 0.5.1. Adds exact selected angular
pairs, half-scoped cross-batch projection caching, persistent scoring-OOM
backoff, locality scheduling, shared direction statistics/grouped insertion,
batched coarse scoring and bounded metadata readback. No new dependencies.

Install `dist/relion_torch-0.5.2-py3-none-any.whl`, or run
`python relion_pytorch_auto_refine.py --help` from this directory.
Read [the 0.5.2 guide (中文)](AUTO_REFINE_v0.5.2_zh.md),
[source audit](SOURCE_AUDIT_v0.5.2.md), and
[validation](validation/VALIDATION_v0.5.2.json).

Defaults: `--auto_execution optimized --auto_cache_mib 2048`.
`--auto_execution reference` retains the 0.5.1 execution path for comparisons.
Positive strict-highres retains parent accumulation; other optimizations still
apply. Sequential independent halves and all 0.5.1 scientific fixes are retained.
CUDA tests and real-data speed/resolution measurements remain pending on a GPU.

## Historical v0.5.1 release notes

# RELION-Torch v0.5.1 — auto-refine sampling and convergence fixes

Complete package based on 0.5.0. Aligns iteration coarse-size timing, the
effective RELION 3.1.4 MPI leader convergence grid, and randomized accuracy
probe selection. Persists diagnostic identities and leader state across
continuation. No new runtime dependency; Class2D/Class3D/CTF kernels unchanged.

Install `dist/relion_torch-0.5.1-py3-none-any.whl`, or run
`python relion_pytorch_auto_refine.py --help` from this source tree.
Read [the 0.5.1 guide (中文)](AUTO_REFINE_v0.5.1_zh.md),
[source audit](SOURCE_AUDIT_v0.5.1.md), and
[validation](validation/VALIDATION_v0.5.1.json).
For a complete comparison with native RELION, start a new run from the same
particles and initial reference; continuing 0.5.0 does not redo old iterations.

## Historical v0.5.0 release notes

# RELION-Torch v0.5.0 — gold-standard C1 3D auto-refine

Complete package based on 0.4.3. Adds `relion_pytorch_auto_refine`: independent
halves executed sequentially on one CPU/CUDA device, shared FSC scheduling,
automatic sampling/convergence, masked FSC, final full-data reconstruction and
resumable dual-model checkpoints. Reuses the Class3D E/M kernels and optical
observation model. No runtime dependency was added.

Install `relion_torch-0.5.0-py3-none-any.whl`, or run
`python relion_pytorch_auto_refine.py --help` from this complete source tree.
Read [the auto-refine guide (中文)](AUTO_REFINE_v0.5.0_zh.md),
[source mapping](SOURCE_AUDIT_v0.5.0.md) and
[validation](validation/VALIDATION_v0.5.0.json).
Scope: C1, K=1, single-body 2D SPA with a common box/pixel size.
CPU integration/regression tests were run; CUDA hardware and real-data/native
RELION executable comparisons are still pending. Multi-GPU execution is not
enabled; half worker/device boundaries are explicit for the future scheduler.

## Historical v0.4.3 release notes

# RELION-Torch v0.4.3 — create CTF spill directories only when needed

Based on v0.4.2. RAM-only CTF fitting units no longer create and delete empty
`ctf_fit_*` directories. The first actual disk-spill block creates one private
directory per unit, with the existing cleanup on success or failure. Cache
limits, numerical algorithms, CLI options and checkpoint signatures are unchanged.
No runtime dependency was added.

Install `relion_torch-0.4.3-py3-none-any.whl`, or use the source launcher.
See [timing analysis and the directory fix (中文)](CTF_TIMING_ANALYSIS_v0.4.3_zh.md)
and [validation](validation/VALIDATION_v0.4.3.json). GPU-resident statistics and
larger work chunks are proposals/experiments, not changes in this release.

## Historical v0.4.2 release notes

# RELION-Torch v0.4.2 — optional CTF timing

Based on v0.4.1, with optional `relion_pytorch_ctf_refine --timing` profiling.
Records all-call inclusive/exclusive wall times, bounded CUDA event samples,
logical transfer payloads, objective evaluations and per-unit memory/cache
diagnostics. Covers particle I/O, Fourier transforms, reference projection,
statistics transfers, CTF loss/gradient, L-BFGS overhead and global optics fits.
Writes cumulative JSON/TXT and incremental per-unit JSONL; normal interruption
retains partial timing. Timing defaults off and does not change scientific
options, fitting precision or the completed-stage checkpoint signature.

Install `relion_torch-0.4.2-py3-none-any.whl`, or use the source launcher.
No runtime dependency was added. Read [the timing guide (中文)](TIMING_v0.4.2_zh.md)
and [validation](validation/VALIDATION_v0.4.2.json). CPU validation includes
identical fitted STAR files with timing on/off; actual CUDA validation requires
a CUDA host. CUDA event samples are stream intervals, not GPU utilization.

## Historical v0.4.1 release notes

# RELION-Torch v0.4.1 — writable metadata and CTF fitting progress

Fixes read-only pandas/NumPy metadata warnings through the shared owned-array
conversion. CTF angles and origins are covered as well as CTF parameters.
Independent L-BFGS line searches now evaluate only pending particles, retaining
per-particle normalization, step acceptance and stopping rules.

CTF fitting reports preparation/optimization time, CPU/disk statistics cache,
iteration/evaluation counts and current process/CUDA memory. Long fits emit
progress approximately every ten seconds between work operations. Completed
0.4.0 scientific stages remain resumable; the checkpoint schema is unchanged.

**Read [the v0.4.1 fix and pause-diagnosis guide (中文)](CTF_FIXES_v0.4.1_zh.md).**
Install `relion_torch-0.4.1-py3-none-any.whl`, or use the source launcher.
The complete v0.4.0 features and no-micrograph restrictions remain in force.
No runtime dependency was added. Validation is recorded in
[`validation/VALIDATION_v0.4.1.json`](validation/VALIDATION_v0.4.1.json).

## Historical v0.4.0 release notes

# RELION-Torch v0.4.0 — CTF and optical refinement

Complete release based on v0.3.9, adding `relion_pytorch_ctf_refine` (alias
`relion_torch_ctf_refine`). Fits particle/micrograph CTF parameters and global
optics-group magnification, beam tilt, trefoil and even Zernike aberrations.
Uses existing NumPy/PyTorch dependencies, analytic/autograd derivatives and
L-BFGS; runs on CPU or CUDA. No native RELION installation is needed at runtime.

**Start with [the CTF refinement guide (中文)](CTF_REFINE_v0.4.0_zh.md).**
Install `relion_torch-0.4.0-py3-none-any.whl` into the existing PyTorch environment,
or run `python relion_pytorch_ctf_refine.py --help` from this source distribution.

Without micrograph names, only independent particle defocus and fits aggregated
over each original optics group are allowed. Input astigmatism, phase, B/scale
and separate Cs fields are preserved, including during magnification fitting.
Half labels and fixed poses are retained; half-map routing follows each native
RELION 3.1.4 estimator. GPU work is chunked; large host statistics spill to disk.

The shared observation model also supports optical corrections in standalone
3D reconstruction with `--ctf` and a common image grid. Class3D/auto-refine is
not extended to full optical corrections by this release.

See [source mapping and numerical differences](SOURCE_AUDIT_v0.4.0.md) and
[validation](validation/VALIDATION_v0.4.0.json). Real CUDA performance and native
RELION end-to-end numerical identity are not claimed by CPU-only validation.

## Historical v0.3.9 release notes

# RELION-Torch v0.3.9 — CC and strict-resolution algorithm corrections

Complete release based on v0.3.8. Fixes first-iteration CC frequency support,
strict-highres likelihood projection sizes, and CC+ini_high reference spectra.
The likelihood and spectrum helpers are shared by Class3D, Class2D and the
applicable generic alignment paths. Strict scoring still accumulates current-size
weighted sums for reconstruction. Class3D automatic GPU memory planning is retained.

**Start with [the v0.3.9 installation and correction guide (中文)](ALGORITHM_FIXES_v0.3.9_zh.md).**
Install `relion_torch-0.3.9-py3-none-any.whl` in the existing PyTorch environment.
No new runtime dependency or command-line switch is required.

Validation: [v0.3.9 report](validation/VALIDATION_v0.3.9.json), independent
source-formula tests, Class2D/Class3D integration, simulated CUDA memory/OOM,
and real v0.3.8 checkpoint transitions. CUDA tests remain hardware-dependent;
no RTX 4090 benchmark or full native RELION E/M parity is claimed.

## Historical v0.3.8 release notes

# RELION-Torch v0.3.8 — automatic Class3D GPU memory planning

Complete release based on v0.3.7. CUDA Class3D now defaults to automatic cache and
workspace planning. Use `--gpu-memory-percent 100` (default) or a lower percentage;
256 MiB to 1 GiB is reserved for the desktop. Full coarse banks take priority,
plans refresh at iteration boundaries, and E-step caches are released before reconstruction.
Scientific candidate support, local search, continuation and progress are retained.

**Start with [the v0.3.8 installation and memory guide (中文)](MEMORY_v0.3.8_zh.md).**
Install `relion_torch-0.3.8-py3-none-any.whl` into your existing PyTorch environment.
Legacy byte limits are superseded in automatic CUDA mode; `--no-auto-memory` restores them.
CPU execution retains manual budgets. No new runtime dependencies.

Validation: [v0.3.8 report](validation/VALIDATION_v0.3.8.json). CPU numerical tests,
simulated CUDA memory/OOM tests and actual v0.3.7 checkpoint transitions are included.
Real CUDA tests are supplied but skipped on the CPU-only validation host.
No RTX 4090 speed or peak-memory result is claimed.

## Historical v0.3.7 release notes

# RELION-Torch v0.3.7 — Class3D scoring and cache execution improvements

Complete release based on v0.3.6. Adds adaptive global scoring tiles with reusable
CTF/noise factors, working-set coarse/fine cache allocation, packed second-chance
projection caches, cached Euler inverses and Fourier geometry, and packed direction
statistics. Full coarse banks, local search, continuation and progress are retained.
Scientific objectives and candidate support are unchanged; floating-point order can differ.
No new runtime dependency or Triton kernel is introduced.

**Start with [the v0.3.7 installation, performance and Triton guide (中文)](PERFORMANCE_v0.3.7_zh.md).**
Install `relion_torch-0.3.7-py3-none-any.whl` into the existing PyTorch environment.
Existing commands and v0.3.6 checkpoints work; optimizations are on by default.
`--coarse-score-chunk-size 0` is automatic; a positive value caps the global score block.

Validation: [v0.3.7 report](validation/VALIDATION_v0.3.7.json). Source and installed-wheel
CPU tests plus actual older checkpoint transitions are checked. CUDA tests are supplied
but skipped on this CPU-only validation host; RTX 4090 speedup is not measured.

## Historical v0.3.6 release notes

# RELION-Torch v0.3.6 — Class3D particle progress display

Built on the complete v0.3.5 release. Class3D now shows a particle progress bar
with completed/total counts, percentage, elapsed time and estimated remaining
particle time. Interactive terminals refresh in place; redirected output gets
occasional newline snapshots. Reconstruction and file-writing phases are named
separately. No additional CUDA synchronization, threads or dependencies are used.

**Start with [the v0.3.6 installation and progress guide (中文)](PROGRESS_v0.3.6_zh.md).**
Install `relion_torch-0.3.6-py3-none-any.whl` in the existing PyTorch environment.
Original commands show progress by default; `--no-progress` disables the display
and `--progress` enables it, including during continuation. All v0.3.5 scientific
calculations and local-search optimizations are retained.

Validation: [v0.3.6 report](validation/VALIDATION_v0.3.6.json). Validation uses CPU
PyTorch; CUDA-specific tests are skipped on this host. Historical reports below
describe their respective releases.

## Historical v0.3.5 release notes

# RELION-Torch v0.3.5 — Class3D local search execution optimizations

Based on the complete v0.3.4 release. Local coarse projections use a fixed-capacity
contiguous cache even when the global grid exceeds the payload budget. Local
scoring reuses each particle's shifted observations across angle blocks, and
cache lookup reuses host sampling IDs without reading them back from CUDA.
The complete-bank path remains available for large caches. Scientific sampling,
priors, posterior selection, fine search and reconstruction formulas are unchanged.

**Start with [the v0.3.5 installation and performance guide (中文)](LOCAL_PERFORMANCE_v0.3.5_zh.md).**
Install the supplied wheel into your working CUDA/PyTorch environment:
`python -m pip install --no-deps --force-reinstall relion_torch-0.3.5-py3-none-any.whl`.
Existing v0.3.4 checkpoints and command-line options remain supported. The three
optimizations activate automatically for local angular search.

Validation: [v0.3.5 results](validation/VALIDATION_v0.3.5.json). Source and installed
wheel tests include bounded-cache eviction, blocked/pairwise score comparisons,
full iterations and real older checkpoint continuations. The validation host has
CPU-only PyTorch; CUDA tests are supplied but skipped here. GPU speedup is not
measured. Different matrix multiplication shapes can change floating-point rounding.

## Historical v0.3.4 release notes

# RELION-Torch v0.3.4 — Class3D local angular search

Built on the complete v0.3.3 source. Adds C1 local angular support, compact batched scoring, native local priors, stable global direction IDs and continuation controls. Existing v0.3.3 global scoring and grouped-statistics optimizations remain enabled.

**Start with [the v0.3.4 installation and local-search guide (中文)](LOCAL_SEARCH_v0.3.4_zh.md).** Install with `python -m pip install --no-deps --force-reinstall relion_torch-0.3.4-py3-none-any.whl` in your working PyTorch environment. All four angular sigma options default to -1 for a new run. Class3D GUI range ±5 degrees corresponds to `--sigma_ang 1.66667`. Continue a saved run to enable, adjust, preserve or disable local search.

Shared modules implement support/priors, indexed projection storage, and particle-specific coarse-to-global mapping. This release does not add auto-refine scheduling. No runtime dependencies added. Native RELION source reference: 3.1.4, commit 2448e08fd216f66ac0471e642ad448b529f12994.

Validation: [environment and results](validation/VALIDATION_v0.3.4.json). CPU tests cover numerical/reference comparisons, full iterations, memory budgets, CLI and genuine older checkpoints. CUDA is unavailable on the validation host; no GPU speedup is claimed.

---

## Historical v0.3.3 release notes

# RELION-Torch v0.3.3 — Class3D bounded execution optimizations

Built on the complete v0.3.2 source. Class3D now uses budgeted contiguous coarse projection banks, orientation-coalesced statistics with packed batched backprojection sums, positive-weight compaction before coarse sorting, and early class-support/CC-only scoring. Sampling, posterior thresholds and scientific model updates are preserved; floating-point accumulation order can differ.

**Start with [the v0.3.3 installation and performance guide (中文)](CLASS3D_PERFORMANCE_v0.3.3_zh.md).** Install into your existing working CUDA/PyTorch environment with `python -m pip install --no-deps --force-reinstall relion_torch-0.3.3-py3-none-any.whl`. Existing commands and 0.3.1/0.3.2 checkpoints remain supported. The four optimizations activate automatically within existing memory budgets.

Reusable primitives live in `inference/` and `alignment/`; this release does not add auto-refine. Class2D retains its existing execution behavior; its phase-basis/planning primitives are now shared imports. No runtime dependencies were added.

Current validation: [source tests](validation/TEST_REPORT_v0.3.3.txt), [installed-wheel tests](validation/TEST_REPORT_WHEEL_v0.3.3.txt), and [environment/provenance](validation/VALIDATION_v0.3.3.json). CPU synthetic validation does not establish CUDA speedup or agreement with a native RELION executable. Floating-point regrouping is tested with numerical tolerances, not claimed bitwise equal across releases.

---

## Historical v0.3.2 release notes

# RELION-Torch v0.3.2 — Class3D continuation with new sampling

Built on the complete v0.3.1 source. Class3D can now resume its own checkpoints with a new `--healpix-order`, `--psi-step`, `--oversampling`, `--offset-range` or `--offset-step`. Changing the direction grid applies RELION 3.1.4's joint direction-prior reset while preserving the saved model and class probabilities. Unchanged sampling retains the previous exact-resume behaviour. Class2D runtime code is unchanged from v0.3.1.

**Start with [the v0.3.2 installation and continuation guide (中文)](CONTINUATION_v0.3.2_zh.md).** Install the wheel into the existing working environment with `python -m pip install --no-deps --force-reinstall relion_torch-0.3.2-py3-none-any.whl`. A v0.3.1 checkpoint can be continued directly; no fresh initialization is required for this feature.

Current validation: [source tests](validation/TEST_REPORT_v0.3.2.txt), [installed-wheel tests](validation/TEST_REPORT_WHEEL_v0.3.2.txt), and [environment/provenance](validation/VALIDATION_v0.3.2.json). CPU synthetic tests do not establish CUDA performance or numerical agreement with a native RELION run.

## Algorithm fixes inherited from v0.3.1

Based on the supplied v0.3.0 source. Fixes Class3D scale statistics, initial reference spectra and data-versus-prior, high-frequency noise/norm power, and fresh-input noise grouping for both Class2D and Class3D. Corrected Class2D formulas are shared with Class3D.

See [the v0.3.1 algorithm changes (中文)](ALGORITHM_FIXES_v0.3.1_zh.md) for historical details. Its advice to start a new run concerned the v0.3.0-to-v0.3.1 initialization and grouping fixes.

## Class3D capabilities inherited from v0.3.0

**Read [the Class3D manual](CLASS3D_v0.3.0_README_zh.md) before use.** This release supports C1, global HEALPix/adaptive search, fixed poses, translation-only classification, one/multiple 3D seeds, CTF/norm/scale, bounded model caches, iteration checkpoints, input STAR row preservation and timing. It is not a complete RELION replacement or gold-standard auto-refine.

Non-C1 symmetry and unsupported modes are rejected explicitly. No new runtime dependencies were added. Validation is CPU synthetic only; there was no CUDA hardware or native RELION executable in the build environment.

See [original source provenance and boundaries](SOURCE_AUDIT_v0.3.0.md) and `tests/`. Older versioned files and pre-existing unversioned validation reports are retained historical records. The v0.3.2 guide supersedes the old Class3D manual's restriction on continuation sampling changes.

---

## Existing Class2D and primitive documentation (retained from v0.2.17)

# 0.2.17 update — cost-model fine scorer selection

Class2D `--fine-score-mode auto` no longer uses the fixed 0.35 retained-parent
density threshold.  It now compares deterministic dense and sparse execution
costs from the exact active coarse-orientation blocks, translation rectangle,
active Fourier support, dense GEMM block fill, workspace feasibility and
expected GEMM/tile calls.  This targets the large mid-density regime where
regular GEMMs can be much faster despite evaluating more child hypotheses.
Explicit `dense` / `sparse` modes and first-iteration CC behavior are unchanged.
See `V0.2.17_FINE_SCORE_COST_MODEL_NOTES_zh.md`.

# 0.2.16 update — late sparse parent supertiles

When Class2D auto mode rejects orientation-major statistics, sparse retained
parents can now be packed across class boundaries into bounded supertiles.
This reduces late-iteration tiny-kernel fragmentation while retaining the
v0.2.15 parent ordering and grouped-backprojection semantics.  Explicit
`--weighted-sum-layout parent` retains the prior per-class path for A/B tests.

# 0.2.15 update — cache residency, adaptive orientation cost, compact scheduling and stable STAR order

Class2D now gives grouped-backprojection cache residency priority to the full K-class
set whenever it fits inside the bounded candidate workspace, preventing cyclic LRU
thrashing as the Fourier working size grows. Orientation-major auto selection uses a
work model instead of the former fixed 50% translation-density gate (the common
oversampling=1 / 21-translation case crosses near 26.8%). Its production scheduler
uses a dense coarse-grid marker and reconstructs compact group metadata on-device,
substantially reducing parent-level D2H/H2D traffic. Fine-prior packing follows
`--weight-precision float32` end-to-end. `_data.star` output is restored to immutable
input-row order through a private source-row mapping that never leaks into STAR files.
Generic Class3D/auto-refine execution remains unchanged. See
`V0.2.15_CACHE_COST_METADATA_ORDER_NOTES_zh.md`.

# 0.2.14 update — dedicated Class2D orientation-major supertiles

Class2D orientation-major weighted sums now bypass the parent Fourier iterator.
Retained integer parent metadata are grouped first, consecutive groups from one
class are merged into orientation-aware bounded supertiles, and each supertile
uses one packed FP32 GEMM for weighted phase, phase power and translation moments.
The mature parent-major route remains the fallback and the generic Class3D/auto-refine
foundation is unchanged. See `V0.2.14_ORIENTATION_SUPERTILE_NOTES_zh.md`.

# 0.2.13 update — Class2D orientation-major weighted sums and accelerator FP32 weights

Class2D can now group retained fine translations by particle/class/fine orientation
before evaluating noise, scale, offset and backprojection statistics. The grouped
weight matrix and weighted phase are reused across all of those terms. This is
deliberately a **Class2D-only** execution path; generic alignment remains on the
translation-parent layout for future Class3D/auto-refine work.

The default Class2D hypothesis-weight arithmetic and hot weighted-sum statistics
now use float32, following the native RELION accelerator representation. Use
`--weighted-sum-layout parent --weight-precision float64 --accumulation-precision float64`
for a conservative v0.2.12-style A/B comparison. No new runtime dependency or
custom CUDA extension is required.

See [V0.2.13_ORIENTATION_WSUM_FP32_NOTES_zh.md](V0.2.13_ORIENTATION_WSUM_FP32_NOTES_zh.md)
and [TEST_REPORT_v0.2.13.txt](TEST_REPORT_v0.2.13.txt).

# 0.2.12 update — accumulation statistics and direct dimensional output

Reuse noise/scale intermediates; compute active Fourier phases only for eligible
premerged tiles; reduce already-clamped residuals by particle before radial shells
in a bounded float64 buffer. Candidate scheduling and startup algorithms are unchanged.

**2-D references are written directly as indexed MRCS stacks; 3-D references remain
individual MRC volumes.** No temporary per-class 2-D images, stack readback, or
model-STAR rewrite is needed. The existing unmasked diagnostic MRCS is retained.
Use a new output prefix: stale files from earlier versions are not deleted.

See [Chinese release notes](V0.2.12_ACCUMULATION_IO_NOTES_zh.md),
[test report](TEST_REPORT_v0.2.12.txt) and [numerical summary](NUMERICAL_SUMMARY_v0.2.12.json).
`--accumulation-statistics v0211` is an independent statistic-order control;
it retains the new stack-only output. No additional runtime dependencies.

# 0.2.11 update

Compact, class/group-aligned candidate scheduling and launch-aware weight coalescing;
a bounded shared startup mask/FFT pass for noise spectra and initial references;
optional RELION 3.1 `--fast_subsets` with saved particle permutation; separate
startup timing and fully covered per-batch scheduling sub-stages.

See [Chinese usage and validation notes](V0.2.11_SCHEDULE_INIT_SUBSETS_NOTES_zh.md)
and [test report](TEST_REPORT_v0.2.11.txt). Defaults still use **all particles**.
Use `--candidate-schedule v0210 --initialization-mode legacy` for the retained
0.2.10 schedule/startup paths. No additional runtime dependency or CUDA build.

# 0.2.10 update

Shared bounded particle-batch preparation, RELION C++ ROUND edge parity,
weighted-phase reuse, bounded early weight coalescing, iteration-scoped LRU
gridding sums, and sampled detailed timing. See
[V0.2.10_BATCH_PERFORMANCE_NOTES_zh.md](V0.2.10_BATCH_PERFORMANCE_NOTES_zh.md)
and [TEST_REPORT_v0.2.10.txt](TEST_REPORT_v0.2.10.txt).
No new runtime dependencies. CUDA performance has not been measured in this build environment.

# Release 0.2.9 — bounded candidate execution

See [0.2.9 Chinese release notes](V0.2.9_CANDIDATE_PERFORMANCE_NOTES_zh.md) and
[actual test report](TEST_REPORT_v0.2.9.txt) before using the new default.

This release removes repeated dynamic indexing, prunes exactly-zero retained
parents, groups weighted 2D backprojection by orientation, and adds bounded
regular GEMM fine scoring. Particle preprocessing and runtime dependencies are
unchanged. `--performance-mode v028` preserves the former cached execution path.
**New defaults change floating-point summation order. One deliberately weak,
underpopulated stress case amplified small grid changes to ~7.7% map relative-L2;
this is not a strict lossless/bitwise release.** Grouping can be independently
switched off. CPU benchmarks are 1.6–1.67x overall; no GPU benchmark was possible.

The README sections and reports below are retained release history. Where their
0.2.8 optimized-mode claims differ, the 0.2.9 notes above take precedence.

---

# Current release: 0.2.8 — bounded, equivalent Class2D performance optimizations

Built directly on the exact 0.2.7 streaming-I/O source. See
[Chinese analysis / commands](V0.2.8_LOSSLESS_PERFORMANCE_NOTES_zh.md),
[source audit](SOURCE_AUDIT_v0.2.8.md), and [validation report](TEST_REPORT_v0.2.8.txt).

Reuse retained posterior weights, existing translation phases, bounded active
Fourier views and class-independent backprojection geometry. Preserve scientific
parameters, numerical types, original particle/hypothesis order, and compute
batch/chunk boundaries. Single-orientation gridding retains the original path.
All 0.2.7 bounded particle reading and CPU pre-read/device-pool controls remain.

`--performance-mode optimized` is the default. `--performance-mode reference`
retains the 0.2.7 computation path for A/B. `--performance-cache-mib 256` limits
new geometry/active-view tables (not total RAM/VRAM). `--timing` writes synchronized
stage timings to `<output>_timing.jsonl`; `--no-timing` explicitly disables them.

327 tests passed, 10 CUDA tests skipped. Independent original-0.2.7 CPU process
comparisons yielded exactly equal scientific tensors. Component and small
synthetic end-to-end CPU benchmarks are included; no real 27,000-particle CUDA
speedup or cross-hardware bitwise guarantee is claimed. This release does not
add a complete Class3D/auto-refine scientific state machine.

Historical releases follow below.

---

# Current release: 0.2.7 — bounded particle I/O, CPU pre-read, device pools

Built directly on the exact uploaded 0.2.6 projector-support/init source.
Read [Chinese usage and analysis](V0.2.7_PARTICLE_IO_NOTES_zh.md),
[source audit](SOURCE_AUDIT_v0.2.7.md), and [test report](TEST_REPORT_v0.2.7.txt).

Default particle reads now seek/read selected slices instead of retaining an
unbounded dictionary of full-stack memmaps. CPU disk batches, optional full
CPU raw-image pre-read, and raw device pools have separate controls. Class2D
initialization and iterations share one raw store; current 2D/3D alignment
uses the same infrastructure. Computation batch boundaries are unchanged.

304 CPU tests passed; 1 CUDA test was skipped (no GPU). Seven independent
synthetic comparisons against untouched 0.2.6 matched exactly on CPU.
A controlled low-FD test reproduced the original NoneType.ndim failure and
passed with both new backends. Real 27,000-particle CUDA/NFS execution is NOT
claimed. Full Class3D/auto-refine scientific state machines are not added.

Everything below this separator is retained historical release information.

---

# Current release: 0.2.6 — projector source support and reference-free initialization

Based on the exact supplied 0.2.5 source tree. **Use these current documents:**
[release notes](V0.2.6_PROJECTOR_SUPPORT_INIT_NOTES.md),
[commands](CLASS2D_COMMANDS_v0.2.6.md),
[source audit](SOURCE_AUDIT_v0.2.6.md).

Finite circular/spherical source support is applied BEFORE interpolation,
with zero halo and nonperiodic Nyquist-neighbor reads. Iteration current_size
is distinct from coarse/fine output_size; source changes invalidate caches.
Reference-free RELION initialization resolves automatic ini_high before seed
reconstruction and persists it through low-pass, CC and continuation.

259 CPU tests pass. H200 particle-score/EM reruns and CUDA performance are not
claimed. Older release sections below are retained as historical documentation.

---

# Current release: 0.2.5 diagnostics / I/O fix

Based on the exact 0.2.4 source package. Read
[V0.2.5_DIAGNOSTICS_IO_NOTES.md](V0.2.5_DIAGNOSTICS_IO_NOTES.md) and
[CLASS2D_COMMANDS_v0.2.5.md](CLASS2D_COMMANDS_v0.2.5.md) for the current changes.
Writable norm metadata, explicit current-resolution logging, native Class2D
10-particle/metadata-Euler accuracy diagnostics, and numeric STAR NaN output.
Class2D EM priors, physical transforms and reconstruction kernels are unchanged.
Earlier release notes below are historical, not claims of new validation.

---

# Current release: 0.2.4 — Class2D translation-prior and DC reporting fixes

Default Class2D priors reproduce the pinned RELION 3.1 native distance formula
and GPU log-prior convention. `--debug-dimensionally-consistent-prior` is opt-in
and OFF by default. `--translation-prior-normalization cpu` supports comparison
with native CPU DLL outputs without undoing the coordinate fix.

See [release notes](V0.2.4_TRANSLATION_PRIOR_DC_NOTES.md),
[commands](CLASS2D_COMMANDS_v0.2.4.md), and [source audit](SOURCE_AUDIT_v0.2.4.md).
Per-class resolution now scans DC; working-size scheduling is unchanged.
The following sections include retained historical project documentation.

---

# RELION-Torch 0.2.3

Class2D EM state-machine update based on the exact 0.2.2 source.

**Start here:** [current commands](CLASS2D_COMMANDS_v0.2.3.md),
[implementation and limits](V0.2.3_CLASS2D_STATE_MACHINE_NOTES.md),
[upstream source audit](SOURCE_AUDIT_v0.2.3.md).

Norm/scale, class-specific offset priors, sparse/dense/fixed moments, seed/CC
transitions, solvent flattening, perturbation, conditional coarser sampling and
same-version exact continuation are now wired into the running optimiser.
CTF and corrected-reference flags are explicit and default OFF. First-CC
remains ON by project policy. Use matched flags for native comparisons.

163 CPU tests pass. This is not a claim of demonstrated H200/CUDA 25-iteration
parity, or support for every optional RELION observation model. See limits above.
Earlier version-specific sections below are historical, not this release's CLI contract.

---

# relion-torch 0.2.1 — Class2D geometry and state parity

A pip-installable PyTorch implementation of the shared numerical core for
RELION-style single-particle reconstruction and fixed-pose MAP/EM.  The code
follows RELION 3.1 (`ver3.1`) conventions while replacing FFTW/OpenMP/CUDA C++
kernels with PyTorch tensor operations.


## Version 0.2.1 Class2D geometry/state fixes

Version 0.2.1 builds on the 0.2.0 Class2D rewrite.  It fixes the 2-D
projector/backprojector Euler transform for non-zero rot/tilt metadata, preserves
near-empty classes using RELION's 1e-6 accumulated-weight gate, serialises the
working current resolution together with its matching current image size, and
allows per-class estimated resolution to reach Nyquist.  The 3-D projector and
backprojector were audited and already used the complete 3x3 inverse.  See
`V0.2.1_CLASS2D_GEOMETRY_STATE_FIX_NOTES.md`.


## Version 0.1.12 sparse adaptive oversampling

Version 0.1.12 extends the validated dense global-search implementation to
RELION's two-pass adaptive-oversampling flow.  The coarse pass uses one reusable
coarse-size projection bank and a batched matrix likelihood.  Only raw-weight
significant parent tiles are expanded; their NEST direction, psi and translation
children are scored at current size using sparse fine projection blocks cached
across particle batches.

Fine maximization remains tensorized: translations are collapsed before
backprojection, residual noise uses posterior moments, particles sharing a fine
orientation are aggregated, and compact-grid insertions are batched.  Base and
fine translation traversal and higher-order HEALPix child ordering now match
RELION's observable table order.

The program prints the effective particle diameter and pixel radius at startup.
No empirical likelihood-temperature correction is applied.  For a strict H200
comparison, pass the same `--particle-diameter 405.44` used by the RELION command;
omitting it uses RELION's default `(box-maskedge)*pixel`, which is 397.52125 A
for box 256, pixel 1.58375 A and mask edge 5.

The full suite contains 123 tests.  See
`V0.1.12_SPARSE_ADAPTIVE_OVERSAMPLING_NOTES.md` for algorithm, memory and
performance details.

## Version 0.1.11 parity freeze

Version 0.1.11 freezes the currently validated single-class C1 alignment and
fixed-pose numerical core before full adaptive oversampling and multi-class
classification are added.  It retains the projector-space tau², expected
accuracy and dense global-search work from 0.1.10, and closes the remaining
known process-level mismatches in the implemented paths:

- RELION 3.1 significant samples are selected from max-shifted, unnormalised
  float64 weights with the 700-log-unit cutoff, positive-weight filtering,
  descending sort, strict cumulative `>` crossing and `weight >= threshold`
  tie retention.  The separately reported coarse count is preserved for
  `rlnNrOfSignificantSamples`.
- `--zero-mask` now uses RELION's historical `softMaskOutsideMap` semantics:
  the solvent is replaced by the weighted average background and blended over
  the raised-cosine edge; it is not literally multiplied by zero.  The default
  noisy-solvent path uses the same exact blending convention.
- Oversampled children inherit their coarse parent's class/orientation and
  translation prior.  `--skip-align` and `--skip-rotate` disable adaptive
  oversampling, as in RELION.
- `--firstiter-cc` uses a hard best-CC hypothesis, reports one significant
  sample, leaves the noise spectrum unchanged, and stores the mean CC as the
  model log-likelihood.
- A strict expectation-resolution cutoff affects posterior scoring only; DLL
  normalisation, high-resolution Xi² and noise/weighted-sum updates retain the
  full working-current-size boundaries.
- The same mask, stored-half-plane noise, raw-weight selector, projector-space
  tau² and exact-zero class-prior semantics are used by the fixed-pose multi-
  class backend.

The freeze is covered by 116 regression tests.  See
`V0.1.11_FREEZE_PARITY_NOTES.md` for the exact state rules, audit findings and
intentional limits.

## Version 0.1.10 alignment entry point

Version 0.1.10 retains the fast dense global-search implementation from
0.1.9 and corrects the remaining reference-prior mismatch.  The tau² supplied
to `updateSSNRarrays()` and MAP reconstruction is now calculated directly from
the same padded, gridding-corrected, projector-normalised Fourier volume used
to score orientations.  The raw, unpadded map spectrum remains limited to the
`it000` initial model state.

The release also writes the per-class orientation PDF, spectral orientability
contribution, and RELION-style rotational/translational assignment-accuracy
estimates.  Accuracy estimation uses at most 100 particles by default and can
be disabled for a tau²-only parity run with `--skip-expected-accuracy`.  See
`V0.1.10_PROJECTOR_TAU2_MODEL_STATE_NOTES.md` for the precise accumulation
convention and validation targets.

## Version 0.1.9 dense-search foundation

Version 0.1.9 retains the 0.1.8 translation-likelihood and alignment-state
corrections, fixes the remaining iteration-zero half-plane noise weighting, and
turns the `--oversampling 0` global 3-D search into a batched GPU workload.  See
`V0.1.9_DENSE_GLOBAL_SEARCH_NOTES.md` for the numerical equivalence tests,
memory model, tuning controls and current limits.

The initialization path now counts every coefficient stored in the RFFT
half-plane exactly once and applies

```text
sigma2 = 0.5 * (mean particle power - average-image power)
```

without Hermitian multiplicity reweighting.  Negative shells follow RELION's
previous-positive/next-positive repair rule.  This is the correction intended
to remove the residual 4–5% low noise bias and the associated systematically
sharp translation posterior observed in the H200 `--skip-rotate` comparison.

For global rotation search with `--oversampling 0`, all current-size class
projections are generated once per iteration in orientation chunks.  Particle
batches are then scored by matrix products over the complete
`class × orientation × translation` hypothesis tensor.  Posterior reduction,
significant-sample selection, class/direction statistics and offset variance
remain on-device.  Translation hypotheses are collapsed before noise and
backprojection accumulation, and particles are summed within each batch, so
one class/orientation insertion replaces the former per-particle,
per-translation insertions.

Adaptive oversampling now uses the same batched architecture.  A coarse-size
dense pass selects raw-weight significant parents; only their fine children are
projected and scored, and the fine projection blocks are reused across particle
batches.  Both `--oversampling 0` and `--oversampling 1` therefore avoid the
legacy scalar global-search path.

Install an unpacked source tree with:

```bash
python -m pip install -e .
```

This release implements the agreed Phase 1, 2, 3 and fixed-pose Phase 5 scope:

- RELION 3.1 STAR/MRC I/O, one-based `index@stack.mrcs` references, Euler
  matrices, Angstrom origins and standard astigmatic CTF;
- 2-D/3-D Fourier projectors and adjoint backprojectors using half-Hermitian
  storage;
- standalone C1 reconstruction with CTF/FOM weighting, MAP/tau²
  regularisation, Pipe–Menon preweighting, half maps, FSC, masks and debug
  grids;
- fixed-pose Class2D/Class3D EM in which class identity is the only latent
  variable.

## Important v0.1.2 correction

The previously supplied experimental v0.1.1-to-v0.1.2 patch must not be used.
It routed fixed-pose execution through a parallel implementation that changed
particle/reference FFTs from the validated `norm="forward"` convention to
`norm="ortho"`.  For a 256x256 image, this inflates Fourier power and
`sigma2_noise` by approximately `256**2 = 65,536`, producing values of order
one instead of order `1e-4`.

This package was rebuilt directly from the clean v0.1.1 tree.  All fixed-pose
FFTs use the same forward-normalised implementation already validated by the
standalone reconstruction path.  No `relion31_*` parallel entry point is
included.

Version 0.1.2 additionally provides:

1. a real RELION-style `it000` initialization state;
2. separate PSNR-derived resolution, working current size, and strict
   expectation cutoff;
3. rounded `Mresol = floor(radius + 0.5)` shells;
4. per-`rlnGroupNumber` initial and residual noise spectra;
5. RELION factor-of-two and average-image correction for initial noise;
6. zero-mask and deterministic group-coloured noisy-solvent particle masks;
7. exclusion of DC and redundant `x=0,y<0` coefficients from likelihoods;
8. `posterior*CTF/sigma²` and `posterior*CTF²/sigma²` M-step accumulation;
9. `updateSSNRarrays()` before reconstruction, with tau², reference sigma²,
   data-versus-prior and Fourier-coverage output;
10. RELION-style model statistics and high-precision STAR spectra.

The package supports one optics group, which may contain multiple RELION noise
groups identified by `rlnGroupNumber`.

The legacy fixed-pose description below documents the validated numerical
backend inherited from 0.1.6.  Version 0.1.12 includes translation-only, 2-D psi and
3-D global alignment, NEST HEALPix sampling, dense single-pass and batched
sparse coarse/fine expectation,
first-iteration CC, pose-dependent M-step and `--skip-maximize` diagnostics.
Expected assignment accuracy and orientation-PDF serialization are active;
automatic changes of HEALPix order remain deferred, as do 3-D auto-refine
convergence control, symmetry other than C1, multiple optics
groups, anisotropic magnification, CTF-premultiplied particles,
continuation-compatible optimiser/sampling STAR, SIRM and MWTCF.

## Installation

From the wheel:

```bash
python -m pip install --upgrade relion_torch-0.1.12-py3-none-any.whl
```

From the source archive:

```bash
python -m pip install .
```

Runtime dependencies are NumPy, PyTorch, mrcfile and starfile.

## Dense global 3-D search

The following command uses the dense single-pass path:

```bash
relion_torch_align \
  --i particles.star \
  --ref reference.mrc \
  --o Align3D/run \
  --refdim 3 \
  --healpix-order 2 \
  --psi-step 15 \
  --offset-range 2 \
  --offset-step 1 \
  --oversampling 0 \
  --adaptive-fraction 0.999 \
  --zero-mask \
  --device cuda:0 \
  --batch-size 8 \
  --orientation-chunk-size 256 \
  --backprojector-chunk-size 128
```

For the fastest isolated verification of projector-space tau², append:

```text
--skip-expected-accuracy
```

To retain the RELION-style accuracy fields, leave the default enabled or set
`--expected-accuracy-trials 100` explicitly.

`--batch-size` controls the number of particles scored together.
`--orientation-chunk-size` bounds temporary projection/likelihood tensors, and
`--backprojector-chunk-size` bounds each vectorised Fourier insertion.  Reduce
the particle batch first if a later high-current-size iteration exhausts GPU
memory.  Increasing either orientation chunk can improve throughput when ample
memory is available.

For HEALPix order 2, 15-degree psi sampling and the 13-point translation grid,
the bank contains 4,608 orientations and 59,904 hypotheses per class and
particle.  At current size 42, a complex64 projection bank occupies about
32.5 MiB per class.

## Sparse adaptive global 3-D search

Set `--oversampling 1` to run a dense coarse pass followed by sparse fine
children only for significant parent tiles:

```bash
relion_torch_align \
  --i particles.star \
  --ref reference.mrc \
  --o Align3D/run_over1 \
  --refdim 3 \
  --healpix-order 2 \
  --psi-step 15 \
  --offset-range 2 \
  --offset-step 1 \
  --oversampling 1 \
  --adaptive-fraction 0.999 \
  --particle-diameter 405.44 \
  --zero-mask \
  --device cuda:0 \
  --batch-size 8 \
  --orientation-chunk-size 256 \
  --backprojector-chunk-size 128
```

The particle STAR reports the coarse significant-sample count, while fine
children determine the final pose, Pmax, DLL and M-step.  Reduce particle batch
size first if the union of retained fine orientations exhausts GPU memory.

## Fixed-pose 3-D EM

```bash
relion_torch_fixedpose \
  --i particles.star \
  --ref initial_class001.mrc \
  --ref initial_class002.mrc \
  --o FixedPose/run \
  --refdim 3 \
  --iter 1 \
  --device cuda:0 \
  --batch-size 32 \
  --tau2-fudge 1.0 \
  --particle-diameter 405.44 \
  --zero-mask \
  --adaptive-fraction 1.0
```

The program writes `*_it000_data.star` and `*_it000_model.star` before the
first expectation step.  Iteration 1 then derives a PSNR shell from the it000
class `data_vs_prior`, adds the configured working-size increment, and applies
an optional strict cutoff only to probability calculations.

For the supplied H200 regression spectra (box 256, pixel size 1.58375 A), the
expected schedule is:

```text
PSNR shell 8  -> 50.68 A
working shell 18 -> current size 36
```

Changing `--particle-diameter` affects only the real-space particle mask; it
does not enter the PSNR/data-versus-prior equations.

### Resolution controls

```text
--current-size-increment 10
    Add ten Fourier shells to the PSNR-derived safe shell when forming the
    working current size.

--strict-highres-exp ANGSTROM
--maxres ANGSTROM
    Cap the frequency range used for class probabilities.  This does not
    overwrite the PSNR resolution or working current size.

--use-all-data
    Set the working size to the original box size.
```

### Particle mask controls

`--particle-diameter` is a diameter in Angstrom.  The mask radius is therefore
`diameter / (2*pixel_size)`.  The cosine edge width is controlled by
`--mask-edge` in pixels and defaults to five.

- With `--zero-mask`, RELION estimates a weighted mean background from the
  transition/outside region, replaces the solvent by that background, and
  blends it over the raised-cosine edge.  The option name is historical; the
  outside is not literally forced to zero.
- Without it, the likelihood image is blended into deterministic group-coloured
  noisy solvent using the same RELION edge convention; the reconstruction image
  remains unmasked.  The statistical construction is matched, although the
  random-number stream is not byte-identical to RELION C++.

## Standalone reconstruction

```bash
relion_torch_reconstruct \
  --i particles.star \
  --o Reconstruct/run \
  --ctf \
  --pad 2 \
  --preweight-iters 10 \
  --device cuda:0 \
  --batch-size 8 \
  --write-debug
```

The standalone program continues to use the shared CTF, Fourier-shift,
backprojector and reconstruction code validated in v0.1.0/v0.1.1.

## Tests

```bash
PYTHONPATH=src python -m pytest -q
```

The complete v0.1.12 suite contains 123 tests, including regressions for:

- the 256x256 FFT normalization failure;
- H200 it000 `data_vs_prior` yielding shell 8/current size 36;
- independence of the PSNR schedule from particle diameter;
- strict-cutoff versus working-size separation;
- iteration-zero output;
- fixed-pose 2-D and 3-D end-to-end execution;
- raw-weight significant thresholds, exponent cutoff and threshold ties;
- exact average-background/noisy-solvent masking;
- strict-high-resolution score versus current-size sufficient-statistic boundaries;
- first-iteration CC state, oversampled-parent priors and skip-mode flow.

## License and provenance

RELION is copyright its original authors and distributed under GPL v2.  This
implementation derives algorithms and conventions from RELION 3.1 and is
released under GPL-2.0-or-later.  See `COPYING`, `NOTICE`, and
`RELION_PROVENANCE.md`.

### v0.1.4 parity diagnostics

When `--write-posteriors` is enabled, each written EM iteration also produces
`*_itNNN_dll_components.npz` with `raw_log_evidence`, `log_sigma2`,
`relion_log_likelihood_contribution`, `group_id`, and `maximum_shell`.  The
reported contribution follows RELION's complex-Gaussian normalisation over the
actual likelihood Mresol support.

Reference tau² is computed from the gridding-precorrected map and carries the
projector padding normalisation (`pad**2` for 2-D references and `pad**3` for
3-D references).

### v0.1.5 finite Class3D reconstruction safeguards

The iterative Pipe--Menon inverse sampling weight now follows RELION 3.1's
single-precision reconstruction path: the recursive weight is stored in
float64, the convolved correction is floored at `1e-6`, and the weight is
clipped to `1e20` only when applied to a complex64 numerator.  This prevents
sparse or strongly anisotropic Class3D sampling from overflowing the class map
after several preweighting iterations.

The Fourier backprojector also carries the iteration's `current_size`.  Its
accumulation, SSNR calculation, iterative preweighting and final Fourier map
are all restricted to `ROUND((current_size/2) * padding_factor)^2`; early
iterations no longer process the unobserved region between the working
resolution and the original-box Nyquist limit.

The backprojector also carries the active EM working size.  Its accumulation,
SSNR support and reconstruction sphere stop at `current_size / 2`, rather than
running the low-frequency weighted sums through an otherwise empty Nyquist
sphere.

Particle metadata arrays are explicitly copied into writable, C-contiguous
NumPy storage before conversion to tensors, eliminating the PyTorch warning
about non-writable pandas views.  Reconstruction and MRC-output boundaries now
reject NaN/Inf values with a diagnostic error rather than writing corrupted
maps.


### v0.1.6 RELION 3.1 reconstruction geometry

The backprojector now allocates RELION's compact odd Fourier grid for the
iteration's active `current_size`.  Pipe--Menon preweighting runs on that
compact periodic domain.  The final map is formed by copying identical logical
frequencies into the even `padding_factor * original_size` Fourier grid, doing
a full padded inverse FFT, centrally cropping in real space, applying
`softMaskOutsideMap`, and finally performing the interpolation gridding
correction.  No every-`padding_factor` Fourier decimation remains.

The blob correction uses RELION's 10,000-entry `TabFtBlob`, direct compact-grid
coordinates, and the physical denominator `original_size * padding_factor`.

## Class2D rewrite (0.2.0)

The source tree now includes `relion_torch_class2d`, including multi-class
class × psi × XY EM, `--skip-align`, supplied or deterministic initial class
averages, sparse adaptive oversampling, continuation and RELION-style
`classes.mrcs` output.  See `V0.2.0_CLASS2D_REWRITE_NOTES.md` and
`CLASS2D_COMMANDS_v0.2.0_REWRITE.md`.

Norm correction, group scale correction and accuracy-driven automatic sampling
are explicitly rejected in this milestone rather than being silently ignored.
Use `--no-norm --no-scale --fixed-sampling` for validated runs.
