#!/usr/bin/env python3
"""Run the complete source distribution without installing the wheel."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'src'))

from relion_torch.cli.ctf_refine import main

if __name__ == '__main__':
    raise SystemExit(main())
