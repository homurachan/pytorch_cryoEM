"""Shared center-preserving real-space windows and Fourier map resizing."""
import torch
from relion_torch.fourier.conventions import centered_rfft, centered_irfft


def window_centered_map(real, size):
    """Crop/pad a cube with its origin at floor(N/2), including parity changes."""
    n = real.shape[0]
    if real.ndim not in (2,3) or tuple(real.shape) != (n,)*real.ndim or size < 2:
        raise ValueError('Expected a square/cubic map and target size >=2')
    out = real.new_zeros((size,)*real.ndim)
    # Integer coordinates are [-floor(N/2), ..., N-floor(N/2)-1].
    begin = max(-(n//2), -(size//2))
    end = min(n-n//2, size-size//2)
    src = (slice(begin+n//2, end+n//2),)*real.ndim
    dst = (slice(begin+size//2, end+size//2),)*real.ndim
    out[dst] = real[src]
    return out


def resize_centered_map(real, size):
    """RELION resizeMap Fourier window, preserving the real-space field of view.

    This port uses even grids (as the native SIRM mask path does). Logical
    frequencies, including the positive Nyquist convention, are copied once.
    """
    n = real.shape[0]
    if real.ndim not in (2,3) or tuple(real.shape) != (n,)*real.ndim or n%2 or size%2:
        raise ValueError('Fourier map resizing requires even square/cubic grids')
    source = centered_rfft(real, ndim=real.ndim)
    target = source.new_zeros((size,)*(real.ndim-1)+(size//2+1,))
    k = torch.arange(size, device=real.device)
    k = torch.where(k <= size//2, k, k-size)
    x = torch.arange(size//2+1, device=real.device)
    # Slabs keep indexing arrays bounded for large particle boxes.
    if real.ndim == 2:
        coords = torch.meshgrid(k, x, indexing='ij')
        valid = (coords[0] > -n//2) & (coords[0] <= n//2) & (coords[1] <= n//2)
        if size > n:
            valid &= sum(c.square() for c in coords) <= (n//2)**2
        target[valid] = source[tuple(c[valid]%n for c in coords)]
    else:
        for z0 in range(0,size,8):
            coords = torch.meshgrid(k[z0:z0+8], k, x, indexing='ij')
            valid = ((coords[0] > -n//2) & (coords[0] <= n//2) &
                     (coords[1] > -n//2) & (coords[1] <= n//2) & (coords[2] <= n//2))
            if size > n:
                valid &= sum(c.square() for c in coords) <= (n//2)**2
            target[z0:z0+8][valid] = source[tuple(c[valid]%n for c in coords)]
    return centered_irfft(target, (size,)*real.ndim, ndim=real.ndim)
