"""Bounded, model-independent projection geometry shared across classes."""
from collections import OrderedDict
import torch


class EulerInverseCache:
    """Cache full small angle tables; large tables use bounded request work.

    inv_ex preserves the generic inverse arithmetic without inv's CUDA error
    check synchronization. Only internally constructed Euler rotations enter
    this path; arbitrary matrices still use FourierProjector.project checks.
    Source storage/version is retained to avoid stale or recycled cache keys.
    """
    def __init__(self, max_bytes=128 * 1024**2, counters=None):
        self.max_bytes = max(0, int(max_bytes))
        self.bytes = 0
        self.items = OrderedDict()
        self.counts = counters if counters is not None else {}

    @staticmethod
    def invert(angles):
        from relion_torch.alignment.core import _euler_matrix
        return torch.linalg.inv_ex(_euler_matrix(angles), check_errors=False).inverse

    def gather(self, angles, ids):
        key = (angles.untyped_storage().data_ptr(), angles.storage_offset(),
               tuple(angles.shape), tuple(angles.stride()), angles._version,
               str(angles.device), angles.dtype)
        cached = self.items.get(key)
        if cached is None:
            needed = len(angles) * 9 * angles.element_size()
            if needed > self.max_bytes:
                self.counts['projection_geometry_uncached_requests'] = self.counts.get('projection_geometry_uncached_requests', 0) + 1
                return self.invert(angles[ids])
            while self.items and self.bytes + needed > self.max_bytes:
                _, (_, value) = self.items.popitem(last=False)
                self.bytes -= value.numel() * value.element_size()
            # Bound temporary Euler construction, even for a large fine grid.
            value = torch.empty((len(angles), 3, 3), device=angles.device, dtype=angles.dtype)
            for start in range(0, len(angles), 4096):
                value[start:start+4096] = self.invert(angles[start:start+4096])
            self.items[key] = (angles, value)
            self.bytes += needed
            self.counts['projection_geometry_peak_bytes'] = max(self.counts.get('projection_geometry_peak_bytes', 0), self.bytes)
            self.counts['projection_geometry_table_builds'] = self.counts.get('projection_geometry_table_builds', 0) + 1
        else:
            self.items.move_to_end(key)
            value = cached[1]
        return value[ids]
