from __future__ import annotations

import torch

from relion_torch.geometry.grids import (
    radial_frequency_pixels_2d,
    radial_frequency_pixels_3d,
    rfft_multiplicity,
)


def shell_indices(
    box_size: int,
    ndim: int,
    *,
    device: torch.device | str | None = None,
) -> torch.Tensor:
    if ndim == 2:
        radius = radial_frequency_pixels_2d(box_size, device=device, dtype=torch.float64)
    elif ndim == 3:
        radius = radial_frequency_pixels_3d(box_size, device=device, dtype=torch.float64)
    else:
        raise ValueError("ndim must be 2 or 3")
    return torch.floor(radius + 0.5).to(torch.long).clamp(max=box_size // 2)


def radial_sum_and_count(
    values: torch.Tensor,
    shells: torch.Tensor,
    *,
    multiplicity: torch.Tensor | None = None,
    max_shell: int | None = None,
    accumulate_dtype: torch.dtype = torch.float64,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Sum real values over RFFT shells, preserving arbitrary leading dims."""

    if values.shape[-shells.ndim:] != shells.shape:
        raise ValueError(
            f"Trailing value shape {values.shape[-shells.ndim:]} does not match shells {shells.shape}"
        )
    if values.is_complex():
        raise TypeError("radial_sum_and_count expects real values")
    if max_shell is None:
        max_shell = int(shells.max().item())
    lead_shape = values.shape[:-shells.ndim]
    flat_values = values.reshape(-1, shells.numel()).to(accumulate_dtype)
    flat_shells = shells.reshape(-1)
    if multiplicity is None:
        flat_mult = torch.ones_like(flat_shells, dtype=accumulate_dtype)
    else:
        flat_mult = multiplicity.expand_as(shells).reshape(-1).to(accumulate_dtype)
    sums = torch.zeros((flat_values.shape[0], max_shell + 1), device=values.device,
                       dtype=accumulate_dtype)
    counts = torch.zeros_like(sums)
    index = flat_shells.unsqueeze(0).expand(flat_values.shape[0], -1)
    sums.scatter_add_(1, index, flat_values * flat_mult.unsqueeze(0))
    counts.scatter_add_(1, index, flat_mult.unsqueeze(0).expand_as(flat_values))
    return sums.reshape(*lead_shape, max_shell + 1), counts.reshape(*lead_shape, max_shell + 1)


def radial_average(
    values: torch.Tensor,
    box_size: int,
    ndim: int,
    *,
    use_rfft_multiplicity: bool = True,
    eps: float = 1.0e-12,
    accumulate_dtype: torch.dtype = torch.float64,
) -> torch.Tensor:
    shells = shell_indices(box_size, ndim, device=values.device)
    multiplicity = (
        rfft_multiplicity(box_size, ndim, device=values.device, dtype=values.real.dtype)
        if use_rfft_multiplicity
        else None
    )
    sums, counts = radial_sum_and_count(
        values, shells, multiplicity=multiplicity, max_shell=box_size // 2,
        accumulate_dtype=accumulate_dtype,
    )
    return sums / counts.clamp_min(eps)


def expand_shell_values(shell_values: torch.Tensor, shells: torch.Tensor) -> torch.Tensor:
    """Gather radial shell values onto an RFFT grid."""

    lead = shell_values.shape[:-1]
    flat_shells = shells.reshape(-1)
    gathered = torch.gather(
        shell_values.reshape(-1, shell_values.shape[-1]),
        1,
        flat_shells.unsqueeze(0).expand(int(torch.tensor(lead).prod().item()) if lead else 1, -1),
    )
    return gathered.reshape(*lead, *shells.shape)


def smooth_spectrum(spectrum: torch.Tensor, radius: int = 2) -> torch.Tensor:
    if radius <= 0:
        return spectrum
    width = 2 * radius + 1
    padded = torch.nn.functional.pad(spectrum.unsqueeze(-2), (radius, radius), mode="replicate")
    kernel = torch.ones((1, 1, width), device=spectrum.device, dtype=spectrum.dtype) / width
    flat = padded.reshape(-1, 1, padded.shape[-1])
    out = torch.nn.functional.conv1d(flat, kernel)
    return out.reshape_as(spectrum)
