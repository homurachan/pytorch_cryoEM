"""Bounded, iteration-local geometry reuse for Class2D backprojection.

Coordinates, matrix inverse, Hermitian mapping and the four bilinear neighbours
follow FourierBackprojector.accumulate / splat_half_spectrum_. The v028 path
preserves insertion order; static_insert uses fixed-size zero slots and may
change floating-point reduction grouping, but retains the same radial mask.
Observation grouping is performed separately, above this geometry-only layer.
"""
from __future__ import annotations

from dataclasses import dataclass
import itertools
from typing import TYPE_CHECKING

import torch

from relion_torch.geometry.grids import rfft_frequency_coordinates_2d
from relion_torch.fourier.interpolation import hermitian_map_coordinates

if TYPE_CHECKING:
    from relion_torch.fourier.backprojector import FourierBackprojector


@dataclass(slots=True)
class BackprojectionPlan2D:
    original_size: int
    image_size: int
    current_size: int
    padding_factor: float
    compact_size: int
    rotations: torch.Tensor
    valid_indices: torch.Tensor
    keep: torch.Tensor                 # [orientation, active image pixel]
    conjugate: torch.Tensor            # same shape, BEFORE radial compression
    neighbour_indices: tuple[torch.Tensor, ...]
    coefficients: tuple[torch.Tensor, ...]
    byte_size: int
    calls: int = 0
    inserted_orientations: int = 0
    singleton_fallbacks: int = 0
    static_insert: bool = False
    singleton_plan: "BackprojectionPlan2D | None" = None
    static_calls: int = 0

    @classmethod
    @torch.no_grad()
    def build(cls, backprojector: FourierBackprojector, rotations: torch.Tensor,
              image_size: int, *, max_bytes: int, static_insert: bool = False,
              _singleton_geometry: bool = False) -> BackprojectionPlan2D | None:
        """Return None *before* allocating the table if its byte budget is exceeded.

        The plan is shared across all classes and destroyed at the next
        iteration, when sampling perturbation, support or padding may change.
        Only 2D is supported; other callers must use the validated original API.
        """
        bp = backprojector
        if bp.reference_dim != 2:
            raise ValueError("BackprojectionPlan2D requires a 2-D backprojector")
        if rotations.ndim != 3 or rotations.shape[-2:] not in ((2, 2), (3, 3)):
            raise ValueError("rotations must be [orientation,2,2] or [orientation,3,3]")
        if image_size < 2 or image_size % 2 or image_size > bp.original_size:
            raise ValueError("invalid RFFT image size")
        if rotations.device != bp.denominator.device or rotations.dtype != bp.denominator.dtype:
            raise ValueError("rotation dtype/device must match backprojector")
        if int(max_bytes) <= 0:
            return None
        coords = rfft_frequency_coordinates_2d(image_size, device=rotations.device,
                                               dtype=rotations.dtype, flatten=True)
        radius = min(bp.r_max, image_size / 2.0)
        valid = coords.square().sum(-1) <= radius**2 + 1.e-5
        valid &= ~((coords[:, 0] == 0) & (coords[:, 1] < 0))
        valid_indices = torch.nonzero(valid, as_tuple=False).squeeze(-1)
        pixels = int(valid_indices.numel())
        orientations = int(rotations.shape[0])
        # two bool masks + four int64 neighbour indices + four FP coefficients.
        needed = orientations * pixels * (2 + 4 * (8 + rotations.element_size()))
        needed += valid_indices.numel() * valid_indices.element_size()
        needed += rotations.numel() * rotations.element_size()
        if needed * (2 if static_insert else 1) > int(max_bytes):
            return None
        plane = coords[valid]
        shape = (orientations, pixels)
        keep = torch.empty(shape, device=rotations.device, dtype=torch.bool)
        conjugate = torch.empty_like(keep)
        neighbours = tuple(torch.empty(shape, device=rotations.device, dtype=torch.long)
                           for _ in range(4))
        coeffs = tuple(torch.empty(shape, device=rotations.device, dtype=rotations.dtype)
                       for _ in range(4))
        p, nx = bp.compact_size, bp.compact_size // 2 + 1
        # Bound temporary geometry even when the complete table fits the budget.
        build_chunk = max(1, min(64, (32 * 1024**2) // max(1, pixels * 64)))
        if _singleton_geometry:
            build_chunk = 1
        for start in range(0, orientations, build_chunk):
            stop = min(orientations, start + build_chunk)
            rot = rotations[start:stop]
            # einsum's batch=1 matrix path can round differently from its
            # batched path. The main table is the batched variant; static mode
            # separately prebuilds the singleton variant for one-row chunks.
            if len(rot) == 1 and not _singleton_geometry:
                rot = torch.cat((rot, rot), dim=0)
            inv = torch.linalg.inv(rot)
            if inv.shape[-2:] == (3, 3):
                inv = inv[..., :2, :2]
            inv = inv * bp.padding_factor
            mapped = torch.einsum('bij,pj->bpi', inv, plane)[:stop-start]
            radial = mapped.square().sum(-1) <= float(bp.max_r2_padded) + 1.e-5
            mapped, conj = hermitian_map_coordinates(mapped)
            # A point inside max_r2_padded is strictly inside the compact-grid
            # x extent (there is a one-voxel guard). Thus splat's x-valid mask
            # is identically true AFTER radial selection, exactly as upstream.
            keep[start:stop] = radial
            conjugate[start:stop] = conj
            floors = torch.floor(mapped)
            frac = mapped - floors
            base = floors.to(torch.int64)
            at_upper = base[..., 0] >= p // 2
            frac = frac.clone()
            frac[..., 0] = torch.where(at_upper, torch.zeros_like(frac[..., 0]), frac[..., 0])
            base = base.clone()
            base[..., 0] = base[..., 0].clamp(0, p // 2)
            for corner, bits in enumerate(itertools.product((0, 1), repeat=2)):
                coeff = torch.ones(mapped.shape[:-1], device=mapped.device, dtype=mapped.dtype)
                indices = []
                for axis, bit in enumerate(bits):
                    f = frac[..., axis]
                    coeff = coeff * (f if bit else (1.0 - f))
                    index = base[..., axis] + bit
                    index = index.clamp(0, p // 2) if axis == 0 else torch.remainder(index, p)
                    indices.append(index)
                neighbours[corner][start:stop] = indices[1] * nx + indices[0]
                coeffs[corner][start:stop] = coeff
        result = cls(bp.original_size, int(image_size), bp.current_size, bp.padding_factor,
                     bp.compact_size, rotations.clone(), valid_indices, keep, conjugate, neighbours, coeffs, needed)
        if static_insert:
            result.singleton_plan = cls.build(bp, rotations, image_size,
                max_bytes=int(max_bytes)-needed, _singleton_geometry=True)
            if result.singleton_plan is None:
                return None
            result.static_insert = True
            result.byte_size += result.singleton_plan.byte_size
        return result

    @torch.no_grad()
    def accumulate(self, bp: FourierBackprojector, images: torch.Tensor,
                   weights: torch.Tensor, orientation_indices: torch.Tensor, *,
                   orientation_chunk_size: int = 256,
                   pixel_chunk_size: int = 262_144) -> None:
        """Insert in the same chunk/pixel/neighbour order as the original path.

        The historical v028 path below retains dynamic radial compression to
        reproduce its pixel-chunk boundaries. static_insert dispatches to the
        fixed-shape 0.2.9 path with no dynamic selection inside insertion.
        """
        bp._assert_mutable()
        if self.static_insert:
            return self._accumulate_static(bp, images, weights, orientation_indices,
                orientation_chunk_size=orientation_chunk_size, pixel_chunk_size=pixel_chunk_size)
        if (bp.reference_dim, bp.original_size, bp.current_size, bp.padding_factor,
                bp.compact_size) != (2, self.original_size, self.current_size,
                                    self.padding_factor, self.compact_size):
            raise ValueError("backprojection plan does not match accumulator geometry")
        if images.ndim == 2:
            images = images.unsqueeze(0)
        if images.ndim != 3 or tuple(images.shape[-2:]) != (self.image_size, self.image_size // 2 + 1):
            raise ValueError("image shape does not match cached backprojection plan")
        batch = int(images.shape[0])
        if orientation_indices.dtype != torch.long or orientation_indices.shape != (batch,):
            raise ValueError("orientation indices must be int64 [batch]")
        if (images.device != self.keep.device or orientation_indices.device != self.keep.device or
                images.real.dtype != self.coefficients[0].dtype):
            raise ValueError("image/index dtype or device differs from the cached plan")
        weights = torch.broadcast_to(weights, images.shape)
        values = images.reshape(batch, -1).index_select(1, self.valid_indices)
        sample_weights = weights.reshape(batch, -1).index_select(1, self.valid_indices)
        pixels = int(self.valid_indices.numel())
        chunk = max(1, int(orientation_chunk_size))
        pixel_chunk = max(1, int(pixel_chunk_size))
        flat_r, flat_i, flat_w = (bp.numerator_real.reshape(-1), bp.numerator_imag.reshape(-1),
                                bp.denominator.reshape(-1))
        fallback_observations = 0
        for start in range(0, batch, chunk):
            stop = min(start + chunk, batch)
            ids = orientation_indices[start:stop]
            if stop - start == 1:
                bp.accumulate(images[start:stop], self.rotations.index_select(0, ids), weights[start:stop],
                              orientation_chunk_size=1, pixel_chunk_size=pixel_chunk)
                fallback_observations += 1
                continue
            selected = torch.nonzero(self.keep.index_select(0, ids).reshape(-1), as_tuple=False).squeeze(-1)
            # The same orientation-major / pixel-minor flattened order used by
            # mapped[mapped_valid] in the original implementation.
            local_orientation = torch.div(selected, pixels, rounding_mode='floor')
            geometry_index = ids.index_select(0, local_orientation) * pixels + torch.remainder(selected, pixels)
            v = values[start:stop].reshape(-1).index_select(0, selected)
            w = sample_weights[start:stop].reshape(-1).index_select(0, selected)
            conj = self.conjugate.reshape(-1).index_select(0, geometry_index)
            for pstart in range(0, selected.numel(), pixel_chunk):
                pstop = min(pstart + pixel_chunk, selected.numel())
                lookup = geometry_index[pstart:pstop]
                raw = v[pstart:pstop]
                mapped_values = torch.where(conj[pstart:pstop], raw.conj(), raw)
                for indices, coefficients in zip(self.neighbour_indices, self.coefficients):
                    linear = indices.reshape(-1).index_select(0, lookup)
                    coeff = coefficients.reshape(-1).index_select(0, lookup)
                    contribution = mapped_values * coeff
                    wcontribution = w[pstart:pstop] * coeff
                    flat_r.index_add_(0, linear, contribution.real)
                    flat_i.index_add_(0, linear, contribution.imag)
                    flat_w.index_add_(0, linear, wcontribution)
        # Class2D supplies no observation_weights: summing batch ones on the
        # GPU then calling .item() was an unnecessary synchronization.
        bp.n_observations += float(batch - fallback_observations)
        self.calls += 1
        self.inserted_orientations += batch - fallback_observations
        self.singleton_fallbacks += fallback_observations


    @torch.no_grad()
    def _accumulate_static(self, bp: FourierBackprojector, images: torch.Tensor,
                           weights: torch.Tensor, orientation_indices: torch.Tensor, *,
                           orientation_chunk_size: int, pixel_chunk_size: int) -> None:
        """Fixed-shape gridding: NO nonzero/masked_select/device scalar reads.

        Retain the original radial predicate (including the singleton rounding
        variant). Invalid pixels contribute exact zeros through torch.where;
        merely multiplying by a zero mask would allow NaNs to contaminate sums.
        Zero slots alter pixel-chunk/reduction grouping, NOT support/geometry.
        """
        if (bp.reference_dim, bp.original_size, bp.current_size, bp.padding_factor,
                bp.compact_size) != (2, self.original_size, self.current_size,
                                    self.padding_factor, self.compact_size):
            raise ValueError("backprojection plan does not match accumulator geometry")
        if images.ndim == 2:
            images = images.unsqueeze(0)
        if images.ndim != 3 or tuple(images.shape[-2:]) != (self.image_size, self.image_size//2+1):
            raise ValueError("image shape does not match cached backprojection plan")
        batch = images.shape[0]
        if orientation_indices.dtype != torch.long or orientation_indices.shape != (batch,):
            raise ValueError("orientation indices must be int64 [batch]")
        if (images.device != self.keep.device or orientation_indices.device != self.keep.device
                or images.real.dtype != self.coefficients[0].dtype):
            raise ValueError("image/index dtype or device differs from the cached plan")
        weights = torch.broadcast_to(weights, images.shape)
        values = images.reshape(batch, -1).index_select(1, self.valid_indices)
        sample_weights = weights.reshape(batch, -1).index_select(1, self.valid_indices)
        pixels = self.valid_indices.numel()
        chunk = max(1, int(orientation_chunk_size))
        pixel_chunk = max(1, int(pixel_chunk_size))
        flat_r, flat_i, flat_w = (bp.numerator_real.reshape(-1), bp.numerator_imag.reshape(-1),
                                bp.denominator.reshape(-1))
        for start in range(0, batch, chunk):
            stop = min(start+chunk, batch)
            table = self.singleton_plan if stop-start == 1 else self
            ids = orientation_indices[start:stop]
            keep = table.keep.index_select(0, ids).reshape(-1)
            conj = table.conjugate.index_select(0, ids).reshape(-1)
            raw = values[start:stop].reshape(-1)
            v = torch.where(keep, torch.where(conj, raw.conj(), raw), 0.)
            w = torch.where(keep, sample_weights[start:stop].reshape(-1), 0.)
            # Fixed-length lookup; the host already knows its output shape.
            lookup = (ids[:, None]*pixels + torch.arange(pixels, device=ids.device)[None]).reshape(-1)
            for pstart in range(0, lookup.numel(), pixel_chunk):
                pstop = min(pstart+pixel_chunk, lookup.numel())
                ix = lookup[pstart:pstop]
                for indices, coefficients in zip(table.neighbour_indices, table.coefficients):
                    linear = indices.reshape(-1).index_select(0, ix)
                    coeff = coefficients.reshape(-1).index_select(0, ix)
                    contribution = v[pstart:pstop] * coeff
                    wcontribution = w[pstart:pstop] * coeff
                    flat_r.index_add_(0, linear, contribution.real)
                    flat_i.index_add_(0, linear, contribution.imag)
                    flat_w.index_add_(0, linear, wcontribution)
        bp.n_observations += float(batch)
        self.calls += 1
        self.static_calls += 1
        self.inserted_orientations += batch
