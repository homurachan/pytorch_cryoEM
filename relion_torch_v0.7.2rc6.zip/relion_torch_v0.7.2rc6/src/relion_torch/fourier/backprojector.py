from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import torch

from relion_torch.relion_statistics import relion_round_positive
from relion_torch.fourier.interpolation import splat_half_spectrum_
from relion_torch.geometry.grids import rfft_frequency_coordinates_2d


@dataclass(slots=True)
class FourierBackprojector:
    original_size: int
    current_size: int
    padding_factor: float
    reference_dim: int
    numerator_real: torch.Tensor
    numerator_imag: torch.Tensor
    denominator: torch.Tensor
    interpolation: str = "linear"
    n_observations: float = 0.0
    _hermitian_enforced: bool = False
    _point_group_enforced: str | None = None

    @classmethod
    def create(
        cls,
        original_size: int,
        *,
        current_size: int | None = None,
        padding_factor: float = 2.0,
        reference_dim: int = 3,
        device: torch.device | str = "cpu",
        dtype: torch.dtype = torch.float32,
        interpolation: str = "linear",
    ) -> "FourierBackprojector":
        from relion_torch.fourier.conventions import padded_size

        if reference_dim not in (2, 3):
            raise ValueError("reference_dim must be 2 or 3")
        n = int(original_size)
        active_size = n if current_size is None else int(current_size)
        if active_size < 2 or active_size > n:
            raise ValueError(
                f"current_size must be between 2 and original_size ({n}), got {active_size}"
            )
        # RELION first rounds the full padded real-space size to an even
        # integer, then uses that effective padding factor for all projector and
        # backprojector coordinates.  The weighted Fourier sum itself is not
        # allocated on that full p*N grid: Projector::initialiseData() uses the
        # compact odd grid
        #
        #   2 * (ROUND(padding_factor * r_max) + 1) + 1
        #
        # where the extra one-voxel guard on either side guarantees that every
        # trilinear neighbour remains addressable at the active spherical edge.
        full_padded = padded_size(original_size, padding_factor)
        effective = full_padded / float(original_size)
        max_radius_padded = int(
            relion_round_positive((active_size / 2.0) * effective)
        )
        compact_size = 2 * (max_radius_padded + 1) + 1
        shape = (
            (compact_size, compact_size // 2 + 1)
            if reference_dim == 2
            else (compact_size, compact_size, compact_size // 2 + 1)
        )
        zeros = torch.zeros(shape, device=device, dtype=dtype)
        return cls(
            original_size=n,
            current_size=active_size,
            padding_factor=effective,
            reference_dim=reference_dim,
            numerator_real=zeros.clone(),
            numerator_imag=zeros.clone(),
            denominator=zeros.clone(),
            interpolation=interpolation,
        )

    @property
    def compact_size(self) -> int:
        """RELION's odd Fourier accumulator size for this ``current_size``."""

        return (
            int(self.numerator_real.shape[-2])
            if self.reference_dim == 2
            else int(self.numerator_real.shape[-3])
        )

    @property
    def padded_size(self) -> int:
        """Backward-compatible alias for :attr:`compact_size`.

        In RELION terminology ``pad_size`` is the compact odd projector grid,
        not the final even ``padding_factor * original_size`` IFFT grid.
        """

        return self.compact_size

    @property
    def full_padded_size(self) -> int:
        """Even real-space IFFT size used by ``windowToOridimRealSpace``."""

        from relion_torch.fourier.conventions import padded_size

        return padded_size(self.original_size, self.padding_factor)

    @property
    def r_max(self) -> float:
        """Original-box Fourier radius active in this iteration."""

        return self.current_size / 2.0

    @property
    def max_radius_padded(self) -> int:
        return int(relion_round_positive(self.r_max * self.padding_factor))

    @property
    def max_r2_padded(self) -> int:
        return self.max_radius_padded * self.max_radius_padded

    @property
    def numerator(self) -> torch.Tensor:
        return torch.complex(self.numerator_real, self.numerator_imag)

    def clear(self) -> None:
        self.numerator_real.zero_()
        self.numerator_imag.zero_()
        self.denominator.zero_()
        self.n_observations = 0.0
        self._hermitian_enforced = False
        self._point_group_enforced = None

    def _assert_mutable(self) -> None:
        if self._hermitian_enforced:
            raise RuntimeError(
                "This backprojector has already been Hermitian-completed for reconstruction; "
                "call clear() before accumulating more observations"
            )

    def accumulate(
        self,
        images_fourier: torch.Tensor,
        rotations: torch.Tensor,
        sample_weights: torch.Tensor,
        *,
        observation_weights: torch.Tensor | None = None,
        pixel_chunk_size: int = 262_144,
        orientation_chunk_size: int = 256,
        fusion_mode: str = 'off',
        fusion_counters: dict | None = None,
    ) -> None:
        """Backproject weighted Fourier images and scalar/pixel weights.

        ``images_fourier`` may be stored at either the original box size or a
        smaller even current size.  Fourier-windowed coefficients retain their
        original integer frequency coordinates, so inserting the current-size
        plane is exactly equivalent to inserting a full plane whose inactive
        coefficients are zero.  Orientations are mapped and splatted in batches
        rather than one Python call per orientation.
        """

        self._assert_mutable()
        if fusion_mode not in ('off', 'auto', 'required', 'ordered'):
            raise ValueError('Invalid gridding mode: '+str(fusion_mode))
        n = self.original_size
        if images_fourier.ndim == 2:
            images_fourier = images_fourier.unsqueeze(0)
        if images_fourier.ndim != 3:
            raise ValueError(
                "images_fourier must have shape [batch,size,size//2+1] or [size,size//2+1]"
            )
        image_size = int(images_fourier.shape[-2])
        if (
            image_size < 2
            or image_size > n
            or image_size % 2
            or int(images_fourier.shape[-1]) != image_size // 2 + 1
        ):
            raise ValueError(
                f"Invalid RFFT image shape {tuple(images_fourier.shape[-2:])} "
                f"for original size {n}"
            )
        batch = int(images_fourier.shape[0])
        if rotations.ndim == 2:
            rotations = rotations.unsqueeze(0)
        if rotations.shape[0] != batch:
            raise ValueError("Rotation batch does not match image batch")
        if sample_weights.ndim == 2:
            sample_weights = sample_weights.unsqueeze(0)
        sample_weights = torch.broadcast_to(sample_weights, images_fourier.shape)
        if observation_weights is None:
            observation_weights = torch.ones(
                batch,
                device=images_fourier.device,
                dtype=images_fourier.real.dtype,
            )
        observation_weights = torch.as_tensor(
            observation_weights,
            device=images_fourier.device,
            dtype=images_fourier.real.dtype,
        ).reshape(batch)

        if fusion_mode not in ('off', 'ordered'):
            from relion_torch.inference.fused_gridding import accumulate as fused_accumulate
            if fused_accumulate(self,images_fourier,rotations,sample_weights,
                                mode=fusion_mode,counters=fusion_counters):
                self.n_observations+=float(observation_weights.sum().item())
                return

        coords = rfft_frequency_coordinates_2d(
            image_size,
            device=images_fourier.device,
            dtype=images_fourier.real.dtype,
            flatten=True,
        )
        active_radius = min(self.r_max, image_size / 2.0)
        # The x=0 values with negative y are redundant Friedel mates. RELION
        # starts at x=1 for this half of the input image.
        valid = coords.square().sum(dim=-1) <= active_radius**2 + 1.0e-5
        valid &= ~((coords[:, 0] == 0) & (coords[:, 1] < 0))
        valid_idx = torch.nonzero(valid, as_tuple=False).squeeze(-1)
        plane2 = coords[valid]
        if self.reference_dim == 3:
            plane = torch.cat(
                (
                    plane2,
                    torch.zeros(
                        (plane2.shape[0], 1),
                        device=plane2.device,
                        dtype=plane2.dtype,
                    ),
                ),
                dim=-1,
            )
        else:
            plane = plane2

        flat_images = images_fourier.reshape(batch, -1)[:, valid_idx]
        flat_weights = sample_weights.reshape(batch, -1)[:, valid_idx]
        chunk = max(1, int(orientation_chunk_size))
        pixel_chunk = max(1, int(pixel_chunk_size))
        for start in range(0, batch, chunk):
            stop = min(start + chunk, batch)
            rot = rotations[start:stop]
            if self.reference_dim == 2:
                if rot.shape[-2:] == (3, 3):
                    # Match RELION BackProjector::backrotate2D(): invert the
                    # complete Euler matrix first and then use its in-plane
                    # block.  Inverting the 2x2 block directly is only
                    # equivalent for pure in-plane rotations and is badly
                    # conditioned for many non-zero-tilt input poses.
                    inv = torch.linalg.inv(rot)[..., :2, :2]
                else:
                    inv = torch.linalg.inv(rot)
                inv = inv * self.padding_factor
            else:
                if rot.shape[-2:] != (3, 3):
                    raise ValueError("3-D backprojection requires 3x3 rotations")
                inv = torch.linalg.inv(rot) * self.padding_factor

            mapped = torch.einsum("bij,pj->bpi", inv, plane)
            values = flat_images[start:stop]
            weights = flat_weights[start:stop]
            mapped_valid = (
                mapped.square().sum(dim=-1)
                <= float(self.max_r2_padded) + 1.0e-5
            )
            mapped_flat = mapped[mapped_valid]
            values_flat = values[mapped_valid]
            weights_flat = weights[mapped_valid]
            for pstart in range(0, int(mapped_flat.shape[0]), pixel_chunk):
                pstop = min(pstart + pixel_chunk, int(mapped_flat.shape[0]))
                splat_half_spectrum_(
                    self.numerator_real,
                    self.numerator_imag,
                    self.denominator,
                    mapped_flat[pstart:pstop],
                    values_flat[pstart:pstop],
                    weights_flat[pstart:pstop],
                    ordered=fusion_mode == 'ordered',
                )

        if fusion_mode == 'ordered' and fusion_counters is not None:
            fusion_counters['ordered_gridding_calls'] = fusion_counters.get('ordered_gridding_calls', 0)+1
        # One scalar transfer per accumulated batch, rather than one per pose.
        self.n_observations += float(observation_weights.sum().item())

    def enforce_hermitian_x0_(self) -> None:
        """Sum Friedel pairs on the stored x=0 plane, matching RELION.

        The operation is idempotent: subsequent calls are no-ops. Accumulation
        after completion is rejected because it would mix completed and raw sums.
        """

        if self._hermitian_enforced:
            return
        p = self.padded_size
        plane = self.numerator[..., 0]
        weight = self.denominator[..., 0]
        if self.reference_dim == 2:
            y = torch.arange(p, device=plane.device)
            pair_y = torch.remainder(-y, p)
            original = plane.clone()
            original_w = weight.clone()
            combined = original + original[pair_y].conj()
            combined_w = original_w + original_w[pair_y]
            self_pair = y == pair_y
            combined = torch.where(self_pair, original.real.to(original.dtype), combined)
            combined_w = torch.where(self_pair, original_w, combined_w)
            self.numerator_real[:, 0].copy_(combined.real)
            self.numerator_imag[:, 0].copy_(combined.imag)
            self.denominator[:, 0].copy_(combined_w)
        else:
            z = torch.arange(p, device=plane.device)
            y = torch.arange(p, device=plane.device)
            zz, yy = torch.meshgrid(z, y, indexing="ij")
            pz = torch.remainder(-zz, p)
            py = torch.remainder(-yy, p)
            original = plane.clone()
            original_w = weight.clone()
            combined = original + original[pz, py].conj()
            combined_w = original_w + original_w[pz, py]
            self_pair = (zz == pz) & (yy == py)
            combined = torch.where(self_pair, original.real.to(original.dtype), combined)
            combined_w = torch.where(self_pair, original_w, combined_w)
            self.numerator_real[..., 0].copy_(combined.real)
            self.numerator_imag[..., 0].copy_(combined.imag)
            self.denominator[..., 0].copy_(combined_w)
        self._hermitian_enforced = True

    def add_(self, other: "FourierBackprojector") -> "FourierBackprojector":
        self._assert_mutable()
        if other._hermitian_enforced:
            raise RuntimeError("Cannot merge an already Hermitian-completed backprojector")
        if (
            self.original_size != other.original_size
            or self.current_size != other.current_size
            or self.reference_dim != other.reference_dim
            or self.padded_size != other.padded_size
        ):
            raise ValueError("Cannot merge incompatible backprojectors")
        self.numerator_real.add_(other.numerator_real)
        self.numerator_imag.add_(other.numerator_imag)
        self.denominator.add_(other.denominator)
        self.n_observations += other.n_observations
        return self

    def state_dict(self) -> dict[str, torch.Tensor | float | int]:
        return {
            "original_size": self.original_size,
            "current_size": self.current_size,
            "padding_factor": self.padding_factor,
            "reference_dim": self.reference_dim,
            "numerator_real": self.numerator_real,
            "numerator_imag": self.numerator_imag,
            "denominator": self.denominator,
            "n_observations": self.n_observations,
            "hermitian_enforced": int(self._hermitian_enforced),
            "point_group_enforced": self._point_group_enforced,
        }
