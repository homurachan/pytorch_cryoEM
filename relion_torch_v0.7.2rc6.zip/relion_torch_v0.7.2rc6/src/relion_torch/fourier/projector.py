from __future__ import annotations

from dataclasses import dataclass, field

import torch

from relion_torch.fourier.conventions import centered_rfft, gridding_correct, pad_centered, padded_size
from relion_torch.fourier.interpolation import sample_half_spectrum
from relion_torch.geometry.grids import rfft_frequency_coordinates_2d
from relion_torch.relion_statistics import relion_round_positive


@dataclass(slots=True)
class FourierProjector:
    data: torch.Tensor
    original_size: int
    padded_size: int
    padding_factor: float
    reference_dim: int
    interpolation: str = "linear"
    source_current_size: int | None = None
    _geometry: dict = field(default_factory=dict, init=False, repr=False)

    def project_optics(self, rotations: torch.Tensor, *, output_size: int,
                       frequency_matrix: torch.Tensor | None = None,
                       scale_ratio: float = 1., gradients: bool = False):
        """Project onto an optics group's grid, optionally returning dP/d(kx,ky).

        scale_ratio is reference_box*reference_pixel/(image_box*image_pixel).
        Gradients differentiate the shared trilinear interpolant, including the
        Hermitian reflection. They do not differentiate a CTF/MTF multiplier.
        """
        if self.reference_dim != 3 or output_size < 2 or output_size % 2:
            raise ValueError('optics projection requires a 3D reference and an even image box')
        dtype, device = self.data.real.dtype, self.data.device
        rotations = torch.as_tensor(rotations, device=device, dtype=dtype).reshape(-1, 3, 3)
        matrix = torch.eye(2, device=device, dtype=dtype) if frequency_matrix is None else frequency_matrix.to(device=device, dtype=dtype)
        if (not gradients and float(scale_ratio) == 1. and output_size <= self.original_size
                and torch.equal(matrix, torch.eye(2, device=device, dtype=dtype))):
            return self.project(rotations, output_size=output_size)
        coords = rfft_frequency_coordinates_2d(output_size, device=device, dtype=dtype)
        disk = coords.square().sum(-1) <= (output_size//2)**2
        xy = coords.reshape(-1, 2).expand(len(rotations), -1, -1).clone()

        def sample(xy):
            transformed = torch.einsum('ij,bpj->bpi', matrix, xy)
            plane = torch.cat((transformed, torch.zeros_like(transformed[..., :1])), -1)
            mapped = torch.einsum('bij,bpj->bpi', torch.linalg.inv(rotations), plane)
            mapped = mapped*(float(scale_ratio)*self.padding_factor)
            values = sample_half_spectrum(self.data.detach(), mapped,
                interpolation=self.interpolation, source_radius=self.source_radius_padded).values
            support = disk.reshape(1, -1) & (mapped.square().sum(-1) <= self.source_radius_padded**2)
            return torch.where(support, values, torch.zeros_like(values))

        if gradients:
            with torch.enable_grad():
                xy.requires_grad_(True)
                values = sample(xy)
                real, = torch.autograd.grad(values.real.sum(), xy, retain_graph=True)
                imag, = torch.autograd.grad(values.imag.sum(), xy)
                gradient = torch.complex(real, imag).detach()
            return values.detach().reshape(-1, output_size, output_size//2+1), gradient.reshape(-1, output_size, output_size//2+1, 2)
        with torch.no_grad():
            return sample(xy).reshape(-1, output_size, output_size//2+1)

    def __post_init__(self) -> None:
        if self.source_current_size is None:
            self.source_current_size = int(self.original_size)
        size = int(self.source_current_size)
        if size < 2 or size > self.original_size or size % 2:
            raise ValueError("source current_size must be even and between 2 and original_size")
        self.source_current_size = size

    @property
    def source_radius_padded(self) -> int:
        """Radius of the SOURCE coefficients, not the output Fourier plane."""
        return min(self.padded_size // 2, int(relion_round_positive(
            (int(self.source_current_size) // 2) * self.padding_factor)))

    @torch.no_grad()
    def _zero_outside_source_support(self, z_chunk_size: int = 16) -> None:
        """Zero source corners before interpolation without a full 3-D radius grid.

        ``from_real`` owns this buffer. Directly constructed diagnostic projectors
        are also protected by the per-neighbor support check in ``project``.
        """
        p = int(self.padded_size)
        r2max = self.source_radius_padded ** 2
        axis = torch.arange(p, device=self.data.device, dtype=torch.int64)
        signed = torch.where(axis <= p // 2, axis, axis - p)
        x = torch.arange(p // 2 + 1, device=self.data.device, dtype=torch.int64)
        plane2 = signed[:, None].square() + x[None, :].square()
        if self.reference_dim == 2:
            self.data.masked_fill_(plane2 > r2max, 0)
        else:
            for start in range(0, p, z_chunk_size):
                stop = min(p, start + z_chunk_size)
                radius2 = signed[start:stop, None, None].square() + plane2[None]
                self.data[start:stop].masked_fill_(radius2 > r2max, 0)

    @classmethod
    def from_real(
        cls,
        reference: torch.Tensor,
        *,
        padding_factor: float = 2.0,
        interpolation: str = "linear",
        gridding_pre_correction: bool = True,
        current_size: int | None = None,
    ) -> "FourierProjector":
        if reference.ndim not in (2, 3):
            raise ValueError(f"Reference must be 2-D or 3-D, got shape {reference.shape}")
        n = int(reference.shape[-1])
        if any(int(v) != n for v in reference.shape):
            raise ValueError("Reference must have equal spatial dimensions")
        p = padded_size(n, padding_factor)
        effective_padding = p / float(n)
        work = reference
        if gridding_pre_correction:
            work = gridding_correct(
                work,
                padding_factor=effective_padding,
                interpolation=interpolation,
                ndim=reference.ndim,
            )
        padded = pad_centered(work, p, ndim=reference.ndim)
        fourier = centered_rfft(padded, ndim=reference.ndim)
        # RELION projector normalisation converts the padded, volume-normalised
        # transform to the normalisation of a 2-D particle Fourier image.
        if reference.ndim == 2:
            normfft = effective_padding**2
        else:
            normfft = effective_padding**3 * n
        # CUDA FFT output can be transposed (for example strides P,1,P*P).
        # Own one contiguous projector from construction. Otherwise every fused
        # dispatch's _complex_parts would copy the ENTIRE padded 3-D model.
        # Do this before normalization: only two Fourier buffers coexist, just
        # as in the original out-of-place multiplication; no persistent copy.
        fourier = fourier.contiguous()
        fourier = fourier * normfft
        projector = cls(
            data=fourier,
            original_size=n,
            padded_size=p,
            padding_factor=effective_padding,
            reference_dim=reference.ndim,
            interpolation=interpolation,
            source_current_size=current_size,
        )
        projector._zero_outside_source_support()
        return projector

    @torch.no_grad()
    def power_spectrum(
        self,
        *,
        current_size: int | None = None,
        z_chunk_size: int = 16,
    ) -> torch.Tensor:
        """Return RELION's projector-space radial tau² spectrum.

        RELION does **not** use the radial power spectrum of the unpadded input
        map for the expectation/MAP prior.  ``Projector::computeFourierTransformMap``
        first applies the gridding pre-correction, pads the map, performs the
        forward-normalised FFT, multiplies by the projector ``normfft`` factor,
        and only then averages ``|F|^2 / 2`` over padded Fourier coefficients.

        This method operates directly on :attr:`data`, i.e. the exact Fourier
        representation used by :meth:`project`.  It reproduces RELION's
        positive-radius shell convention::

            max_r2 = ROUND(r_max * padding_factor) ** 2
            ires   = ROUND(sqrt(r2) / padding_factor)
            tau2[ires] += |data[k]|**2 / 2
            counter[ires] += 1

        Every coefficient stored in the RFFT half-volume is counted once; no
        Hermitian multiplicity is applied.  Shells above ``current_size / 2``
        remain zero, matching the current projector support.
        """

        n = int(self.original_size)
        if current_size is None:
            active_size = int(self.source_current_size)
        else:
            active_size = int(current_size)
        if active_size < 2 or active_size > n:
            raise ValueError(
                "current_size must be between 2 and original_size "
                f"({n}), got {active_size}"
            )
        if active_size % 2:
            raise ValueError(f"current_size must be even, got {active_size}")
        if active_size > int(self.source_current_size):
            raise ValueError("requested tau2 support exceeds the constructed source support; rebuild the projector")
        if z_chunk_size < 1:
            raise ValueError("z_chunk_size must be positive")

        r_max = min(active_size // 2, n // 2)
        padded_radius = int(
            relion_round_positive(float(r_max) * float(self.padding_factor))
        )
        p = int(self.padded_size)
        padded_radius = min(padded_radius, p // 2)
        maximum_radius_squared = padded_radius * padded_radius
        n_shells = n // 2 + 1

        real_dtype = self.data.real.dtype
        device = self.data.device
        accumulation_dtype = torch.float64

        # PyTorch's RFFT stores x >= 0 and full periodic y/z axes.  Selecting
        # only coordinates that can fall inside the sphere avoids allocating a
        # full 512^3 radius grid for a typical 256-pixel, padding-factor-2 map.
        signed_axis = torch.fft.fftfreq(
            p, d=1.0 / p, device=device, dtype=real_dtype
        )
        signed_keep = signed_axis.abs() <= float(padded_radius)
        signed_indices = torch.nonzero(signed_keep, as_tuple=False).squeeze(-1)
        signed_coordinates = signed_axis.index_select(0, signed_indices)
        x_coordinates = torch.arange(
            padded_radius + 1, device=device, dtype=real_dtype
        )

        total = torch.zeros(n_shells, device=device, dtype=accumulation_dtype)
        counter = torch.zeros_like(total)

        def accumulate(
            power_values: torch.Tensor, radius_squared: torch.Tensor
        ) -> None:
            support = radius_squared <= float(maximum_radius_squared)
            radii = torch.sqrt(radius_squared[support]) / float(self.padding_factor)
            shell = relion_round_positive(radii)
            assert isinstance(shell, torch.Tensor)
            shell = shell.clamp(0, n_shells - 1).reshape(-1)
            power = power_values[support].to(accumulation_dtype).reshape(-1) * 0.5
            total.scatter_add_(0, shell, power)
            counter.scatter_add_(0, shell, torch.ones_like(power))

        if self.reference_dim == 2:
            selected = self.data.index_select(0, signed_indices)[
                :, : padded_radius + 1
            ]
            yy, xx = torch.meshgrid(
                signed_coordinates, x_coordinates, indexing="ij"
            )
            radius_squared = xx.square() + yy.square()
            power_values = selected.real.square() + selected.imag.square()
            accumulate(power_values, radius_squared)
        elif self.reference_dim == 3:
            # The data layout is [z, y, x_half].  Chunk z to keep the full-size
            # Nyquist case memory-bounded while preserving exact accumulation.
            y_coordinates = signed_coordinates
            yy, xx = torch.meshgrid(
                y_coordinates, x_coordinates, indexing="ij"
            )
            in_plane_radius_squared = yy.square() + xx.square()
            for start in range(0, int(signed_indices.numel()), int(z_chunk_size)):
                stop = min(start + int(z_chunk_size), int(signed_indices.numel()))
                z_indices = signed_indices[start:stop]
                zz = signed_coordinates[start:stop]
                selected = (
                    self.data.index_select(0, z_indices)
                    .index_select(1, signed_indices)[..., : padded_radius + 1]
                )
                radius_squared = (
                    zz[:, None, None].square()
                    + in_plane_radius_squared[None, :, :]
                )
                power_values = selected.real.square() + selected.imag.square()
                accumulate(power_values, radius_squared)
        else:  # pragma: no cover - guarded by construction
            raise ValueError(f"unsupported reference_dim={self.reference_dim}")

        spectrum = torch.where(
            counter >= 1.0,
            total / counter.clamp_min(1.0),
            torch.zeros_like(total),
        )
        return spectrum.to(dtype=real_dtype)

    def project(
        self,
        rotations: torch.Tensor,
        *,
        output_size: int | None = None,
        rotations_are_inverse: bool = False,
    ) -> torch.Tensor:
        """Project one or more RELION rotations directly at ``output_size``.

        The previous alignment adapter always generated an original-size
        ``N x (N/2+1)`` plane and then Fourier-windowed it.  Global alignment
        normally needs only the much smaller current-size plane.  Sampling the
        retained integer Fourier coordinates directly gives the same values
        inside RELION's circular output support, zeros the rectangular corner
        coefficients that RELION does not project, and avoids most interpolation
        work.
        """

        if rotations.shape[-2:] not in ((3, 3), (2, 2)):
            raise ValueError(
                f"Expected rotations (...,3,3) or (...,2,2), got {rotations.shape}"
            )
        scalar = rotations.ndim == 2
        if scalar:
            rotations = rotations.unsqueeze(0)
        rotations = rotations.to(device=self.data.device, dtype=self.data.real.dtype)

        nout = self.original_size if output_size is None else int(output_size)
        if nout < 2 or nout > self.original_size or nout % 2:
            raise ValueError(
                "output_size must be an even integer between 2 and original_size "
                f"({self.original_size}), got {nout}"
            )

        geometry_key = (nout, self.data.device, self.data.real.dtype)
        geometry = self._geometry.get(geometry_key)
        if geometry is None:
            coords2 = rfft_frequency_coordinates_2d(
                nout, device=self.data.device, dtype=self.data.real.dtype, flatten=True)
            valid_disk = coords2.square().sum(dim=-1) <= (nout / 2.0) ** 2 + 1.0e-5
            plane = torch.cat((coords2, torch.zeros_like(coords2[:, :1])), dim=-1)
            if len(self._geometry) >= 4:
                self._geometry.pop(next(iter(self._geometry)))
            self._geometry[geometry_key] = geometry = (coords2, valid_disk, plane)
        coords2, valid_disk, plane = geometry
        # Precomputed inverses are supplied only by the validated Euler path.
        # Generic callers retain checked inversion and singular-matrix errors.
        if self.reference_dim == 3 and rotations.shape[-2:] != (3, 3):
            raise ValueError("A 3-D reference requires 3x3 rotations")
        inverse = rotations if rotations_are_inverse else torch.linalg.inv(rotations)

        if self.reference_dim == 2:
            if rotations.shape[-2:] == (3, 3):
                # RELION's Projector::project()/rotate2D() first inverts the
                # complete Euler matrix and only then uses Ainv(0:2, 0:2).
                # In general, inv(A[:2,:2]) != inv(A)[:2,:2] when rot/tilt
                # are non-zero (for example, skip-alignment Class2D on a STAR
                # produced by a previous 3-D refinement).  The old order could
                # become nearly singular around tilt=90 degrees and discard
                # most of the Fourier disk.
                inv = inverse[..., :2, :2]
            else:
                inv = inverse
            inv = inv * self.padding_factor
            mapped = torch.einsum("bij,pj->bpi", inv, coords2)
        else:
            if rotations.shape[-2:] != (3, 3):
                raise ValueError("A 3-D reference requires 3x3 rotations")
            inv = inverse * self.padding_factor
            mapped = torch.einsum("bij,pj->bpi", inv, plane)

        # sample_half_spectrum accepts arbitrary leading coordinate dimensions,
        # so all orientations in this call are interpolated in one vectorised
        # operation (only the 4/8 interpolation-corner loop remains in Python).
        sampled = sample_half_spectrum(
            self.data, mapped, interpolation=self.interpolation,
            source_radius=self.source_radius_padded,
        ).values
        mapped_radius2 = mapped.square().sum(dim=-1)
        if self.reference_dim == 2:
            source_valid = torch.trunc(mapped_radius2) <= self.source_radius_padded ** 2
        else:
            source_valid = mapped_radius2 <= self.source_radius_padded ** 2
        sampled = torch.where(
            valid_disk.unsqueeze(0) & source_valid, sampled, torch.zeros_like(sampled)
        )
        result = sampled.reshape(rotations.shape[0], nout, nout // 2 + 1)
        return result[0] if scalar else result
