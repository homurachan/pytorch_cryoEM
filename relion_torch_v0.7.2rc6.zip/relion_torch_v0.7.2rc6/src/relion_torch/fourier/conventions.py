from __future__ import annotations

import math
from typing import Sequence

import torch
import torch.nn.functional as F

from relion_torch.geometry.grids import rfft_frequency_coordinates_2d


def padded_size(original_size: int, padding_factor: float) -> int:
    if original_size < 2:
        raise ValueError("original_size must be >=2")
    if padding_factor < 1.0:
        raise ValueError("padding_factor must be >=1")
    size = int(round(original_size * float(padding_factor)))
    if size % 2:
        size += 1
    return size


def _spatial_dims(tensor: torch.Tensor, ndim: int) -> tuple[int, ...]:
    if tensor.ndim < ndim:
        raise ValueError(f"Tensor rank {tensor.ndim} is smaller than ndim={ndim}")
    return tuple(range(tensor.ndim - ndim, tensor.ndim))


def centered_rfft(real: torch.Tensor, *, ndim: int | None = None) -> torch.Tensor:
    """Forward-normalised RFFT of a centre-origin real array.

    The input's spatial centre is at ``N//2``. ``ifftshift`` moves that origin to
    array index zero before the FFT. ``norm='forward'`` matches RELION's
    normalised forward transform convention.
    """

    if ndim is None:
        ndim = 2 if real.ndim <= 3 else 3
    dims = _spatial_dims(real, ndim)
    shifted = torch.fft.ifftshift(real, dim=dims)
    return torch.fft.rfftn(shifted, dim=dims, norm="forward")


def centered_irfft(
    fourier: torch.Tensor,
    output_shape: Sequence[int],
    *,
    ndim: int | None = None,
) -> torch.Tensor:
    """Inverse of :func:`centered_rfft` for a specified real spatial shape."""

    shape = tuple(int(v) for v in output_shape)
    if ndim is None:
        ndim = len(shape)
    dims = _spatial_dims(fourier, ndim)
    real = torch.fft.irfftn(fourier, s=shape, dim=dims, norm="forward")
    return torch.fft.fftshift(real, dim=dims)


def pad_centered(real: torch.Tensor, target_size: int, *, ndim: int | None = None) -> torch.Tensor:
    """Symmetrically zero-pad or crop the last ``ndim`` dimensions."""

    if ndim is None:
        ndim = 2 if real.ndim <= 3 else 3
    current = real.shape[-ndim:]
    if any(int(v) != int(current[0]) for v in current):
        raise ValueError(f"Expected equal spatial dimensions, got {current}")
    n = int(current[0])
    if target_size == n:
        return real.clone()
    if target_size < n:
        start = (n - target_size) // 2
        slices = [slice(None)] * (real.ndim - ndim) + [slice(start, start + target_size)] * ndim
        return real[tuple(slices)].contiguous()
    before = (target_size - n) // 2
    after = target_size - n - before
    pad: list[int] = []
    for _ in range(ndim):
        pad.extend((before, after))
    return F.pad(real, pad)


def centered_crop(real: torch.Tensor, target_size: int, *, ndim: int | None = None) -> torch.Tensor:
    return pad_centered(real, target_size, ndim=ndim)


def fourier_shift_factor_2d(
    grid_size: int,
    shifts_pixels: torch.Tensor | Sequence[float],
    *,
    original_size: int | None = None,
    sign: float = -1.0,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """Return the phase factor for translating an unshifted 2-D RFFT grid.

    ``grid_size`` describes the stored/windowed Fourier array.  ``original_size``
    describes the real-space image in which ``shifts_pixels`` is measured.  The
    distinction is essential for RELION's current-size Fourier windows: a
    coefficient with integer index ``k`` keeps phase ``k/N_original`` after the
    high-frequency coefficients have been cropped.
    """

    n_grid = int(grid_size)
    n_original = n_grid if original_size is None else int(original_size)
    if n_grid < 2:
        raise ValueError("grid_size must be >=2")
    if n_original < n_grid:
        raise ValueError("original_size must be >= grid_size")
    shift = torch.as_tensor(shifts_pixels, device=device, dtype=dtype)
    if shift.shape[-1] != 2:
        raise ValueError("shifts_pixels must end in (x,y)")
    coords = rfft_frequency_coordinates_2d(
        n_grid, device=shift.device, dtype=shift.dtype
    )
    x = coords[..., 0]
    y = coords[..., 1]
    sx = shift[..., 0][(...,) + (None, None)]
    sy = shift[..., 1][(...,) + (None, None)]
    phase = (
        float(sign)
        * 2.0
        * math.pi
        * (x * sx + y * sy)
        / float(n_original)
    )
    return torch.complex(torch.cos(phase), torch.sin(phase))


def fourier_shift_2d(
    fourier: torch.Tensor,
    shifts_pixels: torch.Tensor | Sequence[float],
    *,
    original_size: int | None = None,
    sign: float = -1.0,
) -> torch.Tensor:
    """Apply a real-space translation to an unshifted RFFT image.

    ``sign=-1`` multiplies by ``exp(-2*pi*i*k·shift/N)`` and moves image content
    by ``+shift`` pixels. RELION STAR origins specify the translation that aligns
    an observation to its reference, so alignment uses ``sign=-1`` with the
    stored origin. A predicted reference is moved into the observation with the
    opposite sign.
    """

    n = int(fourier.shape[-2])
    if fourier.shape[-1] != n // 2 + 1:
        raise ValueError(f"Expected RFFT image shape (...,{n},{n//2+1}), got {fourier.shape}")
    shift = torch.as_tensor(
        shifts_pixels, device=fourier.device, dtype=fourier.real.dtype
    )
    lead = fourier.ndim - 2
    while shift.ndim < lead + 1:
        shift = shift.unsqueeze(0)
    factor = fourier_shift_factor_2d(
        n,
        shift,
        original_size=original_size,
        sign=sign,
        device=fourier.device,
        dtype=fourier.real.dtype,
    )
    return fourier * factor


def _centered_radius(n: int, ndim: int, *, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    axes = [torch.arange(n, device=device, dtype=dtype) - float(n // 2) for _ in range(ndim)]
    mesh = torch.meshgrid(*axes, indexing="ij")
    radius2 = sum(axis.square() for axis in mesh)
    return torch.sqrt(radius2)


def gridding_correct(
    real: torch.Tensor,
    *,
    padding_factor: float,
    interpolation: str = "trilinear",
    inverse: bool = False,
    eps: float = 1.0e-6,
    ndim: int | None = None,
) -> torch.Tensor:
    """RELION-style radial gridding correction on a centred real map.

    Linear interpolation uses ``sinc(r/(N*padding_factor))^2``. Forward map
    preparation divides by this factor; ``inverse=True`` multiplies by it.
    """

    if ndim is None:
        if real.ndim == 2:
            ndim = 2
        elif real.ndim == 3 and len(set(int(v) for v in real.shape)) == 1:
            ndim = 3
        elif real.ndim == 3:
            ndim = 2
        elif real.ndim >= 4:
            ndim = 3
        else:
            raise ValueError("Could not infer gridding dimensionality")
    if ndim not in (2, 3):
        raise ValueError("ndim must be 2 or 3")
    n = int(real.shape[-1])
    if any(int(v) != n for v in real.shape[-ndim:]):
        raise ValueError("gridding_correct requires equal spatial dimensions")
    radius = _centered_radius(n, ndim, device=real.device, dtype=real.dtype)
    rval = radius / (float(n) * float(padding_factor))
    sinc = torch.sinc(rval)
    interpolation_lower = interpolation.lower()
    if interpolation_lower in {"trilinear", "linear", "bilinear"}:
        corr = sinc.square()
    elif interpolation_lower in {"nearest", "nearest-neighbour", "nearest_neighbor"}:
        corr = sinc
    else:
        raise ValueError(f"Unsupported interpolation: {interpolation}")
    corr = corr.clamp_min(eps)
    while corr.ndim < real.ndim:
        corr = corr.unsqueeze(0)
    return real * corr if inverse else real / corr


def soft_mask_outside(
    real: torch.Tensor,
    radius_pixels: float,
    *,
    edge_width_pixels: float = 3.0,
    fill: float | torch.Tensor = 0.0,
    ndim: int | None = None,
) -> torch.Tensor:
    """Cosine-soft-mask a centred 2-D image or 3-D volume outside a radius."""

    if ndim is None:
        if real.ndim == 2:
            ndim = 2
        elif real.ndim == 3 and len(set(int(v) for v in real.shape)) == 1:
            ndim = 3
        elif real.ndim == 3:
            ndim = 2
        elif real.ndim >= 4:
            ndim = 3
        else:
            raise ValueError("Could not infer mask dimensionality")
    if ndim not in (2, 3):
        raise ValueError("ndim must be 2 or 3")
    n = int(real.shape[-1])
    radius = _centered_radius(n, ndim, device=real.device, dtype=real.dtype)
    if edge_width_pixels <= 0:
        weight = (radius <= radius_pixels).to(real.dtype)
    else:
        inner = radius_pixels
        outer = radius_pixels + edge_width_pixels
        t = ((radius - inner) / max(edge_width_pixels, 1.0e-12)).clamp(0.0, 1.0)
        weight = torch.where(
            radius <= inner,
            torch.ones_like(radius),
            torch.where(radius >= outer, torch.zeros_like(radius), 0.5 * (1.0 + torch.cos(math.pi * t))),
        )
    while weight.ndim < real.ndim:
        weight = weight.unsqueeze(0)
    fill_tensor = torch.as_tensor(fill, device=real.device, dtype=real.dtype)
    while fill_tensor.ndim < real.ndim:
        fill_tensor = fill_tensor.unsqueeze(-1)
    return real * weight + fill_tensor * (1.0 - weight)


def normalise_real_image(image: torch.Tensor, *, eps: float = 1.0e-8) -> torch.Tensor:
    dims = (-2, -1)
    mean = image.mean(dim=dims, keepdim=True)
    centred = image - mean
    std = centred.square().mean(dim=dims, keepdim=True).sqrt().clamp_min(eps)
    return centred / std


def relion_soft_mask_outside_map(
    real: torch.Tensor,
    *,
    radius_pixels: float = -1.0,
    cosine_width_pixels: float = 3.0,
    noise: torch.Tensor | None = None,
    ndim: int | None = None,
) -> torch.Tensor:
    """Reproduce RELION 3.1 ``softMaskOutsideMap`` for a centred map.

    RELION does not set the corners to zero.  With ``noise=None`` it first
    estimates a weighted average background from the transition and outer
    regions, then blends the map into that average with the source raised-cosine
    convention.  The comparisons deliberately follow the C++ implementation:
    ``r < radius`` is untouched, ``r > radius + width`` is replaced, and both
    boundaries are handled by the cosine branch.
    """

    if ndim is None:
        if real.ndim == 2:
            ndim = 2
        elif real.ndim == 3 and len(set(int(v) for v in real.shape)) == 1:
            ndim = 3
        else:
            raise ValueError(
                "ndim is required for batched maps or ambiguous 3-D tensors"
            )
    if ndim not in (2, 3) or real.ndim < ndim:
        raise ValueError("ndim must describe the final two or three spatial axes")
    n = int(real.shape[-1])
    if any(int(v) != n for v in real.shape[-ndim:]):
        raise ValueError("RELION corner masking requires equal spatial dimensions")
    width = float(cosine_width_pixels)
    if width <= 0.0 or not math.isfinite(width):
        raise ValueError("cosine_width_pixels must be positive and finite")
    radius_value = float(radius_pixels)
    if radius_value < 0.0:
        radius_value = n / 2.0
    if not math.isfinite(radius_value):
        raise ValueError("radius_pixels must be finite")
    if noise is not None and noise.shape != real.shape:
        raise ValueError("noise map must have the same shape as the reconstruction")

    radius = _centered_radius(n, ndim, device=real.device, dtype=real.dtype)
    radius_outer = radius_value + width
    transition = (radius >= radius_value) & (radius <= radius_outer)
    outer = radius > radius_outer
    raised = torch.zeros_like(radius)
    raised[transition] = 0.5 + 0.5 * torch.cos(
        math.pi * (radius_outer - radius[transition]) / width
    )
    raised[outer] = 1.0

    # When the requested mask radius covers the entire discrete grid, RELION's
    # second loop leaves every voxel untouched.  Its intermediate background
    # average is formally 0/0 but is never consumed; return the unchanged map
    # explicitly and avoid both NaNs and a CUDA scalar synchronisation.
    farthest = math.sqrt(float(ndim)) * float(n // 2)
    if radius_value >= farthest:
        return real

    spatial_dims = tuple(range(real.ndim - ndim, real.ndim))
    while raised.ndim < real.ndim:
        raised = raised.unsqueeze(0)
    if noise is None:
        denominator = raised.sum(dim=spatial_dims, keepdim=True)
        background = (raised * real).sum(
            dim=spatial_dims, keepdim=True
        ) / denominator
        add = background
    else:
        add = noise.to(device=real.device, dtype=real.dtype)

    return (1.0 - raised) * real + raised * add
