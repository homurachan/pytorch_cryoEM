"""Bounded point-group summation of immutable Fourier numerator/weight grids."""
import itertools
import torch
from relion_torch.geometry.symmetry import normalize_symmetry, operators


@torch.no_grad()
def _symmetrise_reference_(bp, symmetry, work_bytes=64*2**20):
    name=normalize_symmetry(symmetry)
    previous=bp._point_group_enforced
    if previous is not None:
        if previous!=name:raise ValueError('Cannot change symmetry of a completed accumulator')
        return bp
    if name=='C1':return bp
    if bp.reference_dim!=3:raise ValueError('Point groups require a 3D accumulator')
    bp.enforce_hermitian_x0_()
    sources=[x.clone() for x in (bp.numerator_real,bp.numerator_imag,bp.denominator)]
    outputs=(bp.numerator_real,bp.numerator_imag,bp.denominator)
    p=bp.compact_size;w=p//2+1; total=p*p*w; radius2=bp.max_r2_padded
    # Coordinates, index arrays and interpolation temporaries fit this allowance.
    chunk=max(1,int(work_bytes)//512); device=bp.denominator.device;dtype=bp.denominator.dtype
    for op in operators(name)[1:]:
        matrix=torch.tensor(op,device=device,dtype=dtype)
        for start in range(0,total,chunk):
            flat=torch.arange(start,min(total,start+chunk),device=device)
            x=flat%w;y=(flat//w)%p;z=flat//(w*p)
            y=torch.where(y<=p//2,y,y-p);z=torch.where(z<=p//2,z,z-p)
            coords=torch.stack((x,y,z),-1).to(dtype)
            active=coords.square().sum(-1)<=radius2
            mapped=coords@matrix.T; negative=mapped[:,0]<0
            mapped=torch.where(negative[:,None],-mapped,mapped)
            floor=mapped.floor();fraction=mapped-floor;base=floor.long()
            sums=[torch.zeros_like(x,dtype=dtype) for _ in range(3)]
            for bits in itertools.product((0,1),repeat=3):
                index=base+torch.tensor(bits,device=device)
                weight=torch.ones_like(sums[0])
                for axis,bit in enumerate(bits):weight*=fraction[:,axis] if bit else 1-fraction[:,axis]
                valid=(index[:,0]>=0)&(index[:,0]<w)&(index[:,1].abs()<=p//2)&(index[:,2].abs()<=p//2)&active
                key=(index[:,2]%p)*p*w+(index[:,1]%p)*w+index[:,0].clamp(0,w-1)
                weight=weight*valid
                for j,source in enumerate(sources):sums[j]+=source.flatten()[key]*weight
            sums[1]=torch.where(negative,-sums[1],sums[1])
            for output,value in zip(outputs,sums):output.flatten()[start:start+len(flat)].add_(value)
    bp._point_group_enforced=name
    return bp


@torch.no_grad()
def symmetrise_backprojector_(bp, symmetry, work_bytes=64*2**20, *, backend='auto', counters=None):
    name=normalize_symmetry(symmetry)
    if bp._point_group_enforced is not None:
        if bp._point_group_enforced!=name:raise ValueError('Cannot change symmetry of a completed accumulator')
        return bp
    if name=='C1':return bp
    if bp.reference_dim!=3:raise ValueError('Point groups require a 3D accumulator')
    bp.enforce_hermitian_x0_()
    from relion_torch.reconstruction.volume_fusion import symmetry as fused
    out=fused(bp,operators(name),group=name,mode=backend)
    if out is None:return _symmetrise_reference_(bp,name,work_bytes)
    # Commit only after all private output kernels have been submitted.
    # Do not catch/replay a failed copy into live sufficient statistics.
    for target,value in zip((bp.numerator_real,bp.numerator_imag,bp.denominator),out):target.copy_(value)
    bp._point_group_enforced=name
    if counters is not None:counters['fused_symmetry_calls']=counters.get('fused_symmetry_calls',0)+1
    return bp
