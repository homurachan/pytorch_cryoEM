from __future__ import annotations

from dataclasses import dataclass
import itertools

import torch


@dataclass(slots=True)
class InterpolationResult:
    values: torch.Tensor
    valid: torch.Tensor


def hermitian_map_coordinates(coords: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Map signed Cartesian Fourier coordinates to the RFFT x>=0 half-space."""

    if coords.shape[-1] not in (2, 3):
        raise ValueError("coords must end in 2 or 3 Cartesian dimensions")
    conjugate = coords[..., 0] < 0
    mapped = torch.where(conjugate[..., None], -coords, coords)
    return mapped, conjugate


def sample_half_spectrum(
    data: torch.Tensor,
    coords: torch.Tensor,
    *,
    interpolation: str = "linear",
    source_radius: int | None = None,
) -> InterpolationResult:
    """Bilinearly/trilinearly sample an unshifted RFFT half-spectrum.

    ``data`` is ``(P,P//2+1)`` or ``(P,P,P//2+1)`` and coordinates are Cartesian
    ``(x,y[,z])`` in padded Fourier-pixel units. y/z wrap periodically; x is
    mapped to the Hermitian half-space and conjugated when needed.
    """

    spatial_dim = data.ndim
    if spatial_dim not in (2, 3):
        raise ValueError(f"Expected a 2-D or 3-D half-spectrum, got rank {data.ndim}")
    if coords.shape[-1] != spatial_dim:
        raise ValueError(f"Coordinate dimension {coords.shape[-1]} != data rank {spatial_dim}")
    p = int(data.shape[-2]) if spatial_dim == 2 else int(data.shape[-3])
    expected = [p] * (spatial_dim - 1) + [p // 2 + 1]
    if list(data.shape) != expected:
        raise ValueError(f"Expected half-spectrum shape {tuple(expected)}, got {tuple(data.shape)}")

    if source_radius is not None:
        return _sample_supported_half_spectrum(data, coords, interpolation, source_radius)

    mapped, conjugate = hermitian_map_coordinates(coords)
    x = mapped[..., 0]
    valid = (x >= -1.0e-6) & (x <= (p / 2.0 + 1.0e-6))
    mode = interpolation.lower()
    if mode in {"nearest", "nearest-neighbour", "nearest_neighbor"}:
        idx_cart = torch.round(mapped).to(torch.int64)
        xi = idx_cart[..., 0].clamp(0, p // 2)
        yi = torch.remainder(idx_cart[..., 1], p)
        if spatial_dim == 2:
            values = data[yi, xi]
        else:
            zi = torch.remainder(idx_cart[..., 2], p)
            values = data[zi, yi, xi]
        values = torch.where(conjugate, values.conj(), values)
        return InterpolationResult(torch.where(valid, values, torch.zeros_like(values)), valid)
    if mode not in {"linear", "bilinear", "trilinear"}:
        raise ValueError(f"Unsupported interpolation: {interpolation}")

    floors = torch.floor(mapped)
    frac = mapped - floors
    base = floors.to(torch.int64)
    # At positive Nyquist, x+1 is outside the half-volume; force exact boundary use.
    at_upper = base[..., 0] >= p // 2
    frac_x = torch.where(at_upper, torch.zeros_like(frac[..., 0]), frac[..., 0])
    frac = frac.clone()
    frac[..., 0] = frac_x
    base = base.clone()
    base[..., 0] = base[..., 0].clamp(0, p // 2)

    out = torch.zeros(coords.shape[:-1], device=data.device, dtype=data.dtype)
    for bits in itertools.product((0, 1), repeat=spatial_dim):
        weight = torch.ones(coords.shape[:-1], device=data.device, dtype=coords.dtype)
        indices: list[torch.Tensor] = []
        for axis, bit in enumerate(bits):
            f = frac[..., axis]
            weight = weight * (f if bit else (1.0 - f))
            idx = base[..., axis] + bit
            if axis == 0:
                idx = idx.clamp(0, p // 2)
            else:
                idx = torch.remainder(idx, p)
            indices.append(idx)
        if spatial_dim == 2:
            value = data[indices[1], indices[0]]
        else:
            value = data[indices[2], indices[1], indices[0]]
        out = out + value * weight
    out = torch.where(conjugate, out.conj(), out)
    out = torch.where(valid, out, torch.zeros_like(out))
    return InterpolationResult(out, valid)


def _sample_supported_half_spectrum(
    data: torch.Tensor,
    coords: torch.Tensor,
    interpolation: str,
    source_radius: int,
) -> InterpolationResult:
    """Finite RELION source disk/sphere with zero halo (no periodic aliasing).

    The unshifted buffer's y/z Nyquist row represents +P/2, as in FFTW's
    FOR_ALL_ELEMENTS_IN_FFTW_TRANSFORM. There is no stored coefficient at -P/2
    in the compact source: that halo is zero, NOT an alias of +P/2. Mask signed
    integer neighbors BEFORE taking remainders for buffer lookup. x=P/2+1 is
    likewise a zero halo, not a clamped copy of x=P/2.
    """
    dim = data.ndim
    p = int(data.shape[0])
    radius = int(source_radius)
    if radius < 0 or radius > p // 2 or radius != source_radius:
        raise ValueError("source_radius must be an integer in [0, padded_size/2]")
    mapped, conjugate = hermitian_map_coordinates(coords)
    finite = torch.isfinite(mapped).all(dim=-1)
    # Invalid coordinates are never indexed, even before the mask is applied.
    safe = torch.where(finite[..., None], mapped, torch.zeros_like(mapped))
    mode = interpolation.lower()

    def read_neighbor(index: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        inside = index.square().sum(-1) <= radius * radius
        inside &= (index[..., 0] >= 0) & (index[..., 0] <= p // 2)
        for axis in range(1, dim):
            inside &= (index[..., axis] > -p // 2) & (index[..., axis] <= p // 2)
        xi = index[..., 0].clamp(0, p // 2)
        yi = torch.remainder(index[..., 1], p)
        value = data[yi, xi] if dim == 2 else data[torch.remainder(index[..., 2], p), yi, xi]
        return torch.where(inside, value, torch.zeros_like(value)), inside

    if mode in {"nearest", "nearest-neighbour", "nearest_neighbor"}:
        index = torch.where(safe >= 0, torch.floor(safe + .5), torch.ceil(safe - .5)).long()
        out, valid = read_neighbor(index)
        valid &= finite
    elif mode in {"linear", "bilinear", "trilinear"}:
        floors = torch.floor(safe)
        fraction = safe - floors
        base = floors.long()
        out = torch.zeros(coords.shape[:-1], device=data.device, dtype=data.dtype)
        valid = torch.zeros_like(finite)
        for bits in itertools.product((0, 1), repeat=dim):
            weight = torch.ones_like(safe[..., 0])
            index = base.clone()
            for axis, bit in enumerate(bits):
                weight = weight * (fraction[..., axis] if bit else 1.0 - fraction[..., axis])
                index[..., axis] += bit
            value, inside = read_neighbor(index)
            out = out + value * weight
            valid |= inside & (weight != 0)
        valid &= finite
    else:
        raise ValueError(f"Unsupported interpolation: {interpolation}")
    out = torch.where(conjugate, out.conj(), out)
    return InterpolationResult(torch.where(valid, out, torch.zeros_like(out)), valid)


def splat_half_spectrum_(
    numerator_real: torch.Tensor,
    numerator_imag: torch.Tensor,
    denominator: torch.Tensor,
    coords: torch.Tensor,
    values: torch.Tensor,
    weights: torch.Tensor,
    *, ordered: bool = False,
) -> None:
    """Adjoint linear interpolation into a real/imag RFFT accumulator."""

    spatial_dim = numerator_real.ndim
    if spatial_dim not in (2, 3):
        raise ValueError("Accumulator must be 2-D or 3-D")
    if numerator_real.shape != numerator_imag.shape or numerator_real.shape != denominator.shape:
        raise ValueError("Accumulator components must have identical shapes")
    p = int(numerator_real.shape[-2]) if spatial_dim == 2 else int(numerator_real.shape[-3])
    mapped, conjugate = hermitian_map_coordinates(coords)
    mapped_values = torch.where(conjugate, values.conj(), values)
    x = mapped[..., 0]
    valid = (x >= -1.0e-6) & (x <= (p / 2.0 + 1.0e-6))
    if not torch.any(valid):
        return
    mapped = mapped[valid]
    mapped_values = mapped_values[valid]
    weights = weights[valid]

    floors = torch.floor(mapped)
    frac = mapped - floors
    base = floors.to(torch.int64)
    at_upper = base[..., 0] >= p // 2
    frac = frac.clone()
    frac[..., 0] = torch.where(at_upper, torch.zeros_like(frac[..., 0]), frac[..., 0])
    base = base.clone()
    base[..., 0] = base[..., 0].clamp(0, p // 2)

    flat_r = numerator_real.reshape(-1)
    flat_i = numerator_imag.reshape(-1)
    flat_w = denominator.reshape(-1)
    nx = p // 2 + 1

    for bits in itertools.product((0, 1), repeat=spatial_dim):
        coeff = torch.ones(mapped.shape[:-1], device=mapped.device, dtype=mapped.dtype)
        idxs: list[torch.Tensor] = []
        for axis, bit in enumerate(bits):
            f = frac[..., axis]
            coeff = coeff * (f if bit else (1.0 - f))
            idx = base[..., axis] + bit
            if axis == 0:
                idx = idx.clamp(0, p // 2)
            else:
                idx = torch.remainder(idx, p)
            idxs.append(idx)
        if spatial_dim == 2:
            linear = idxs[1] * nx + idxs[0]
        else:
            linear = (idxs[2] * p + idxs[1]) * nx + idxs[0]
        contribution = mapped_values * coeff
        wcontribution = weights * coeff
        if ordered:
            # Sort each bounded pixel chunk, then assign each unique voxel once.
            # No contended floating-point atomics; ordering is stable for fixed
            # inputs and chunk sizes. The default fast path remains unchanged.
            order = torch.argsort(linear.reshape(-1), stable=True)
            unique, lengths = torch.unique_consecutive(linear.reshape(-1)[order], return_counts=True)
            channels = torch.stack((contribution.real.reshape(-1),
                                    contribution.imag.reshape(-1), wcontribution.reshape(-1)), -1)
            summed = torch.segment_reduce(channels[order], 'sum', lengths=lengths)
            flat_r[unique] = flat_r[unique]+summed[:, 0]
            flat_i[unique] = flat_i[unique]+summed[:, 1]
            flat_w[unique] = flat_w[unique]+summed[:, 2]
        else:
            flat_r.index_add_(0, linear.reshape(-1), contribution.real.reshape(-1))
            flat_i.index_add_(0, linear.reshape(-1), contribution.imag.reshape(-1))
            flat_w.index_add_(0, linear.reshape(-1), wcontribution.reshape(-1))
