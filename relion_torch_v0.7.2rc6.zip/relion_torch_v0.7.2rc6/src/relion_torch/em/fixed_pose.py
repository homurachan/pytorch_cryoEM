from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
import torch

from relion_torch.em.model import FixedPoseModel
from relion_torch.fourier.backprojector import FourierBackprojector
from relion_torch.fourier.conventions import (
    centered_irfft,
    centered_rfft,
    fourier_shift_2d,
    gridding_correct,
    padded_size,
    relion_soft_mask_outside_map,
)
from relion_torch.fourier.projector import FourierProjector
from relion_torch.fourier.shells import smooth_spectrum
from relion_torch.geometry.euler import relion_euler_matrix_2d
from relion_torch.io.mrc import load_references, read_mrc, write_mrc
from relion_torch.io.particles import (
    ParticleBatch,
    ParticleDataset,
    rebase_image_references,
)
from relion_torch.io.star import read_relion_star, write_relion_star, write_star
from relion_torch.optics.ctf import compute_ctf
from relion_torch.reconstruction.fsc import (
    fourier_shell_correlation,
    radial_power_spectrum,
)
from relion_torch.reconstruction.masks import (
    apply_real_space_mask,
    soft_spherical_mask,
)
from relion_torch.reconstruction.reconstruct import (
    ReconstructionOptions,
    ReconstructionResult,
    reconstruct_backprojector,
)
from relion_torch.reconstruction.ssnr import SSNRResult, update_ssnr_arrays
from relion_torch.inference.alignment import (
    mean_normalised_log_class_prior,
    relion_weight_selection_batch,
)
from relion_torch.relion_statistics import (
    Mresol2D,
    radial_sum_unique_2d,
    relion_mresol_2d,
    repair_negative_spectrum_relion,
    repair_nonpositive_spectrum,
    resolution_schedule,
    resolution_shell_from_data_vs_prior,
    class_resolution_shell_from_data_vs_prior,
    shell_to_angstrom,
)


@dataclass(slots=True)
class FixedPoseEMConfig:
    device: str = "cpu"
    dtype: torch.dtype = torch.float32
    iterations: int = 5
    batch_size: int = 8
    padding_factor: float = 2.0
    do_ctf: bool = True
    tau2_fudge: float = 1.0
    preweight_iterations: int = 10
    skip_gridding: bool = False
    split_random_halves: bool = False
    random_seed: int = 0
    particle_diameter_angstrom: float | None = None
    # RELION's width_mask_edge is measured in pixels. The Angstrom field is
    # retained only for backwards-compatible programmatic callers.
    mask_edge_pixels: float = 5.0
    mask_edge_angstrom: float | None = None
    zero_mask: bool = False
    flatten_solvent: bool = False
    solvent_mask_path: str | None = None
    # Both names mean RELION's strict_highres_exp: they cap probability
    # calculations but do not overwrite the PSNR-derived resolution or the
    # working reconstruction size.
    strict_highres_exp_angstrom: float | None = None
    max_resolution_angstrom: float | None = None
    current_size_increment: int = 10
    minres_map: int = 5
    use_all_data: bool = False
    adaptive_fraction: float = 1.0
    noise_smoothing_radius: int = 0
    minimum_class_prior: float = 1.0e-12
    minimum_variance: float = 1.0e-20
    write_every_iteration: bool = True
    write_posterior_table: bool = False


@dataclass(slots=True)
class FixedPoseEMResult:
    model: FixedPoseModel
    posteriors: torch.Tensor
    particles: pd.DataFrame
    log_likelihood_contribution: torch.Tensor
    output_files: dict[str, Path]


class FixedPoseEM:
    """RELION-style fixed-pose MAP/EM shared by Class2D and Class3D.

    The particle angles and origins remain fixed; class identity is the only
    latent variable. All FFTs continue to use the v0.1.1 ``norm='forward'``
    convention that was validated by standalone reconstruction.
    """

    def __init__(self, config: FixedPoseEMConfig) -> None:
        self.config = config
        self.device = torch.device(config.device)
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError(
                f"CUDA device {self.device} requested but CUDA is unavailable"
            )
        if config.iterations < 1 or config.batch_size < 1:
            raise ValueError("iterations and batch_size must be positive")
        if config.current_size_increment < 0:
            raise ValueError("current_size_increment must be non-negative")
        if config.minres_map < 0:
            raise ValueError("minres_map must be non-negative")
        if config.mask_edge_pixels < 0:
            raise ValueError("mask_edge_pixels must be non-negative")
        if (
            config.mask_edge_angstrom is not None
            and config.mask_edge_angstrom < 0
        ):
            raise ValueError("mask_edge_angstrom must be non-negative")
        if not 0.0 < config.adaptive_fraction <= 1.0:
            raise ValueError("adaptive_fraction must be in (0,1]")
        if (
            config.strict_highres_exp_angstrom is not None
            and config.max_resolution_angstrom is not None
            and not math.isclose(
                config.strict_highres_exp_angstrom,
                config.max_resolution_angstrom,
                rel_tol=1.0e-12,
                abs_tol=1.0e-12,
            )
        ):
            raise ValueError(
                "strict_highres_exp_angstrom and max_resolution_angstrom disagree"
            )

    @property
    def _strict_highres(self) -> float | None:
        value = self.config.strict_highres_exp_angstrom
        if value is None:
            value = self.config.max_resolution_angstrom
        return value

    def _ensure_random_subsets(self, dataset: ParticleDataset) -> None:
        if "rlnRandomSubset" in dataset.table.columns:
            values = pd.to_numeric(dataset.table["rlnRandomSubset"], errors="coerce")
            if values.notna().all() and set(
                int(v) for v in values.unique()
            ).issubset({1, 2}):
                return
        rng = np.random.default_rng(self.config.random_seed)
        subsets = np.ones(len(dataset), dtype=np.int64)
        subsets[len(dataset) // 2 :] = 2
        rng.shuffle(subsets)
        dataset.table["rlnRandomSubset"] = subsets

    def _mask_edge_pixels(self, dataset: ParticleDataset) -> float:
        if self.config.mask_edge_angstrom is not None:
            return float(self.config.mask_edge_angstrom) / dataset.pixel_size
        return float(self.config.mask_edge_pixels)

    def _effective_particle_diameter_angstrom(
        self, dataset: ParticleDataset
    ) -> float:
        """Return the explicit diameter or RELION's non-helical default.

        RELION 3.1 uses ``(ori_size - width_mask_edge) * pixel_size`` when the
        user leaves ``--particle_diameter`` unset.  Keeping this calculation in
        the masking path also makes it impossible for the diameter to enter the
        PSNR/data-versus-prior equations directly.
        """

        diameter = self.config.particle_diameter_angstrom
        if diameter is None:
            diameter = (
                float(dataset.box_size) - self._mask_edge_pixels(dataset)
            ) * float(dataset.pixel_size)
        if diameter <= 0:
            raise ValueError("particle_diameter_angstrom must be positive")
        return float(diameter)

    def _particle_mask_radius(self, dataset: ParticleDataset) -> float:
        diameter = self._effective_particle_diameter_angstrom(dataset)
        return diameter / (2.0 * dataset.pixel_size)

    def _particle_mask(self, dataset: ParticleDataset) -> torch.Tensor:
        radius = self._particle_mask_radius(dataset)
        return soft_spherical_mask(
            (dataset.box_size, dataset.box_size),
            radius,
            edge_width_pixels=self._mask_edge_pixels(dataset),
            device=self.device,
            dtype=self.config.dtype,
        )

    def _initial_real_images(
        self,
        images: torch.Tensor,
        dataset: ParticleDataset,
        mask: torch.Tensor | None,
    ) -> torch.Tensor:
        # RELION applies softMaskOutsideMap during initial power estimation only
        # for --zero_mask.  Despite the option name, the outside is replaced by
        # each particle's weighted average background, not literal zeros.
        if self.config.zero_mask and mask is not None:
            return relion_soft_mask_outside_map(
                images,
                radius_pixels=self._particle_mask_radius(dataset),
                cosine_width_pixels=self._mask_edge_pixels(dataset),
                ndim=2,
            )
        return images

    def _coloured_noise_batch(
        self,
        batch: ParticleBatch,
        dataset: ParticleDataset,
        sigma2_noise: torch.Tensor,
        *,
        iteration: int,
    ) -> torch.Tensor:
        """Generate group-specific noisy solvent with RELION sigma2 convention.

        A unit-variance real image transformed with ``norm='forward'`` has
        interior real/imag Fourier-component variance ``1/(2*N**2)``. Scaling
        by ``N*sqrt(2*sigma2)`` therefore produces the requested per-component
        Fourier variance without changing the package-wide FFT convention.
        """

        n = dataset.box_size
        mresol = relion_mresol_2d(
            n, n, device=self.device, dtype=self.config.dtype
        )
        complex_dtype = (
            torch.complex64 if self.config.dtype == torch.float32 else torch.complex128
        )
        out: list[torch.Tensor] = []
        for local, row_index in enumerate(batch.row_indices):
            generator = torch.Generator(device=self.device)
            # RELION resets the generator with random_seed + part_id whenever
            # the particle is prepared, yielding the same deterministic noisy
            # solvent realization on every iteration.
            seed = int(self.config.random_seed) + int(row_index)
            generator.manual_seed(seed & 0x7FFF_FFFF_FFFF_FFFF)
            white = torch.randn(
                (n, n),
                generator=generator,
                device=self.device,
                dtype=self.config.dtype,
            )
            fourier = centered_rfft(white, ndim=2).to(complex_dtype)
            group = int(batch.group_index[local].item())
            spectrum = sigma2_noise[group]
            sigma_grid = spectrum[
                mresol.shells.clamp_max(spectrum.numel() - 1)
            ].clamp_min(0.0)
            scale = float(n) * torch.sqrt(2.0 * sigma_grid)
            noise_fourier = fourier * scale.to(fourier.real.dtype)
            out.append(centered_irfft(noise_fourier, (n, n), ndim=2))
        return torch.stack(out, dim=0)

    def _prepare_images(
        self,
        batch: ParticleBatch,
        dataset: ParticleDataset,
        sigma2_noise: torch.Tensor,
        mask: torch.Tensor | None,
        *,
        iteration: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Return masked likelihood data and unmasked reconstruction data."""

        unmasked = centered_rfft(batch.images, ndim=2)
        if mask is None:
            likelihood_real = batch.images
        elif self.config.zero_mask:
            likelihood_real = relion_soft_mask_outside_map(
                batch.images,
                radius_pixels=self._particle_mask_radius(dataset),
                cosine_width_pixels=self._mask_edge_pixels(dataset),
                ndim=2,
            )
        else:
            noise = self._coloured_noise_batch(
                batch,
                dataset,
                sigma2_noise,
                iteration=iteration,
            )
            likelihood_real = relion_soft_mask_outside_map(
                batch.images,
                radius_pixels=self._particle_mask_radius(dataset),
                cosine_width_pixels=self._mask_edge_pixels(dataset),
                noise=noise,
                ndim=2,
            )
        if likelihood_real.data_ptr() == batch.images.data_ptr():
            masked = unmasked
        else:
            masked = centered_rfft(likelihood_real, ndim=2)
        masked = fourier_shift_2d(masked, batch.origins_pixels, sign=-1.0)
        unmasked = fourier_shift_2d(unmasked, batch.origins_pixels, sign=-1.0)
        return masked, unmasked

    def _solvent_mask(
        self, reference: torch.Tensor, dataset: ParticleDataset
    ) -> torch.Tensor | None:
        if not self.config.flatten_solvent:
            return None
        if self.config.solvent_mask_path:
            mask = read_mrc(
                self.config.solvent_mask_path,
                device=self.device,
                dtype=self.config.dtype,
            )
            if mask.shape != reference.shape:
                raise ValueError(
                    f"Solvent mask shape {tuple(mask.shape)} does not match "
                    f"reference {tuple(reference.shape)}"
                )
            return mask.clamp(0.0, 1.0)
        radius = self._particle_mask_radius(dataset)
        return soft_spherical_mask(
            tuple(int(v) for v in reference.shape),
            radius,
            edge_width_pixels=self._mask_edge_pixels(dataset),
            device=self.device,
            dtype=self.config.dtype,
        )

    @staticmethod
    def _apply_solvent(
        result: ReconstructionResult, mask: torch.Tensor | None
    ) -> torch.Tensor:
        if mask is None:
            return result.map
        return apply_real_space_mask(result.map, mask, solvent_value=0.0)

    def _ctf(self, batch: ParticleBatch, dataset: ParticleDataset) -> torch.Tensor:
        if not self.config.do_ctf:
            return torch.ones(
                (
                    len(batch.row_indices),
                    dataset.box_size,
                    dataset.box_size // 2 + 1,
                ),
                device=self.device,
                dtype=self.config.dtype,
            )
        return compute_ctf(
            dataset.box_size,
            dataset.pixel_size,
            batch.ctf_parameters,
            device=self.device,
            dtype=self.config.dtype,
        )

    def _rotations(self, batch: ParticleBatch, reference_dim: int) -> torch.Tensor:
        if reference_dim == 2:
            return relion_euler_matrix_2d(
                batch.euler_degrees[:, 2],
                device=self.device,
                dtype=self.config.dtype,
            )
        return batch.rotations

    def _inverse_noise_grid(
        self,
        sigma2_noise: torch.Tensor,
        group_index: torch.Tensor,
        mresol: Mresol2D,
    ) -> torch.Tensor:
        per_particle = sigma2_noise.index_select(0, group_index)
        shell_flat = mresol.shells.clamp_max(
            sigma2_noise.shape[1] - 1
        ).reshape(-1)
        sigma = per_particle[:, shell_flat].reshape(
            per_particle.shape[0], *mresol.shells.shape
        )
        inverse = 1.0 / sigma.clamp_min(self.config.minimum_variance)
        return torch.where(
            mresol.likelihood_mask.unsqueeze(0),
            inverse,
            torch.zeros_like(inverse),
        )

    def _initial_noise(
        self,
        dataset: ParticleDataset,
        mask: torch.Tensor | None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """RELION initial sigma2_noise and average image.

        The forward-normalised FFT used here is the same implementation as in
        v0.1.1. This prevents the N**2 power blow-up introduced by the rejected
        patch's orthonormal FFT path.
        """

        n = dataset.box_size
        groups = dataset.number_of_groups
        shell_count = n // 2 + 1
        group_power = torch.zeros(
            (groups, shell_count), device=self.device, dtype=torch.float64
        )
        average_image_sum = torch.zeros(
            (n, n), device=self.device, dtype=torch.float64
        )
        group_counts = torch.zeros(
            groups, device=self.device, dtype=torch.float64
        )
        # Initial noise follows FFTW's physically stored R2C half-plane: every
        # stored coefficient and shell count contributes once, including the
        # x=0 negative-y entries.  No Hermitian multiplicity is applied.
        ky = torch.fft.fftfreq(
            n, d=1.0 / n, device=self.device, dtype=self.config.dtype
        )
        kx = torch.arange(
            n // 2 + 1, device=self.device, dtype=self.config.dtype
        )
        yy, xx = torch.meshgrid(ky, kx, indexing="ij")
        shells = torch.floor(torch.sqrt(xx.square() + yy.square()) + 0.5).long()
        valid = shells < shell_count
        shell_index = shells[valid].reshape(-1)
        coefficient_count = torch.zeros(
            shell_count, device=self.device, dtype=torch.float64
        )
        coefficient_count.scatter_add_(
            0, shell_index, torch.ones_like(shell_index, dtype=torch.float64)
        )

        for batch in dataset.iter_batches(
            self.config.batch_size,
            device=self.device,
            dtype=self.config.dtype,
        ):
            real = self._initial_real_images(batch.images, dataset, mask)
            average_image_sum += real.to(torch.float64).sum(dim=0)
            fourier = centered_rfft(real, ndim=2)
            power = fourier.real.square() + fourier.imag.square()
            flat_power = power[:, valid].to(torch.float64)
            spectra_sum = torch.zeros(
                (power.shape[0], shell_count),
                device=self.device,
                dtype=torch.float64,
            )
            expanded_shells = shell_index.unsqueeze(0).expand(power.shape[0], -1)
            spectra_sum.scatter_add_(1, expanded_shells, flat_power)
            spectra = spectra_sum / coefficient_count.clamp_min(1.0)
            group_power.index_add_(0, batch.group_index, spectra)
            group_counts.index_add_(
                0,
                batch.group_index,
                torch.ones(
                    len(batch.row_indices),
                    device=self.device,
                    dtype=torch.float64,
                ),
            )

        average_image = (
            average_image_sum / float(len(dataset))
        ).to(self.config.dtype)
        average_fourier = centered_rfft(average_image, ndim=2)
        average_power = (
            average_fourier.real.square() + average_fourier.imag.square()
        ).to(torch.float64)
        average_sum = torch.zeros(
            shell_count, device=self.device, dtype=torch.float64
        )
        average_sum.scatter_add_(0, shell_index, average_power[valid].reshape(-1))
        average_spectrum = average_sum / coefficient_count.clamp_min(1.0)
        sigma = group_power / (
            2.0 * group_counts[:, None].clamp_min(1.0)
        )
        sigma -= average_spectrum[None, :] / 2.0
        sigma = repair_negative_spectrum_relion(
            sigma.to(self.config.dtype),
            minimum=self.config.minimum_variance,
        )
        if self.config.noise_smoothing_radius > 0:
            sigma = smooth_spectrum(
                sigma, self.config.noise_smoothing_radius
            )
        return (
            sigma.clamp_min(self.config.minimum_variance),
            average_image,
        )

    def _reference_tau2(self, reference: torch.Tensor) -> torch.Tensor:
        """RELION-3.1-compatible radial tau^2 spectrum from an input reference.

        The reference is transformed without projector gridding correction.  With
        ``norm=\"forward\"``, RELION's 2-D image likelihood convention requires
        a scale N**(2*(ref_dim-2))/2: N**2/2 for a 3-D map and 1/2 for
        a 2-D class average.  Padding does not enter this spectrum.
        """
        import torch
        _ref = torch.as_tensor(reference)
        if _ref.ndim not in (2, 3):
            raise ValueError(f"reference must be 2-D or 3-D, got shape {tuple(_ref.shape)}")
        if any(int(v) != int(_ref.shape[-1]) for v in _ref.shape):
            raise ValueError(f"reference must be square/cubic, got shape {tuple(_ref.shape)}")
        _n = int(_ref.shape[-1])
        _dims = tuple(range(_ref.ndim))
        _ft = torch.fft.rfftn(torch.fft.ifftshift(_ref, dim=_dims), dim=_dims, norm="forward")
        _freq_axes = [torch.fft.fftfreq(_n, d=1.0/_n, device=_ref.device, dtype=_ref.dtype) for _ in range(_ref.ndim - 1)]
        _freq_axes.append(torch.fft.rfftfreq(_n, d=1.0/_n, device=_ref.device, dtype=_ref.dtype))
        _mesh = torch.meshgrid(*_freq_axes, indexing="ij")
        _radius2 = torch.zeros_like(_mesh[0])
        for _axis in _mesh:
            _radius2 = _radius2 + _axis * _axis
        _shell = torch.floor(torch.sqrt(_radius2) + 0.5).to(torch.long)
        _max_shell = _n // 2
        _valid = _shell <= _max_shell
        _last_k = _mesh[-1]
        _mult = torch.where((_last_k == 0) | ((_n % 2 == 0) & (_last_k == (_n // 2))), torch.ones_like(_last_k), torch.full_like(_last_k, 2.0))
        _pow = (_ft.real * _ft.real + _ft.imag * _ft.imag)
        _sum = torch.zeros(_max_shell + 1, dtype=_ref.dtype, device=_ref.device)
        _count = torch.zeros_like(_sum)
        _idx = _shell[_valid].reshape(-1)
        _sum.scatter_add_(0, _idx, (_pow[_valid] * _mult[_valid]).reshape(-1))
        _count.scatter_add_(0, _idx, _mult[_valid].reshape(-1))
        _spectrum = _sum / _count.clamp_min(1.0)
        _scale = (float(_n) ** (2 * (_ref.ndim - 2))) / 2.0
        _tau2 = _spectrum * _scale
        return _tau2


    def _log_sigma2_normalisation(
        self,
        sigma2_noise: torch.Tensor,
        group_index: torch.Tensor,
        mresol: Mresol2D,
    ) -> torch.Tensor:
        """RELION complex-Gaussian normalisation for per-image dLL.

        RELION sums ``log(2*pi*sigma2_noise[group][shell])`` over the fine
        current-size Fourier support.  A stricter ``strict_highres_exp`` may
        reduce the residual-score support, but it does not shrink this Gaussian
        normaliser.  DC and redundant x=0,y<0 coefficients are excluded.
        """

        per_particle = sigma2_noise.index_select(0, group_index)
        shell_flat = mresol.shells.clamp_max(
            sigma2_noise.shape[1] - 1
        ).reshape(-1)
        sigma = per_particle[:, shell_flat].reshape(
            per_particle.shape[0], *mresol.shells.shape
        )
        selected = sigma[:, mresol.likelihood_mask].to(torch.float64).clamp_min(
            self.config.minimum_variance
        )
        return torch.log((2.0 * math.pi) * selected).sum(dim=1)

    def _initialise_data_vs_prior(
        self,
        tau2: Sequence[torch.Tensor],
        class_priors: torch.Tensor,
        sigma2_noise: torch.Tensor,
        group_particle_counts: Sequence[int],
        *,
        reference_dim: int,
    ) -> list[torch.Tensor]:
        """RELION 3.1 analytic initial evidence-to-prior approximation."""

        counts = torch.as_tensor(
            group_particle_counts,
            device=self.device,
            dtype=torch.float64,
        )
        noise = sigma2_noise.to(torch.float64).clamp_min(
            self.config.minimum_variance
        )
        evidence = torch.sum(counts[:, None] / noise, dim=0)
        shell = torch.arange(
            noise.shape[1], device=self.device, dtype=torch.float64
        )
        geometry = (
            torch.where(shell > 0, 2.0 * shell, torch.ones_like(shell))
            if reference_dim == 3
            else torch.ones_like(shell)
        )
        values: list[torch.Tensor] = []
        for index, tau in enumerate(tau2):
            dvp = (
                tau.to(torch.float64)
                * float(class_priors[index].item())
                * float(self.config.tau2_fudge)
                * evidence
                / geometry
            )
            values.append(
                torch.nan_to_num(
                    dvp,
                    nan=0.0,
                    posinf=0.0,
                    neginf=0.0,
                ).to(self.config.dtype)
            )
        return values

    def _new_bp(
        self, n: int, ref_dim: int, *, current_size: int
    ) -> FourierBackprojector:
        return FourierBackprojector.create(
            n,
            current_size=current_size,
            padding_factor=self.config.padding_factor,
            reference_dim=ref_dim,
            device=self.device,
            dtype=self.config.dtype,
        )

    def initialise_model(
        self,
        dataset: ParticleDataset,
        references: Sequence[torch.Tensor],
        mask: torch.Tensor | None,
    ) -> FixedPoseModel:
        refs = [
            ref.to(device=self.device, dtype=self.config.dtype).clone()
            for ref in references
        ]
        if not refs:
            raise ValueError("At least one reference is required")
        shape = refs[0].shape
        if len(shape) not in (2, 3) or len(set(shape)) != 1:
            raise ValueError("References must be square 2-D or cubic 3-D arrays")
        if any(ref.shape != shape for ref in refs):
            raise ValueError("All references must have identical shapes")
        if shape[-1] != dataset.box_size:
            raise ValueError(
                f"Reference box {shape[-1]} differs from particle box "
                f"{dataset.box_size}"
            )

        priors = torch.full(
            (len(refs),),
            1.0 / len(refs),
            device=self.device,
            dtype=self.config.dtype,
        )
        noise, _average_image = self._initial_noise(dataset, mask)
        tau2 = [self._reference_tau2(ref) for ref in refs]
        data_vs_prior = self._initialise_data_vs_prior(
            tau2,
            priors,
            noise,
            dataset.group_particle_counts,
            reference_dim=len(shape),
        )
        class_shells = [
            class_resolution_shell_from_data_vs_prior(value)
            for value in data_vs_prior
        ]
        global_shell = resolution_shell_from_data_vs_prior(
            torch.stack(data_vs_prior), min_shell=self.config.minres_map
        )
        zeros = [torch.zeros_like(value) for value in tau2]
        halves1 = (
            [ref.clone() for ref in refs]
            if self.config.split_random_halves
            else None
        )
        halves2 = (
            [ref.clone() for ref in refs]
            if self.config.split_random_halves
            else None
        )
        model = FixedPoseModel(
            references=refs,
            class_priors=priors,
            sigma2_noise=noise,
            tau2=tau2,
            sigma2_class=[value.clone() for value in zeros],
            data_vs_prior=data_vs_prior,
            fourier_coverage=[value.clone() for value in zeros],
            group_numbers=list(dataset.group_numbers),
            group_names=list(dataset.group_names),
            group_particle_counts=list(dataset.group_particle_counts),
            current_size=0,
            likelihood_size=0,
            current_resolution_shell=global_shell,
            # RELION's it000 general block remains inf/0; class rows carry the
            # initial estimated resolution.
            current_resolution_angstrom=float("inf"),
            class_resolution_shells=class_shells,
            class_resolution_angstroms=[
                shell_to_angstrom(
                    dataset.box_size, dataset.pixel_size, shell
                )
                for shell in class_shells
            ],
            average_pmax=0.0,
            log_likelihood=0.0,
            sigma_offset_angstrom=10.0,
            half1_references=halves1,
            half2_references=halves2,
            iteration=0,
        )
        model.validate()
        return model

    def _reconstruction_options(
        self,
        tau2: torch.Tensor | None,
        *,
        normalise: float,
        fsc: torch.Tensor | None = None,
    ) -> ReconstructionOptions:
        return ReconstructionOptions(
            preweight_iterations=self.config.preweight_iterations,
            skip_gridding=self.config.skip_gridding,
            tau2=tau2,
            fsc=fsc,
            tau2_fudge=self.config.tau2_fudge,
            interpolation="linear",
            normalise=max(
                float(normalise), self.config.minimum_class_prior
            ),
            min_resol_shell=self.config.minres_map,
        )

    @staticmethod
    def _significant_class_mask(
        raw_weights: torch.Tensor, adaptive_fraction: float
    ) -> torch.Tensor:
        # Compatibility wrapper for callers that already hold unnormalised
        # class weights.  The EM likelihood path uses the shared RELION selector
        # directly so the exponent cutoff, count and threshold are preserved.
        raw64 = raw_weights.to(torch.float64)
        log_weight = torch.full_like(raw64, -torch.inf)
        positive = torch.isfinite(raw64) & (raw64 > 0.0)
        log_weight[positive] = torch.log(raw64[positive])
        selection = relion_weight_selection_batch(
            log_weight,
            torch.zeros_like(raw64),
            adaptive_fraction,
        )
        return selection.significant

    @staticmethod
    def _sigma_offset_angstrom(dataset: ParticleDataset) -> float:
        table = dataset.table

        def column_or_zeros(label: str) -> np.ndarray:
            if label not in table.columns:
                return np.zeros(len(table), dtype=np.float64)
            return (
                pd.to_numeric(table[label], errors="coerce")
                .fillna(0.0)
                .to_numpy(dtype=np.float64)
            )

        if "rlnOriginXAngst" in table.columns:
            ox = column_or_zeros("rlnOriginXAngst")
        else:
            ox = column_or_zeros("rlnOriginX") * dataset.pixel_size
        if "rlnOriginYAngst" in table.columns:
            oy = column_or_zeros("rlnOriginYAngst")
        else:
            oy = column_or_zeros("rlnOriginY") * dataset.pixel_size
        return float(np.sqrt(np.mean(ox * ox + oy * oy) / 2.0))

    @torch.no_grad()
    def run(
        self,
        dataset: ParticleDataset,
        references: Sequence[torch.Tensor],
        output_prefix: str | Path,
    ) -> FixedPoseEMResult:
        if self.config.split_random_halves:
            self._ensure_random_subsets(dataset)

        n = dataset.box_size
        output_prefix = Path(output_prefix).expanduser().resolve()
        output_prefix.parent.mkdir(parents=True, exist_ok=True)
        particle_mask = self._particle_mask(dataset)
        model = self.initialise_model(dataset, references, particle_mask)
        ref_dim = model.reference_dim
        k_classes = model.number_of_classes
        groups = dataset.number_of_groups
        output_files: dict[str, Path] = {}
        posteriors = torch.empty(
            (len(dataset), k_classes),
            device=self.device,
            dtype=self.config.dtype,
        )
        # RELION accumulates per-particle dLL into a double-precision global
        # sum even when the Fourier kernels use single precision.
        log_contrib = torch.empty(
            (len(dataset),), device=self.device, dtype=torch.float64
        )
        raw_log_evidence = torch.empty_like(log_contrib)
        log_sigma2_normalisation = torch.empty_like(log_contrib)
        dll_maximum_shell = torch.zeros(
            (len(dataset),), device=self.device, dtype=torch.int64
        )
        significant_counts = torch.full(
            (len(dataset),),
            k_classes,
            device=self.device,
            dtype=torch.int64,
        )
        solvent_masks = [
            self._solvent_mask(ref, dataset) for ref in model.references
        ]
        last_fsc_by_class: list[torch.Tensor] = []

        # RELION writes the initial state before entering expectation iteration 1.
        output_files.update(
            self._write_iteration(
                model,
                output_prefix,
                dataset,
                (),
                particle_table=None,
            )
        )

        for iteration in range(1, self.config.iterations + 1):
            schedule = resolution_schedule(
                torch.stack(model.data_vs_prior),
                box_size=n,
                pixel_size_angstrom=dataset.pixel_size,
                increment=self.config.current_size_increment,
                min_shell=self.config.minres_map,
                strict_highres_angstrom=self._strict_highres,
                use_all_data=self.config.use_all_data,
            )
            print(
                f"Iteration {iteration}: PSNR resolution "
                f"{schedule.psnr_angstrom:.6g} A (shell {schedule.psnr_shell}); "
                f"working current size {schedule.working_current_size} "
                f"(shell {schedule.working_max_shell}); likelihood size "
                f"{schedule.likelihood_current_size} "
                f"(shell {schedule.likelihood_max_shell})"
            )

            working_mresol = relion_mresol_2d(
                n,
                schedule.working_current_size,
                device=self.device,
                dtype=self.config.dtype,
            )
            likelihood_mresol = relion_mresol_2d(
                n,
                schedule.likelihood_current_size,
                device=self.device,
                dtype=self.config.dtype,
            )
            full_mresol = relion_mresol_2d(
                n, n, device=self.device, dtype=self.config.dtype
            )

            combined_projectors = [
                FourierProjector.from_real(
                    ref,
                    padding_factor=self.config.padding_factor,
                    interpolation="linear",
                    current_size=schedule.working_current_size,
                )
                for ref in model.references
            ]
            # RELION's setFourierTransformMaps derives the working tau² from
            # the exact gridding-corrected, padded and normalised projector
            # representation used for projection, not from an unpadded map FFT.
            current_tau2 = [
                projector.power_spectrum(
                    current_size=schedule.working_current_size
                ).to(self.config.dtype)
                for projector in combined_projectors
            ]
            half1_projectors = None
            half2_projectors = None
            if model.has_random_halves:
                assert model.half1_references is not None
                assert model.half2_references is not None
                half1_projectors = [
                    FourierProjector.from_real(
                        ref, padding_factor=self.config.padding_factor,
                        current_size=schedule.working_current_size,
                    )
                    for ref in model.half1_references
                ]
                half2_projectors = [
                    FourierProjector.from_real(
                        ref, padding_factor=self.config.padding_factor,
                        current_size=schedule.working_current_size,
                    )
                    for ref in model.half2_references
                ]

            all_bp = [
                self._new_bp(
                    n, ref_dim, current_size=schedule.working_current_size
                )
                for _ in range(k_classes)
            ]
            half1_bp = (
                [
                    self._new_bp(
                        n, ref_dim, current_size=schedule.working_current_size
                    )
                    for _ in range(k_classes)
                ]
                if model.has_random_halves
                else None
            )
            half2_bp = (
                [
                    self._new_bp(
                        n, ref_dim, current_size=schedule.working_current_size
                    )
                    for _ in range(k_classes)
                ]
                if model.has_random_halves
                else None
            )
            class_mass = torch.zeros(
                k_classes, device=self.device, dtype=torch.float64
            )
            half_class_mass = torch.zeros(
                (2, k_classes), device=self.device, dtype=torch.float64
            )
            residual_sum = torch.zeros(
                (groups, n // 2 + 1),
                device=self.device,
                dtype=torch.float64,
            )
            residual_weight = torch.zeros_like(residual_sum)
            log_prior = mean_normalised_log_class_prior(model.class_priors)

            for batch in dataset.iter_batches(
                self.config.batch_size,
                device=self.device,
                dtype=self.config.dtype,
            ):
                masked_fourier, unmasked_fourier = self._prepare_images(
                    batch,
                    dataset,
                    model.sigma2_noise,
                    particle_mask,
                    iteration=iteration,
                )
                ctf = self._ctf(batch, dataset)
                rotations = self._rotations(batch, ref_dim)
                invsigma_likelihood = self._inverse_noise_grid(
                    model.sigma2_noise,
                    batch.group_index,
                    likelihood_mresol,
                )
                invsigma_working = self._inverse_noise_grid(
                    model.sigma2_noise,
                    batch.group_index,
                    working_mresol,
                )

                residuals: list[torch.Tensor] = []
                diff2_values: list[torch.Tensor] = []
                for class_index in range(k_classes):
                    if model.has_random_halves:
                        assert half1_projectors is not None
                        assert half2_projectors is not None
                        p1 = half1_projectors[class_index].project(rotations)
                        p2 = half2_projectors[class_index].project(rotations)
                        if p1.ndim == 2:
                            p1 = p1.unsqueeze(0)
                            p2 = p2.unsqueeze(0)
                        projection = torch.where(
                            (batch.random_subset == 1)[:, None, None], p1, p2
                        )
                    else:
                        projection = combined_projectors[class_index].project(
                            rotations
                        )
                        if projection.ndim == 2:
                            projection = projection.unsqueeze(0)
                    prediction = projection * ctf.to(projection.dtype)
                    residual = (masked_fourier - prediction).abs().square()
                    diff2 = 0.5 * torch.sum(
                        residual * invsigma_likelihood, dim=(-2, -1)
                    )
                    residuals.append(residual)
                    diff2_values.append(diff2)

                diff2_by_class = torch.stack(diff2_values, dim=1)
                # Beyond the working current-size support RELION adds one
                # common particle-only Xi² term to every class hypothesis.  A
                # stricter likelihood cutoff leaves the intervening band unused;
                # it must not move the Xi² boundary inward.  This term cancels
                # from the posterior but is required for per-particle DLL parity.
                highres_mask = (
                    full_mresol.unique_mask
                    & (full_mresol.shells > schedule.working_max_shell)
                    & (full_mresol.shells <= n // 2)
                )
                highres_xi2 = 0.5 * masked_fourier.abs().square()[
                    :, highres_mask
                ].sum(dim=-1)
                diff2_by_class = diff2_by_class + highres_xi2[:, None]
                selection = relion_weight_selection_batch(
                    log_prior[None, :].expand_as(diff2_by_class),
                    diff2_by_class,
                    self.config.adaptive_fraction,
                )
                posterior = selection.posterior
                keep = selection.significant
                weighted_posterior = posterior * keep.to(posterior.dtype)
                row = torch.as_tensor(
                    batch.row_indices,
                    device=self.device,
                    dtype=torch.int64,
                )
                posteriors[row] = posterior
                significant_counts[row] = selection.reported_significant_count
                batch_raw_log_evidence = selection.log_evidence
                batch_log_sigma2 = self._log_sigma2_normalisation(
                    model.sigma2_noise,
                    batch.group_index,
                    working_mresol,
                )
                raw_log_evidence[row] = batch_raw_log_evidence
                log_sigma2_normalisation[row] = batch_log_sigma2
                dll_maximum_shell[row] = schedule.working_max_shell
                # RELION: dLL = log(sum_weight) - min_diff2 - logsigma2.
                # logsumexp(-diff2 + log prior) is exactly the first two terms.
                log_contrib[row] = batch_raw_log_evidence - batch_log_sigma2
                class_mass += weighted_posterior.sum(
                    dim=0, dtype=torch.float64
                )
                for subset_index, subset_value in enumerate((1, 2)):
                    selected = batch.random_subset == subset_value
                    if torch.any(selected):
                        half_class_mass[subset_index] += weighted_posterior[
                            selected
                        ].sum(dim=0, dtype=torch.float64)

                expected_residual = torch.zeros_like(residuals[0])
                retained_mass = weighted_posterior.sum(dim=1)
                for class_index in range(k_classes):
                    probability = weighted_posterior[
                        :, class_index, None, None
                    ]
                    weighted = probability * invsigma_working
                    numerator = (
                        unmasked_fourier
                        * ctf.to(unmasked_fourier.dtype)
                        * weighted
                    )
                    denominator = ctf.square() * weighted
                    all_bp[class_index].accumulate(
                        numerator,
                        rotations,
                        denominator,
                        observation_weights=weighted_posterior[:, class_index],
                    )
                    if model.has_random_halves:
                        assert half1_bp is not None and half2_bp is not None
                        sel1 = batch.random_subset == 1
                        sel2 = batch.random_subset == 2
                        if torch.any(sel1):
                            half1_bp[class_index].accumulate(
                                numerator[sel1],
                                rotations[sel1],
                                denominator[sel1],
                                observation_weights=weighted_posterior[
                                    sel1, class_index
                                ],
                            )
                        if torch.any(sel2):
                            half2_bp[class_index].accumulate(
                                numerator[sel2],
                                rotations[sel2],
                                denominator[sel2],
                                observation_weights=weighted_posterior[
                                    sel2, class_index
                                ],
                            )
                    expected_residual += residuals[class_index] * probability

                # Within current_size use posterior-weighted residuals. Above
                # current_size use the class-independent masked particle power.
                noise_values = torch.where(
                    working_mresol.valid_mask.unsqueeze(0),
                    expected_residual,
                    masked_fourier.abs().square(),
                )
                noise_weights = torch.where(
                    working_mresol.valid_mask.unsqueeze(0),
                    retained_mass[:, None, None],
                    torch.ones_like(expected_residual),
                )
                shell_sums = radial_sum_unique_2d(
                    noise_values, full_mresol, max_shell=n // 2
                )
                shell_weights = radial_sum_unique_2d(
                    noise_weights, full_mresol, max_shell=n // 2
                )
                residual_sum.index_add_(
                    0, batch.group_index, shell_sums
                )
                residual_weight.index_add_(
                    0, batch.group_index, shell_weights
                )

            sigma2_noise = torch.where(
                residual_weight > 0,
                residual_sum
                / (2.0 * residual_weight).clamp_min(1.0),
                model.sigma2_noise.to(torch.float64),
            ).to(self.config.dtype)
            sigma2_noise = repair_nonpositive_spectrum(
                sigma2_noise, minimum=self.config.minimum_variance
            )
            if self.config.noise_smoothing_radius > 0:
                sigma2_noise = smooth_spectrum(
                    sigma2_noise, self.config.noise_smoothing_radius
                )
            sigma2_noise = sigma2_noise.clamp_min(
                self.config.minimum_variance
            )

            new_refs: list[torch.Tensor] = []
            new_half1: list[torch.Tensor] | None = (
                [] if model.has_random_halves else None
            )
            new_half2: list[torch.Tensor] | None = (
                [] if model.has_random_halves else None
            )
            new_sigma2_class: list[torch.Tensor] = []
            new_data_vs_prior: list[torch.Tensor] = []
            new_coverage: list[torch.Tensor] = []
            fsc_by_class: list[torch.Tensor] = []

            for class_index in range(k_classes):
                # RELION updates SSNR arrays from the current tau² before
                # reconstructing the next reference.
                ssnr = update_ssnr_arrays(
                    all_bp[class_index],
                    current_tau2[class_index],
                    tau2_fudge=self.config.tau2_fudge,
                )
                new_sigma2_class.append(ssnr.sigma2)
                new_data_vs_prior.append(ssnr.data_vs_prior)
                new_coverage.append(ssnr.fourier_coverage)

                fsc = None
                if model.has_random_halves:
                    assert half1_bp is not None and half2_bp is not None
                    assert new_half1 is not None and new_half2 is not None
                    half1_result = reconstruct_backprojector(
                        half1_bp[class_index],
                        self._reconstruction_options(
                            current_tau2[class_index],
                            normalise=float(
                                half_class_mass[0, class_index].item()
                            ),
                        ),
                    )
                    half2_result = reconstruct_backprojector(
                        half2_bp[class_index],
                        self._reconstruction_options(
                            current_tau2[class_index],
                            normalise=float(
                                half_class_mass[1, class_index].item()
                            ),
                        ),
                    )
                    half1_map = self._apply_solvent(
                        half1_result, solvent_masks[class_index]
                    )
                    half2_map = self._apply_solvent(
                        half2_result, solvent_masks[class_index]
                    )
                    new_half1.append(half1_map)
                    new_half2.append(half2_map)
                    fsc = fourier_shell_correlation(half1_map, half2_map)
                    fsc_by_class.append(fsc)

                combined_result = reconstruct_backprojector(
                    all_bp[class_index],
                    self._reconstruction_options(
                        None if fsc is not None else current_tau2[class_index],
                        fsc=fsc,
                        normalise=float(class_mass[class_index].item()),
                    ),
                )
                new_refs.append(
                    self._apply_solvent(
                        combined_result, solvent_masks[class_index]
                    )
                )

            total_class_mass = class_mass.sum()
            priors = torch.where(
                total_class_mass > 0.0,
                class_mass / total_class_mass,
                class_mass,
            ).to(self.config.dtype)
            data_matrix = torch.stack(new_data_vs_prior)
            resolution_shell = resolution_shell_from_data_vs_prior(
                data_matrix, min_shell=self.config.minres_map
            )
            class_shells = [
                class_resolution_shell_from_data_vs_prior(value)
                if float(priors[index].item()) > 0.0
                else 0
                for index, value in enumerate(new_data_vs_prior)
            ]
            average_pmax = float(
                posteriors.max(dim=1).values.mean().item()
            )
            model = FixedPoseModel(
                references=new_refs,
                class_priors=priors,
                sigma2_noise=sigma2_noise,
                # This is the tau² used by updateSSNRarrays and reconstruction in
                # the current maximization. It will be refreshed from the new
                # references before the next expectation cycle.
                tau2=current_tau2,
                sigma2_class=new_sigma2_class,
                data_vs_prior=new_data_vs_prior,
                fourier_coverage=new_coverage,
                group_numbers=list(dataset.group_numbers),
                group_names=list(dataset.group_names),
                group_particle_counts=list(dataset.group_particle_counts),
                current_size=schedule.working_current_size,
                likelihood_size=schedule.likelihood_current_size,
                current_resolution_shell=resolution_shell,
                current_resolution_angstrom=shell_to_angstrom(
                    n, dataset.pixel_size, resolution_shell
                ),
                class_resolution_shells=class_shells,
                class_resolution_angstroms=[
                    shell_to_angstrom(n, dataset.pixel_size, shell)
                    for shell in class_shells
                ],
                average_pmax=average_pmax,
                log_likelihood=float(log_contrib.sum().item()),
                sigma_offset_angstrom=self._sigma_offset_angstrom(dataset),
                half1_references=new_half1,
                half2_references=new_half2,
                iteration=iteration,
            )
            model.validate()
            last_fsc_by_class = fsc_by_class

            particle_table = self._updated_particle_table(
                dataset,
                posteriors,
                log_contrib,
                significant_counts,
            )
            if (
                self.config.write_every_iteration
                or iteration == self.config.iterations
            ):
                output_files.update(
                    self._write_iteration(
                        model,
                        output_prefix,
                        dataset,
                        fsc_by_class,
                        particle_table=particle_table,
                    )
                )
                if self.config.write_posterior_table:
                    dll_path = output_prefix.with_name(
                        output_prefix.name
                        + f"_it{iteration:03d}_dll_components.npz"
                    )
                    np.savez_compressed(
                        dll_path,
                        raw_log_evidence=raw_log_evidence.detach().cpu().numpy(),
                        log_sigma2=log_sigma2_normalisation.detach().cpu().numpy(),
                        relion_log_likelihood_contribution=log_contrib.detach().cpu().numpy(),
                        group_id=pd.to_numeric(
                            dataset.table["rlnGroupNumber"], errors="coerce"
                        ).fillna(1).to_numpy(dtype=np.int64),
                        maximum_shell=dll_maximum_shell.detach().cpu().numpy(),
                    )
                    output_files[
                        f"iteration_{iteration}_dll_components"
                    ] = dll_path

        output_particles = self._updated_particle_table(
            dataset, posteriors, log_contrib, significant_counts
        )
        data_path = output_prefix.with_name(
            output_prefix.name + "_data.star"
        )
        self._write_data_star(dataset, output_particles, data_path)
        output_files["particles"] = data_path

        model_path = output_prefix.with_name(
            output_prefix.name + "_model.star"
        )
        self._write_model_star(
            model, model_path, output_prefix, dataset, last_fsc_by_class
        )
        output_files["model"] = model_path
        if self.config.write_posterior_table:
            posterior_path = output_prefix.with_name(
                output_prefix.name + "_posteriors.npz"
            )
            np.savez_compressed(
                posterior_path,
                posterior=posteriors.detach().cpu().numpy(),
                significant_samples=significant_counts.detach().cpu().numpy(),
                raw_log_evidence=raw_log_evidence.detach().cpu().numpy(),
                log_sigma2=log_sigma2_normalisation.detach().cpu().numpy(),
                relion_log_likelihood_contribution=log_contrib.detach().cpu().numpy(),
                maximum_shell=dll_maximum_shell.detach().cpu().numpy(),
                source_row=dataset.source_row_indices(),
            )
            output_files["posteriors"] = posterior_path
        return FixedPoseEMResult(
            model, posteriors, output_particles, log_contrib, output_files
        )

    def _updated_particle_table(
        self,
        dataset: ParticleDataset,
        posteriors: torch.Tensor,
        log_contrib: torch.Tensor,
        significant_counts: torch.Tensor,
    ) -> pd.DataFrame:
        best_probability, best_class = torch.max(posteriors, dim=1)
        filtered = dataset.table.copy()
        filtered["rlnClassNumber"] = (
            best_class.detach().cpu().numpy() + 1
        )
        filtered["rlnMaxValueProbDistribution"] = (
            best_probability.detach().cpu().numpy()
        )
        filtered["rlnLogLikeliContribution"] = (
            log_contrib.detach().cpu().numpy()
        )
        filtered["rlnNrOfSignificantSamples"] = (
            significant_counts.detach().cpu().numpy()
        )
        return filtered

    def _write_data_star(
        self,
        dataset: ParticleDataset,
        filtered_particles: pd.DataFrame | None,
        path: Path,
    ) -> Path:
        output_particles = dataset.star.particles.copy()
        source_rows = dataset.source_row_indices()
        if filtered_particles is not None:
            for label in (
                "rlnClassNumber",
                "rlnMaxValueProbDistribution",
                "rlnLogLikeliContribution",
                "rlnNrOfSignificantSamples",
                "rlnRandomSubset",
            ):
                if label in filtered_particles.columns:
                    output_particles.loc[source_rows, label] = filtered_particles[
                        label
                    ].to_numpy()
        output_particles = rebase_image_references(
            output_particles,
            source_dir=dataset.star.source_dir,
            output_dir=path.parent,
        )
        write_relion_star(
            dataset.star.copy_with_particles(output_particles), path
        )
        return path

    def _write_iteration(
        self,
        model: FixedPoseModel,
        prefix: Path,
        dataset: ParticleDataset,
        fsc_by_class: Sequence[torch.Tensor],
        *,
        particle_table: pd.DataFrame | None,
    ) -> dict[str, Path]:
        tag = f"_it{model.iteration:03d}"
        files: dict[str, Path] = {}
        if model.reference_dim == 2:
            path = prefix.with_name(prefix.name + tag + "_classes.mrcs")
            files[f"iteration_{model.iteration}_classes"] = write_mrc(
                path,
                torch.stack(model.references),
                pixel_size_angstrom=dataset.pixel_size,
            )
            if model.has_random_halves:
                assert model.half1_references is not None
                assert model.half2_references is not None
                files[f"iteration_{model.iteration}_half1"] = write_mrc(
                    prefix.with_name(
                        prefix.name + tag + "_half1_classes.mrcs"
                    ),
                    torch.stack(model.half1_references),
                    pixel_size_angstrom=dataset.pixel_size,
                )
                files[f"iteration_{model.iteration}_half2"] = write_mrc(
                    prefix.with_name(
                        prefix.name + tag + "_half2_classes.mrcs"
                    ),
                    torch.stack(model.half2_references),
                    pixel_size_angstrom=dataset.pixel_size,
                )
        else:
            for class_index, reference in enumerate(
                model.references, start=1
            ):
                key = f"iteration_{model.iteration}_class_{class_index}"
                files[key] = write_mrc(
                    prefix.with_name(
                        prefix.name
                        + tag
                        + f"_class{class_index:03d}.mrc"
                    ),
                    reference,
                    pixel_size_angstrom=dataset.pixel_size,
                )
                if model.has_random_halves:
                    assert model.half1_references is not None
                    assert model.half2_references is not None
                    files[key + "_half1"] = write_mrc(
                        prefix.with_name(
                            prefix.name
                            + tag
                            + f"_half1_class{class_index:03d}_unfil.mrc"
                        ),
                        model.half1_references[class_index - 1],
                        pixel_size_angstrom=dataset.pixel_size,
                    )
                    files[key + "_half2"] = write_mrc(
                        prefix.with_name(
                            prefix.name
                            + tag
                            + f"_half2_class{class_index:03d}_unfil.mrc"
                        ),
                        model.half2_references[class_index - 1],
                        pixel_size_angstrom=dataset.pixel_size,
                    )
        if fsc_by_class:
            rows: list[dict[str, float | int]] = []
            for class_index, fsc in enumerate(fsc_by_class, start=1):
                for shell, value in enumerate(
                    fsc.detach().cpu().tolist()
                ):
                    resolution = shell / (
                        dataset.box_size * dataset.pixel_size
                    )
                    rows.append(
                        {
                            "rlnClassNumber": class_index,
                            "rlnSpectralIndex": shell,
                            "rlnResolution": resolution,
                            "rlnAngstromResolution": (
                                float("inf")
                                if shell == 0
                                else 1.0 / resolution
                            ),
                            "rlnFourierShellCorrelation": value,
                        }
                    )
            fsc_path = prefix.with_name(prefix.name + tag + "_fsc.star")
            write_star({"fsc": pd.DataFrame(rows)}, fsc_path)
            files[f"iteration_{model.iteration}_fsc"] = fsc_path

        model_path = prefix.with_name(prefix.name + tag + "_model.star")
        self._write_model_star(
            model, model_path, prefix, dataset, fsc_by_class
        )
        files[f"iteration_{model.iteration}_model"] = model_path
        data_path = prefix.with_name(prefix.name + tag + "_data.star")
        self._write_data_star(dataset, particle_table, data_path)
        files[f"iteration_{model.iteration}_data"] = data_path
        return files

    def _class_reference_name(
        self,
        model: FixedPoseModel,
        prefix: Path,
        class_index: int,
    ) -> str:
        if model.reference_dim == 2:
            return (
                f"{class_index:06d}@{prefix.name}_it"
                f"{model.iteration:03d}_classes.mrcs"
            )
        return (
            f"{prefix.name}_it{model.iteration:03d}_class"
            f"{class_index:03d}.mrc"
        )

    def _write_model_star(
        self,
        model: FixedPoseModel,
        path: Path,
        prefix: Path,
        dataset: ParticleDataset,
        fsc_by_class: Sequence[torch.Tensor] = (),
    ) -> None:
        n = dataset.box_size
        shell = np.arange(n // 2 + 1, dtype=np.int64)
        resolution = shell / (n * dataset.pixel_size)
        angstrom = np.full_like(resolution, np.inf, dtype=np.float64)
        angstrom[1:] = 1.0 / resolution[1:]
        zero_fsc = np.zeros(n // 2 + 1, dtype=np.float64)

        class_rows: list[dict[str, float | str]] = []
        for index, prior in enumerate(
            model.class_priors.detach().cpu().tolist(), start=1
        ):
            safe_shell = model.class_resolution_shells[index - 1]
            coverage = model.fourier_coverage[index - 1]
            if safe_shell > 0:
                overall_coverage = float(
                    coverage[1 : safe_shell + 1].mean().item()
                )
            else:
                # Undefined radius-zero reporting is independent of occupancy.
                overall_coverage = float("nan")
            class_rows.append(
                {
                    "rlnReferenceImage": self._class_reference_name(
                        model, prefix, index
                    ),
                    "rlnClassDistribution": prior,
                    "rlnAccuracyRotations": 0.0,
                    "rlnAccuracyTranslationsAngst": 0.0,
                    "rlnEstimatedResolution": shell_to_angstrom(
                        n, dataset.pixel_size, safe_shell
                    ),
                    "rlnOverallFourierCompleteness": overall_coverage,
                }
            )

        blocks: dict[str, pd.DataFrame] = {
            "model_general": pd.DataFrame(
                [
                    {
                        "rlnReferenceDimensionality": model.reference_dim,
                        "rlnDataDimensionality": 2,
                        "rlnOriginalImageSize": n,
                        "rlnCurrentResolution": model.current_resolution_angstrom,
                        "rlnCurrentImageSize": model.current_size,
                        "rlnPaddingFactor": self.config.padding_factor,
                        "rlnIsHelix": 0,
                        "rlnFourierSpaceInterpolator": 1,
                        "rlnMinRadiusNnInterpolation": 10,
                        "rlnPixelSize": dataset.pixel_size,
                        "rlnNrClasses": model.number_of_classes,
                        "rlnNrBodies": 1,
                        "rlnNrGroups": model.number_of_groups,
                        "rlnTau2FudgeFactor": self.config.tau2_fudge,
                        "rlnNormCorrectionAverage": model.average_norm_correction,
                        "rlnSigmaOffsetsAngst": model.sigma_offset_angstrom,
                        "rlnLogLikelihood": model.log_likelihood,
                        "rlnAveragePmax": model.average_pmax,
                    }
                ]
            ),
            "model_classes": pd.DataFrame(class_rows),
        }

        for class_index, tau2 in enumerate(model.tau2, start=1):
            fsc = (
                fsc_by_class[class_index - 1].detach().cpu().numpy()
                if class_index <= len(fsc_by_class)
                else zero_fsc
            )
            blocks[f"model_class_{class_index}"] = pd.DataFrame(
                {
                    "rlnSpectralIndex": shell,
                    "rlnResolution": resolution,
                    "rlnAngstromResolution": angstrom,
                    "rlnSsnrMap": model.data_vs_prior[
                        class_index - 1
                    ].detach().cpu().numpy(),
                    "rlnGoldStandardFsc": fsc,
                    "rlnFourierCompleteness": model.fourier_coverage[
                        class_index - 1
                    ].detach().cpu().numpy(),
                    "rlnReferenceSigma2": model.sigma2_class[
                        class_index - 1
                    ].detach().cpu().numpy(),
                    "rlnReferenceTau2": tau2.detach().cpu().numpy(),
                }
            )

        blocks["model_groups"] = pd.DataFrame(
            {
                "rlnGroupNumber": model.group_numbers,
                "rlnGroupName": model.group_names,
                "rlnGroupNrParticles": model.group_particle_counts,
                "rlnGroupScaleCorrection": np.ones(
                    model.number_of_groups, dtype=np.float64
                ),
            }
        )
        for group_index in range(model.number_of_groups):
            blocks[f"model_group_{group_index + 1}"] = pd.DataFrame(
                {
                    "rlnSpectralIndex": shell,
                    "rlnResolution": resolution,
                    "rlnSigma2Noise": model.sigma2_noise[
                        group_index
                    ].detach().cpu().numpy(),
                }
            )
        write_star(blocks, path)


def run_fixed_pose_from_files(
    input_star: str | Path,
    references: Sequence[str | Path] | str,
    output_prefix: str | Path,
    config: FixedPoseEMConfig,
    *,
    reference_dim: int | None = None,
    subset: int | None = None,
    class_number: int | None = None,
) -> FixedPoseEMResult:
    star = read_relion_star(input_star)
    dataset = ParticleDataset(star, subset=subset, class_number=class_number)
    refs, _ = load_references(
        references,
        reference_dim=reference_dim,
        device=config.device,
        dtype=config.dtype,
    )
    try:
        return FixedPoseEM(config).run(dataset, refs, output_prefix)
    finally:
        dataset.close()
