from __future__ import annotations

from dataclasses import dataclass, field

import torch


@dataclass(slots=True)
class FixedPoseModel:
    """State shared by 2-D and 3-D fixed-pose MAP/EM."""

    references: list[torch.Tensor]
    class_priors: torch.Tensor
    sigma2_noise: torch.Tensor
    tau2: list[torch.Tensor]
    sigma2_class: list[torch.Tensor] = field(default_factory=list)
    data_vs_prior: list[torch.Tensor] = field(default_factory=list)
    fourier_coverage: list[torch.Tensor] = field(default_factory=list)
    group_numbers: list[int] = field(default_factory=list)
    group_names: list[str] = field(default_factory=list)
    group_particle_counts: list[int] = field(default_factory=list)
    current_size: int = 0
    likelihood_size: int = 0
    current_resolution_shell: int = 0
    current_resolution_angstrom: float = float("inf")
    class_resolution_shells: list[int] = field(default_factory=list)
    class_resolution_angstroms: list[float] = field(default_factory=list)
    average_pmax: float = 0.0
    log_likelihood: float = 0.0
    sigma_offset_angstrom: float = 10.0
    average_norm_correction: float = 1.0
    half1_references: list[torch.Tensor] | None = None
    half2_references: list[torch.Tensor] | None = None
    iteration: int = 0

    @property
    def number_of_classes(self) -> int:
        return len(self.references)

    @property
    def number_of_groups(self) -> int:
        return int(self.sigma2_noise.shape[0]) if self.sigma2_noise.ndim == 2 else 1

    @property
    def reference_dim(self) -> int:
        return self.references[0].ndim

    @property
    def box_size(self) -> int:
        return int(self.references[0].shape[-1])

    @property
    def has_random_halves(self) -> bool:
        return self.half1_references is not None and self.half2_references is not None

    def validate(self) -> None:
        if not self.references:
            raise ValueError("Model has no references")
        shape = self.references[0].shape
        if len(shape) not in (2, 3) or len(set(shape)) != 1:
            raise ValueError("References must be equal-sized square/cubic tensors")
        if any(ref.shape != shape for ref in self.references):
            raise ValueError("All references must have equal shapes")
        if any(not bool(torch.isfinite(ref).all()) for ref in self.references):
            raise FloatingPointError("Model references contain NaN or Inf values")
        if self.class_priors.shape != (len(self.references),):
            raise ValueError("class_priors has the wrong shape")
        if torch.any(self.class_priors < 0):
            raise ValueError("class_priors must be non-negative")
        total = self.class_priors.sum()
        if not bool(torch.isfinite(total)) or float(total.item()) <= 0:
            raise ValueError("class_priors must have a positive finite sum")
        self.class_priors = self.class_priors / total

        n_shells = self.box_size // 2 + 1
        if self.sigma2_noise.ndim == 1:
            self.sigma2_noise = self.sigma2_noise.unsqueeze(0)
        if self.sigma2_noise.ndim != 2 or self.sigma2_noise.shape[1] != n_shells:
            raise ValueError("sigma2_noise must have shape [group,N/2+1]")
        if not bool(torch.isfinite(self.sigma2_noise).all()):
            raise FloatingPointError("sigma2_noise contains NaN or Inf values")
        if bool((self.sigma2_noise <= 0).any()):
            raise ValueError("sigma2_noise must be strictly positive")
        if len(self.tau2) != len(self.references):
            raise ValueError("One tau2 spectrum is required per class")
        if any(value.numel() != n_shells for value in self.tau2):
            raise ValueError("tau2 spectra must have length N/2+1")
        if any(not bool(torch.isfinite(value).all()) for value in self.tau2):
            raise FloatingPointError("tau2 contains NaN or Inf values")
        if any(bool((value < 0).any()) for value in self.tau2):
            raise ValueError("tau2 must be non-negative")

        def zeros() -> torch.Tensor:
            return torch.zeros(
                n_shells,
                device=self.references[0].device,
                dtype=self.references[0].dtype,
            )

        if not self.sigma2_class:
            self.sigma2_class = [zeros() for _ in self.references]
        if not self.data_vs_prior:
            self.data_vs_prior = [zeros() for _ in self.references]
        if not self.fourier_coverage:
            self.fourier_coverage = [zeros() for _ in self.references]
        for name, spectra in (
            ("sigma2_class", self.sigma2_class),
            ("data_vs_prior", self.data_vs_prior),
            ("fourier_coverage", self.fourier_coverage),
        ):
            if len(spectra) != len(self.references) or any(
                value.numel() != n_shells for value in spectra
            ):
                raise ValueError(
                    f"{name} must contain one N/2+1 spectrum per class"
                )

        groups = int(self.sigma2_noise.shape[0])
        if not self.group_numbers:
            self.group_numbers = list(range(1, groups + 1))
        if not self.group_names:
            self.group_names = [f"group_{value}" for value in self.group_numbers]
        if not self.group_particle_counts:
            self.group_particle_counts = [0] * groups
        if not (
            len(self.group_numbers)
            == len(self.group_names)
            == len(self.group_particle_counts)
            == groups
        ):
            raise ValueError("Group metadata length does not match sigma2_noise")

        if not self.class_resolution_shells:
            self.class_resolution_shells = [self.current_resolution_shell] * self.number_of_classes
        if len(self.class_resolution_shells) != self.number_of_classes:
            raise ValueError("class_resolution_shells has the wrong length")
        if not self.class_resolution_angstroms:
            self.class_resolution_angstroms = [float("inf")] * self.number_of_classes
        if len(self.class_resolution_angstroms) != self.number_of_classes:
            raise ValueError("class_resolution_angstroms has the wrong length")

        # RELION's iteration-zero model deliberately stores current_size=0.
        if self.iteration > 0:
            self.current_size = max(2, min(int(self.current_size), self.box_size))
            if self.current_size % 2:
                self.current_size -= 1
            if self.likelihood_size <= 0:
                self.likelihood_size = self.current_size
            self.likelihood_size = max(
                2, min(int(self.likelihood_size), self.current_size)
            )
            if self.likelihood_size % 2:
                self.likelihood_size -= 1
        else:
            self.current_size = 0
            self.likelihood_size = 0

        for half in (self.half1_references, self.half2_references):
            if half is not None:
                if len(half) != len(self.references) or any(
                    ref.shape != shape for ref in half
                ):
                    raise ValueError("Half-set references must match combined references")
