"""Execution resources scoped to one half, one reference and one E-step."""
import numpy as np
import torch
from relion_torch.inference.execution_policy import candidate_budget
from dataclasses import replace
from relion_torch.class3d.expectation import Class3DExpectation
from relion_torch.class3d.resources import ByteLRU, FineProjectionStore
from relion_torch.inference.alignment import (GlobalProjectionBank, FineProjectionBlocks,
    likelihood_rfft_mask, phase_shift_rfft)
from relion_torch.inference.indexed_projection_cache import IndexedProjectionStore
from relion_torch.inference.work_planning import projection_chunk_rows, statistics_cache_budget
from relion_torch.alignment.packed_grouped_backprojection import PackedGroupedOrientationAccumulator
from relion_torch.alignment.core import _euler_matrix
from .selected_sampling import SelectedSampling, selected_table


def projection_limit(options,available,ceiling):
    limit=min(int(available),int(ceiling))
    return min(limit,int(options.auto_cache_mib*2**20)) if options.auto_cache_mib>=0 else limit


def cap_memory_plan(plan,owner,active_bytes):
    """Apply persistent execution ceilings before allocation and plan reporting."""
    projection=projection_limit(owner.options,plan.projection_bytes,owner._cache_ceiling)
    candidate=min(plan.candidate_bytes,owner._work_ceiling)
    geometry=min(plan.geometry_bytes,candidate//8)
    freed=plan.projection_bytes-projection+(plan.candidate_bytes-candidate)*3//2+plan.geometry_bytes-geometry
    # Selected local stores keep full planes only. Global full banks can also
    # retain an active-pixel copy, but never at the expense of a complete fine bank.
    full_coarse=plan.full_coarse_bytes<=projection
    reserve=min(plan.fine_reserve_bytes,projection//4)
    active=bool(plan.cache_active and not plan.local and
        plan.full_coarse_bytes+active_bytes<=projection)
    if active and plan.full_fine_bytes and plan.full_coarse_bytes+plan.full_fine_bytes<=projection:
        active=plan.full_coarse_bytes+active_bytes+plan.full_fine_bytes<=projection
    coarse_used=plan.full_coarse_bytes+(active_bytes if active else 0) if full_coarse else projection-reserve
    if plan.local and not full_coarse:coarse_used=projection-projection*3//4
    fine=min(plan.full_fine_bytes,max(0,projection-coarse_used))
    return replace(plan,projection_bytes=projection,candidate_bytes=candidate,geometry_bytes=geometry,
        particle_batch=min(plan.particle_batch,owner._batch_ceiling),
        estimated_estep_extra_bytes=max(0,plan.estimated_estep_extra_bytes-freed),
        full_coarse=full_coarse,cache_active=active,fine_reserve_bytes=reserve,
        fine_cache_bytes=fine,full_fine=bool(plan.full_fine_bytes and fine>=plan.full_fine_bytes))


def merge_counts(target, source):
    for key,value in source.items():
        # Resource observations are peaks; work/event counters are additive.
        peak=any(x in key for x in ('bytes','_max','capacity','total_rows','budget','bounded','full_bank','second_chance'))
        target[key]=max(target.get(key,0),int(value)) if peak else target.get(key,0)+int(value)


class GlobalRows:
    def __init__(self,workspace,size,over):
        self.workspace=workspace;self.size=size;self.over=over
        self.cache=workspace.cache;self.device=workspace.owner.device;self.dtype=torch.complex64
        self.shape=(1,workspace.root.number_of_orientations*8**over,size,size//2+1)
        self.max_chunk=projection_chunk_rows(size,candidate_budget(workspace.owner),
            workspace.owner.config.orientation_chunk_size)
    def element_size(self):return 8
    def project_host(self,c,ids):
        oc=8**self.over
        parents,inverse=np.unique(ids//oc,return_inverse=True)
        table=selected_table(self.workspace.root,parents,self.over)
        angles=table.orientation_angles[inverse,ids%oc]
        angles=torch.as_tensor(angles,device=self.device,dtype=torch.float32)
        return self.workspace.owner.projectors[c].project_batch(angles,self.size)


class MappedRows:
    """Local IDs are views only; all retained rows use stable global IDs."""
    def __init__(self,store,parents,oc):
        self.store=store;self.parents=parents;self.oc=oc
        self.shape=(store.shape[0],len(parents)*oc,*store.shape[-2:])
        self.device=store.device;self.dtype=store.dtype
    def element_size(self):return 8
    def _count(self,*args):return self.store._count(*args)
    def _map(self,ids):
        ids=np.asarray(ids,dtype=np.int64).reshape(-1)
        return self.parents[ids//self.oc]*self.oc+ids%self.oc
    def gather_host(self,c,ids):return self.store.gather_host(c,self._map(ids))
    def gather_active_host(self,c,ids):return self.store.gather_active_host(c,self._map(ids))
    def gather_selected_host(self,c,ids,active):return self.store.gather_selected_host(c,self._map(ids),active)
    def gather(self,c,ids):
        if ids.device.type!='cpu':self._count('index_d2h_calls')
        return self.gather_host(c,ids.detach().cpu().numpy())
    def release_storage(self):pass  # The E-step workspace owns the slab.


class ExecutionWorkspace:
    def __init__(self,owner,root):
        self.owner=owner;self.root=root;self.group=None;self.stores={};self.counts={}
        self.cache=ByteLRU(projection_limit(owner.options,int(owner.options.performance_cache_mib*2**20),
            getattr(owner,'_cache_ceiling',2**63-1)))
        self.grouper=None;self.group_optics=None
        self.previous_hits=self.previous_misses=self.previous_peak=0
    def clear_projections(self):
        self.previous_hits+=self.cache.hits;self.previous_misses+=self.cache.misses
        self.previous_peak=max(self.previous_peak,self.cache.peak)
        for store in self.stores.values():
            merge_counts(self.counts,store.counters)
            store.release_storage()
        self.stores.clear();self.cache.clear()
        # ProjectionCache.clear preserves cumulative counters.
        self.cache.hits=self.cache.misses=self.cache.peak=0
    def select_optics(self,group):
        if group!=self.group:
            self.finish_grouped()
            self.clear_projections();self.group=group
    def store(self,size,shell,over,cc):
        key=(size,shell,over,bool(cc))
        if key not in self.stores:
            active=torch.nonzero(likelihood_rfft_mask(size,shell,self.owner.device,
                firstiter_cc=cc).flatten(),as_tuple=False).squeeze(1)
            fallback=GlobalRows(self,size,over)
            reserve=(self.cache.max_bytes*3//4 if over==0 and self.root.adaptive_oversampling else 0)
            prefix=f'auto_projection_s{size}_o{over}_cc{int(cc)}'
            # Revisited optics have fresh slabs but counters must remain cumulative.
            current={}
            store=IndexedProjectionStore(fallback,active,key=key,counters=current,
                reserve_bytes=reserve,counter_prefix=prefix,cache_active=False,sparse_keys=True)
            self.stores[key]=store
        return self.stores[key]
    def finish_grouped(self):
        if self.grouper is not None:self.grouper.finish();self.grouper=None
    def mapped_grouper(self,bps,sampling):
        owner=self.owner;over=owner.config.oversampling;oc=8**over
        if self.grouper is None:
            group=owner.active_optics
            def insert(c,ids,num,den):
                host=ids.detach().cpu().numpy()
                parents,inverse=np.unique(host//oc,return_inverse=True)
                angles=selected_table(self.root,parents,over).orientation_angles[inverse,host%oc]
                matrices=_euler_matrix(torch.as_tensor(angles,device=owner.device,dtype=torch.float32))
                matrices=owner.observation.reconstruction_rotations(matrices,group,
                    owner.dataset.box_size,owner.dataset.pixel_size)
                bps.add(c,num,matrices,torch.ones_like(den),den,
                    orientation_chunk_size=owner.config.backprojector_chunk_size)
                owner._perf_counters['backprojector_calls']+=1
            budget=statistics_cache_budget(candidate_budget(owner),bps.size,
                self.root.number_of_orientations*oc,1,oc,4**over,
                12 if owner.options.accumulation_precision=='float32' else 24)
            self.grouper=PackedGroupedOrientationAccumulator(insert,bps.size,budget,1,
                self.root.number_of_orientations*oc,counters=owner._perf_counters,
                flush_rows=owner.config.backprojector_chunk_size,sparse_keys=True,adaptive=True)
        packed=self.grouper
        parents=getattr(sampling,'global_orientation_ids',None)
        class Adapter:
            max_bytes=packed.max_bytes
            def add(self,c,ids,num,den,*,host_ids=None):
                host=ids.detach().cpu().numpy() if host_ids is None else np.asarray(host_ids)
                glob=host if parents is None else parents[host//oc]*oc+host%oc
                packed.add(c,torch.as_tensor(glob,device=ids.device),num,den,host_ids=glob)
        return Adapter()
    def snapshot(self):
        counts=dict(self.counts)
        for store in self.stores.values():merge_counts(counts,store.counters)
        counts.update(auto_projection_cache_hits=self.previous_hits+self.cache.hits,
            auto_projection_cache_misses=self.previous_misses+self.cache.misses,
            auto_projection_cache_peak_bytes=max(self.previous_peak,self.cache.peak),
            auto_projection_cache_limit_bytes=self.cache.max_bytes)
        return counts


class AutoExpectation(Class3DExpectation):
    def resize_projection_storage(self, max_bytes):
        if isinstance(self.sampling,SelectedSampling) and self.local_buffer is None:
            workspace=self.owner._execution_workspace
            workspace.clear_projections()
            workspace.cache.max_bytes=max(0,int(max_bytes))
        super().resize_projection_storage(max_bytes)

    def release_projection_storage(self,*,disable=False):
        selected=isinstance(self.sampling,SelectedSampling)
        if self.local_buffer is not None and disable:
            self.local_buffer.release()
            self.local_buffer.max_bytes=0
            self.local_buffer.counts['local_projection_budget_bytes']=0
        if selected:
            self._global_projection_banks.clear();self._fine_stores.clear()
            self.geometry.items.clear();self.geometry.bytes=0
        else:super().release_projection_storage(disable=disable)
        if disable and hasattr(self,'owner'):
            self.owner._execution_backoff(self)
    def build_global_projection_bank(self,*,pixel_size,image_size=None,maximum_shell=None):
        if self.local_buffer is not None or not isinstance(self.sampling,SelectedSampling):
            return super().build_global_projection_bank(pixel_size=pixel_size,image_size=image_size,maximum_shell=maximum_shell)
        coarse_size,coarse_shell=self.sizes.coarse_likelihood_grid(self.config.adaptive_oversampling)
        size=int(coarse_size if image_size is None else image_size)
        shell=int(coarse_shell if maximum_shell is None else maximum_shell)
        signature=self._sync_source_caches();key=(size,shell)
        if key in self._global_projection_banks:return self._global_projection_banks[key]
        angles,dirs,psi=self._global_orientation_tensors(self.class_probabilities.device,torch.float32)
        trans=torch.as_tensor(self.sampling.translations,device=angles.device,dtype=torch.float32)
        phase=phase_shift_rfft((size,size//2+1),trans/pixel_size,angles.device,torch.float32,original_size=self.sizes.original_size)
        store=self.owner._execution_workspace.store(size,shell,0,self.config.firstiter_cc)
        mapped=MappedRows(store,self.sampling.global_orientation_ids,1)
        bank=GlobalProjectionBank(angles,dirs,psi,trans,mapped,phase,size,shell,signature)
        self._global_projection_banks[key]=bank
        return bank
    def _build_sparse_fine_projection_blocks(self,parent_class_indices,parent_orientation_indices,fine_angles,*,order,image_size):
        if self.local_buffer is not None or not isinstance(self.sampling,SelectedSampling):
            return super()._build_sparse_fine_projection_blocks(parent_class_indices,parent_orientation_indices,fine_angles,order=order,image_size=image_size)
        no,oc=fine_angles.shape[:2]
        unique,inverse=torch.unique(parent_class_indices*no+parent_orientation_indices,sorted=True,return_inverse=True)
        cs=unique//no;ori=unique%no
        store=self.owner._execution_workspace.store(image_size,image_size//2,order,self.config.firstiter_cc)
        lazy=FineProjectionStore(MappedRows(store,self.sampling.global_orientation_ids,oc),cs,ori,oc)
        return FineProjectionBlocks(unique,cs,ori,fine_angles.index_select(0,ori),lazy),inverse
