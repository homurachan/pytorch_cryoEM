from dataclasses import dataclass
from relion_torch.class3d.config import Class3DConfig


@dataclass
class AutoRefineConfig(Class3DConfig):
    iterations: int = 100
    tau2_fudge: float = 1.0
    use_ctf: bool = True
    ctf_corrected_ref: bool = True
    do_norm_correction: bool = True
    do_scale_correction: bool = True
    flatten_solvent: bool = True
    initial_high_resolution: float | None = 60.0
    auto_local_healpix_order: int = 4
    solvent_correct_fsc: bool = False
    low_resol_join_halves: float = -1.0
    auto_ignore_angle_changes: bool = False
    auto_resolution_based_angles: bool = False
    minimum_angular_sampling: float = -1.0
    maximum_angular_sampling: float = -1.0
    max_healpix_order: int = 10
    force_converge: bool = False
    # Half identity is independent of device assignment and dispatch order.
    half_order: tuple[int, int] = (1, 2)
    auto_execution: str = "optimized"
    # -1: use the automatic/manual projection budget without an extra ceiling.
    # 0 disables retained projections; positive values are explicit MiB caps.
    auto_cache_mib: float = -1.0
    use_all_data: bool = False
    do_mwtcf: bool = False
    mwtcf: float = -10.0
