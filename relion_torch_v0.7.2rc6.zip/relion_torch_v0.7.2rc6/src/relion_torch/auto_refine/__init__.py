"""Gold-standard SPA refinement with device-independent half state."""
