"""One half's model and E/M operations; no cross-half model access."""
from dataclasses import replace
from relion_torch.inference.execution_policy import ExecutionRecovery
import copy
import gc
import time
import numpy as np
import pandas as pd
import torch
from relion_torch.alignment.core import AlignmentDataset, _euler_matrix
from relion_torch.class3d.optimiser import Class3DOptimiser
from relion_torch.class3d.sampling import Class3DSampling
from relion_torch.class3d.runner import make_alignment_config
from relion_torch.optics.observation import ObservationModel
from relion_torch.optics.ctf import compute_ctf
from relion_torch.sampling.local import select_local_angular_support
from relion_torch.reconstruction.ssnr import update_ssnr_arrays
from relion_torch.reconstruction.reconstruct import reconstruct_backprojector, ReconstructionOptions
from relion_torch.reconstruction.half_fsc import move_backprojector
from .controller import pose_changes
from .selected_sampling import select_sampling, SelectedSampling
from .execution import AutoExpectation, ExecutionWorkspace, merge_counts, projection_limit


def tensor_tree(value,device,*,clone=False):
    if torch.is_tensor(value):
        out=value.detach().to(device)
        return out.clone() if clone else out
    if isinstance(value,list):return [tensor_tree(x,device,clone=clone) for x in value]
    if isinstance(value,tuple):return tuple(tensor_tree(x,device,clone=clone) for x in value)
    if isinstance(value,dict):return {k:tensor_tree(v,device,clone=clone) for k,v in value.items()}
    return value


def move_packet(packet,device):
    """Explicit transport boundary, usable by a future per-device executor."""
    pool=packet['bps'];pool.device=torch.device(device)
    if not hasattr(pool,'host'):
        pool.objects=[move_backprojector(bp,device) for bp in pool.objects]
        for k,v in list(packet.items()):
            if k!='bps':packet[k]=tensor_tree(v,device)
        return packet
    objects={**pool.host,**pool.gpu}
    pool.gpu.clear();pool.host.clear()
    for k,bp in objects.items():pool.gpu[k]=move_backprojector(bp,device)
    for k,v in list(packet.items()):
        if k!='bps':packet[k]=tensor_tree(v,device)
    return packet


class _ImageView:
    def __init__(self,parent,indices):
        self.parent=parent;self.indices=np.asarray(indices,dtype=np.int64)
        self.inverse={int(g):i for i,g in enumerate(indices)}
        self.refs=[parent.refs[i] for i in indices]
    def image(self,index):return self.parent.image(int(self.indices[index]))
    def iter_batches(self,*,indices=None,**kwargs):
        selected=self.indices if indices is None else self.indices[np.asarray(indices,dtype=np.int64)]
        for rows,images in self.parent.iter_batches(indices=selected,**kwargs):
            yield np.asarray([self.inverse[int(i)] for i in rows]),images
    def close(self):pass
    def __getattr__(self,key):return getattr(self.parent,key)


class HalfDataset(AlignmentDataset):
    def __init__(self,parent,half):
        self.__dict__.update(parent.__dict__)
        self.global_indices=np.flatnonzero(parent.particles.rlnRandomSubset.to_numpy()==half)
        self.particles=parent.particles.iloc[self.global_indices].copy().reset_index(drop=True)
        self.images=_ImageView(parent.images,self.global_indices)
        self._records=self._make_records()
    def _make_records(self):
        return [replace(r,row=int(self.global_indices[i])) for i,r in enumerate(super()._make_records())]
    def particles_in_source_order(self,particles=None):
        frame=self.particles if particles is None else particles
        return frame.sort_values(self._source_row_column,kind='stable').drop(columns=[self._source_row_column]).reset_index(drop=True)
    def close(self):pass


def compact_sampling(sampling,centres,sigmas,max_bytes):
    support=select_local_angular_support(sampling.directions,sampling.psi_angles,centres,sigmas,symmetry=sampling.symmetry)
    orientations=np.unique(np.concatenate(support.orientation_indices))
    npsi=len(sampling.psi_angles)
    dirs=np.unique(orientations//npsi);psis=np.unique(orientations%npsi)
    size=len(dirs)*len(psis)*(1+8**sampling.adaptive_oversampling)*40
    if size>max_bytes:raise MemoryError('Local sampling table exceeds its bounded workspace')
    out=copy.copy(sampling)
    out._directions=sampling.directions[dirs];out._psi=sampling.psi_angles[psis]
    out._coarse_direction_ids=sampling._coarse_direction_ids[dirs];out._tables={}
    return out,dirs


class _OpticsProjector:
    def __init__(self,owner,handle):self.owner=owner;self.handle=handle
    def __getattr__(self,key):return getattr(self.handle,key)
    def __call__(self,angles,size):return self.project_batch(angles,size)
    def project_batch(self,angles,output_size,chunk_size=256):
        inverse=torch.linalg.inv(_euler_matrix(angles))
        return self.project_inverse_batch(inverse,output_size)
    def fusion_inputs(self,inverses):
        owner=self.owner
        if owner.active_optics is not None:
            mag=torch.eye(3,device=inverses.device,dtype=inverses.dtype)
            mag[:2,:2]=owner.observation.groups[owner.active_optics].matrix
            inverses=inverses@mag
        return self.handle.fusion_inputs(inverses)
    def project_inverse_batch(self,inverses,output_size):
        owner=self.owner
        if owner.active_optics is None:return self.handle.project_inverse_batch(inverses,output_size)
        matrix=owner.observation.groups[owner.active_optics].matrix
        mag=torch.eye(3,device=inverses.device,dtype=inverses.dtype);mag[:2,:2]=matrix
        return self.handle.project_inverse_batch(inverses@mag,output_size)


class HalfOptimiser(Class3DOptimiser):
    use_grouped_backprojection=False
    compact_local_sampling=True
    _tensor_fields=('class_prob','direction_priors','norm_corrections','group_scales',
        'rotation_accuracy_deg','translation_accuracy_angstrom','sigma2','tau2','sigma2_class',
        'data_vs_prior','fourier_coverage','orientability_contrib')
    def __init__(self,*args,half_id,**kwargs):
        self.half_id=int(half_id);self.active_optics=None;self.observation=None
        self.fsc=None;self.final_iteration=False
        self._iteration_sizes=None
        super().__init__(*args,**kwargs)
        self.optimized=self.options.auto_execution=="optimized"
        if self.optimized:self.expectation_type=AutoExpectation
        self._execution_workspace=None
        self._batch_ceiling=2**31-1;self._cache_ceiling=2**63-1
        self._work_ceiling=2**63-1
        self._recovery=ExecutionRecovery()
        self._global_window=None
        self._global_window_plan=None

    def _check_optics_capabilities(self):
        # The shared observation model validates and consumes these fields.
        self.observation=ObservationModel(self.dataset.optics,source_dir=self.dataset.star_path.parent,
            device=self.device)

    def _make_reference_projectors(self,references):
        return [_OpticsProjector(self,x) for x in super()._make_reference_projectors(references)]

    def _updated_reference_projector(self,c):
        return _OpticsProjector(self,super()._updated_reference_projector(c))

    def move_to(self,device):
        device=torch.device(device)
        self._projector_pool.clear()
        if hasattr(self,'_preparation_cache'):del self._preparation_cache
        self.observation=None;self.active_optics=None
        for key,value in list(vars(self).items()):
            if torch.is_tensor(value) or isinstance(value,(list,tuple,dict)):
                setattr(self,key,tensor_tree(value,device))
        self.device=device;self.config.device=str(device)
        self._set_references(self.references)
        self.observation=ObservationModel(self.dataset.optics,source_dir=self.dataset.star_path.parent,device=device)

    def _accuracy_projector(self,projector,record):
        local=int(np.flatnonzero(self.dataset.global_indices==record.row)[0])
        self.active_optics=int(self.dataset.particles.iloc[local].rlnOpticsGroup)
        return projector

    def _raw_ctf_batch(self,records,indices,n,dtype,**kwargs):
        group=int(self.dataset.particles.iloc[int(indices[0])].rlnOpticsGroup)
        g=self.observation.groups[group]
        return compute_ctf(n,g.pixel_size,self.observation.parameters(self.dataset.particles.iloc[indices],group),
            device=self.device,dtype=dtype,frequency_grid=g.grid,frequency_matrix=g.matrix,gamma_offset=g.even_phase,
            phase_flipped_input=self.options.ctf_phase_flipped,only_flip_phases=self.options.only_flip_phases,
            intact_first_peak=self.options.intact_first_peak)

    def _accuracy_ctf(self,record,n,dtype):
        local=int(np.flatnonzero(self.dataset.global_indices==record.row)[0])
        raw=self._raw_ctf_batch([record],[local],n,dtype)[0] if self.use_ctf else torch.ones((n,n//2+1),device=self.device,dtype=dtype)
        if self.ctf_premultiplied or record.ctf_premultiplied:raw=raw.square()
        return raw*self.observation.groups[self.active_optics].mtf

    def _prepare_batch(self,indices,sigma_old,raw_images=None):
        window=getattr(self,'_global_window',None)
        if window is not None:
            cached=window.prepared.pop(tuple(indices),None)
            if cached is not None:return cached
        prepared=super()._prepare_batch(indices,sigma_old,raw_images)
        g=self.observation.groups[self.active_optics]
        # Odd aberrations are already demodulated exactly once in the shared
        # particle preparation (including the optics magnification coordinates).
        prepared.prediction=prepared.prediction*g.mtf
        prepared.numerator=prepared.numerator*g.mtf
        prepared.denominator=prepared.denominator*g.mtf.square()
        return prepared

    def _build_projection_bank(self,engine,timer,pixel):
        # Defer until an optics group and, for local search, a compact grid are known.
        return None

    def _make_engine(self,iteration):
        # Effective limits are temporary views, never edits to user/plan values.
        original_options,original_config=self.options,self.config
        if self.optimized:
            self.options=copy.copy(original_options)
            self.config=copy.copy(original_config)
            self.options.candidate_work_mib=min(original_options.candidate_work_mib,self._work_ceiling/2**20)
            self.options.performance_cache_mib=projection_limit(original_options,
                original_options.performance_cache_mib*2**20,self._cache_ceiling)/2**20
            self.config.batch_size=min(original_config.batch_size,self._batch_ceiling)
        try:engine=super()._make_engine(iteration)
        finally:self.options,self.config=original_options,original_config
        if self.optimized:
            engine.owner=self;engine.bulk_local=True
            if self._execution_workspace is None:self._execution_workspace=ExecutionWorkspace(self,self.sampling)

        base=engine.projector;owner=self
        class Callback:
            fusion_mode=getattr(base,"fusion_mode","off")
            def fusion_inputs(self,*args):return base.fusion_inputs(*args)
            def __call__(self,*args):return base(*args)
            def project_inverse(self,*args):return base.project_inverse(*args)
            def source_cache_token(self):return (*base.source_cache_token(),owner.half_id,owner.active_optics)
        engine.projector=Callback()
        return engine

    def _evaluate(self,indices,raw,sigma_old,engine,bank,timer,iteration,_oom_retry=False):
        engine.posterior_bytes=max(engine.posterior_bytes,int(self.options.posterior_work_mib*2**20))
        # The shared scorer may recursively split an uncommitted batch. Always
        # select from the original grid, even while an outer generator is
        # suspended with a compact grid installed for accumulation.
        outer=not hasattr(self,'_sampling_root')
        if outer:self._sampling_root=(self.sampling,self.direction_priors)
        try:
            yield from self._evaluate_groups(indices,raw,sigma_old,engine,bank,timer,iteration,_oom_retry)
        finally:
            if outer:del self._sampling_root

    def _posterior_batch_limit(self,engine,size):
        # Exact per-batch admission isolates a broad posterior; a single outlier
        # must not permanently reduce all later batches.
        return min(self._batch_ceiling,size)

    def _score_prepared(self,p,engine,bank,timer,iteration):
        window=getattr(self,'_global_window',None)
        coarse=None if window is None else window.coarse.pop(tuple(p.indices),None)
        if coarse is None:return super()._score_prepared(p,engine,bank,timer,iteration)
        if not self.config.oversampling:return coarse
        return timer.call('fine_expectation',engine.run_sparse_adaptive_batch,
            p.like,p.prediction,p.sigma,offset_prior_angstrom=p.centres,
            orientation_prior_deg=None,pixel_size=self.dataset.pixel_size,coarse=coarse)

    def _evaluate_groups(self,indices,raw,sigma_old,engine,bank,timer,iteration,_oom_retry=False):
        indices=np.asarray(indices,dtype=np.int64)
        groups=self.dataset.particles.iloc[indices].rlnOpticsGroup.to_numpy(dtype=int)
        for group in np.unique(groups):
            sel=np.flatnonzero(groups==group);rows=indices[sel];images=raw[sel]
            if self.optimized:
                self._execution_workspace.select_optics(int(group))
                window_plan=getattr(self,'_global_window_plan',None)
                if (not self.options.local_angular_search and not _oom_retry and
                        getattr(self,'_global_window',None) is None and window_plan is not None and
                        window_plan.particles and len(rows)>self.config.batch_size):
                    if self.active_optics!=int(group):engine.release_projection_storage()
                    self.active_optics=int(group)
                    from .global_window import evaluate_window
                    for start in range(0,len(rows),window_plan.particles):
                        yield from evaluate_window(self,rows[start:start+window_plan.particles],
                            images[start:start+window_plan.particles],sigma_old,engine,timer,iteration)
                    continue
                limit=self._posterior_batch_limit(engine,len(rows))
                if len(rows)>limit:
                    for start in range(0,len(rows),limit):
                        yield from self._evaluate(rows[start:start+limit],images[start:start+limit],sigma_old,engine,None,timer,iteration)
                    continue
            if self.active_optics!=int(group):engine.release_projection_storage()
            self.active_optics=int(group)
            previous=(self.sampling,self.direction_priors,getattr(self,'_compact_direction_ids',None),
                getattr(self,'_full_direction_count',None))
            full,full_prior=self._sampling_root
            local_engine=engine
            try:
                if self.options.local_angular_search:
                    try:
                        if self.optimized:
                            compact,support=timer.call('local_candidate_setup',select_sampling,full,self._angular_centres(rows),self.options.angular_sigmas,
                                int(self.options.sampling_work_mib*2**20),mode=self.options.local_candidate_search,counters=self._perf_counters)
                            ids=compact.global_orientation_ids;npsi=len(full._psi)
                            self._perf_counters['selected_orientation_pairs']=self._perf_counters.get('selected_orientation_pairs',0)+len(ids)
                            avoided=len(np.unique(ids//npsi))*len(np.unique(ids%npsi))-len(ids)
                            self._perf_counters['cartesian_orientation_pairs_avoided']=self._perf_counters.get('cartesian_orientation_pairs_avoided',0)+avoided
                            dirs=None
                        else:
                            compact,dirs=compact_sampling(full,self._angular_centres(rows),self.options.angular_sigmas,
                                int(self.options.sampling_work_mib*2**20))
                    except MemoryError:
                        if len(rows)==1:raise
                        mid=len(rows)//2
                        yield from self._evaluate(rows[:mid],images[:mid],sigma_old,engine,None,timer,iteration)
                        yield from self._evaluate(rows[mid:],images[mid:],sigma_old,engine,None,timer,iteration)
                        continue
                    self.sampling=compact
                    self.direction_priors=full_prior if dirs is None else full_prior[:,torch.as_tensor(dirs,device=self.device)]
                    self._compact_direction_ids=dirs;self._full_direction_count=len(full.directions)
                    local_engine=timer.call('local_engine_setup',self._make_engine,iteration)
                    if self.optimized:
                        local_engine.precomputed_support=support
                        if local_engine.local_buffer is None:local_engine.cache=self._execution_workspace.cache
                local_engine.active_batch_size=len(rows)
                yield from super()._evaluate(rows,images,sigma_old,local_engine,None,timer,iteration,_oom_retry)
            finally:
                if local_engine is not engine:
                    if self.optimized:
                        merge_counts(self._execution_workspace.counts,local_engine.memory_counters)
                        self._posterior_per_particle=max(getattr(self,'_posterior_per_particle',0),
                            local_engine.memory_counters.get('posterior_observed_bytes_per_particle',0))
                        if self.memory_controller is not None:self.memory_controller.observe(local_engine.memory_counters)
                    local_engine.release_projection_storage()
                    self._perf_counters['compact_sampling_batches']=self._perf_counters.get('compact_sampling_batches',0)+1
                self.sampling,self.direction_priors,self._compact_direction_ids,self._full_direction_count=previous

    def _accumulate(self,p,result,bps,grouper):
        owner=self
        class Adapter:
            def __getattr__(self,key):return getattr(bps,key)
            def add(self,c,values,rotations,ctf,weights,**kwargs):
                rotations=owner.observation.reconstruction_rotations(rotations,owner.active_optics,
                    owner.dataset.box_size,owner.dataset.pixel_size)
                return bps.add(c,values,rotations,ctf,weights,**kwargs)
        # Strict-highres can leave a very ill-conditioned high-frequency
        # preweight problem. Keep its parent accumulation order: tiny changes
        # in the gridding sums can be amplified by the RFLOAT blob convolution.
        # Projection reuse, compact pairs and OOM feedback still apply.
        if self.optimized and not (self.options.strict_highres_angstrom and self.options.strict_highres_angstrom>0):
            grouped=self._execution_workspace.mapped_grouper(bps,self.sampling)
            moments=super()._accumulate(p,result,Adapter(),grouped)
        else:
            if self.optimized:self._perf_counters['strict_parent_accumulation_batches']=self._perf_counters.get('strict_parent_accumulation_batches',0)+1
            moments=self._accumulate_parent(p,result,Adapter(),None)
        ids=getattr(self,'_compact_direction_ids',None)
        if ids is not None:
            expanded=torch.zeros((1,self._full_direction_count),device=self.device,dtype=moments.direction_mass.dtype)
            expanded[:,torch.as_tensor(ids,device=self.device)]=moments.direction_mass
            moments.direction_mass=expanded
        return moments

    def _execution_indices(self,selected):
        if not self.optimized:return selected
        from .global_window import plan_window
        self._global_window_plan=plan_window(self)
        self._perf_counters.update(global_window_budget_bytes=self._global_window_plan.budget_bytes,
            global_window_estimated_bytes=self._global_window_plan.estimated_bytes,
            execution_estimated_estep_extra_bytes=(0 if self._memory_plan is None else self._memory_plan.estimated_estep_extra_bytes)+self._global_window_plan.estimated_bytes)
        rows=np.arange(len(self.dataset)) if selected is None else np.asarray(selected)
        groups=self.dataset.particles.iloc[rows].rlnOpticsGroup.to_numpy(dtype=int)
        if self.options.local_angular_search:
            centres=self._angular_centres(rows)
            if torch.is_tensor(centres):centres=centres.cpu().numpy()
            # Periodic psi and roughly equal spherical cells; this is a schedule,
            # never an approximation of the actual prior/candidate selection.
            rot,tilt,psi=centres.T
            width=max(1.,self.sampling.angular_sampling()*3)
            keys=(np.floor((psi%360)/width),np.floor((rot%360)/width),np.floor(tilt/width),groups)
            order=np.lexsort(keys)
        else:order=np.argsort(groups,kind='stable')
        self._perf_counters['execution_reordered_particles']=int(np.count_nonzero(order!=np.arange(len(rows))))
        return rows[order]

    def _execution_read_batch_size(self):
        plan=getattr(self,'_global_window_plan',None)
        return max(self.config.batch_size,0 if plan is None else plan.particles)

    def _sync_recovery_limits(self):
        self._batch_ceiling=self._recovery.batch
        self._cache_ceiling=self._recovery.cache
        self._work_ceiling=self._recovery.work

    def _execution_backoff(self,engine):
        if not hasattr(self,'_recovery'):self._recovery=ExecutionRecovery()
        self._recovery.backoff(getattr(engine,'active_batch_size',1),engine.config.candidate_work_bytes)
        self._sync_recovery_limits()
        window=getattr(self,'_global_window',None)
        if window is not None:window.clear()
        self._global_window_plan=None
        workspace=self._execution_workspace
        if workspace is not None:
            workspace.clear_projections();workspace.cache.max_bytes=0
            workspace.finish_grouped()
        self._perf_counters.update(self._recovery.snapshot())
        print(f'  Execution backoff: batch <= {self._batch_ceiling}, temporary cache release; '
              'recovery will be reconsidered at a safe E-step boundary.',flush=True)

    def _execution_committed(self):
        if self.optimized:self._recovery.committed()

    def _execution_admission_failed(self):
        # Give an unusually broad fine posterior the entire normal workspace.
        # Discard only speculative coarse work for particles not yet committed.
        window=getattr(self,'_global_window',None)
        if window is not None:window.clear()

    def _finish_expectation_execution(self,engine,timer):
        super()._finish_expectation_execution(engine,timer)
        workspace=self._execution_workspace
        if workspace is None:return
        timer.call('flush_grouped_backprojection',workspace.finish_grouped)
        merge_counts(engine.memory_counters,workspace.snapshot())
        engine.memory_counters['auto_batch_ceiling']=self._batch_ceiling
        engine.memory_counters.update(self._recovery.snapshot())
        workspace.clear_projections()

    def expectation_step(self,it):
        self._posterior_per_particle=0
        if self.optimized:
            if self._recovery.begin_epoch():
                print('  Execution recovery probe: recomputing bounded resources for this E-step.',flush=True)
            self._sync_recovery_limits()
        controller=self.memory_controller
        before=getattr(controller,'oom_recoveries',0)
        try:
            packet=super().expectation_step(it)
            if controller is not None and hasattr(controller,'successful_epoch'):
                controller.successful_epoch(before)
            return packet
        finally:
            if self._execution_workspace is not None:
                self._execution_workspace.clear_projections()
                self._execution_workspace=None

    def _finish_maximization(self,bps,mass,direction,iteration,current_tau2):
        if self.fsc is None:raise RuntimeError('Half M-step requires this iteration\'s FSC')
        bp=bps.objects[0]
        from relion_torch.reconstruction.workspace import ReconstructionWorkspace
        workspace=ReconstructionWorkspace(bp)
        ssnr=update_ssnr_arrays(bp,current_tau2[0],workspace=workspace,tau2_fudge=self.config.tau2_fudge,
            fsc=self.fsc,update_tau2_with_fsc=True,reconstruct_whole_map_from_fsc=False)
        from relion_torch.reconstruction.sirm import sirm_options_from_config
        result=reconstruct_backprojector(bp,ReconstructionOptions(tau2=ssnr.tau2,
            sirm=sirm_options_from_config(self.options,fsc=self.fsc),
            tau2_fudge=self.config.tau2_fudge,normalise=float(mass[0]),
            preweight_iterations=self.config.preweight_iterations,min_resol_shell=self.config.minres_map,
            skip_gridding=self.options.skip_gridding,backend=self.options.reconstruction_backend),workspace=workspace,timer=self._detail_timer)
        for key,value in [('tau2',ssnr.tau2),('sigma2_class',ssnr.sigma2),
                          ('data_vs_prior',ssnr.data_vs_prior),('fourier_coverage',ssnr.fourier_coverage)]:
            setattr(self,key,[value])
        self.class_prob.fill_(1.)
        total=direction.sum()
        if float(total)>0:self.direction_priors=(direction/total).to(self.direction_priors.dtype)
        self._set_references([result.map])
        return self.references

    def _postprocess(self,iteration,cc):
        if not self.final_iteration:return super()._postprocess(iteration,cc)

    def _refresh_fourier_sizes(self):
        # Native MPI selects sizes before updateAngularSampling. Shared E-step
        # setup may refresh again, so retain this iteration's immutable sizes.
        if self._iteration_sizes is None:super()._refresh_fourier_sizes()
        else:self.sizes=self._iteration_sizes
        if hasattr(self,'controller_shell'):self.psnr_shell=self.controller_shell

    def _model_blocks(self,*args,**kwargs):
        blocks=super()._model_blocks(*args,**kwargs)
        blocks['model_general']['rlnOrientationalPriorMode']=int(self.options.local_angular_search)
        return blocks

    def _write_outputs(self,iteration,ll,pmax,updated):
        self.last_changes=pose_changes(self.dataset.particles,updated,self.options.symmetry)
        self.last_ll=float(ll);self.last_pmax=float(pmax)
        self.dataset.replace_particles(updated)

    def save_checkpoint(self,iteration):pass  # Only the coordinator commits both halves together.

    def snapshot(self):
        state={k:tensor_tree(getattr(self,k),'cpu',clone=True) for k in self._tensor_fields}
        state.update(references=tensor_tree(self.references,'cpu',clone=True),sampling=self.sampling.state_dict(),
            rng_state=copy.deepcopy(self.generator.bit_generator.state),iteration=self.last_completed_iteration,
            avg_norm_correction=self.avg_norm_correction,refs_are_ctf_corrected=self.refs_are_ctf_corrected,
            sigma_offset=self.sigma_offset_angstrom,working_psnr_shell=self.working_psnr_shell,
            working_current_size=self.working_current_size,history=self._iteration_history,
            direction_prior_reset_pending=self._direction_prior_reset_pending,
            last_ll=getattr(self,'last_ll',0.),last_pmax=getattr(self,'last_pmax',0.))
        return state

    def restore_checkpoint(self,state):
        for key in self._tensor_fields:setattr(self,key,tensor_tree(state[key],self.device,clone=True))
        self.sampling=Class3DSampling.from_state(state['sampling'])
        self.generator.bit_generator.state=copy.deepcopy(state['rng_state'])
        self.last_completed_iteration=int(state['iteration'])
        self.avg_norm_correction=state['avg_norm_correction'];self.refs_are_ctf_corrected=state['refs_are_ctf_corrected']
        self.sigma_offset_angstrom=state['sigma_offset'];self._iteration_history=state['history']
        self._direction_prior_reset_pending=state['direction_prior_reset_pending']
        self.working_psnr_shell=state['working_psnr_shell'];self.working_current_size=state['working_current_size']
        self.last_ll=state.get('last_ll',0.);self.last_pmax=state.get('last_pmax',0.)
        self._set_references(state['references']);self._refresh_fourier_sizes()


class HalfWorker:
    """Device assignment is execution policy, never part of half identity."""
    def __init__(self,half_id,parent,options,references,state=None,device="cpu"):
        self.half_id=half_id;self.dataset=HalfDataset(parent,half_id)
        opts=replace(options,device=str(device),output_root=type(options.output_root)(str(options.output_root)+f'_half{half_id}'),
            skip_expected_accuracy=True)
        cfg=make_alignment_config(opts,parent.star_path,device,0 if state is None else state['iteration'],False)
        cfg.references=list(options.references)
        self.optimiser=HalfOptimiser(cfg,options=opts,dataset=self.dataset,initial_references=references,
            half_id=half_id,checkpoint_state=state)
        self.packet=None
        self.park()

    def begin_iteration(self,controller,options):
        self.optimiser._iteration_sizes=None
        self.configure(controller,options)
        self.optimiser._iteration_sizes=self.optimiser.sizes

    def configure(self,controller,options):
        o=self.optimiser
        q=o.sampling.random_perturbation
        if o.sampling.healpix_order!=controller.order or o.sampling.offset_step!=controller.offset_step or o.sampling.offset_range!=controller.offset_range:
            o.sampling=Class3DSampling(3,controller.order,None,controller.offset_range,controller.offset_step,
                options.oversampling,options.perturbation_factor,q,symmetry=options.symmetry)
            o.direction_priors=torch.full((1,len(o.sampling.directions)),1./len(o.sampling.directions),device=o.device)
            o._direction_prior_reset_pending=True
        sigma=2*controller.angular_step(options.oversampling) if controller.order>=options.auto_local_healpix_order else -1.
        cuda_execution=str(options.device).startswith('cuda') or bool(options.devices and 'cpu' not in options.devices)
        if sigma<=0 and not (options.auto_memory and cuda_execution):
            needed=o.sampling.number_of_orientations*(1+8**options.oversampling)*40
            if needed>options.sampling_work_mib*2**20:
                raise MemoryError('Global sampling table exceeds --sampling-work-mib; increase the budget. No directions were dropped.')
        o.options.healpix_order=o.config.healpix_order=controller.order
        o.options.sigma_ang_deg=-1.
        for axis in ('rot','tilt','psi'):
            setattr(o.options,f'sigma_{axis}_deg',sigma);setattr(o.config,f'sigma_{axis}_deg',sigma)
        o.config.current_size=controller.working_size(self.dataset.box_size,use_all_data=options.use_all_data)
        o.controller_shell=controller.resolution_shell
        o.final_iteration=controller.final_iteration
        o._refresh_fourier_sizes()

    def activate(self,device,memory_controller=None):
        self.optimiser.move_to(device);self.optimiser.memory_controller=memory_controller

    def park(self):
        self.optimiser.memory_controller=None
        self.optimiser.move_to('cpu')
        gc.collect()

    def expectation(self,iteration,device,memory_controller=None):
        self.activate(device,memory_controller)
        self.packet=self.optimiser.expectation_step(iteration)
        self.packet['expectation_seconds']=time.perf_counter()-self.packet['begin']
        move_packet(self.packet,'cpu');self.park()
        return self.packet

    def maximization(self,iteration,fsc,device,memory_controller=None):
        self.activate(device,memory_controller);move_packet(self.packet,device)
        self.packet['begin']=time.perf_counter()-self.packet['expectation_seconds']
        self.optimiser.fsc=fsc.to(device)
        self.optimiser.maximization_step(iteration,self.packet)
        changes=self.optimiser.last_changes
        self.packet=None;self.park()
        return changes
