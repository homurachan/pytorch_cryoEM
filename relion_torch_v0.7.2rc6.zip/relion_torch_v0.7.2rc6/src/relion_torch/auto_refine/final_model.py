"""Full-data scalar/noise statistics, created only after convergence."""
import copy
import math
import torch
from relion_torch.class2d.semantics import update_group_scales
from relion_torch.inference.alignment import rounded_shell_indices_2d
from relion_torch.geometry.grids import signed_fft_indices


def combined_statistics(parent,workers):
    """Aggregate original E-step sums, never averages of fitted noise/scales."""
    model=copy.copy(workers[0].optimiser)
    model.dataset=parent
    model.group_ids=sorted(set().union(*(set(w.optimiser.group_ids) for w in workers)))
    model.group_to_index={g:i for i,g in enumerate(model.group_ids)}
    model.group_names=[];model.group_particle_counts=[];model.sigma2=[]
    ns=parent.box_size//2+1;ng=len(model.group_ids)
    noise=torch.zeros(ng,ns,dtype=torch.float64)
    mass=torch.zeros(ng,dtype=torch.float64);xa=torch.zeros_like(mass);aa=torch.zeros_like(mass)
    for g in model.group_ids:
        i=model.group_to_index[g];names=[];count=0;fallback=torch.zeros(ns,dtype=torch.float64)
        for worker in workers:
            o=worker.optimiser;p=worker.packet
            if g not in o.group_to_index:continue
            j=o.group_to_index[g];cnt=o.group_particle_counts[j]
            count+=cnt;names.append(o.group_names[j]);fallback+=o.sigma2[j].double()*cnt
            noise[i]+=p['noisesum'][j];mass[i]+=p['groupmass'][j]
            xa[i]+=p['gx'][j];aa[i]+=p['ga'][j]
        model.group_names.append(names[0]);model.group_particle_counts.append(count)
        model.sigma2.append((fallback/count).float())
    model.do_scale=model.options.do_scale_correction and ng>1
    model.group_scales=update_group_scales(xa,aa,model.group_particle_counts) if model.do_scale else torch.ones(ng,dtype=torch.float64)
    n=parent.box_size;shell=rounded_shell_indices_2d(n,torch.device('cpu'));fy=signed_fft_indices(n,device='cpu')
    unique=(shell<ns)&~((torch.arange(ns)[None]==0)&(fy[:,None]<0))
    counts=torch.bincount(shell[unique],minlength=ns).double()
    for i in range(ng):
        if float(mass[i])<=0 or float(noise[i].sum())==0:continue
        sp=noise[i]/(2*mass[i]*counts.clamp_min(1))
        if model.has_premultiplied:sp=sp.clamp_min(1e-15)
        for j in range(1,ns):sp[j]=torch.where(sp[j]<1e-14,sp[j-1],sp[j])
        model.sigma2[i]=sp.float()
    total=sum(w.packet['total'] for w in workers)
    model.sigma_offset_angstrom=math.sqrt(max(0.,sum(float(w.packet['offset2']) for w in workers)/(2*total)))
    direction=sum(w.packet['direction'].double() for w in workers)
    model.direction_priors=(direction/direction.sum()).float()
    model.last_ll=sum(w.packet['dll'] for w in workers)
    model.last_pmax=sum(w.packet['pmax'] for w in workers)/total
    return model
