"""Pure control state, independent of CUDA/MPI and of half execution order."""
from dataclasses import dataclass, asdict
import math
import numpy as np
import torch
from relion_torch.geometry.euler import relion_euler_matrix


def pose_changes(old,new,symmetry='C1'):
    """Native C1 mean axis distance, offset squared sum and particle count."""
    cols=['rlnAngleRot','rlnAngleTilt','rlnAnglePsi']
    def angles(frame):
        return torch.tensor(np.column_stack([frame[c].to_numpy() if c in frame else np.zeros(len(frame)) for c in cols]),dtype=torch.float64)
    a,b=angles(old),angles(new)
    ra=relion_euler_matrix(a[:,0],a[:,1],a[:,2]);rb=relion_euler_matrix(b[:,0],b[:,1],b[:,2])
    from relion_torch.geometry.symmetry import angular_axis_distance
    angular=angular_axis_distance(ra,rb,symmetry).sum().item()
    offset=0.
    for col in ('rlnOriginXAngst','rlnOriginYAngst'):
        x=old[col].to_numpy() if col in old else np.zeros(len(old))
        offset+=float(np.square(new[col].to_numpy()-x).sum())
    previous=old['rlnClassNumber'].to_numpy() if 'rlnClassNumber' in old else np.ones(len(old))
    current=new['rlnClassNumber'].to_numpy() if 'rlnClassNumber' in new else np.ones(len(new))
    return dict(angle_sum=angular,offset_square_sum=offset,class_change_sum=int(np.count_nonzero(previous!=current)),count=len(old))


def resolution_shell(curve,minres_map):
    """updateCurrentResolution, including the auto-refine high-side recovery."""
    v=np.asarray(curve,dtype=float);nyq=len(v)-1
    low=nyq-1
    for i in range(1,nyq):
        if v[i]<1:low=i-1;break
    high=low
    for i in range(nyq-1,low-1,-1):
        if v[i]>1:high=i;break
    shell=high if high>low+3 else low
    return max(1,min(nyq-1,max(int(minres_map),shell)))


@dataclass
class AutoRefineController:
    order: int
    offset_step: float
    offset_range: float
    resolution_shell: int
    increment: int = 10
    no_resolution_gain: int = 0
    no_large_changes: int = 0
    smallest_angle_change: float = 999.
    smallest_offset_change: float = 999.
    smallest_class_change: float = 9999999.
    class_change: float = 999.
    angle_change: float = 999.
    offset_change: float = 999.
    acc_rot: float = 999.
    acc_trans: float = 999.
    fine_enough: bool = False
    final_iteration: bool = False
    complete: bool = False
    high_fsc_at_limit: bool = False
    pmax: float = 0.
    iteration: int = 0
    sampling_changed: bool = False
    # RELION 3.1.4's non-helical MPI leader retains the initial sampling.
    # Followers refine their grid, but the leader measures hidden-variable
    # changes against this separate grid. Persist it across continuation.
    convergence_order: int | None = None
    convergence_offset_step: float | None = None

    def __post_init__(self):
        if self.convergence_order is None:self.convergence_order=self.order
        if self.convergence_offset_step is None:self.convergence_offset_step=self.offset_step

    def state_dict(self):return asdict(self)

    def angular_step(self,oversampling):return 360./(6*2**(self.order+oversampling))

    def check_convergence(self,options):
        self.final_iteration=bool(options.force_converge or (self.fine_enough and self.no_resolution_gain>=1
            and (options.auto_ignore_angle_changes or self.no_large_changes>=1)))
        return self.final_iteration

    def working_size(self,n,*,use_all_data=False):
        increment=int(math.floor(.25*n/2+.5)) if self.pmax>.1 and self.high_fsc_at_limit else self.increment
        return n if self.final_iteration or use_all_data else min(n,max(2,2*(self.resolution_shell+increment)))

    def update_sampling(self,options,*,particle_diameter,n,pixel):
        self.sampling_changed=False
        if self.iteration<1 or self.final_iteration:return
        old=self.angular_step(options.oversampling)
        nr=max(1,math.ceil(math.pi*particle_diameter*self.resolution_shell/(n*pixel)))
        proceed=(options.auto_resolution_based_angles and 360./nr<old and self.order+1!=options.auto_local_healpix_order)
        if not (proceed or self.no_resolution_gain>=1):return
        if not (options.auto_ignore_angle_changes or self.no_large_changes>=1):return
        if ((options.maximum_angular_sampling>0 and old<options.maximum_angular_sampling)
            or (old<.75*self.acc_rot and not (options.minimum_angular_sampling>0 and old>options.minimum_angular_sampling))):
            self.fine_enough=True;return
        if self.order>=options.max_healpix_order:
            raise RuntimeError('Auto sampling needs a finer order than --max-healpix-order; resume the checkpoint with a larger limit. This is not convergence.')
        step=min(1.5,.75*self.acc_trans)*2**options.oversampling
        step=max(step,1e-6)
        span=min(1.3*self.offset_range,5*self.offset_change)
        span=max(span,1.5*step)
        if span>4*step:span/=2
        if span>4*step:step=span/4
        if step<=self.offset_step:self.offset_step,self.offset_range=step,span
        self.order+=1;self.fine_enough=False;self.sampling_changed=True
        self.no_resolution_gain=self.no_large_changes=0
        self.smallest_angle_change=self.smallest_offset_change=999.
        self.smallest_class_change=9999999.

    def observe(self,options,*,fsc,data_vs_prior,changes,n,pixel,current_size,pmax,iteration):
        v=np.asarray(fsc,dtype=float)
        def crossing(t):
            x=np.flatnonzero(v<t);return int(x[0]) if len(x) else -1
        self.increment=max(self.increment,crossing(.143)-crossing(.5)+5)
        self.high_fsc_at_limit=bool(self.high_fsc_at_limit or v[current_size//2-1]>.2)
        new=resolution_shell(data_vs_prior,options.minres_map)
        if options.initial_high_resolution and iteration==1 and options.firstiter_cc:
            new=max(1,min(n//2-1,int(math.floor(n*pixel/options.initial_high_resolution+.5))))
        if new/(n*pixel)<=self.resolution_shell/(n*pixel)+.0001:self.no_resolution_gain+=1
        else:self.no_resolution_gain=0
        self.resolution_shell=new
        count=sum(x['count'] for x in changes)
        self.angle_change=sum(x['angle_sum'] for x in changes)/count
        self.offset_change=math.sqrt(sum(x['offset_square_sum'] for x in changes)/(2*count))
        self.class_change=sum(x.get('class_change_sum',0) for x in changes)/count
        leader_angle_step=360./(6*2**(self.convergence_order+options.oversampling))
        leader_offset_step=self.convergence_offset_step/2**options.oversampling
        stable_angle=(self.angle_change/leader_angle_step<.4 or 1.03*self.angle_change>=self.smallest_angle_change)
        stable_offset=(self.offset_change/leader_offset_step<.4 or 1.03*self.offset_change>=self.smallest_offset_change)
        stable_class=1.03*self.class_change>=self.smallest_class_change
        self.no_large_changes=self.no_large_changes+1 if stable_angle and stable_offset and stable_class else 0
        self.smallest_angle_change=min(self.smallest_angle_change,self.angle_change)
        self.smallest_offset_change=min(self.smallest_offset_change,self.offset_change)
        self.smallest_class_change=min(self.smallest_class_change,self.class_change)
        self.pmax=float(pmax);self.iteration=int(iteration)
        if self.final_iteration:self.complete=True
