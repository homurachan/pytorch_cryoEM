"""One bounded global coarse window followed by ordinary fine transactions."""
import gc
import torch
from relion_torch.class3d.expectation import SplitParticleBatch
from relion_torch.inference.execution_policy import GlobalWindowPlan


class GlobalWindow:
    def __init__(self):
        self.prepared = {}
        self.coarse = {}

    def clear(self):
        self.prepared.clear()
        self.coarse.clear()


def plan_window(owner):
    plan = getattr(owner, '_memory_plan', None)
    disabled = (not owner.optimized or owner.device.type != 'cuda' or
                owner.options.local_angular_search or owner.config.skip_align or
                owner.config.skip_rotate or plan is None or plan.full_coarse or
                owner._cache_ceiling == 0)
    maximum = 0 if disabled else int(owner.options.global_window_mib*2**20)
    available = 0 if plan is None else max(0, plan.available_bytes-plan.estimated_estep_extra_bytes)
    coarse, _ = owner.sizes.coarse_likelihood_grid(owner.config.oversampling)
    return GlobalWindowPlan.make(batch=owner.config.batch_size,
        orientations=owner.sampling.number_of_orientations,
        translations=owner.sampling.number_of_translations, classes=len(owner.references),
        original_size=owner.dataset.box_size, coarse_pixels=coarse*(coarse//2+1),
        available_bytes=available, maximum_bytes=maximum)


def evaluate_window(owner, rows, images, sigma, engine, timer, iteration):
    """Only uncommitted particles are retried; committed statistics stay intact."""
    window = GlobalWindow()
    owner._global_window = window
    micro = min(owner.config.batch_size, getattr(owner,'_batch_ceiling',owner.config.batch_size))
    chunks = [(rows[s:s+micro], images[s:s+micro]) for s in range(0, len(rows), micro)]
    bank = None
    try:
        failed = oom = False
        try:
            bank = engine.build_global_projection_bank(pixel_size=owner.dataset.pixel_size)
            store = bank.projections
            covered = getattr(store, 'full_bank', False) or getattr(store, 'host_values', None) is not None
            # A complete resident/host bank already avoids recomputation.
            if not covered:
                for ids, raw in chunks:
                    window.prepared[tuple(ids)] = timer.call('prepare_particles', owner._prepare_batch, ids, sigma, raw)
                batches = [((p.like, p.prediction, p.sigma), dict(
                    offset_prior_angstrom=p.centres, orientation_prior_deg=None,
                    pixel_size=owner.dataset.pixel_size, bank=bank)) for p in window.prepared.values()]
                engine.active_batch_size = micro
                results = timer.call('coarse_expectation', engine.run_global_batches, batches)
                window.coarse.update(zip(window.prepared, results))
                batches = results = None
                counts = owner._perf_counters
                counts['global_windows'] = counts.get('global_windows', 0)+1
                counts['global_window_particles_max'] = max(counts.get('global_window_particles_max', 0), len(rows))
        except SplitParticleBatch:
            failed = True
        except torch.cuda.OutOfMemoryError:
            if owner.memory_controller is None:raise
            failed = oom = True
            # Drop all window owners before the standard release/retry path.
            batches = results = None
            window.clear()
        # Exit exception scope first: tracebacks otherwise retain CUDA tensors.
        if failed:
            batches = results = None
            window.clear()
            if oom:
                engine.release_projection_storage(disable=True)
                bank = None
                gc.collect()
                torch.cuda.empty_cache()
                if owner.memory_controller is not None:owner.memory_controller.recovered_oom()
            owner._perf_counters['global_window_fallbacks'] = owner._perf_counters.get('global_window_fallbacks', 0)+1
        for ids, raw in chunks:
            yield from owner._evaluate(ids, raw, sigma, engine, bank, timer, iteration)
            # A rejected fine pass may split this microbatch. Its coarse entry
            # must not survive after those children have committed.
            window.prepared.pop(tuple(ids), None)
            window.coarse.pop(tuple(ids), None)
    finally:
        window.clear()
        owner._global_window = None
