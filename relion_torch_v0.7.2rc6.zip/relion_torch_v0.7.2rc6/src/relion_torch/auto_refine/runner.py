"""Gold-standard scheduler with optional persistent device worker groups."""
from dataclasses import asdict, fields, replace
from pathlib import Path
import json
import math
import os
import time
import numpy as np
import pandas as pd
import torch
from relion_torch.alignment.core import AlignmentDataset
from relion_torch.io.particle_store import ParticleIOOptions
from relion_torch.io.star import read_star,write_star
from relion_torch.io.mrc import write_mrc
from relion_torch.class3d.runner import validate as validate_class3d, EXECUTION_OVERRIDES
from relion_torch.class3d.references import load_references
from relion_torch.class3d.optimiser import _primitive
from relion_torch.inference.memory_planning import CudaMemoryController
from relion_torch.reconstruction.half_fsc import (backprojector_fsc,mwtcf_backprojector_fsc,solvent_corrected_fsc,
    unregularized_map,move_backprojector,merge_backprojectors,join_low_resolution)
from relion_torch.reconstruction.reconstruct import ReconstructionOptions,reconstruct_backprojector
from relion_torch.reconstruction.ssnr import update_ssnr_arrays
from relion_torch.version import __version__
from .config import AutoRefineConfig
from .controller import AutoRefineController,resolution_shell
from .worker import HalfWorker
from .accuracy import accuracy_probe_rows
from .final_model import combined_statistics

FORMAT='relion-torch-auto-refine-v1'
from relion_torch.reconstruction.sirm import SIRM_CONTINUATION_FIELDS, sirm_options_from_config

EXECUTION_FIELDS=(EXECUTION_OVERRIDES-{'fast_subsets'})|{'force_converge','half_order','max_healpix_order','auto_execution','auto_cache_mib'}
CONTINUATION_FIELDS={'use_all_data','do_mwtcf','mwtcf'}


def validate(options):
    if options.write_unfil_map:raise ValueError('--write-unfil-map is a Class3D option; auto-refine writes independent unfiltered halves in its final iteration')
    if not math.isfinite(options.mwtcf):raise ValueError('mwtcf must be finite')
    if options.number_of_classes!=1:raise ValueError('Gold-standard auto-refine requires K=1')
    if options.fast_subsets:raise ValueError('fast-subsets is not supported in gold-standard auto-refine')
    if options.skip_align or options.skip_rotate:raise ValueError('Auto-refine requires angular refinement')
    if options.skip_expected_accuracy or options.expected_accuracy_trials<1:
        raise ValueError('Auto-refine needs expected angular/translation accuracy estimates')
    if options.current_size is not None:raise ValueError('Auto-refine manages current-size; use ini-high or strict-highres')
    if options.solvent_correct_fsc and options.solvent_mask is None:
        raise ValueError('--solvent-correct-fsc requires an explicit --solvent-mask')
    if options.auto_execution not in ('optimized','reference'):raise ValueError('auto_execution must be optimized or reference')
    if not math.isfinite(options.auto_cache_mib) or (options.auto_cache_mib<0 and options.auto_cache_mib!=-1):
        raise ValueError('auto_cache_mib must be -1 (automatic), 0 (disabled), or a positive MiB ceiling')
    if not 0<=options.auto_local_healpix_order<=options.max_healpix_order<=10:
        raise ValueError('Require 0 <= auto-local-healpix-order <= max-healpix-order <= 10')
    if not 0<=options.healpix_order<=options.max_healpix_order:raise ValueError('Initial HEALPix order exceeds allowed range')
    if options.psi_step_deg is not None:raise ValueError('Auto-refine derives psi step from HEALPix order')
    if options.local_angular_search:raise ValueError('Auto-refine manages sigma angles; choose auto-local-healpix-order')
    if tuple(sorted(options.half_order))!=(1,2):raise ValueError('half-order must be 1,2 or 2,1')
    if not math.isfinite(options.sampling_work_mib) or options.sampling_work_mib<=0:
        raise ValueError('sampling-work-mib must be positive and finite')
    for name in ('low_resol_join_halves','minimum_angular_sampling','maximum_angular_sampling'):
        if not math.isfinite(getattr(options,name)):raise ValueError(f'{name} must be finite')
    # Preserve the existing Class3D validation; compact local tables are bounded
    # at each actual batch rather than by a hypothetical all-sphere table.
    proxy=replace(options,healpix_order=min(options.healpix_order,6),sampling_work_mib=max(options.sampling_work_mib,1e9))
    validate_class3d(proxy)


def assign_halves(frame,seed):
    if len(frame)<2:raise ValueError('At least two particles are required')
    if 'rlnRandomSubset' in frame:
        labels=pd.to_numeric(frame.rlnRandomSubset,errors='coerce').to_numpy()
        if not np.isfinite(labels).all() or not np.isin(labels,[1,2]).all():
            raise ValueError('rlnRandomSubset must contain only complete 1/2 labels; no silent resplitting')
        if set(labels)!={1,2}:raise ValueError('Both random halves must contain particles')
        return labels.astype(np.int64)
    # Stable balanced random split, created only once and persisted in data STAR.
    labels=np.ones(len(frame),dtype=np.int64);labels[len(frame)//2:]=2
    np.random.default_rng(seed).shuffle(labels)
    frame['rlnRandomSubset']=labels
    return labels


def load_checkpoint(path):
    path=Path(path).expanduser().resolve()
    if path.suffix=='.star':
        values=[str(v) for frame in read_star(path).values() if 'rlnTorchCheckpoint' in frame for v in frame.rlnTorchCheckpoint]
        if len(values)!=1:raise ValueError('Continuation needs an auto-refine checkpoint or its optimiser STAR')
        q=Path(values[0]);path=q if q.is_absolute() else path.parent/q
    state=torch.load(path,map_location='cpu',weights_only=True)
    if state.get('format')!=FORMAT:raise ValueError('Not a supported auto-refine checkpoint')
    if state['controller']['complete']:raise ValueError('Joined final result cannot restart independent half refinement; use the last unjoined checkpoint')
    return state


def _particles(parent,workers):
    result=parent.particles.copy()
    for worker in workers:
        frame=worker.dataset.particles
        for col in frame:
            if col not in result:result[col]=np.nan
            if result[col].dtype != frame[col].dtype:
                result[col]=result[col].astype(frame[col].dtype)
            result.loc[worker.dataset.global_indices,col]=frame[col].to_numpy()
    # Keep output/continuation portable across output directories.
    result['rlnImageName']=[f'{r.stack_index}@{r.stack_path}' for r in parent._records]
    return parent.particles_in_source_order(result)


def _write_iteration(options,parent,workers,controller,fsc,history,*,probe_rows,initial=False):
    iteration=controller.iteration
    root=f'{options.output_root}_it{iteration:03d}'
    data_path=Path(root+'_data.star')
    particles=_particles(parent,workers)
    write_star({'optics':parent.optics,'particles':particles},data_path)
    model_paths=[]
    for worker in workers:
        o=worker.optimiser
        o.working_psnr_shell=(resolution_shell(o.data_vs_prior[0].numpy(),options.minres_map)
            if controller.complete else controller.resolution_shell)
        map_path=Path(root+f'_half{worker.half_id}_class001.mrc')
        write_mrc(map_path,o.references[0],pixel_size_angstrom=parent.pixel_size)
        model_path=Path(root+f'_half{worker.half_id}_model.star');model_paths.append(str(model_path))
        blocks=o._model_blocks([str(map_path)],log_likelihood=getattr(o,'last_ll',0.),
            average_pmax=getattr(o,'last_pmax',0.),initial_state=initial)
        for frame in blocks.values():
            if 'rlnSpectralIndex' in frame and len(frame)==len(fsc):frame['rlnGoldStandardFsc']=fsc.numpy()
        write_star(blocks,model_path)
    sm=workers[0].optimiser.sampling.state_dict()
    sampling_path=Path(root+'_sampling.star')
    write_star({'sampling_general':pd.DataFrame([{
        'rlnReferenceDimensionality':3,'rlnSymmetryGroup':options.symmetry,
        'rlnHealpixOrder':sm['healpix_order'],'rlnPsiStep':sm['psi_step'],
        'rlnOffsetRange':sm['offset_range'],'rlnOffsetStep':sm['offset_step'],
        'rlnSamplingPerturbInstance':sm['random_perturbation'],'rlnSamplingPerturbFactor':sm['perturbation_factor']}])},sampling_path)
    fsc_path=Path(root+'_fsc.star')
    write_star({'fsc':pd.DataFrame({'rlnSpectralIndex':np.arange(len(fsc)),
        'rlnResolution':np.arange(len(fsc))/(parent.box_size*parent.pixel_size),'rlnGoldStandardFsc':fsc.numpy()})},fsc_path)
    state=dict(format=FORMAT,package_version=__version__,config=_primitive(asdict(options)),
        iteration=iteration,data_star=str(data_path),input_star=str(options.input_star),
        half_labels=particles.rlnRandomSubset.to_numpy(dtype=np.int64).tolist(),
        accuracy_probe_rows=probe_rows.tolist(),
        image_names=particles.rlnImageName.astype(str).tolist(),
        particle_numeric={col:torch.from_numpy(particles[col].to_numpy(copy=True)) for col in particles if particles[col].dtype.kind in 'biuf'},
        halves=[w.optimiser.snapshot() for w in workers],controller=controller.state_dict(),fsc=fsc.cpu(),history=history)
    state_path=Path(root+'_state.pt');temp=Path(str(state_path)+'.tmp')
    torch.save(state,temp);os.replace(temp,state_path)
    if not controller.complete:
        write_star({'optimiser_general':pd.DataFrame([{'rlnCurrentIteration':iteration,
            'rlnDoAutoRefine':1,'rlnDo3DClassification':0,'rlnDoSplitRandomHalves':1,
            'rlnDoJoinRandomHalves':0,'rlnDataStarFile':str(data_path),
            'rlnModelStarFile':model_paths[0],'rlnModelStarFile2':model_paths[1],
            'rlnSamplingStarFile':str(sampling_path),'rlnTorchCheckpoint':str(state_path)}])},root+'_optimiser.star')
    return state_path


def _check_resume(options,state):
    for field in fields(options):
        name=field.name
        if name in SIRM_CONTINUATION_FIELDS|EXECUTION_FIELDS|CONTINUATION_FIELDS or name in ('iterations','output_root','continue_from','input_star'):continue
        if _primitive(getattr(options,name))!=state['config'].get(name):
            raise ValueError(f'Cannot change scientific setting {name} during continuation')


@torch.no_grad()
def run_auto_refine(options:AutoRefineConfig,*,checkpoint_state=None):
    options=replace(options)
    from relion_torch.inference.permanent_workers import devices,PermanentPool,parallel_halves,accuracy
    worker_devices=devices(options)
    if worker_devices:options.device="cpu"
    pool=None
    validate(options)
    state=checkpoint_state if checkpoint_state is not None else (load_checkpoint(options.continue_from) if options.continue_from else None)
    if state is not None:_check_resume(options,state)
    if options.do_mwtcf and options.solvent_correct_fsc:
        print('Solvent-corrected FSC takes precedence over MWTCF, matching SIRM-RELION.',flush=True)
    options.output_root=Path(options.output_root).expanduser().resolve();options.output_root.parent.mkdir(parents=True,exist_ok=True)
    if options.solvent_mask is not None:options.solvent_mask=Path(options.solvent_mask).expanduser().resolve()
    if options.sirm_mask is not None:options.sirm_mask=Path(options.sirm_mask).expanduser().resolve()
    if state is None:
        if options.input_star is None or not options.references:raise ValueError('A new auto-refine requires --i and --ref')
        options.input_star=Path(options.input_star).expanduser().resolve();inputstar=options.input_star
    else:
        inputstar=Path(state['data_star']);options.input_star=Path(state['input_star'])
        if options.iterations<=state['iteration']:raise ValueError('--iter must exceed the saved iteration')
    device=torch.device(options.device)
    if device.type=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable; use --device cpu for testing')
    with CudaMemoryController(device,options.gpu_memory_percent,automatic=options.auto_memory) as guard:
        memory=guard if options.auto_memory and guard.enabled else None
        parent=AlignmentDataset(inputstar,io_options=ParticleIOOptions.from_config(options),preserve_noise_groups=state is not None)
        try:
            # Output STARs live beside the refinement, not necessarily beside
            # the input. Preserve relative optical calibration file identities.
            if 'rlnMtfFileName' in parent.optics:
                from relion_torch.io.particles import parse_image_reference
                parent.optics=parent.optics.copy()
                parent.optics['rlnMtfFileName']=[str(parse_image_reference(str(v),parent.star_path.parent)[1])
                    if str(v) not in ('None','none','nan','?','.','') else v for v in parent.optics.rlnMtfFileName]
            if parent.box_size<4:raise ValueError('Auto-refine needs an even box size >=4')
            if options.preread_images:parent.images.preread(shared=bool(worker_devices))
            labels=assign_halves(parent.particles,options.random_seed)
            if state is not None and labels.tolist()!=state['half_labels']:raise ValueError('Checkpoint half identities differ from data STAR')
            if state is not None:
                if parent.particles.rlnImageName.astype(str).tolist()!=state['image_names']:
                    raise ValueError('Checkpoint image identities differ from data STAR')
                restored=parent.particles.copy()
                for col,values in state['particle_numeric'].items():restored[col]=values.numpy().copy()
                parent.replace_particles(restored)
            probe_rows=accuracy_probe_rows(parent.particles,options.random_seed,options.expected_accuracy_trials,
                None if state is None else state.get('accuracy_probe_rows'))
            if memory is not None:
                from relion_torch.class3d.memory import configure_startup
                configure_startup(memory,options,parent.box_size)
            from relion_torch.inference.permanent_workers import configure_coordinator
            configure_coordinator(options,parent.box_size)
            if state is None:
                refs,_,_=load_references(options.references,1,parent.box_size,parent.pixel_size,torch.device('cpu'),options.reference_max_gib)
            else:refs=state['halves'][0]['references']
            workers=[HalfWorker(i,parent,options,refs if state is None else state['halves'][i-1]['references'],
                None if state is None else state['halves'][i-1],device=device) for i in (1,2)]
            if worker_devices:
                pool=PermanentPool(options)
                for w in workers:pool.bind(w.optimiser,w.half_id,parent)
            probe_indices=np.searchsorted(workers[0].dataset.global_indices,probe_rows)
            refs=None
            if state is None:
                shell=max(1,min(parent.box_size//2-1,workers[0].optimiser.psnr_shell))
                if options.initial_high_resolution:
                    shell=max(1,min(parent.box_size//2-1,int(math.floor(parent.box_size*parent.pixel_size/options.initial_high_resolution+.5))))
                controller=AutoRefineController(options.healpix_order,options.offset_step_pixels*parent.pixel_size,
                    options.offset_range_pixels*parent.pixel_size,shell)
                fsc=torch.zeros(parent.box_size//2+1);history=[]
            else:
                control_state=dict(state['controller'])
                # Upgrade v0.5.0 checkpoints from the saved INITIAL config,
                # never from the already refined follower sampling.
                control_state.setdefault('convergence_order',options.healpix_order)
                control_state.setdefault('convergence_offset_step',options.offset_step_pixels*parent.pixel_size)
                controller=AutoRefineController(**control_state);fsc=state['fsc'];history=state['history']
                # A newly enabled/changed reference constraint needs an M-step
                # and a following alignment step before convergence can join.
                # Do not reset an unchanged SIRM checkpoint (exact resume).
                if options.sirm and any(_primitive(getattr(options,key)) != state['config'].get(key)
                                        for key in SIRM_CONTINUATION_FIELDS):
                    controller.no_resolution_gain=controller.no_large_changes=0
                    controller.smallest_angle_change=controller.smallest_offset_change=999.
                    controller.smallest_class_change=9999999.
                    controller.final_iteration=False
            for w in workers:w.configure(controller,options)
            if state is None:_write_iteration(options,parent,workers,controller,fsc,history,probe_rows=probe_rows,initial=True)
            checkpoint=None
            for iteration in range(controller.iteration+1,options.iterations+1):
                print('=============================',flush=True)
                start=time.perf_counter();stages={}
                controller.check_convergence(options)
                for w in workers:w.begin_iteration(controller,options)
                first=workers[0];first.activate(device,memory)
                if not (iteration==1 and options.firstiter_cc):
                    t=time.perf_counter()
                    accuracy(first.optimiser,first.optimiser.sigma2,particle_indices=probe_indices)
                    controller.acc_rot=float(first.optimiser.rotation_accuracy_deg[0]);controller.acc_trans=float(first.optimiser.translation_accuracy_angstrom[0])
                    stages['expected_accuracy']=time.perf_counter()-t
                first.park()
                controller.update_sampling(options,particle_diameter=first.optimiser.particle_diameter_angstrom,
                    n=parent.box_size,pixel=parent.pixel_size)
                for w in workers:
                    w.configure(controller,options)
                    w.optimiser.rotation_accuracy_deg.fill_(controller.acc_rot)
                    w.optimiser.translation_accuracy_angstrom.fill_(controller.acc_trans)
                from relion_torch.class3d.memory import volume_payloads
                _,bp_bytes,_=volume_payloads(parent.box_size,first.optimiser.sizes.current_size,options.padding_factor)
                host_need=bp_bytes*(3 if controller.final_iteration else 2)
                if host_need>options.backprojector_host_gib*2**30:
                    raise MemoryError(f'Two half grids and final join require {host_need/2**30:.3f} GiB of accumulator RAM; increase --backprojector-host-gib.')
                from relion_torch.relion_statistics import shell_to_angstrom
                resolution=shell_to_angstrom(parent.box_size,parent.pixel_size,controller.resolution_shell)
                print(f'Auto-refine iteration {iteration}: order={controller.order}, resolution={resolution:.4g} A, coarse={first.optimiser.sizes.coarse_size}, final={controller.final_iteration}',flush=True)
                t=time.perf_counter()
                for half_id,value,elapsed in parallel_halves([workers[h-1] for h in options.half_order],options,'expectation',iteration,device,memory):
                    stages[f'half{half_id}_expectation_and_transfer']=elapsed
                if pool is not None:stages['parallel_halves_expectation_wall']=time.perf_counter()-t
                bps=[w.packet['bps'].objects[0] for w in workers]
                current=bps[0].current_size
                masses=[float(w.packet['mass'].sum()) for w in workers]
                # Preserve independent final unfiltered maps BEFORE any optional
                # low-frequency exchange or full-data join.
                unfiltered=[]
                if controller.final_iteration or options.solvent_correct_fsc:
                    t=time.perf_counter()
                    for h,bp in enumerate(bps,1):
                        map_=(pool.reconstruct(h,bp,masses[h-1],options)['map'] if pool is not None else
                            unregularized_map(move_backprojector(bp,device),normalise=masses[h-1],preweight_iterations=options.preweight_iterations,skip_gridding=options.skip_gridding,backend=options.reconstruction_backend).cpu())
                        unfiltered.append(map_)
                        if controller.final_iteration:write_mrc(str(options.output_root)+f'_half{h}_class001_unfil.mrc',map_,pixel_size_angstrom=parent.pixel_size)
                    stages['unregularized_reconstruction']=time.perf_counter()-t
                if options.low_resol_join_halves>0:
                    join_low_resolution(*bps,options.low_resol_join_halves,parent.pixel_size,
                        parent.box_size*parent.pixel_size/controller.resolution_shell)
                t=time.perf_counter()
                diagnostics={}
                if options.solvent_correct_fsc:
                    # Reconstruct joined low frequencies if that option was used.
                    maps=unfiltered
                    if options.low_resol_join_halves>0:
                        maps=[(pool.reconstruct(j+1,bp,masses[j],options)['map'] if pool is not None else
                            unregularized_map(move_backprojector(bp,device),normalise=masses[j],preweight_iterations=options.preweight_iterations,skip_gridding=options.skip_gridding,backend=options.reconstruction_backend).cpu()) for j,bp in enumerate(bps)]
                    fsc,diagnostics=solvent_corrected_fsc(*maps,first.optimiser._solvent_mask.cpu(),current_size=current,
                        seed=options.random_seed+iteration*2)
                    fsc_method='solvent_corrected'
                elif options.do_mwtcf:
                    # workers/bps are indexed by immutable half identity, even
                    # when execution order or permanent device groups differ.
                    fsc=mwtcf_backprojector_fsc(*bps,threshold=options.mwtcf).cpu()
                    fsc_method='mwtcf_half1_weights'
                else:
                    fsc=backprojector_fsc(*bps).cpu()
                    fsc_method='ordinary'
                stages['half_fsc']=time.perf_counter()-t
                joined=merge_backprojectors(*bps) if controller.final_iteration else None
                combined=combined_statistics(parent,workers) if joined is not None else None
                changes=[]
                t=time.perf_counter()
                for half_id,value,elapsed in parallel_halves(workers,options,'maximization',iteration,fsc,device,memory):
                    changes.append(value);stages[f'half{half_id}_maximization_and_transfer']=elapsed
                if pool is not None:stages['parallel_halves_maximization_wall']=time.perf_counter()-t
                resolution_curve=first.optimiser.data_vs_prior[0]
                if joined is not None:
                    t=time.perf_counter()
                    from relion_torch.inference.permanent_workers import reconstruct_grid
                    if pool is not None:
                        final_result=pool.reconstruct(1,joined,sum(masses),options,fsc,first.optimiser.tau2[0])
                    else:
                        final_result=reconstruct_grid(joined,device,sum(masses),dict(tau2=first.optimiser.tau2[0],
                            tau2_fudge=options.tau2_fudge,preweight_iterations=options.preweight_iterations,minres_map=options.minres_map,
                            sirm=sirm_options_from_config(options,fsc=fsc),skip_gridding=options.skip_gridding,reconstruction_backend=options.reconstruction_backend),fsc)
                    combined.references=[final_result['map']]
                    for key,value in [(key,final_result[key]) for key in ('tau2','sigma2_class','data_vs_prior','fourier_coverage')]:
                        setattr(combined,key,[value.cpu()])
                    resolution_curve=combined.data_vs_prior[0]
                    combined.avg_norm_correction=sum(float(w.optimiser.norm_corrections.sum()) for w in workers)/sum(masses) if combined.do_norm else 1.
                    write_mrc(str(options.output_root)+'_class001.mrc',combined.references[0],pixel_size_angstrom=parent.pixel_size)
                    write_star({'optics':parent.optics,'particles':_particles(parent,workers)},str(options.output_root)+'_data.star')
                    stages['final_combined_reconstruction']=time.perf_counter()-t
                    del joined,final_result
                controller.observe(options,fsc=fsc.numpy(),data_vs_prior=resolution_curve.numpy(),
                    changes=changes,n=parent.box_size,pixel=parent.pixel_size,current_size=current,
                    pmax=first.optimiser.last_pmax,iteration=iteration)
                if combined is not None:
                    combined.working_psnr_shell=controller.resolution_shell
                    blocks=combined._model_blocks([str(options.output_root)+'_class001.mrc'],
                        log_likelihood=combined.last_ll,average_pmax=combined.last_pmax)
                    blocks['model_class_1']['rlnGoldStandardFsc']=fsc.numpy()
                    write_star(blocks,str(options.output_root)+'_model.star')
                    del combined
                entry=dict(iteration=iteration,controller=controller.state_dict(),current_size=current,
                    fsc_method=fsc_method,mwtcf_threshold=options.mwtcf if fsc_method=='mwtcf_half1_weights' else None,
                    coarse_size=first.optimiser.sizes.coarse_size,accuracy_probe_count=len(probe_rows),
                    resolution_angstrom=parent.box_size*parent.pixel_size/controller.resolution_shell,
                    stages_seconds=stages,elapsed_seconds=time.perf_counter()-start)
                if pool is not None:
                    entry['timing_schema_version']=4
                    entry['execution']=dict(devices=pool.devices,worker_pids=[p.pid for p in pool.processes],
                        half_groups={str(h):[pool.devices[j] for j in pool.group(h)] for h in (1,2)},
                        timing_note='half durations overlap for concurrent groups; use parallel_halves_*_wall and elapsed_seconds for wall time')
                history.append(entry)
                t=time.perf_counter()
                checkpoint=_write_iteration(options,parent,workers,controller,fsc,history,probe_rows=probe_rows)
                if diagnostics:
                    write_star({'fsc':pd.DataFrame({k:v.numpy() for k,v in diagnostics.items() if torch.is_tensor(v)})},f'{options.output_root}_it{iteration:03d}_fsc_diagnostics.star')
                stages['write_outputs_and_checkpoint']=time.perf_counter()-t
                entry['elapsed_seconds']=time.perf_counter()-start
                if options.timing:
                    with Path(str(options.output_root)+'_auto_refine_timing.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(entry)+'\n')
                print(f'  resolution={entry["resolution_angstrom"]:.4g} A; angle change={controller.angle_change:.4g} deg; offset change={controller.offset_change:.4g} A; {entry["elapsed_seconds"]:.2f}s',flush=True)
                del bps,unfiltered
                if controller.complete:break
            return dict(converged=controller.complete,iteration=controller.iteration,checkpoint=checkpoint,
                half_maps=[w.optimiser.references[0] for w in workers],fsc=fsc,history=history)
        finally:
            if pool is not None:pool.close()
            parent.close()
