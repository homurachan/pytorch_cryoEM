"""Fixed accuracy probes from RELION's initial randomized particle ordering."""
import numpy as np
from relion_torch.class2d.initialise import relion_c_random_values


def accuracy_probe_rows(particles, seed, trials, saved_rows=None):
    """Return input-row identities for the half-1 accuracy diagnostic.

    Experiment::randomiseParticlesOrder first runs at iteration 1 with seed+1.
    For half 1, reproduce the forward rand() shuffle used by GNU libstdc++'s
    std::random_shuffle, then stable-sort on optics group. The C random stream
    is shared with existing RELION compatibility functions; it can differ on
    non-Linux platforms. Do not reshuffle each iteration or mutate STAR order.
    Small synthetic datasets use all available half-1 particles, without
    borrowing particles from the other half's model.
    """
    half=np.flatnonzero(particles.rlnRandomSubset.to_numpy()==1)
    count=min(int(trials),len(half))
    if count<1:raise ValueError('Accuracy estimation requires particles in half 1')
    if saved_rows is not None:
        raw=np.asarray(saved_rows)
        if (raw.ndim!=1 or raw.dtype.kind not in 'iu' or len(raw)!=count
                or len(np.unique(raw))!=count or not np.isin(raw,half).all()):
            raise ValueError('Checkpoint accuracy probe identities are invalid')
        return raw.astype(np.int64,copy=True)
    # Native iterate() skips randomiseParticlesOrder entirely for seed zero,
    # including its optics sort. Half splitting has already grouped halves.
    if int(seed)==0:return half[:count].copy()
    order=half.copy()
    for i,draw in enumerate(relion_c_random_values(int(seed)+1,len(order)-1),1):
        j=draw%(i+1)
        order[i],order[j]=order[j],order[i]
    groups=particles.rlnOpticsGroup.to_numpy()
    order=order[np.argsort(groups[order],kind='stable')]
    return order[:count].copy()
