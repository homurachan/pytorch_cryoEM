from __future__ import annotations

from dataclasses import dataclass

import torch

from relion_torch.relion_statistics import relion_round_positive
from relion_torch.fourier.backprojector import FourierBackprojector
from relion_torch.geometry.grids import (
    rfft_frequency_coordinates_2d,
    rfft_frequency_coordinates_3d,
)


@dataclass(slots=True)
class SSNRResult:
    tau2: torch.Tensor
    sigma2: torch.Tensor
    data_vs_prior: torch.Tensor
    fourier_coverage: torch.Tensor
    counter: torch.Tensor


def _padded_shells_and_support(bp: FourierBackprojector) -> tuple[torch.Tensor, torch.Tensor]:
    p = bp.padded_size
    dtype = bp.denominator.dtype
    device = bp.denominator.device
    if bp.reference_dim == 2:
        coords = rfft_frequency_coordinates_2d(p, device=device, dtype=dtype)
    else:
        coords = rfft_frequency_coordinates_3d(p, device=device, dtype=dtype)
    radius = torch.linalg.vector_norm(coords, dim=-1)
    shells = relion_round_positive(radius / bp.padding_factor)
    assert isinstance(shells, torch.Tensor)
    # RELION uses r2 < max_r2 in updateSSNRarrays.
    support = radius.square() < float(bp.max_r2_padded)
    support &= shells <= int(bp.r_max)
    return shells, support


def update_ssnr_arrays(
    bp: FourierBackprojector,
    tau2: torch.Tensor,
    *,
    tau2_fudge: float = 1.0,
    fsc: torch.Tensor | None = None,
    update_tau2_with_fsc: bool = False,
    reconstruct_whole_map_from_fsc: bool = True,
    eps: float = 1.0e-20,
    workspace=None,
) -> SSNRResult:
    """PyTorch equivalent of RELION 3.1 BackProjector::updateSSNRarrays."""

    bp.enforce_hermitian_x0_()
    cache_key = None
    if workspace is not None:
        if workspace.bp is not bp:
            raise ValueError('Reconstruction workspace belongs to a different accumulator')
        def signature(tensor):
            if tensor is None:return None
            return (tensor.data_ptr(),tensor._version,tuple(tensor.shape),tensor.stride(),tensor.dtype,tensor.device)
        cache_key=(signature(bp.denominator),signature(tau2),signature(fsc),tau2_fudge,
                   update_tau2_with_fsc,reconstruct_whole_map_from_fsc,eps)
        if getattr(workspace,'ssnr_key',None)==cache_key:
            return workspace.ssnr_result
    def finish(result):
        if workspace is not None:
            # Own these small spectra so a recycled allocation cannot hit the cache.
            workspace.ssnr_inputs=(tau2,fsc)
            workspace.ssnr_key=cache_key
            workspace.ssnr_result=result
        return result
    n_shells = bp.original_size // 2 + 1
    dtype = bp.denominator.dtype
    device = bp.denominator.device
    tau = tau2.to(device=device, dtype=dtype).clone()
    if tau.numel() < n_shells:
        raise ValueError("tau2 spectrum is shorter than N/2+1")
    tau = tau[:n_shells]
    if not bool(torch.isfinite(tau).all()):
        raise FloatingPointError("tau2 spectrum contains NaN or Inf values")
    if bool((tau < 0).any()):
        raise ValueError("tau2 spectrum must be non-negative")

    if workspace is None:
        shells, support = _padded_shells_and_support(bp)
        idx = shells[support].reshape(-1)
        weights = bp.denominator[support].reshape(-1)
        correction = float(bp.padding_factor ** bp.reference_dim)
        weighted = weights * correction
        sums = torch.bincount(idx, weights=weighted, minlength=n_shells)[:n_shells]
        counter = torch.bincount(idx, minlength=n_shells).to(dtype)[:n_shells]
        sigma2 = torch.where(
            sums > 1.0e-10,
            counter / sums.clamp_min(torch.finfo(dtype).tiny),
            torch.zeros_like(sums),
        )
    else:
        shells=workspace.shells
        idx,weights,counter,sigma2=workspace.weight_summary(bp)
        support=workspace.mask
        correction=float(bp.padding_factor**bp.reference_dim)

    if update_tau2_with_fsc:
        if fsc is None:
            raise ValueError("FSC is required when update_tau2_with_fsc=True")
        curve = fsc.to(device=device, dtype=dtype)
        if curve.numel() < n_shells:
            raise ValueError("FSC spectrum is shorter than N/2+1")
        curve = curve[:n_shells].clamp(0.001, 0.999)
        if reconstruct_whole_map_from_fsc:
            curve = torch.sqrt((2.0 * curve / (1.0 + curve)).clamp_min(0.0)).clamp_max(0.999)
        ssnr = float(tau2_fudge) * curve / (1.0 - curve)
        tau = ssnr * sigma2
        data_vs_prior = ssnr
    else:
        shell_tau = tau[idx]
        positive_tau = shell_tau > 0.0
        invtau = torch.empty_like(weights)
        invtau[positive_tau] = 1.0 / (correction * float(tau2_fudge) * shell_tau[positive_tau])
        fallback = (weights > eps) & ~positive_tau
        invtau[fallback] = 1.0 / (0.001 * weights[fallback])
        invtau[~positive_tau & ~(weights > eps)] = torch.inf
        ratio_vals = torch.where(torch.isfinite(invtau) & (invtau > 0),
                                 weights / invtau, torch.zeros_like(weights))
        ratio_sum = torch.bincount(idx, weights=ratio_vals, minlength=n_shells)[:n_shells]
        covered = (ratio_vals >= 1.0).to(dtype)
        coverage_sum = torch.bincount(idx, weights=covered, minlength=n_shells)[:n_shells]
        active_shell = torch.arange(n_shells, device=device) <= int(bp.r_max)
        data_vs_prior = torch.where(
            ~active_shell,
            torch.zeros_like(counter),
            torch.where(
                counter > 0,
                ratio_sum / counter.clamp_min(1.0),
                torch.full_like(counter, 999.0),
            ),
        )
        fourier_coverage = torch.where(
            counter > 0,
            coverage_sum / counter.clamp_min(1.0),
            torch.zeros_like(counter),
        )
        return finish(SSNRResult(
            tau2=tau,
            sigma2=sigma2,
            data_vs_prior=data_vs_prior,
            fourier_coverage=fourier_coverage,
            counter=counter,
        ))

    shell_tau = tau[idx]
    positive = shell_tau > 0
    ratio = torch.where(positive,
        weights * correction * float(tau2_fudge) * shell_tau,
        0.001 * weights.square())
    covered = (ratio >= 1.0).to(dtype)
    coverage_sum = torch.bincount(idx, weights=covered, minlength=n_shells)[:n_shells]
    fourier_coverage = torch.where(
        counter > 0,
        coverage_sum / counter.clamp_min(1.0),
        torch.zeros_like(counter),
    )
    return finish(SSNRResult(
        tau2=tau,
        sigma2=sigma2,
        data_vs_prior=data_vs_prior,
        fourier_coverage=fourier_coverage,
        counter=counter,
    ))
