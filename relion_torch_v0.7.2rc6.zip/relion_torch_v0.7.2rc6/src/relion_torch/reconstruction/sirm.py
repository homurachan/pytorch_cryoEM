"""Shared SIRM Fourier constraints, ported from SIRM-RELION v1p1.

Runs on the compact, unshifted padded FFT *before* final windowing/gridding.
It never changes the measured numerator/denominator or the FSC/SSNR model.
"""
from dataclasses import dataclass
from pathlib import Path
import math

import torch

from relion_torch.io.mrc import read_mrc


SIRM_CONTINUATION_FIELDS = frozenset({
    'sirm', 'sirm_threshold', 'sirm_histogram', 'sirm_iterations', 'sirm_mask',
})


@dataclass(slots=True)
class SIRMOptions:
    threshold: float = 0.3
    iterations: int = 30
    histogram_threshold: float = 0.0
    mask_path: str | Path | None = None
    # Separate from the MAP FSC: supplying a SIRM weight curve does not enable MAP.
    fsc: torch.Tensor | None = None

    def validate(self):
        if not math.isfinite(self.threshold) or self.threshold <= 0:
            raise ValueError('SIRM threshold must be positive and finite')
        if not isinstance(self.iterations, int) or self.iterations < 1:
            raise ValueError('SIRM iterations must be a positive integer')
        if not math.isfinite(self.histogram_threshold) or self.histogram_threshold < 0:
            raise ValueError('SIRM histogram threshold must be nonnegative and finite')
        if self.mask_path is not None and not Path(self.mask_path).is_file():
            raise FileNotFoundError(f'SIRM real-space mask not found: {self.mask_path}')
        return self


def sirm_options_from_config(config, *, fsc=None):
    """Common entry for Class3D, half workers and joined final reconstruction."""
    if not getattr(config, 'sirm', False):
        return None
    return SIRMOptions(config.sirm_threshold, config.sirm_iterations,
                       config.sirm_histogram, config.sirm_mask, fsc).validate()


def sirm_snr_from_fsc(fsc):
    """Native SIRM calibration: 2*f/(1-f), including for independent half refs."""
    if fsc.ndim != 1 or not bool(torch.isfinite(fsc).all()):
        raise ValueError('SIRM FSC must be a finite one-dimensional spectrum')
    f = fsc.clamp(0., .998)
    snr = 2. * f / (1. - f)
    return torch.where(snr < .11, 0., snr)


def sirm_reliability(weight, radius, *, padding_factor, max_r2, snr):
    """W(k)/mean_shell(abs(W))*SNR. Count all stored voxels, including zeros."""
    if snr.ndim != 1 or not bool(torch.isfinite(snr).all()) or bool((snr < 0).any()):
        raise ValueError('SIRM SNR must be a finite nonnegative one-dimensional spectrum')
    shell = torch.floor(radius / padding_factor + .5).long()
    support = radius.square() < max_r2
    if bool((support & (shell >= snr.numel())).any()):
        raise ValueError('SIRM spectrum does not cover the reconstruction support')
    idx = shell[support]
    count = torch.bincount(idx, minlength=snr.numel()).to(weight.dtype)
    sums = torch.bincount(idx, weights=weight[support].abs(), minlength=snr.numel())
    factor = torch.where(sums > 0, snr * count / sums.clamp_min(torch.finfo(weight.dtype).tiny), 0.)
    reliability = weight * factor[shell.clamp_max(snr.numel()-1)]
    reliability.masked_fill_(~support, 0.)
    return reliability


def sirm_resolution_radius(snr, padding_factor):
    """Native inner-loop low pass (not the auto-refine convergence criterion)."""
    cutoff = 0
    # Only one small spectrum transfer, never a device sync per Fourier voxel.
    for i, value in enumerate(snr.detach().cpu().tolist()):
        if i > 10 and value < .334:
            break
        cutoff = i
    return float(cutoff) * padding_factor


def sirm_histogram_cutoff(real, threshold):
    """Native bin-frequency crossing, NOT a quantile or a percentile cutoff.

    Define coordinates for empty bins too; v1p1's uninitialised bin coordinates
    make the crossing depend on empty bins. Constant volumes have cutoff zero.
    """
    low, high = real.amin(), real.amax()
    bins = real.shape[-1]
    width = (high-low)/bins
    if float(width) <= 0:
        return 0.
    indices = torch.floor((real-low)/width + .5).long().clamp(0, bins-1)
    counts = torch.bincount(indices.flatten(), minlength=bins).to(real.dtype)
    counts *= 100./real.numel()
    centers = low + torch.arange(bins, device=real.device, dtype=real.dtype)*width
    first = torch.nonzero((centers[:-1] <= threshold) & (centers[1:] >= threshold)).flatten()
    if first.numel() == 0:
        return 0.
    frequency = counts[first[0]+1]
    crossing = torch.nonzero((centers[1:] > 0) & (counts[:-1] >= frequency) &
                             (counts[1:] <= frequency)).flatten()
    return float(centers[crossing[0]+1]) if crossing.numel() else 0.


def sirm_mask_on_compact_grid(mask, *, original_size, full_padded_size, compact_size):
    """Native pad -> Fourier resize to even -> centered crop to odd mask.

    The same origin shift is used on all axes, fixing the native odd-grid Y/Z
    one-voxel offset. The returned array is in unshifted FFT real-space order.
    """
    from relion_torch.fourier.resampling import resize_centered_map, window_centered_map
    if tuple(mask.shape) != (original_size,)*3 or not bool(torch.isfinite(mask).all()):
        raise ValueError('SIRM mask must be a finite 3D volume with the original particle box size')
    padded = window_centered_map(mask, full_padded_size)
    resized = resize_centered_map(padded, compact_size + compact_size % 2)
    compact = window_centered_map(resized, compact_size).clamp(0., 1.)
    compact.masked_fill_(compact < .001, 0.)
    return torch.fft.ifftshift(compact, dim=(-3,-2,-1))


@torch.no_grad()
def apply_sirm(fourier, raw_weight, radius, *, original_size, full_padded_size,
               padding_factor, max_r2, snr, options):
    """Fixed-count error reduction; F0 stays immutable for every inner step."""
    options.validate()
    if fourier.ndim != 3 or fourier.shape != raw_weight.shape:
        raise ValueError('SIRM requires a 3D compact RFFT numerator and matching weights')
    p = fourier.shape[0]
    shape = (p,)*3
    if fourier.shape != (p,p,p//2+1):
        raise ValueError('Invalid compact SIRM Fourier dimensions')
    snr = snr.to(device=fourier.device, dtype=fourier.real.dtype)
    if snr.ndim != 1 or not bool(torch.isfinite(snr).all()) or bool((snr < 0).any()):
        raise ValueError('SIRM SNR must be finite and nonnegative')
    snr = torch.where(snr < .11, 0., snr)
    reliability = sirm_reliability(raw_weight, radius, padding_factor=padding_factor,
                                  max_r2=max_r2, snr=snr)
    blend = (reliability / options.threshold).clamp(0., 1.).square_()
    del reliability
    lowpass = radius <= sirm_resolution_radius(snr, padding_factor)
    mask = None
    if options.mask_path is not None:
        mask = sirm_mask_on_compact_grid(read_mrc(options.mask_path,
            device=fourier.device, dtype=fourier.real.dtype), original_size=original_size,
            full_padded_size=full_padded_size, compact_size=p)
    real = torch.fft.irfftn(fourier, s=shape, norm='forward')
    hist_cutoff = 0.
    for step in range(options.iterations):
        if mask is not None:
            real.mul_(mask)
        # v1p1 recomputes initially and after iterations NER=0..19, then freezes.
        if options.histogram_threshold > .00001 and step <= 20:
            hist_cutoff = sirm_histogram_cutoff(real, options.histogram_threshold)
        real.sub_(hist_cutoff).clamp_min_(0.)
        current = torch.fft.rfftn(real, norm='forward')
        # lerp writes to the FFT workspace; no retained list of intermediate maps.
        current.real.lerp_(fourier.real, blend)
        current.imag.lerp_(fourier.imag, blend)
        if step < options.iterations-1:
            current.masked_fill_(~lowpass, 0.)
        real = torch.fft.irfftn(current, s=shape, norm='forward')
    # Native output is unconstrained: no mask, positivity or histogram after
    # the last mix. Match its final real -> Fourier transform as well.
    output = torch.fft.rfftn(real, norm='forward')
    if not bool(torch.isfinite(output).all()):
        raise FloatingPointError('Non-finite SIRM Fourier reconstruction')
    return output
