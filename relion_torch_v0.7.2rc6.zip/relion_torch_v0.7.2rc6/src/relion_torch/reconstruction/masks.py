from __future__ import annotations

import math

import torch


def soft_spherical_mask(
    shape: tuple[int, ...],
    radius_pixels: float,
    *,
    edge_width_pixels: float = 3.0,
    device: torch.device | str = "cpu",
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    ndim = len(shape)
    if ndim not in (2, 3) or len(set(shape)) != 1:
        raise ValueError("soft_spherical_mask expects equal 2-D or 3-D dimensions")
    n = shape[0]
    axes = [torch.arange(n, device=device, dtype=dtype) - float(n // 2) for _ in range(ndim)]
    grids = torch.meshgrid(*axes, indexing="ij")
    radius = torch.sqrt(sum(grid.square() for grid in grids))
    if edge_width_pixels <= 0:
        return (radius <= radius_pixels).to(dtype)
    t = ((radius - radius_pixels) / edge_width_pixels).clamp(0.0, 1.0)
    return torch.where(
        radius <= radius_pixels,
        torch.ones_like(radius),
        torch.where(
            radius >= radius_pixels + edge_width_pixels,
            torch.zeros_like(radius),
            0.5 * (1.0 + torch.cos(math.pi * t)),
        ),
    )


def zero_mask_particles(
    images: torch.Tensor,
    *,
    radius_pixels: float,
    edge_width_pixels: float = 3.0,
) -> torch.Tensor:
    n = int(images.shape[-1])
    mask = soft_spherical_mask(
        (n, n), radius_pixels, edge_width_pixels=edge_width_pixels,
        device=images.device, dtype=images.dtype,
    )
    return images * mask


def apply_real_space_mask(
    real: torch.Tensor,
    mask: torch.Tensor,
    *,
    solvent_value: float | torch.Tensor = 0.0,
) -> torch.Tensor:
    if real.shape != mask.shape:
        raise ValueError(f"Map/mask shapes differ: {real.shape} versus {mask.shape}")
    mask = mask.to(device=real.device, dtype=real.dtype).clamp(0.0, 1.0)
    solvent = torch.as_tensor(solvent_value, device=real.device, dtype=real.dtype)
    return real * mask + solvent * (1.0 - mask)
