"""RELION 3.1 half comparison, distinct from multiplicity-weighted generic FSC."""
from dataclasses import replace
import math
import torch
from relion_torch.geometry.grids import signed_fft_indices
from relion_torch.fourier.conventions import centered_rfft, centered_irfft
from relion_torch.reconstruction.reconstruct import ReconstructionOptions, reconstruct_backprojector


def move_backprojector(bp, device, *, clone=False):
    if bp.denominator.device==torch.device(device) and not clone:return bp
    def move(x):
        y=x.to(device)
        return y.clone() if clone else y
    return replace(bp, numerator_real=move(bp.numerator_real),
        numerator_imag=move(bp.numerator_imag), denominator=move(bp.denominator))


def merge_backprojectors(first, second):
    if (first.original_size,first.current_size,first.padding_factor)!=(second.original_size,second.current_size,second.padding_factor):
        raise ValueError('Cannot merge backprojectors on different grids')
    if first._point_group_enforced!=second._point_group_enforced:raise ValueError("Half symmetry mismatch")
    first.enforce_hermitian_x0_();second.enforce_hermitian_x0_()
    other=move_backprojector(second,first.denominator.device)
    return replace(first,numerator_real=first.numerator_real+other.numerator_real,
        numerator_imag=first.numerator_imag+other.numerator_imag,
        denominator=first.denominator+other.denominator,
        n_observations=first.n_observations+other.n_observations)


def downsampled_average(bp, *, return_weight=False):
    """Sum numerator/weight into rounded unpadded coordinates, then divide.

    Process one z plane at a time to avoid a full-volume int64 coordinate grid.
    Arrays here use unshifted FFT storage, unlike native centered y/z storage.
    """
    bp.enforce_hermitian_x0_()
    if bp.reference_dim!=3:raise ValueError('half comparison requires 3D backprojectors')
    dev=bp.denominator.device;p=bp.compact_size;d=2*(int(bp.r_max)+1)+1;w=d//2+1
    def rnd(x):return (x.sign()*torch.floor(x.abs()+.5)).long()
    coord=signed_fft_indices(p,device=dev).to(torch.float64)
    yz=rnd(coord/bp.padding_factor)%d
    xx=rnd(torch.arange(p//2+1,device=dev,dtype=torch.float64)/bp.padding_factor)
    real=torch.zeros(d*d*w,device=dev,dtype=bp.denominator.dtype)
    imag=torch.zeros_like(real);weight=torch.zeros_like(real)
    plane=yz[:,None]*w+xx[None,:]
    for z in range(p):
        ix=(yz[z]*d*w+plane).flatten()
        real.index_add_(0,ix,bp.numerator_real[z].flatten())
        imag.index_add_(0,ix,bp.numerator_imag[z].flatten())
        weight.index_add_(0,ix,bp.denominator[z].flatten())
    avg=torch.complex(real,imag)/weight.clamp_min(torch.finfo(weight.dtype).tiny)
    average=torch.where(weight>0,avg,0).reshape(d,d,w)
    return (average,weight.reshape(d,d,w)) if return_weight else average


def _fsc_fourier(a,b,ns,*,radius_limit=None,fix_dc=False,selection_weight=None,shell_threshold=None):
    if a.shape!=b.shape:raise ValueError('FSC shapes differ')
    n=a.shape[0];dev=a.device
    c=signed_fft_indices(n,device=dev).to(torch.float64)
    xy=c[:,None].square()+torch.arange(a.shape[-1],device=dev,dtype=torch.float64)[None,:].square()
    cross=torch.zeros(ns,device=dev,dtype=torch.float64);p1=torch.zeros_like(cross);p2=torch.zeros_like(cross)
    for z in range(n):
        r=torch.sqrt(xy+c[z].square());shell=torch.floor(r+.5).long()
        valid=shell<ns
        if radius_limit is not None:valid &= r<=radius_limit
        if selection_weight is not None:
            # Index only supported shells; do not clamp out-of-range radii
            # into the last shell. Native MWTCF uses >=, including zero weight.
            selected=selection_weight[z][valid] >= shell_threshold[shell[valid]]
            valid[valid.clone()]=selected
        ix=shell[valid];u=a[z][valid].to(torch.complex128);v=b[z][valid].to(torch.complex128)
        cross+=torch.bincount(ix,weights=(u*v.conj()).real,minlength=ns)
        p1+=torch.bincount(ix,weights=u.abs().square(),minlength=ns)
        p2+=torch.bincount(ix,weights=v.abs().square(),minlength=ns)
    den=torch.sqrt(p1*p2)
    out=torch.where(den>0,cross/den.clamp_min(1e-300),0).clamp(-1,1)
    if fix_dc:out[0]=1
    return out.to(a.real.dtype)


def backprojector_fsc(first,second):
    if (first.original_size,first.current_size,first.padding_factor)!=(second.original_size,second.current_size,second.padding_factor):
        raise ValueError('Half grids differ')
    a=downsampled_average(first);b=downsampled_average(second).to(a.device)
    return _fsc_fourier(a,b,first.original_size//2+1,radius_limit=first.r_max,fix_dc=True)


def mwtcf_backprojector_fsc(first,second,threshold=-10.):
    """SIRM-RELION MWTCF, using the *half1* raw backprojection weights.

    Downsample weights by coordinate rounding and summation, including empty
    Fourier points in each shell mean. Keep points with W >= threshold*mean|W|,
    then compute ordinary (unweighted) FSC on that set. There is no half2-weight
    test or smoothing. Call after symmetry/optional low-resolution half joining,
    just like native compareTwoHalves; solvent-corrected FSC bypasses this path.
    The reduction uses z planes to bound coordinate workspace.
    """
    if not math.isfinite(threshold):raise ValueError('MWTCF threshold must be finite')
    if (first.original_size,first.current_size,first.padding_factor)!=(second.original_size,second.current_size,second.padding_factor):
        raise ValueError('Half grids differ')
    a,weight=downsampled_average(first,return_weight=True)
    b=downsampled_average(second).to(a.device)
    ns=first.original_size//2+1;n=a.shape[0];dev=a.device
    c=signed_fft_indices(n,device=dev).to(torch.float64)
    xy=c[:,None].square()+torch.arange(a.shape[-1],device=dev,dtype=torch.float64)[None,:].square()
    total=torch.zeros(ns,device=dev,dtype=torch.float64);count=torch.zeros_like(total)
    for z in range(n):
        r=torch.sqrt(xy+c[z].square());shell=torch.floor(r+.5).long()
        valid=(r<=first.r_max)&(shell<=int(first.r_max))&(shell<ns)
        ix=shell[valid]
        total+=torch.bincount(ix,weights=weight[z][valid].abs().double(),minlength=ns)
        count+=torch.bincount(ix,minlength=ns)
    mean=total/count.clamp_min(1)
    return _fsc_fourier(a,b,ns,radius_limit=first.r_max,fix_dc=True,
        selection_weight=weight,shell_threshold=float(threshold)*mean)


def relion_map_fsc(first,second):
    return _fsc_fourier(centered_rfft(first),centered_rfft(second),first.shape[0]//2+1)


def randomize_phases_beyond(volume,shell,*,seed):
    # Native randomizes stored RFFT coefficients independently before irfft.
    ft=centered_rfft(volume);n=volume.shape[0];dev=ft.device
    generator=torch.Generator(device=dev).manual_seed(int(seed))
    phase=torch.rand(ft.shape,device=dev,dtype=ft.real.dtype,generator=generator)*(2*math.pi)
    c=signed_fft_indices(n,device=dev)
    r2=c[:,None,None].square()+c[None,:,None].square()+torch.arange(n//2+1,device=dev)[None,None,:].square()
    out=torch.where(r2>=int(shell)**2,torch.polar(ft.abs(),phase),ft)
    return centered_irfft(out,(n,n,n))


def unregularized_map(bp,*,normalise=1.,preweight_iterations=10,skip_gridding=False,backend="auto"):
    return reconstruct_backprojector(bp,ReconstructionOptions(tau2=None,fsc=None,
        normalise=normalise,preweight_iterations=preweight_iterations,skip_gridding=skip_gridding,backend=backend)).map


def solvent_corrected_fsc(first,second,mask,*,current_size,seed):
    unmasked=relion_map_fsc(first,second)
    masked=relion_map_fsc(first*mask,second*mask)
    crossings=torch.nonzero(unmasked[1:]<.8).flatten()
    random_at=int(crossings[0])+1 if len(crossings) else -1
    randomized=torch.zeros_like(masked)
    if random_at>0:
        a=randomize_phases_beyond(first,random_at,seed=seed)
        b=randomize_phases_beyond(second,random_at,seed=seed+1)
        randomized=relion_map_fsc(a*mask,b*mask)
        corrected=torch.where(randomized>masked,0.,(masked-randomized)/(1-randomized).clamp_min(1e-12))
        corrected[:random_at+2]=masked[:random_at+2]
    else:corrected=unmasked.clone()
    corrected[current_size//2+1:]=0
    return corrected,dict(unmasked=unmasked,masked=masked,random_masked=randomized,randomize_at=random_at)


def join_low_resolution(first,second,resolution,pixel,current_resolution):
    cutoff=math.ceil(first.original_size*pixel/max(resolution,current_resolution))
    if first.denominator.device!=second.denominator.device:raise ValueError('Low-resolution join requires colocated buffers')
    if first._point_group_enforced!=second._point_group_enforced:raise ValueError("Half symmetry mismatch")
    first.enforce_hermitian_x0_();second.enforce_hermitian_x0_()
    p=first.compact_size;c=signed_fft_indices(p,device=first.denominator.device)
    xy=c[:,None].square()+torch.arange(p//2+1,device=c.device)[None,:].square()
    for z in range(p):
        active=xy+c[z].square()<=round(cutoff*first.padding_factor)**2
        for name in ('numerator_real','numerator_imag','denominator'):
            a=getattr(first,name)[z];b=getattr(second,name)[z]
            avg=(a[active]+b[active])*.5;a[active]=avg;b[active]=avg
