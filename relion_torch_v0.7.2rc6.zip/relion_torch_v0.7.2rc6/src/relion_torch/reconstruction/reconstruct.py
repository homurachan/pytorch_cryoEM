from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from contextlib import nullcontext
import math

import torch

from relion_torch.relion_statistics import relion_round_positive
from relion_torch.fourier.backprojector import FourierBackprojector
from relion_torch.fourier.conventions import (
    centered_crop,
    centered_irfft,
    gridding_correct,
    relion_soft_mask_outside_map,
)
from relion_torch.geometry.grids import (
    rfft_frequency_coordinates_2d,
    rfft_frequency_coordinates_3d,
)
from relion_torch.reconstruction.ssnr import update_ssnr_arrays
from relion_torch.reconstruction.sirm import SIRMOptions, apply_sirm, sirm_snr_from_fsc
from relion_torch.reconstruction.shells import shell_average, shell_indices


@dataclass(slots=True)
class ReconstructionOptions:
    preweight_iterations: int = 10
    skip_gridding: bool = False
    tau2: torch.Tensor | None = None
    fsc: torch.Tensor | None = None
    tau2_fudge: float = 1.0
    reconstruct_whole_map_from_fsc: bool = True
    min_resol_shell: int = 0
    interpolation: str = "linear"
    blob_radius: float = 1.9
    blob_alpha: float = 15.0
    blob_order: int = 0
    mask_corners: bool = True
    corner_edge_width: float = 3.0
    normalise: float = 1.0
    eps: float = 1.0e-8
    # RELION's Pipe--Menon loop uses a hard 1e-6 floor for the
    # blob-convolved sampling weights.  This is deliberately separate from
    # ``eps``: the latter is a generic guard for direct divisions, whereas the
    # former is part of the reconstruction algorithm and materially affects
    # the growth of the iterative inverse weights.
    preweight_min_convolution: float = 1.0e-6
    # In RELION_SINGLE_PRECISION builds the double-precision iterative weight
    # is clipped immediately before it is multiplied into the single-precision
    # Fourier numerator.  Without this cap, an otherwise finite double value
    # can overflow while being cast to float32 and poison the reconstructed
    # map with Inf/NaN values.
    single_precision_preweight_cap: float = 1.0e20
    check_finite: bool = True
    sirm: SIRMOptions | None = None
    backend: str = "auto"


@dataclass(slots=True)
class ReconstructionResult:
    map: torch.Tensor
    fourier_map: torch.Tensor
    regularised_weight: torch.Tensor
    tau2: torch.Tensor | None
    sigma2: torch.Tensor
    data_vs_prior: torch.Tensor | None
    preweight: torch.Tensor


def _assert_finite(name: str, tensor: torch.Tensor) -> None:
    """Raise an informative error at the first non-finite reconstruction stage."""

    finite = torch.isfinite(tensor)
    if bool(finite.all()):
        return
    nan_count = int(torch.isnan(tensor).sum().item())
    posinf_count = int(torch.isposinf(tensor).sum().item())
    neginf_count = int(torch.isneginf(tensor).sum().item())
    raise FloatingPointError(
        f"Non-finite values in {name}: "
        f"NaN={nan_count}, +Inf={posinf_count}, -Inf={neginf_count}. "
        "This indicates an invalid weighted sum or an unstable reconstruction "
        "state; refusing to write a corrupted MRC map."
    )


def _padded_radius(bp: FourierBackprojector) -> torch.Tensor:
    p = bp.padded_size
    dtype = bp.denominator.dtype
    device = bp.denominator.device
    if bp.reference_dim == 2:
        coords = rfft_frequency_coordinates_2d(p, device=device, dtype=dtype)
    else:
        coords = rfft_frequency_coordinates_3d(p, device=device, dtype=dtype)
    return torch.linalg.vector_norm(coords, dim=-1)


def _original_shells_on_padded(bp: FourierBackprojector) -> torch.Tensor:
    shells = relion_round_positive(_padded_radius(bp) / bp.padding_factor)
    assert isinstance(shells, torch.Tensor)
    return shells


def _weight_sigma2_spectrum(bp: FourierBackprojector) -> torch.Tensor:
    # Calculate on the backprojector in its current state.  The public
    # reconstruction path Hermitian-completes first; keeping this helper free of
    # side effects also makes it usable for diagnostics and unit tests.
    radius = _padded_radius(bp)
    shells = _original_shells_on_padded(bp)
    n_shells = bp.original_size // 2 + 1
    valid = (radius.square() < float(bp.max_r2_padded)) & (
        shells <= int(bp.r_max)
    )
    idx = shells[valid].reshape(-1)
    vals = bp.denominator[valid].reshape(-1)
    correction = float(bp.padding_factor ** bp.reference_dim)
    sums = torch.bincount(idx, weights=vals * correction, minlength=n_shells)[:n_shells]
    counts = torch.bincount(idx, minlength=n_shells).to(vals.dtype)[:n_shells]
    return torch.where(
        sums > 1.0e-10,
        counts / sums.clamp_min(torch.finfo(vals.dtype).tiny),
        torch.zeros_like(sums),
    )


@lru_cache(maxsize=32)
def _relion_ft_blob_table_cpu(
    radius: float,
    alpha: float,
    order: int,
    n_table: int,
) -> tuple[torch.Tensor, float]:
    """RELION 3.1 ``TabFtBlob`` for the default order-zero blob.

    ``TabFtBlob::initialise`` samples ``kaiser_Fourier_value`` at
    ``i * (0.5 / n_table)`` and its accessor uses a truncating/floor lookup;
    it does not linearly interpolate.  Store the table normalised by its DC
    value because every use in ``BackProjector`` divides by ``tab_ftblob(0)``.
    """

    if order != 0:
        raise NotImplementedError("RELION-Torch currently implements blob order 0")
    if radius <= 0.0 or not math.isfinite(float(radius)):
        raise ValueError("blob radius must be positive and finite")
    if alpha <= 0.0 or not math.isfinite(float(alpha)):
        raise ValueError("blob alpha must be positive and finite")
    if n_table <= 0:
        raise ValueError("n_table must be positive")

    # Work in NumPy float64 so table construction has the same scalar precision
    # as RELION's CPU implementation before casting to RFLOAT for multiplication.
    import numpy as np

    sampling = 0.5 / float(n_table)
    w = np.arange(n_table, dtype=np.float64) * sampling
    scaled = (2.0 * math.pi * float(radius)) * w
    delta = float(alpha) ** 2 - scaled * scaled
    sigma = np.sqrt(np.abs(delta))

    # kaiser_Fourier_value(order=0) contains I_{3/2}(sigma)/sigma^(3/2)
    # below the alpha crossing and J_{3/2}(sigma)/sigma^(3/2) above it.
    # Use the closed-form half-integer Bessel expressions used by RELION's
    # bess{i,j}1_5 helpers.  Both branches have sqrt(2/pi)/3 as sigma -> 0.
    ratio = np.empty_like(sigma)
    small = sigma < 1.0e-7
    ratio[small] = math.sqrt(2.0 / math.pi) / 3.0

    regular = ~small
    if np.any(regular):
        x = sigma[regular]
        prefactor = np.sqrt(2.0 / (math.pi * x))
        below = scaled[regular] <= float(alpha)
        vals = np.empty_like(x)
        if np.any(below):
            xb = x[below]
            i32 = prefactor[below] * (np.cosh(xb) - np.sinh(xb) / xb)
            vals[below] = i32 / np.power(xb, 1.5)
        if np.any(~below):
            xa = x[~below]
            j32 = prefactor[~below] * (np.sin(xa) / xa - np.cos(xa))
            vals[~below] = j32 / np.power(xa, 1.5)
        ratio[regular] = vals

    # The common factor (2*pi)^(3/2) * radius^3 / I0(alpha) cancels in
    # tab_ftblob(r)/tab_ftblob(0), so omitting it avoids unnecessary dynamic
    # range while preserving RELION's exact normalised multiplier.
    ratio /= ratio[0]
    table = torch.from_numpy(np.ascontiguousarray(ratio))
    return table, sampling


def _relion_ft_blob_table(
    *,
    radius: float,
    alpha: float,
    order: int,
    device: torch.device,
    dtype: torch.dtype,
    n_table: int = 10_000,
) -> tuple[torch.Tensor, float]:
    table, sampling = _relion_ft_blob_table_cpu(
        float(radius), float(alpha), int(order), int(n_table)
    )
    return table.to(device=device, dtype=dtype), sampling

def _relion_blob_direct_axis(
    size: int,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    """Direct-index coordinates used by RELION's blob convolution.

    This intentionally mirrors ``(i < pad_size/2) ? i : i-pad_size`` from
    ``BackProjector::convoluteBlobRealSpace``.  For the odd compact grids used
    by RELION this is not identical to ``torch.fft.fftfreq`` at the middle
    element, so it must remain a dedicated coordinate helper.
    """

    index = torch.arange(size, device=device, dtype=torch.int64)
    half = size // 2
    logical = torch.where(index < half, index, index - size)
    return logical.to(dtype=dtype)


def _multiply_blob_ft_inplace(
    real_unshifted: torch.Tensor,
    *,
    table: torch.Tensor,
    sampling: float,
    physical_period: float,
) -> None:
    """Multiply by RELION's tabulated blob FT on the compact FFT domain.

    The FFT domain is ``pad_size`` (for example 75), whereas the physical
    coordinate denominator is always ``ori_size * padding_factor`` (for
    example 512).  Conflating those two sizes changes the Pipe--Menon
    correction by a large factor.
    """

    ndim = real_unshifted.ndim
    if ndim not in (2, 3):
        raise ValueError("Blob convolution expects a 2-D or 3-D compact array")
    compact_size = int(real_unshifted.shape[-1])
    if any(int(v) != compact_size for v in real_unshifted.shape):
        raise ValueError("Blob convolution expects equal compact dimensions")
    if table.device != real_unshifted.device or table.dtype != real_unshifted.dtype:
        raise ValueError("Blob table device/dtype must match the real-space array")
    if physical_period <= 0.0 or not math.isfinite(float(physical_period)):
        raise ValueError("physical_period must be positive and finite")

    if sampling <= 0.0 or not math.isfinite(float(sampling)):
        raise ValueError("blob table sampling must be positive and finite")
    axis = _relion_blob_direct_axis(
        compact_size, device=real_unshifted.device, dtype=real_unshifted.dtype
    )

    def lookup(q: torch.Tensor) -> torch.Tensor:
        # C++ casts the non-negative quotient to int, i.e. truncates/floors.
        index = torch.floor(torch.abs(q) / float(sampling)).to(torch.int64)
        valid = index < table.numel()
        safe = index.clamp(0, table.numel() - 1)
        return torch.where(valid, table[safe], torch.zeros_like(q))

    if ndim == 2:
        yy, xx = torch.meshgrid(axis, axis, indexing="ij")
        q = torch.sqrt(xx.square() + yy.square()) / float(physical_period)
        real_unshifted.mul_(lookup(q))
        return

    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    xy2 = xx.square() + yy.square()
    for z0 in range(0, compact_size, 8):
        z1 = min(z0 + 8, compact_size)
        zz = axis[z0:z1, None, None]
        q = torch.sqrt(xy2[None, :, :] + zz.square()) / float(physical_period)
        real_unshifted[z0:z1].mul_(lookup(q))


def _convolute_blob_real_space(
    fourier: torch.Tensor,
    *,
    ndim: int,
    table: torch.Tensor,
    sampling: float,
    physical_period: float,
    workspace=None, backend="auto",
) -> torch.Tensor:
    """RELION compact-domain blob convolution used by Pipe--Menon."""

    compact_size = int(fourier.shape[-2]) if ndim == 2 else int(fourier.shape[-3])
    dims = tuple(range(fourier.ndim - ndim, fourier.ndim))
    # RELION applies the blob on the direct, uncentred inverse-FFT array.
    real = torch.fft.irfftn(
        fourier, s=(compact_size,) * ndim, dim=dims, norm="forward"
    )
    if workspace is None:
        _multiply_blob_ft_inplace(real, table=table, sampling=sampling, physical_period=physical_period)
    else:
        workspace.apply(real,table=table,sampling=sampling,physical_period=physical_period,backend=backend)
    return torch.fft.rfftn(real, dim=dims, norm="forward")


def _compact_to_full_padded_fourier(
    bp: FourierBackprojector,
    compact: torch.Tensor,
    *,
    z_chunk_size: int = 8,
) -> torch.Tensor:
    """RELION ``windowFourierTransform`` from compact to full padded RFFT.

    Frequencies are copied by identical integer logical coordinates.  There is
    no interpolation and, crucially, no every-``padding_factor`` Fourier
    decimation.  Frequencies outside ``max_r2`` remain zero.
    """

    compact_size = bp.compact_size
    full_size = bp.full_padded_size
    expected = (
        (compact_size, compact_size // 2 + 1)
        if bp.reference_dim == 2
        else (compact_size, compact_size, compact_size // 2 + 1)
    )
    if tuple(compact.shape) != expected:
        raise ValueError(
            f"Expected compact Fourier shape {expected}, got {tuple(compact.shape)}"
        )
    target_shape = (
        (full_size, full_size // 2 + 1)
        if bp.reference_dim == 2
        else (full_size, full_size, full_size // 2 + 1)
    )
    full = torch.zeros(target_shape, device=compact.device, dtype=compact.dtype)
    full_flat = full.reshape(-1)
    nx_full = full_size // 2 + 1
    coord_dtype = compact.real.dtype

    if bp.reference_dim == 2:
        coords = rfft_frequency_coordinates_2d(
            compact_size, device=compact.device, dtype=coord_dtype, flatten=True
        )
        x = coords[:, 0].to(torch.int64)
        y = coords[:, 1].to(torch.int64)
        r2 = coords.square().sum(dim=-1)
        valid = r2 < float(bp.max_r2_padded)
        valid &= x <= full_size // 2
        # The strict spherical support excludes the even-grid Nyquist
        # ambiguity; these bounds guard malformed/custom states.
        valid &= (y > -(full_size // 2)) & (y <= full_size // 2)
        target_y = torch.remainder(y[valid], full_size)
        linear = target_y * nx_full + x[valid]
        full_flat.index_copy_(0, linear, compact.reshape(-1)[valid])
        return full

    kx = torch.arange(
        compact_size // 2 + 1, device=compact.device, dtype=coord_dtype
    )
    ky = torch.fft.fftfreq(
        compact_size, d=1.0 / compact_size, device=compact.device, dtype=coord_dtype
    )
    kz = ky
    source = compact
    for z0 in range(0, compact_size, max(1, int(z_chunk_size))):
        z1 = min(z0 + max(1, int(z_chunk_size)), compact_size)
        zz, yy, xx = torch.meshgrid(kz[z0:z1], ky, kx, indexing="ij")
        r2 = xx.square() + yy.square() + zz.square()
        valid = r2 < float(bp.max_r2_padded)
        valid &= xx <= full_size // 2
        valid &= (yy > -(full_size // 2)) & (yy <= full_size // 2)
        valid &= (zz > -(full_size // 2)) & (zz <= full_size // 2)
        # Empty index_copy is safe; avoid one host/GPU synchronization per slab.
        xi = xx[valid].to(torch.int64)
        yi = torch.remainder(yy[valid].to(torch.int64), full_size)
        zi = torch.remainder(zz[valid].to(torch.int64), full_size)
        linear = (zi * full_size + yi) * nx_full + xi
        full_flat.index_copy_(0, linear, source[z0:z1].reshape(-1)[valid.reshape(-1)])
    return full


def _window_to_original_real_space(
    bp: FourierBackprojector,
    compact_fourier: torch.Tensor,
    *,
    mask_corners: bool,
    corner_edge_width: float,
    interpolation: str,
) -> tuple[torch.Tensor, torch.Tensor]:
    """RELION 3.1 ``windowToOridimRealSpace`` and gridding correction."""

    full_fourier = _compact_to_full_padded_fourier(bp, compact_fourier)
    full_size = bp.full_padded_size
    padded_real = centered_irfft(
        full_fourier, (full_size,) * bp.reference_dim, ndim=bp.reference_dim
    )
    real = centered_crop(
        padded_real, bp.original_size, ndim=bp.reference_dim
    ).contiguous()

    # All input particle Fourier transforms are normalised as ori_size^2 2-D
    # transforms.  These are the exact branches in RELION's
    # windowToOridimRealSpace for data_dim == 2.
    if bp.reference_dim == 2:
        normfft = bp.padding_factor**2
    else:
        normfft = bp.padding_factor**3 * bp.original_size
    real = real / float(normfft)

    if mask_corners:
        real = relion_soft_mask_outside_map(
            real,
            radius_pixels=-1.0,
            cosine_width_pixels=corner_edge_width,
            ndim=bp.reference_dim,
        )
    real = gridding_correct(
        real,
        padding_factor=bp.padding_factor,
        interpolation=interpolation,
        ndim=bp.reference_dim,
    )
    return real, full_fourier


def reconstruct_backprojector(
    bp: FourierBackprojector,
    options: ReconstructionOptions | None = None,
    *, workspace=None, timer=None,
) -> ReconstructionResult:
    """Reconstruct a map from a (possibly point-group symmetrised) Fourier sum."""

    if options is None:
        options = ReconstructionOptions()
    if options.blob_order != 0:
        raise NotImplementedError("This milestone implements RELION's default blob order 0")
    if options.normalise <= 0 or not math.isfinite(float(options.normalise)):
        raise ValueError("normalise must be positive and finite")
    if (
        options.preweight_min_convolution <= 0
        or not math.isfinite(float(options.preweight_min_convolution))
    ):
        raise ValueError("preweight_min_convolution must be positive and finite")
    if (
        options.single_precision_preweight_cap <= 0
        or not math.isfinite(float(options.single_precision_preweight_cap))
    ):
        raise ValueError("single_precision_preweight_cap must be positive and finite")

    if options.sirm is not None:
        options.sirm.validate()
        if bp.reference_dim != 3:
            raise ValueError("SIRM reconstruction requires 3D output")
    section=lambda name: timer.section(name,full=True) if timer is not None else nullcontext()
    with section('reconstruction.prepare_ssnr'):
        bp.enforce_hermitian_x0_()
        from .workspace import ReconstructionWorkspace, BlobWorkspace
        if workspace is None:workspace=ReconstructionWorkspace(bp)
        elif workspace.bp is not bp:raise ValueError("Workspace belongs to another accumulator")
        numerator = bp.numerator  # property already allocates private complex storage
        weight = bp.denominator.clone()
        if options.check_finite:
            _assert_finite("backprojector numerator.real", numerator.real)
            _assert_finite("backprojector numerator.imag", numerator.imag)
            _assert_finite("backprojector denominator", weight)
        if bool((weight < 0).any()):
            minimum = float(weight.min().item())
            raise FloatingPointError(
                f"Backprojector denominator contains negative weights (minimum={minimum:.9g})"
            )
        n_shells = bp.original_size // 2 + 1
        dummy_tau = torch.ones(n_shells, device=weight.device, dtype=weight.dtype)
    
        tau2 = options.tau2
        tau2_was_derived_from_fsc = False
        if tau2 is not None:
            tau2 = tau2.to(device=weight.device, dtype=weight.dtype)
            if tau2.numel() < n_shells:
                raise ValueError("tau2 spectrum is shorter than N/2+1")
            tau2 = tau2[:n_shells]
            if options.check_finite:
                _assert_finite("tau2 spectrum", tau2)
            if bool((tau2 < 0).any()):
                minimum = float(tau2.min().item())
                raise FloatingPointError(
                    f"tau2 spectrum contains negative values (minimum={minimum:.9g})"
                )
            ssnr = update_ssnr_arrays(
                bp,
                tau2,
                tau2_fudge=options.tau2_fudge,workspace=workspace,
            )
        elif options.fsc is not None:
            ssnr = update_ssnr_arrays(
                bp,
                dummy_tau,
                tau2_fudge=options.tau2_fudge,
                fsc=options.fsc,
                update_tau2_with_fsc=True,
                reconstruct_whole_map_from_fsc=options.reconstruct_whole_map_from_fsc,workspace=workspace,
            )
            tau2 = ssnr.tau2
            tau2_was_derived_from_fsc = True
        else:
            ssnr = update_ssnr_arrays(bp, dummy_tau,workspace=workspace)

    sigma2 = ssnr.sigma2
    data_vs_prior: torch.Tensor | None = None if tau2 is None else ssnr.data_vs_prior

    radius = workspace.radius
    support = workspace.support

    if tau2 is not None:
        shells = workspace.shells
        valid = support & (shells >= int(options.min_resol_shell)) & (shells < tau2.numel())
        shell_tau = tau2[shells.clamp(0, tau2.numel() - 1)]
        oversampling = float(bp.padding_factor ** bp.reference_dim)
        prior_fudge = float(options.tau2_fudge)
        # RELION treats every strictly positive tau2 as a valid prior.  Using
        # the generic 1e-8 epsilon here incorrectly classified physically valid
        # small high-resolution tau2 values as zero and triggered the fallback
        # regulariser over a much larger region than the original program.
        positive_tau = shell_tau > 0.0
        invtau = torch.zeros_like(weight)
        invtau[valid & positive_tau] = 1.0 / (
            oversampling * prior_fudge * shell_tau[valid & positive_tau]
        )
        # RELION's zero-tau fallback keeps an occupied Fourier voxel finite.
        fallback = valid & ~positive_tau & (weight > 1.0e-20)
        invtau[fallback] = 1.0 / (0.001 * weight[fallback])
        weight = weight + invtau
        if options.check_finite:
            _assert_finite("MAP-regularised denominator", weight)
        del shells, valid, shell_tau, positive_tau, invtau, fallback

    workspace.release_statistics()

    # Every BackProjector is tied to the iteration's current_size.  RELION uses
    # max_r2 = ROUND((current_size/2) * padding_factor)^2 throughout SSNR,
    # Pipe--Menon preweighting and reconstruction.  Extending this support to
    # the original-box Nyquist sphere makes the unsampled outer region divide
    # by the convolution floor repeatedly and eventually yields Inf/NaN.
    support = workspace.support
    with section('reconstruction.preweight'):
        if options.skip_gridding or options.preweight_iterations <= 0:
            # RELION's direct path floors each denominator at one-thousandth of the
            # radial mean weight for the corresponding original-box shell.
            radial_shells = torch.floor(radius / bp.padding_factor).to(torch.int64)
            max_shell = max(1, int(bp.r_max))
            flat_shells = radial_shells.reshape(-1)
            flat_weight = weight.reshape(-1)
            radial_valid = (flat_shells < max_shell) & support.reshape(-1)
            shell_idx = flat_shells[radial_valid]
            shell_weight = flat_weight[radial_valid]
            sums = torch.bincount(shell_idx, weights=shell_weight, minlength=max_shell + 1)
            counts = torch.bincount(shell_idx, minlength=max_shell + 1).to(weight.dtype)
            means = torch.where(counts > 0, sums / counts.clamp_min(1.0), torch.zeros_like(sums))
            radial_floor = means / 1000.0
            clipped = radial_shells.clamp(0, radial_floor.numel() - 1)
            floor_grid = radial_floor[clipped].clamp_min(options.eps)
            safe_weight = torch.maximum(weight, floor_grid)
            padded_map = torch.where(support, numerator / safe_weight, torch.zeros_like(numerator))
            preweight = torch.where(support, 1.0 / safe_weight, torch.zeros_like(weight))
            regularised_weight = weight
        else:
            # BackProjector::reconstruct divides both data and regularised weights by
            # the class posterior mass before the Pipe--Menon preweighting loop.
            work_weight = weight / float(options.normalise)
            work_numerator = numerator / float(options.normalise)
            del weight, numerator
            # RELION always stores Fnewweight in double precision, even when data,
            # Fweight and FFTs use single precision.  Sparse or highly anisotropic
            # 3-D sampling can make these inverse weights extremely large; keeping
            # them in float32 causes deterministic overflow after only a few
            # Pipe--Menon iterations.
            preweight = torch.where(
                support,
                torch.ones_like(work_weight, dtype=torch.float64),
                torch.zeros_like(work_weight, dtype=torch.float64),
            )
            blob_table, blob_sampling = _relion_ft_blob_table(
                radius=options.blob_radius * 2.0,
                alpha=options.blob_alpha,
                order=options.blob_order,
                device=work_weight.device,
                dtype=work_weight.dtype,
            )
            blob_workspace=BlobWorkspace(bp.compact_size,bp.reference_dim,blob_table,blob_sampling,float(bp.original_size)*bp.padding_factor)
            finite_flags=[]
            weighted64=torch.empty_like(preweight)
            conv_input=torch.zeros_like(work_numerator)
            min_convolution = float(options.preweight_min_convolution)
            for iteration in range(int(options.preweight_iterations)):
                # The convolution itself follows the RFLOAT precision of RELION's
                # Fconv.  Only the recursively updated inverse sampling weight is
                # retained in float64.
                torch.mul(preweight,work_weight,out=weighted64)
                conv_input.real.copy_(weighted64)
                weighted=conv_input.real
                if options.check_finite:
                    finite_flags.append((f"Pipe-Menon weighted sampling grid at iteration {iteration + 1}",torch.isfinite(weighted).all()))
                conv = _convolute_blob_real_space(
                    conv_input,
                    ndim=bp.reference_dim,
                    table=blob_table,
                    sampling=blob_sampling,
                    physical_period=float(bp.original_size) * bp.padding_factor,workspace=blob_workspace,backend=options.backend,
                ).abs()
                if options.check_finite:
                    finite_flags.append((f"Pipe-Menon convolved sampling grid at iteration {iteration + 1}",torch.isfinite(conv).all()))
                weighted64.copy_(conv).clamp_min_(min_convolution)
                preweight.div_(weighted64).masked_fill_(~support,0)
                if options.check_finite:
                    finite_flags.append((f"Pipe-Menon inverse weight at iteration {iteration + 1}",torch.isfinite(preweight).all()))
    
            if finite_flags:
                # One readback for all scalar checks; never retain old volume tensors.
                flags=torch.stack([value for _,value in finite_flags]).cpu().tolist()
                for (name,_),valid in zip(finite_flags,flags):
                    if not valid:raise FloatingPointError('Non-finite values in '+name)
            del blob_workspace,weighted64,conv_input,weighted,conv
    
            # RELION_SINGLE_PRECISION caps the double Fnewweight at 1e20 immediately
            # before multiplying it into the RFLOAT Fourier numerator.  Mirror that
            # behaviour exactly for complex64/float32 reconstructions.  Returning
            # the uncapped float64 preweight remains useful for diagnostics.
            applied_preweight = preweight
            if work_numerator.real.dtype == torch.float32:
                applied_preweight = applied_preweight.clamp_max(
                    float(options.single_precision_preweight_cap)
                )
            applied_preweight = applied_preweight.to(dtype=work_numerator.real.dtype)
            # Mask before multiplication as well as after it.  This avoids 0*Inf
            # semantics if a future numerical regression produces an extreme value
            # outside the active support.
            applied_preweight = torch.where(
                support, applied_preweight, torch.zeros_like(applied_preweight)
            )
            padded_map = torch.where(
                support,
                work_numerator * applied_preweight,
                torch.zeros_like(work_numerator),
            )
            regularised_weight = work_weight
            del work_numerator, applied_preweight

    if options.check_finite:
        _assert_finite("preweighted padded Fourier map", padded_map.real)
        _assert_finite("preweighted padded Fourier map", padded_map.imag)

    if options.sirm is not None:
        curve = options.sirm.fsc if options.sirm.fsc is not None else options.fsc
        if curve is not None:
            if curve.numel() != n_shells:
                raise ValueError("SIRM FSC must contain exactly original_size/2+1 shells")
            sirm_snr = sirm_snr_from_fsc(curve)
        elif tau2 is not None:
            # Class3D has no independent half FSC: use each class's own SSNR.
            sirm_snr = ssnr.data_vs_prior
        else:
            raise ValueError("SIRM needs an FSC weight curve, tau2 prior, or split random halves")
        padded_map = apply_sirm(padded_map, bp.denominator, radius,
            original_size=bp.original_size, full_padded_size=bp.full_padded_size,
            padding_factor=bp.padding_factor, max_r2=bp.max_r2_padded,
            snr=sirm_snr, options=options.sirm)

    with section('reconstruction.final_window_fft'):
        real_map, full_padded_fourier = _window_to_original_real_space(
            bp,
            padded_map,
            mask_corners=options.mask_corners,
            corner_edge_width=options.corner_edge_width,
            interpolation=options.interpolation,
        )
    if options.check_finite:
        _assert_finite("full padded Fourier reconstruction", full_padded_fourier.real)
        _assert_finite("full padded Fourier reconstruction", full_padded_fourier.imag)
        _assert_finite("final real-space reconstruction", real_map)
    # Keep the compact preweighted Fourier representation in the result.  The
    # full p*N grid is only a transient required by RELION's final padded IFFT;
    # retaining it for every class would consume hundreds of MiB per result at
    # common box sizes.
    return ReconstructionResult(
        map=real_map,
        fourier_map=padded_map,
        regularised_weight=regularised_weight,
        tau2=tau2,
        sigma2=sigma2,
        data_vs_prior=data_vs_prior,
        preweight=preweight,
    )
