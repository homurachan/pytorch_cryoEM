"""Private-output kernels: no retry can duplicate a live additive update."""
import importlib.util
import warnings
import torch

_disabled=set()
_validated=set()


def _ready(tensor, mode, key):
    if mode not in ('auto','off','required'):raise ValueError('Invalid volume backend')
    if mode=='off':return False
    ready=(tensor.device.type=='cuda' and tensor.dtype==torch.float32 and tensor.is_contiguous()
           and key not in _disabled and importlib.util.find_spec('triton') is not None)
    if not ready and mode=='required':raise RuntimeError(key+' requires CUDA FP32 and Triton')
    return ready


def _failed(key,mode,exc):
    if isinstance(exc,(torch.cuda.OutOfMemoryError,MemoryError)) or mode=='required':raise exc
    _disabled.add(key)
    warnings.warn(key+' preflight failed; using reference path: '+str(exc),RuntimeWarning)


def symmetry(bp, ops, *, group, mode='auto'):
    if not _ready(bp.denominator,mode,'symmetry'):return None
    sources=(bp.numerator_real,bp.numerator_imag,bp.denominator)
    if any(x.dtype!=torch.float32 or not x.is_contiguous() for x in sources):
        if mode=='required':raise RuntimeError('Symmetry needs contiguous FP32 grids')
        return None
    try:
        from .volume_kernels import symmetry_kernel
        import triton
        key=('symmetry',str(bp.denominator.device),group)
        if key not in _validated:
            from relion_torch.fourier.backprojector import FourierBackprojector
            from relion_torch.fourier.symmetry import _symmetrise_reference_
            check=FourierBackprojector.create(4,device=bp.denominator.device)
            g=torch.Generator(device=bp.denominator.device).manual_seed(514)
            for t in (check.numerator_real,check.numerator_imag,check.denominator):
                t.copy_(torch.rand(t.shape,device=t.device,generator=g))
            check.enforce_hermitian_x0_()
            cc=(check.numerator_real,check.numerator_imag,check.denominator)
            oo=[torch.empty_like(t) for t in cc]
            mm=torch.tensor(ops.copy(),device=cc[0].device,dtype=torch.float32)
            symmetry_kernel[(triton.cdiv(cc[0].numel(),128),)](*cc,mm,*oo,cc[0].numel(),P=check.compact_size,R2=check.max_r2_padded,NOPS=len(mm),BLOCK=128,enable_fp_fusion=False)
            _symmetrise_reference_(check,group)
            for a,b in zip(oo,cc):torch.testing.assert_close(a,b,rtol=4e-5,atol=3e-5)
            _validated.add(key)
        matrices=torch.tensor(ops.copy(),device=sources[0].device,dtype=torch.float32)
        out=[torch.empty_like(t) for t in sources]
        n=sources[0].numel()
        symmetry_kernel[(triton.cdiv(n,128),)](*sources,matrices,*out,n,P=bp.compact_size,R2=bp.max_r2_padded,NOPS=len(ops),BLOCK=128,enable_fp_fusion=False)
        return out
    except Exception as exc:
        _failed('symmetry',mode,exc)
        return None


def multiply_blob(real,table,sampling,period,*,mode='auto'):
    if not _ready(real,mode,'blob'):return False
    try:
        from .volume_kernels import blob_kernel
        import triton
        p=real.shape[-1];n=real.numel()
        meta=dict(P=p,NDIM=real.ndim,PERIOD=period,STEP=sampling,NT=len(table),BLOCK=256,enable_fp_fusion=False)
        key=('blob',str(real.device))
        if key not in _validated:
            from .reconstruct import _multiply_blob_ft_inplace
            ref=torch.ones((11,)*real.ndim,device=real.device)
            out=torch.empty_like(ref)
            blob_kernel[(triton.cdiv(ref.numel(),256),)](ref,table,out,ref.numel(),**dict(meta,P=11))
            _multiply_blob_ft_inplace(ref,table=table,sampling=sampling,physical_period=period)
            torch.testing.assert_close(out,ref,rtol=2e-5,atol=2e-6)
            _validated.add(key)
        blob_kernel.warmup(real,table,real,n,grid=(triton.cdiv(n,256),),**meta)
    except Exception as exc:
        _failed('blob',mode,exc)
        return False
    # In-place only after preflight; never replay a possibly partial multiply.
    blob_kernel[(triton.cdiv(n,256),)](real,table,real,n,**meta)
    return True
