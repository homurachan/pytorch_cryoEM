from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from relion_torch.fourier.backprojector import FourierBackprojector
from relion_torch.fourier.conventions import centered_rfft, fourier_shift_2d
from relion_torch.geometry.euler import relion_euler_matrix_2d
from relion_torch.io.mrc import read_mrc, write_mrc
from relion_torch.io.particles import ParticleDataset
from relion_torch.io.star import read_relion_star, write_spectrum_star
from relion_torch.optics.ctf import compute_ctf
from relion_torch.optics.observation import ObservationModel
from relion_torch.reconstruction.fsc import fourier_shell_correlation
from relion_torch.reconstruction.masks import apply_real_space_mask, zero_mask_particles
from relion_torch.reconstruction.reconstruct import (
    ReconstructionOptions,
    ReconstructionResult,
    reconstruct_backprojector,
)


@dataclass(slots=True)
class StandaloneReconstructionConfig:
    input_star: str | Path
    output_root: str | Path
    device: str = "cpu"
    dtype: torch.dtype = torch.float32
    batch_size: int = 8
    reference_dim: int = 3
    padding_factor: float = 2.0
    use_ctf: bool = True
    fom_weighting: bool = False
    split_random_halves: bool = False
    random_seed: int = 0
    subset: int | None = None
    class_number: int | None = None
    max_resolution_angstrom: float | None = None
    particle_diameter_angstrom: float | None = None
    zero_mask: bool = False
    mask_path: str | Path | None = None
    solvent_flatten: bool = False
    write_debug: bool = False
    reconstruction_options: ReconstructionOptions | None = None
    symmetry: str = "C1"
    symmetry_backend: str = "auto"
    gridding_backend: str = "auto"


@dataclass(slots=True)
class StandaloneReconstructionOutput:
    combined: ReconstructionResult
    half1: ReconstructionResult | None
    half2: ReconstructionResult | None
    fsc: torch.Tensor | None
    output_files: dict[str, Path]


def _make_backprojector(config: StandaloneReconstructionConfig, n: int) -> FourierBackprojector:
    return FourierBackprojector.create(
        n,
        padding_factor=config.padding_factor,
        reference_dim=config.reference_dim,
        device=config.device,
        dtype=config.dtype,
        interpolation="linear",
    )


def _ensure_random_subsets(dataset: ParticleDataset, seed: int) -> None:
    if "rlnRandomSubset" in dataset.table.columns:
        values = pd.to_numeric(dataset.table["rlnRandomSubset"], errors="coerce")
        if values.notna().all() and set(int(v) for v in values.unique()).issubset({1, 2}):
            return
    rng = np.random.default_rng(seed)
    subset = np.ones(len(dataset), dtype=np.int64)
    subset[len(dataset) // 2 :] = 2
    rng.shuffle(subset)
    dataset.table["rlnRandomSubset"] = subset


def _frequency_resolution_mask(
    n: int,
    pixel_size: float,
    max_resolution_angstrom: float | None,
    *,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor | None:
    if max_resolution_angstrom is None or max_resolution_angstrom <= 0:
        return None
    from relion_torch.geometry.grids import radial_frequency_pixels_2d

    max_shell = n * pixel_size / max_resolution_angstrom
    radius = radial_frequency_pixels_2d(n, device=device, dtype=dtype)
    return (radius <= max_shell).to(dtype)


def _write_debug_arrays(
    root: Path,
    name: str,
    bp: FourierBackprojector,
    pixel_size: float,
) -> dict[str, Path]:
    outputs: dict[str, Path] = {}
    for suffix, array in (
        ("data_real", bp.numerator_real),
        ("data_imag", bp.numerator_imag),
        ("weight", bp.denominator),
    ):
        path = root.parent / f"{root.name}_{name}_{suffix}.mrc"
        outputs[f"{name}_{suffix}"] = write_mrc(path, array, pixel_size_angstrom=pixel_size)
    return outputs


def _apply_output_mask(
    result: ReconstructionResult,
    *,
    mask: torch.Tensor | None,
    solvent_flatten: bool,
) -> ReconstructionResult:
    if mask is None:
        return result
    outside = 0.0
    if not solvent_flatten:
        # Explicit masks in reconstruction are conventionally solvent-flattening
        # masks; this branch is retained for a soft multiplication-only request.
        outside = 0.0
    result.map = apply_real_space_mask(result.map, mask, solvent_value=outside)
    return result


def run_standalone_reconstruction(
    config: StandaloneReconstructionConfig,
) -> StandaloneReconstructionOutput:
    if config.reference_dim not in (2, 3):
        raise ValueError("reference_dim must be 2 or 3")
    if config.batch_size < 1:
        raise ValueError("batch_size must be >=1")
    from relion_torch.geometry.symmetry import normalize_symmetry
    from relion_torch.fourier.symmetry import symmetrise_backprojector_
    symmetry = normalize_symmetry(config.symmetry)
    if config.reference_dim != 3 and symmetry != 'C1':
        raise ValueError('Point-group reconstruction requires 3D output')
    options = config.reconstruction_options or ReconstructionOptions()
    if options.sirm is not None:
        options.sirm.validate()
        if config.reference_dim != 3:
            raise ValueError('SIRM reconstruction requires 3D output')
        if options.sirm.fsc is None and options.fsc is None and options.tau2 is None and not config.split_random_halves:
            raise ValueError('SIRM needs --SIRM_weight_star / --fsc, --tau2, or --split-random-halves')
    device = torch.device(config.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(f"CUDA device {device} requested but CUDA is unavailable")

    input_star = read_relion_star(config.input_star, require_single_optics=False)
    dataset = ParticleDataset(
        input_star,
        subset=config.subset,
        class_number=config.class_number,
        require_single_optics=False,
    )
    if config.split_random_halves:
        _ensure_random_subsets(dataset, config.random_seed)
    n = dataset.box_size
    optical_labels = ('rlnBeamTiltX', 'rlnBeamTiltY', 'rlnOddZernike', 'rlnEvenZernike',
                      'rlnMagMat00', 'rlnMagMat01', 'rlnMagMat10', 'rlnMagMat11', 'rlnMtfFileName')
    needs_model = (len(input_star.optics) > 1 or any(label in input_star.optics for label in optical_labels)
                   or any(label in dataset.table for label in ('rlnCtfBfactor', 'rlnCtfScalefactor', 'rlnSphericalAberration')))
    observation_model = None
    if needs_model and config.use_ctf:
        if config.reference_dim != 3:
            dataset.close()
            raise NotImplementedError('Full optical corrections in standalone reconstruction currently require 3D output')
        optics = input_star.optics.copy()
        if 'rlnImageSize' not in optics:
            optics['rlnImageSize'] = n
        if 'rlnImagePixelSize' not in optics:
            optics['rlnImagePixelSize'] = dataset.pixel_size
        observation_model = ObservationModel(optics, source_dir=input_star.source_dir, device=device, dtype=config.dtype)
        if any(int(g.row.get('rlnCtfDataAreCtfPremultiplied', 0)) for g in observation_model.groups.values()):
            dataset.close()
            raise NotImplementedError('Full optical reconstruction currently requires non-CTF-premultiplied particles')
    bp_all = _make_backprojector(config, n)
    bp_half1 = _make_backprojector(config, n) if config.split_random_halves else None
    bp_half2 = _make_backprojector(config, n) if config.split_random_halves else None
    resolution_mask = _frequency_resolution_mask(
        n,
        dataset.pixel_size,
        config.max_resolution_angstrom,
        device=device,
        dtype=config.dtype,
    )

    try:
        for batch in dataset.iter_batches(
            config.batch_size,
            device=device,
            dtype=config.dtype,
            shuffle=False,
        ):
            images = batch.images
            if config.zero_mask:
                if config.particle_diameter_angstrom is None:
                    raise ValueError("--zero-mask requires --particle-diameter")
                radius = config.particle_diameter_angstrom / (2.0 * dataset.pixel_size)
                images = zero_mask_particles(images, radius_pixels=radius)
            fourier = centered_rfft(images, ndim=2)
            fourier = fourier_shift_2d(fourier, batch.origins_pixels, sign=-1.0)
            fourier[..., 0, 0] = 0.0
            if config.use_ctf:
                ctf = compute_ctf(
                    n,
                    dataset.pixel_size,
                    batch.ctf_parameters,
                    device=device,
                    dtype=config.dtype,
                )
            else:
                ctf = torch.ones_like(fourier.real)
            if resolution_mask is not None:
                fourier = fourier * resolution_mask
                ctf = ctf * resolution_mask
            fom = batch.fom if config.fom_weighting else torch.ones_like(batch.fom)
            numerator_images = fourier * ctf * fom[:, None, None]
            denominator_images = ctf.square() * fom[:, None, None]
            if config.reference_dim == 2:
                rotations = relion_euler_matrix_2d(
                    batch.euler_degrees[:, 2], device=device, dtype=config.dtype
                )
            else:
                rotations = batch.rotations
            if observation_model is not None:
                rows = dataset.table.iloc[batch.row_indices]
                group_ids = np.asarray(rows.rlnOpticsGroup, dtype=int)
                for group_id in np.unique(group_ids):
                    selected = np.flatnonzero(group_ids == group_id)
                    selection = torch.as_tensor(selected, device=device)
                    nr, dn = observation_model.reconstruction_terms(fourier[selection], rows.iloc[selected], int(group_id))
                    if resolution_mask is not None:
                        nr, dn = nr*resolution_mask, dn*resolution_mask
                    numerator_images[selection] = nr*fom[selection, None, None]
                    denominator_images[selection] = dn*fom[selection, None, None]
                    rotations[selection] = observation_model.reconstruction_rotations(
                        batch.rotations[selection], int(group_id), n, dataset.pixel_size)
            bp_all.accumulate(
                numerator_images,
                rotations,
                denominator_images,
                observation_weights=fom, fusion_mode=config.gridding_backend,
            )
            if config.split_random_halves:
                assert bp_half1 is not None and bp_half2 is not None
                sel1 = batch.random_subset == 1
                sel2 = batch.random_subset == 2
                if torch.any(sel1):
                    bp_half1.accumulate(
                        numerator_images[sel1], rotations[sel1], denominator_images[sel1],
                        observation_weights=fom[sel1], fusion_mode=config.gridding_backend,
                    )
                if torch.any(sel2):
                    bp_half2.accumulate(
                        numerator_images[sel2], rotations[sel2], denominator_images[sel2],
                        observation_weights=fom[sel2], fusion_mode=config.gridding_backend,
                    )
    finally:
        dataset.close()

    for bp in (bp_all, bp_half1, bp_half2):
        if bp is not None:
            symmetrise_backprojector_(bp, symmetry, backend=config.symmetry_backend)
    half1_result: ReconstructionResult | None = None
    half2_result: ReconstructionResult | None = None
    fsc: torch.Tensor | None = None
    if config.split_random_halves:
        assert bp_half1 is not None and bp_half2 is not None
        # Independent unfiltered maps and their FSC never use SIRM constraints.
        half_options = replace(options, tau2=None, fsc=None, sirm=None)
        half1_result = reconstruct_backprojector(bp_half1, half_options)
        half2_result = reconstruct_backprojector(bp_half2, half_options)
        fsc = fourier_shell_correlation(half1_result.map, half2_result.map)
        if options.tau2 is None and options.fsc is None:
            options = replace(options, fsc=fsc)
        if options.sirm is not None and options.sirm.fsc is None:
            curve = options.fsc if options.fsc is not None else fsc
            options = replace(options, sirm=replace(options.sirm, fsc=curve))
    combined = reconstruct_backprojector(bp_all, options)

    mask: torch.Tensor | None = None
    if config.mask_path is not None:
        mask = read_mrc(config.mask_path, device=device, dtype=config.dtype)
        expected = (n,) * config.reference_dim
        if tuple(mask.shape) != expected:
            raise ValueError(f"Mask shape {tuple(mask.shape)} differs from output shape {expected}")
        combined = _apply_output_mask(combined, mask=mask, solvent_flatten=config.solvent_flatten)
        if half1_result is not None:
            half1_result = _apply_output_mask(half1_result, mask=mask, solvent_flatten=config.solvent_flatten)
        if half2_result is not None:
            half2_result = _apply_output_mask(half2_result, mask=mask, solvent_flatten=config.solvent_flatten)

    root = Path(config.output_root).expanduser().resolve()
    root.parent.mkdir(parents=True, exist_ok=True)
    output_files: dict[str, Path] = {}
    output_files["combined"] = write_mrc(
        root.parent / f"{root.name}_class001.mrc", combined.map,
        pixel_size_angstrom=dataset.pixel_size,
    )
    if half1_result is not None and half2_result is not None:
        output_files["half1"] = write_mrc(
            root.parent / f"{root.name}_half1_class001_unfil.mrc",
            half1_result.map,
            pixel_size_angstrom=dataset.pixel_size,
        )
        output_files["half2"] = write_mrc(
            root.parent / f"{root.name}_half2_class001_unfil.mrc",
            half2_result.map,
            pixel_size_angstrom=dataset.pixel_size,
        )
    if fsc is not None:
        shell = np.arange(fsc.numel())
        resolution = shell / (n * dataset.pixel_size)
        angstrom = np.full_like(resolution, np.inf, dtype=np.float64)
        angstrom[1:] = 1.0 / resolution[1:]
        output_files["fsc"] = write_spectrum_star(
            root.parent / f"{root.name}_fsc.star",
            {
                "rlnSpectralIndex": shell,
                "rlnResolution": resolution,
                "rlnAngstromResolution": angstrom,
                "rlnFourierShellCorrelation": fsc.detach().cpu().numpy(),
            },
            block_name="fsc",
        )
    if config.write_debug:
        output_files.update(_write_debug_arrays(root, "all", bp_all, dataset.pixel_size))
        if bp_half1 is not None and bp_half2 is not None:
            output_files.update(_write_debug_arrays(root, "half1", bp_half1, dataset.pixel_size))
            output_files.update(_write_debug_arrays(root, "half2", bp_half2, dataset.pixel_size))

    return StandaloneReconstructionOutput(
        combined=combined,
        half1=half1_result,
        half2=half2_result,
        fsc=fsc,
        output_files=output_files,
    )
