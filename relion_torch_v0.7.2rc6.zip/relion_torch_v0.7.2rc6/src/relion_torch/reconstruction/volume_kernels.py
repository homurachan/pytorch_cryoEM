"""Bounded Fourier symmetry gather and invariant blob geometry kernels."""
import triton
import triton.language as tl


@triton.jit
def symmetry_kernel(R, I, W, OPS, OR, OI, OW, N,
                    P: tl.constexpr, R2: tl.constexpr, NOPS: tl.constexpr, BLOCK: tl.constexpr):
    pos = tl.program_id(0).to(tl.int64)*BLOCK+tl.arange(0, BLOCK)
    ok = pos < N
    width: tl.constexpr = P//2+1
    x = (pos % width).to(tl.float32)
    iy, iz = (pos//width)%P, pos//(width*P)
    y = tl.where(iy<=P//2, iy, iy-P).to(tl.float32)
    z = tl.where(iz<=P//2, iz, iz-P).to(tl.float32)
    active = ok & ((x*x+y*y+z*z)<=R2)
    ar, ai, aw = tl.load(R+pos,ok,0), tl.load(I+pos,ok,0), tl.load(W+pos,ok,0)
    for op in range(1, NOPS):
        m = OPS+op*9
        xx = x*tl.load(m)+y*tl.load(m+1)+z*tl.load(m+2)
        yy = x*tl.load(m+3)+y*tl.load(m+4)+z*tl.load(m+5)
        zz = x*tl.load(m+6)+y*tl.load(m+7)+z*tl.load(m+8)
        neg = xx<0
        xx, yy, zz = tl.where(neg,-xx,xx), tl.where(neg,-yy,yy), tl.where(neg,-zz,zz)
        fx, fy, fz = tl.floor(xx), tl.floor(yy), tl.floor(zz)
        dx, dy, dz = xx-fx, yy-fy, zz-fz
        sr, si, sw = tl.full((BLOCK,),0,tl.float32), tl.full((BLOCK,),0,tl.float32), tl.full((BLOCK,),0,tl.float32)
        for bx in tl.static_range(2):
            for by in tl.static_range(2):
                for bz in tl.static_range(2):
                    jx, jy, jz = fx.to(tl.int64)+bx, fy.to(tl.int64)+by, fz.to(tl.int64)+bz
                    valid = active & (jx>=0)&(jx<width)&(tl.abs(jy)<=P//2)&(tl.abs(jz)<=P//2)
                    weight = tl.where(bx==1,dx,1-dx)*tl.where(by==1,dy,1-dy)*tl.where(bz==1,dz,1-dz)
                    key = (((jz+P)%P)*P+(jy+P)%P)*width+jx
                    sr += tl.load(R+key,valid,0)*weight
                    si += tl.load(I+key,valid,0)*weight
                    sw += tl.load(W+key,valid,0)*weight
        ar += sr
        ai += tl.where(neg,-si,si)
        aw += sw
    tl.store(OR+pos,ar,ok); tl.store(OI+pos,ai,ok); tl.store(OW+pos,aw,ok)


@triton.jit
def blob_kernel(X, TABLE, OUT, N, P: tl.constexpr, NDIM: tl.constexpr,
                PERIOD: tl.constexpr, STEP: tl.constexpr, NT: tl.constexpr, BLOCK: tl.constexpr):
    i=tl.program_id(0).to(tl.int64)*BLOCK+tl.arange(0,BLOCK)
    ok=i<N
    ix,iy=i%P,(i//P)%P
    x=tl.where(ix<P//2,ix,ix-P).to(tl.float32)
    y=tl.where(iy<P//2,iy,iy-P).to(tl.float32)
    r2=x*x+y*y
    if NDIM==3:
        iz=i//(P*P)
        z=tl.where(iz<P//2,iz,iz-P).to(tl.float32)
        r2=r2+z*z
    # Correctly rounded sqrt/divide preserve the table's floor boundaries.
    q=tl.div_rn(tl.sqrt_rn(r2),PERIOD)
    index=tl.floor(tl.div_rn(tl.abs(q),STEP)).to(tl.int64)
    value=tl.load(TABLE+index,ok&(index<NT),0)
    tl.store(OUT+i,tl.load(X+i,ok,0)*value,ok)
