from __future__ import annotations

from functools import lru_cache

import torch

from relion_torch.geometry.grids import (
    radial_frequency_pixels_2d,
    radial_frequency_pixels_3d,
    rfft_multiplicity,
)


def shell_indices(n: int, ndim: int, *, device: torch.device | str, dtype: torch.dtype = torch.float32) -> torch.Tensor:
    if ndim == 2:
        radius = radial_frequency_pixels_2d(n, device=device, dtype=dtype)
    elif ndim == 3:
        radius = radial_frequency_pixels_3d(n, device=device, dtype=dtype)
    else:
        raise ValueError("ndim must be 2 or 3")
    return torch.floor(radius + 0.5).to(torch.int64)


def shell_sum(
    values: torch.Tensor,
    *,
    n: int,
    ndim: int,
    multiplicity: bool = True,
    max_shell: int | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Sum real values over rounded Fourier shells and return sums/counts."""

    if max_shell is None:
        max_shell = n // 2
    idx = shell_indices(n, ndim, device=values.device, dtype=values.dtype).reshape(-1)
    flat = values.reshape(-1)
    valid = idx <= max_shell
    idx = idx[valid]
    flat = flat[valid]
    if multiplicity:
        mult = rfft_multiplicity(n, ndim, device=values.device, dtype=values.dtype).reshape(-1)[valid]
    else:
        mult = torch.ones_like(flat)
    sums = torch.bincount(idx, weights=flat * mult, minlength=max_shell + 1)
    counts = torch.bincount(idx, weights=mult, minlength=max_shell + 1)
    return sums[: max_shell + 1], counts[: max_shell + 1]


def shell_average(
    values: torch.Tensor,
    *,
    n: int,
    ndim: int,
    multiplicity: bool = True,
    max_shell: int | None = None,
    eps: float = 1.0e-12,
) -> torch.Tensor:
    sums, counts = shell_sum(
        values,
        n=n,
        ndim=ndim,
        multiplicity=multiplicity,
        max_shell=max_shell,
    )
    return sums / counts.clamp_min(eps)


def expand_shell_spectrum(
    spectrum: torch.Tensor,
    *,
    n: int,
    ndim: int,
    scale_coordinates: float = 1.0,
    output_shape: tuple[int, ...] | None = None,
) -> torch.Tensor:
    """Expand a 1-D original-box shell spectrum onto an RFFT grid.

    ``scale_coordinates`` converts output-grid pixel coordinates to original-box
    shell coordinates; a padded grid uses ``1/padding_factor``.
    """

    if output_shape is None:
        output_n = n
    else:
        output_n = int(output_shape[-2]) if ndim == 2 else int(output_shape[-3])
    idx = shell_indices(output_n, ndim, device=spectrum.device, dtype=spectrum.dtype)
    idx = torch.round(idx.to(spectrum.dtype) * float(scale_coordinates)).to(torch.int64)
    valid = idx < spectrum.numel()
    clipped = idx.clamp(0, spectrum.numel() - 1)
    expanded = spectrum[clipped]
    return torch.where(valid, expanded, torch.zeros_like(expanded))
