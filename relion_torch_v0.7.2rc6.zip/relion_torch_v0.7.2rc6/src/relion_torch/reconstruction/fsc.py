from __future__ import annotations

import torch

from relion_torch.fourier.conventions import centered_rfft
from relion_torch.geometry.grids import rfft_multiplicity
from relion_torch.reconstruction.shells import shell_indices


def _as_fourier(value: torch.Tensor) -> tuple[torch.Tensor, int, int]:
    if value.is_complex():
        ndim = value.ndim
        n = int(value.shape[-2]) if ndim == 2 else int(value.shape[-3])
        return value, n, ndim
    ndim = value.ndim
    if ndim not in (2, 3):
        raise ValueError("Expected a 2-D image or 3-D volume")
    n = int(value.shape[-1])
    return centered_rfft(value, ndim=ndim), n, ndim


def fourier_shell_correlation(
    first: torch.Tensor,
    second: torch.Tensor,
    *,
    eps: float = 1.0e-20,
) -> torch.Tensor:
    """Calculate an RFFT-multiplicity-corrected FSC curve.

    RELION explicitly fixes the zero-frequency shell to one.  This also avoids
    an undefined 0/0 result for mean-subtracted maps.
    """

    f1, n1, ndim1 = _as_fourier(first)
    f2, n2, ndim2 = _as_fourier(second)
    if n1 != n2 or ndim1 != ndim2 or f1.shape != f2.shape:
        raise ValueError("FSC inputs must have matching dimensions")
    n, ndim = n1, ndim1
    max_shell = n // 2
    idx = shell_indices(n, ndim, device=f1.device, dtype=f1.real.dtype).reshape(-1)
    valid = idx <= max_shell
    idx = idx[valid]
    mult = rfft_multiplicity(n, ndim, device=f1.device, dtype=f1.real.dtype).reshape(-1)[valid]
    cross = (f1 * f2.conj()).real.reshape(-1)[valid]
    p1 = f1.abs().square().reshape(-1)[valid]
    p2 = f2.abs().square().reshape(-1)[valid]
    numerator = torch.bincount(idx, weights=cross * mult, minlength=max_shell + 1)
    den1 = torch.bincount(idx, weights=p1 * mult, minlength=max_shell + 1)
    den2 = torch.bincount(idx, weights=p2 * mult, minlength=max_shell + 1)
    fsc = numerator / torch.sqrt((den1 * den2).clamp_min(eps))
    fsc = torch.clamp(fsc[: max_shell + 1], -1.0, 1.0)
    if fsc.numel():
        fsc = fsc.clone()
        fsc[0] = 1.0
    return fsc


def radial_power_spectrum(value: torch.Tensor, *, eps: float = 0.0) -> torch.Tensor:
    fourier, n, ndim = _as_fourier(value)
    max_shell = n // 2
    idx = shell_indices(n, ndim, device=fourier.device, dtype=fourier.real.dtype).reshape(-1)
    valid = idx <= max_shell
    idx = idx[valid]
    mult = rfft_multiplicity(n, ndim, device=fourier.device, dtype=fourier.real.dtype).reshape(-1)[valid]
    power = fourier.abs().square().reshape(-1)[valid]
    sums = torch.bincount(idx, weights=power * mult, minlength=max_shell + 1)
    counts = torch.bincount(idx, weights=mult, minlength=max_shell + 1)
    return sums[: max_shell + 1] / counts[: max_shell + 1].clamp_min(max(eps, 1.0e-20))


def fsc_to_tau2(
    fsc: torch.Tensor,
    sigma2: torch.Tensor,
    *,
    tau2_fudge: float = 1.0,
    reconstruct_whole_map: bool = True,
) -> torch.Tensor:
    """Convert a gold-standard half-map FSC to RELION's tau² spectrum.

    For a whole-data reconstruction RELION first converts the correlation of
    two independent half maps to the corresponding full-map correlation::

        FSC_full = sqrt(2 * FSC_half / (1 + FSC_half))

    It then uses ``SSNR = FSC_full/(1-FSC_full)`` and
    ``tau2 = tau2_fudge * SSNR * sigma2``.  Set
    ``reconstruct_whole_map=False`` only when the supplied FSC already describes
    the reconstruction being regularised.
    """

    if fsc.shape != sigma2.shape:
        raise ValueError("fsc and sigma2 spectra must have matching shape")
    safe = fsc.clamp_min(0.001)
    if reconstruct_whole_map:
        safe = torch.sqrt((2.0 * safe / (safe + 1.0)).clamp_min(0.0))
    safe = safe.clamp_max(0.999)
    ssnr = safe / (1.0 - safe)
    return torch.clamp(ssnr * sigma2 * float(tau2_fudge), min=1.0e-20)
