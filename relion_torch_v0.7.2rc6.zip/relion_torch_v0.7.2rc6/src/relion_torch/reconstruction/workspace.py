"""Call-scoped geometry and weight statistics, never retained in a checkpoint."""
import torch


class ReconstructionWorkspace:
    def __init__(self, bp):
        from .reconstruct import _padded_radius
        from relion_torch.relion_statistics import relion_round_positive
        bp.enforce_hermitian_x0_()
        self.bp = bp
        self.radius = _padded_radius(bp)
        self.shells = relion_round_positive(self.radius / bp.padding_factor)
        self.support = self.radius.square() < float(bp.max_r2_padded)
        mask = self.support & (self.shells <= int(bp.r_max))
        self.mask = mask
        self.indices = self.shells[mask].reshape(-1)
        self.counts = torch.bincount(self.indices, minlength=bp.original_size//2+1).to(bp.denominator.dtype)
        self._weights = None
        self._version = None

    def weight_summary(self, bp):
        if bp is not self.bp:
            raise ValueError('Reconstruction workspace belongs to a different accumulator')
        if self.indices is None:
            self.mask = self.support & (self.shells <= int(bp.r_max))
            self.indices = self.shells[self.mask].reshape(-1)
        signature = (bp.denominator.data_ptr(), bp.denominator._version)
        if self._version != signature:
            n = bp.original_size//2+1
            weights = bp.denominator[self.mask].reshape(-1)
            sums = torch.bincount(self.indices, weights=weights*float(bp.padding_factor**bp.reference_dim), minlength=n)[:n]
            counts = self.counts[:n]
            sigma = torch.where(sums>1.e-10, counts/sums.clamp_min(torch.finfo(weights.dtype).tiny), torch.zeros_like(sums))
            self._weights = weights, sigma
            self._version = signature
        return self.indices, self._weights[0], self.counts[:bp.original_size//2+1], self._weights[1]

    def release_statistics(self):
        """Drop gathered voxel arrays before allocating FFT workspaces."""
        self.mask = self.indices = self._weights = self._version = None
        self.ssnr_key = self.ssnr_inputs = self.ssnr_result = None


class BlobWorkspace:
    """Cache the invariant multiplier only when its whole volume fits 32 MiB."""
    def __init__(self, size, ndim, table, sampling, physical_period, budget=32*2**20):
        self.multiplier = None
        if size**ndim * table.element_size() <= budget:
            from .reconstruct import _multiply_blob_ft_inplace
            self.multiplier = torch.ones((size,)*ndim, device=table.device, dtype=table.dtype)
            _multiply_blob_ft_inplace(self.multiplier, table=table, sampling=sampling, physical_period=physical_period)

    def apply(self, real, *, table, sampling, physical_period, backend='auto'):
        if self.multiplier is not None:
            real.mul_(self.multiplier)
            return
        from .volume_fusion import multiply_blob
        if multiply_blob(real, table, sampling, physical_period, mode=backend):
            return
        from .reconstruct import _multiply_blob_ft_inplace
        _multiply_blob_ft_inplace(real, table=table, sampling=sampling, physical_period=physical_period)
