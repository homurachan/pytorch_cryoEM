"""Bounded, batched device readback of particle output metadata."""
import numpy as np
import torch


class DeferredParticleMetadata:
    columns=('rlnClassNumber','rlnAngleRot','rlnAngleTilt','rlnAnglePsi',
        'rlnOriginXAngst','rlnOriginYAngst','rlnLogLikeliContribution',
        'rlnMaxValueProbDistribution','rlnNrOfSignificantSamples')
    def __init__(self,frame,device,counts,capacity=4096):
        self.frame=frame;self.counts=counts;self.capacity=capacity;self.used=0
        self.rows=np.empty(capacity,dtype=np.int64)
        self.values=torch.empty((capacity,9),device=device,dtype=torch.float64)
        self.dll=self.pmax=0.
    def append(self,rows,best,angles,origin,result):
        values=torch.cat(((best+1)[:,None].double(),angles.double(),origin.double(),
            result.log_likelihood_contribution[:,None].double(),result.pmax[:,None].double(),
            result.significant_count[:,None].double()),1)
        for start in range(0,len(rows),self.capacity):
            stop=min(len(rows),start+self.capacity);n=stop-start
            if self.used+n>self.capacity:self.flush()
            self.rows[self.used:self.used+n]=rows[start:stop]
            self.values[self.used:self.used+n].copy_(values[start:stop]);self.used+=n
    def flush(self):
        if not self.used:return
        data=self.values[:self.used].cpu().numpy()
        rows=self.rows[:self.used]
        for j,col in enumerate(self.columns):self.frame.loc[rows,col]=data[:,j]
        self.dll+=float(data[:,6].sum());self.pmax+=float(data[:,7].sum())
        self.counts['metadata_readback_batches']=self.counts.get('metadata_readback_batches',0)+1
        self.counts['metadata_readback_bytes']=self.counts.get('metadata_readback_bytes',0)+data.nbytes
        self.used=0
