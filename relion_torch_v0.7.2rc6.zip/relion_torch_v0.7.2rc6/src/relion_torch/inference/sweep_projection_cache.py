"""Exact projection reuse for repeated global sweeps larger than GPU storage.

Device slots retain a fixed prefix, instead of evicting the previous sweep's
tail on every pass. An optional bounded, pinned host bank retains the remaining
full complex64 planes. It is scoped to the same reference/sampling generation
as its owning expectation engine; it is not an image or disk cache.
"""
import ctypes
import os
from pathlib import Path
import numpy as np
import torch
from .indexed_projection_cache import IndexedProjectionStore


def available_host_memory():
    """Conservative best-effort available/total RAM, without optional packages."""
    try:
        if os.name == 'nt':
            class Status(ctypes.Structure):
                _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [
                    (name, ctypes.c_ulonglong) for name in ('total', 'available',
                    'page_total', 'page_available', 'virtual_total', 'virtual_available', 'extended')]
            state = Status(); state.length = ctypes.sizeof(state)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
                return int(state.available), int(state.total)
        else:
            values = {}
            for line in Path('/proc/meminfo').read_text().splitlines():
                key, value = line.split(':', 1)
                if key in ('MemAvailable', 'MemTotal'):
                    values[key] = int(value.split()[0])*1024
            if len(values) == 2:return values['MemAvailable'], values['MemTotal']
    except (OSError, ValueError, AttributeError):
        pass
    return None


class SweepProjectionStore(IndexedProjectionStore):
    """Stable GPU prefix, plus full-plane host backing when it fits its budget.

    Host capacity is independent of the GPU cache cap. Zero GPU retention also
    disables host retention. Failed/unsafe host allocation falls back to fixed
    device retention, preserving every requested orientation and pixel.
    """
    def __init__(self, *args, host_max_bytes=0, **kwargs):
        super().__init__(*args, **kwargs)
        self.host_values = None
        self.host_ready = None
        self.host_bytes = 0
        self._count('second_chance', -1)
        self._count('fixed_prefix', 1)
        limit = max(0, int(host_max_bytes))
        self._count('host_budget_bytes', limit)
        # The device prefix is already permanent; do not duplicate it in RAM.
        needed = (self.total_rows-self.capacity)*int(np.prod(self.shape[2:]))*self.element_size()
        if (not limit or needed > limit or self.cache.max_bytes == 0 or
                self.device.type != 'cuda' or self.full_bank):
            return
        memory = available_host_memory()
        if memory is None or needed > memory[0]-max(2**30, memory[1]//10):
            self._count('host_headroom_rejections')
            return
        try:
            self.host_values = torch.empty((self.total_rows-self.capacity, *self.shape[2:]),
                                           dtype=self.dtype, device='cpu', pin_memory=True)
        except (MemoryError, RuntimeError):
            self._count('host_allocation_failures')
            return
        self.host_ready = np.zeros(self.total_rows, dtype=bool)
        self.host_bytes = needed
        self._count('host_bytes', needed)
        self._count('host_pinned', 1)

    def release_storage(self):
        super().release_storage()
        self.host_values = self.host_ready = None
        self.host_bytes = 0

    def _write(self, keys, value):
        if self.full_bank:return super()._write(keys, value)
        if not self.capacity:return
        keep = np.flatnonzero(keys < self.capacity)
        if not len(keep):return
        retained = keys[keep]
        self.values.index_copy_(0, self._device_ids(retained),
                                value.index_select(0, self._device_ids(keep)))
        self.slots.assign(retained, retained)

    @staticmethod
    def _contiguous(keys):
        return len(keys) == 1 or np.all(np.diff(keys) == 1)

    def _save_host(self, keys, value):
        # Complete D2H before publishing ready flags; subsequent requests may
        # read these pages on the host or another CUDA stream.
        keep = np.flatnonzero(keys >= self.capacity)
        if not len(keep):return
        if len(keep) != len(keys):value = value.index_select(0, self._device_ids(keep))
        keys = keys[keep]
        host_keys = keys-self.capacity
        if self._contiguous(host_keys):
            self.host_values[int(host_keys[0]):int(host_keys[-1])+1].copy_(value, non_blocking=False)
        else:
            self.host_values.index_copy_(0, torch.as_tensor(host_keys), value.cpu())
        self.host_ready[keys] = True
        self._count('device_to_host_bytes', value.numel()*value.element_size())

    def _load_host(self, keys):
        keys = keys-self.capacity
        if self._contiguous(keys):
            source = self.host_values[int(keys[0]):int(keys[-1])+1]
        else:
            source = self.host_values.index_select(0, torch.as_tensor(keys))
        value = source.to(self.device, non_blocking=source.is_pinned())
        self._count('host_to_device_bytes', value.numel()*value.element_size())
        self._count('host_transfers')
        return value

    def _gather_host(self, c, host, active, active_indices=None):
        if self.host_values is None:
            return super()._gather_host(c, host, active, active_indices)
        if not 0 <= c < self.shape[0] or np.any((host < 0) | (host >= self.shape[1])):
            raise IndexError('Projection class/orientation outside global sampling grid')
        indices = self.active_indices if active_indices is None else active_indices
        tail = (indices.numel(),) if active else self.shape[2:]
        if not len(host):return torch.empty((0, *tail), device=self.device, dtype=self.dtype)
        if len(host) == 1 or np.all(host[1:] > host[:-1]):
            unique, inverse = host, None
        else:
            unique, inverse = np.unique(host, return_inverse=True)
        keys = c*self.shape[1]+unique
        slots = self.slots.lookup(keys)
        hit = slots >= 0
        self.cache.hits += int(hit.sum());self.cache.misses += int((~hit).sum())
        self._count('hits', hit.sum());self._count('misses', (~hit).sum())
        if hit.all():return self._select(slots if inverse is None else slots[inverse], active, indices)
        out = torch.empty((len(unique), *tail), device=self.device, dtype=self.dtype)
        positions = np.flatnonzero(hit)
        if len(positions):out.index_copy_(0, self._device_ids(positions), self._select(slots[positions], active, indices))
        ready = self.host_ready[keys]
        positions = np.flatnonzero(~hit & ready)
        if len(positions):
            value = self._load_host(keys[positions])
            pixels = value.flatten(-2).index_select(-1, indices) if active else value
            out.index_copy_(0, self._device_ids(positions), pixels)
            self._count('host_hits', len(positions))
            del value, pixels
        missing = np.flatnonzero(~hit & ~ready)
        for first in range(0, len(missing), self.fallback.max_chunk):
            positions = missing[first:first+self.fallback.max_chunk]
            ids = unique[positions]
            value = (self.fallback.project_host(c, ids) if hasattr(self.fallback, 'project_host') else
                     self.fallback.project(c, self._device_ids(ids)))
            if value.ndim == 2:value = value[None]
            self._save_host(keys[positions], value)
            self._write(keys[positions], value)
            pixels = value.flatten(-2).index_select(-1, indices) if active else value
            out.index_copy_(0, self._device_ids(positions), pixels)
            self.calls += 1
            self._count('fill_batches');self._count('projected_rows', len(positions))
        return out if inverse is None else out.index_select(0, self._device_ids(inverse))
