"""Byte-bounded projection storage shared by SPA classification/refinement.

Resident banks and the row LRU share ONE payload budget. Resident allocations
are pinned until the model/sampling owner clears the cache. Oversized banks use
the caller's lazy store without changing the projection or sampling formula.
"""
from collections import OrderedDict
import numpy as np
import torch


class ProjectionCache:
    def __init__(self, max_bytes):
        self.max_bytes = max(0, int(max_bytes))
        self.bytes = self.peak = 0
        self.hits = self.misses = self.evictions = 0
        self.items = OrderedDict()
        self.resident = {}

    def get(self, key):
        if key not in self.items:
            self.misses += 1
            return None
        self.hits += 1
        self.items.move_to_end(key)
        return self.items[key]

    def _make_room(self, size):
        pinned = sum(x.numel() * x.element_size() for x in self.resident.values())
        if pinned + size > self.max_bytes:
            return False
        while self.items and self.bytes + size > self.max_bytes:
            _, old = self.items.popitem(last=False)
            self.bytes -= old.numel() * old.element_size()
            self.evictions += 1
        return True

    def put(self, key, tensor):
        size = tensor.numel() * tensor.element_size()
        if key in self.items:
            old = self.items.pop(key)
            self.bytes -= old.numel() * old.element_size()
        if not self._make_room(size):
            return
        self.items[key] = tensor.clone()
        self.bytes += size
        self.peak = max(self.peak, self.bytes)

    def reserve(self, key, shape, *, device, dtype):
        if key in self.resident:
            return self.resident[key]
        size = int(np.prod(shape)) * torch.empty((), dtype=dtype).element_size()
        if not self._make_room(size):
            return None
        value = torch.empty(shape, device=device, dtype=dtype)
        self.resident[key] = value
        self.bytes += size
        self.peak = max(self.peak, self.bytes)
        return value

    def clear(self):
        self.items.clear()
        self.resident.clear()
        self.bytes = 0


class ContiguousProjectionStore:
    """Lazy-filled contiguous coarse bank, with an optional active-pixel bank.

    A sequential score request needs no GPU-to-host index copy, unique, Python
    row lookup, stack or index-select when its active bank fits. Only requested
    classes are projected (including single-class initialization). The owner
    must discard this store when its source generation changes.
    """
    def __init__(self, fallback, active_indices, *, key, cache_active=True):
        self.fallback = fallback
        self.shape = fallback.shape
        self.device, self.dtype = fallback.device, fallback.dtype
        self.active_indices = active_indices
        self.chunk = fallback.max_chunk
        self.cache = fallback.cache
        self.values = self.cache.reserve((key, 'full'), self.shape,
                                         device=self.device, dtype=self.dtype)
        self.active_values = None
        if self.values is not None and cache_active:
            self.active_values = self.cache.reserve(
                (key, 'active'), (*self.shape[:2], active_indices.numel()),
                device=self.device, dtype=self.dtype)
        self.ready = np.zeros((self.shape[0], (self.shape[1] + self.chunk - 1) // self.chunk), dtype=bool)
        self.calls = 0

    def release_storage(self):
        """Drop owned payloads as well as the cache registry's references."""
        self.values = self.active_values = None
        self.ready.fill(False)

    def element_size(self):
        return self.fallback.element_size()

    def _ensure(self, c, blocks):
        for block in blocks:
            block = int(block)
            if self.ready[c, block]:
                continue
            start = block * self.chunk
            stop = min(start + self.chunk, self.shape[1])
            value = self.fallback.project(c, slice(start, stop))
            if value.ndim == 2:
                value = value[None]
            self.values[c, start:stop].copy_(value)
            if self.active_values is not None:
                self.active_values[c, start:stop].copy_(value.flatten(-2).index_select(-1, self.active_indices))
            self.ready[c, block] = True
            self.cache.misses += stop - start
            self.calls += 1

    def slice_active(self, c, start, stop, active):
        if self.values is None:
            return self.fallback.slice_active(c, start, stop, active)
        blocks = range(start // self.chunk, (stop + self.chunk - 1) // self.chunk)
        missing_rows = sum(max(0, min(stop, (q+1)*self.chunk)-max(start, q*self.chunk))
                           for q in blocks if not self.ready[c, q])
        self.cache.hits += stop - start - missing_rows
        self._ensure(c, blocks)
        if self.active_values is not None and active is self.active_indices:
            return self.active_values[c, start:stop]
        return self.values[c, start:stop].flatten(-2).index_select(-1, active)

    def gather(self, c, ids):
        if self.values is None:
            return self.fallback.gather(c, ids)
        ids = torch.as_tensor(ids, device=self.device, dtype=torch.long).reshape(-1)
        # Arbitrary gathers are used in statistics, not the hot coarse sweep.
        host = ids.detach().cpu().numpy()
        blocks = np.unique(host // self.chunk)
        self.cache.hits += int(self.ready[c, host // self.chunk].sum())
        self._ensure(c, blocks)
        return self.values[c].index_select(0, ids)


# Public compatibility import; implementation is shared with future SPA users.
from .indexed_projection_cache import IndexedProjectionStore
