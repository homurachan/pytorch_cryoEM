"""Execution-only SPA tile/cache planning; never reduces candidate support."""
MIB = 1024 ** 2


def projection_chunk_rows(size, work_bytes, preferred=64):
    # Interpolation holds coordinate, corner, index and complex temporaries.
    # Keep this sub-workspace bounded even for a large user memory allowance.
    budget = max(1, min(int(work_bytes) // 4, 256 * MIB))
    per_row = int(size) * (int(size) // 2 + 1) * 256
    capacity = max(1, budget // per_row)
    target = max(256, int(preferred))
    return max(1, min(1024, target, capacity))


def fine_cache_reserve(available, size, batch_size, oversampling):
    # Reserve a reusable fine working set, not a fixed quarter of a many-GiB
    # cache. Bound it by a quarter when the overall cache is small.
    rowbytes = int(size) * (int(size) // 2 + 1) * 8
    working = max(64 * MIB, int(batch_size) * 256 * (8 ** int(oversampling)) * rowbytes)
    return min(max(0, int(available)) // 4, working)


def statistics_cache_budget(work_bytes, size, orientation_count, classes,
                            orientation_children, translation_children,
                            element_bytes=12):
    # Leave room for the noise reducer and at least 32 parent statistics rows.
    work = max(0, int(work_bytes))
    pixels = int(size) * (int(size) // 2 + 1)
    per_parent = pixels * 8 * (translation_children + 6 * orientation_children + 12) + 256 * orientation_children * translation_children
    scratch = max(work // 2, min(32 * MIB, work // 16) + 32 * per_parent)
    available = max(0, work - scratch)
    useful = int(orientation_count) * int(classes) * (pixels * element_bytes + 256)
    # Allocation retains flush workspace as well as cached rows.
    return min(available, (useful * 5 + 3) // 4)
