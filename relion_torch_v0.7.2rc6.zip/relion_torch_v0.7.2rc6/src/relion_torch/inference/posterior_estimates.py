"""One byte estimate for planning and admitting complete local posteriors."""


def local_posterior_bytes(batch, classes, orientations, translations):
    # Scores/priors/weights, sorting and masks, plus local IDs/prior metadata.
    # The same bound must be used before preparation and before allocation.
    return int(batch)*int(orientations)*(int(classes)*int(translations)*112+32)
