"""Shared coarse/fine expectation engine for RELION-style alignment.

The engine is deliberately independent of MRC/STAR I/O.  Its projector callback
receives Euler angles and a requested Fourier size, which allows the already
validated slow projector and an optional vectorised backend to share exactly the
same posterior code.
"""
from __future__ import annotations
from contextlib import nullcontext
from relion_torch.geometry.grids import signed_fft_indices


from dataclasses import dataclass, field, replace
import math
from typing import Callable, Iterable, Mapping, Sequence

import numpy as np
import torch

from relion_torch.fourier.conventions import fourier_shift_factor_2d
from relion_torch.sampling.relion_sampling import (
    FineSamplingTable,
    RelionSampling,
    SamplingPoint,
)

Tensor = torch.Tensor
Projector = Callable[[int, Tensor, int], Tensor]


@dataclass
class FourierSizeState:
    original_size: int
    pixel_size: float
    current_size: int
    coarse_size: int
    strict_highres_angstrom: float | None = None

    @property
    def current_shell(self) -> int:
        return self.current_size // 2

    @property
    def coarse_shell(self) -> int:
        return self.coarse_size // 2

    def strict_shell(self) -> int | None:
        if self.strict_highres_angstrom is None or self.strict_highres_angstrom <= 0:
            return None
        return max(1, int(math.floor(
            self.original_size * self.pixel_size / self.strict_highres_angstrom + 0.5
        )))

    def likelihood_shell(self, fine: bool) -> int:
        shell = self.likelihood_image_size(fine) // 2
        strict = self.strict_shell()
        return shell if strict is None else min(shell, strict)

    def likelihood_image_size(self, fine: bool) -> int:
        """RELION uses the coarse Fourier box for BOTH strict-cutoff passes.

        Weighted sums/reconstruction always retain ``current_size``. A shell
        mask on a larger projection is not equivalent at the circular edge.
        """
        if self.strict_shell() is not None:
            return self.coarse_size
        return self.current_size if fine else self.coarse_size

    def coarse_likelihood_grid(self, oversampling: int) -> tuple[int, int]:
        """One sizing rule for deferred coarse banks and their memory budget.

        Without an adaptive fine pass, score at the current likelihood size.
        Strict-highres still restricts both passes; weighted sums use current_size.
        """
        fine = int(oversampling) == 0
        return self.likelihood_image_size(fine), self.likelihood_shell(fine)


def coarse_size_from_sampling(
    *, original_size: int, pixel_size: float, particle_diameter: float,
    angular_step_deg: float, reference_dim: int, current_size: int,
    strict_highres_angstrom: float | None = None,
) -> int:
    if angular_step_deg <= 0 or particle_diameter <= 0:
        return current_size
    rotated_distance = angular_step_deg * math.pi * particle_diameter / 360.0
    safety = 1.2 if reference_dim == 3 else 1.5
    coarse_resolution = max(pixel_size * 2.0, rotated_distance / safety)
    shell = int(math.ceil(original_size * pixel_size / coarse_resolution))
    if strict_highres_angstrom is not None and strict_highres_angstrom > 0:
        strict_shell = int(math.floor(original_size * pixel_size / strict_highres_angstrom + 0.5))
        shell = min(shell, max(1, strict_shell))
    size = max(2, min(current_size, 2 * shell))
    if size % 2:
        size += 1
    return min(size, current_size)


def rounded_shell_indices_2d(size: int, device: torch.device | str = "cpu") -> Tensor:
    ky = signed_fft_indices(size, device=device)
    kx = torch.arange(size // 2 + 1, device=device, dtype=ky.dtype)
    yy, xx = torch.meshgrid(ky, kx, indexing="ij")
    return torch.floor(torch.sqrt(xx * xx + yy * yy) + 0.5).to(torch.int64)


def independent_rfft_mask(size: int, maximum_shell: int, device: torch.device | str) -> Tensor:
    shells = rounded_shell_indices_2d(size, device)
    ky = signed_fft_indices(size, device=device)
    duplicate = (torch.arange(size // 2 + 1, device=device)[None, :] == 0) & (ky[:, None] < 0)
    return (shells > 0) & (shells <= int(maximum_shell)) & ~duplicate


def likelihood_rfft_mask(size: int, maximum_shell: int, device: torch.device | str,
                         *, firstiter_cc: bool = False) -> Tensor:
    """CC uses the entire working RFFT; Gaussian uses independent coefficients.

    Native CC includes DC, both x=0 conjugates and the image power in corners.
    Its cutoff is imposed by the working image/projection size, not by the
    Gaussian inverse-noise mask. Keep that mask unchanged for other callers.
    """
    if firstiter_cc:
        return torch.ones((size, size // 2 + 1), device=device, dtype=torch.bool)
    return independent_rfft_mask(size, maximum_shell, device)


def likelihood_inverse_noise(sigma2_by_shell: Tensor, active_shells: Tensor,
                             *, firstiter_cc: bool = False) -> Tensor:
    """Unit CC weights avoid indexing a radial noise spectrum at RFFT corners."""
    if firstiter_cc:
        return sigma2_by_shell.new_ones((*sigma2_by_shell.shape[:-1], active_shells.numel()))
    sigma = sigma2_by_shell.index_select(-1, active_shells)
    return torch.where(sigma > 0, sigma.reciprocal(), torch.zeros_like(sigma))


def phase_shift_rfft(
    shape: tuple[int, int],
    xy_pixels: Tensor,
    device: torch.device,
    dtype: torch.dtype,
    *,
    original_size: int | None = None,
) -> Tensor:
    """RELION Fourier translation phase for a full or windowed RFFT image."""

    h, w_half = shape
    w = (w_half - 1) * 2
    if h != w:
        raise ValueError(f"Expected square RFFT image, got shape {shape}")
    return fourier_shift_factor_2d(
        h,
        xy_pixels,
        original_size=h if original_size is None else original_size,
        sign=-1.0,
        device=device,
        dtype=dtype,
    )


def gaussian_translation_priors(
    translations_angstrom: Tensor,
    centre_angstrom: Tensor,
    sigma_angstrom: float,
) -> Tensor:
    if sigma_angstrom <= 0:
        return torch.ones(translations_angstrom.shape[:-1], device=translations_angstrom.device,
                          dtype=translations_angstrom.dtype)
    delta = translations_angstrom - centre_angstrom
    p = torch.exp(-0.5 * torch.sum(delta * delta, dim=-1) / (sigma_angstrom * sigma_angstrom))
    mean = p.mean()
    return p / mean.clamp_min(torch.finfo(p.dtype).tiny)


def normalised_discrete_prior(values: Tensor) -> Tensor:
    out = torch.clamp(values, min=0)
    total = out.sum()
    if not torch.isfinite(total) or total <= 0:
        return torch.zeros_like(out)
    return out / total


def exact_log_class_prior(class_probabilities: Tensor) -> Tensor:
    """Return log priors while preserving truly dead classes as ``-inf``."""
    result = torch.full_like(class_probabilities, -torch.inf)
    positive = class_probabilities > 0
    result[positive] = torch.log(class_probabilities[positive])
    return result


def mean_normalised_log_class_prior(class_probabilities: Tensor) -> Tensor:
    """Return RELION's class prior divided by its sampled-grid mean.

    ``convertAllSquaredDifferencesToWeights`` divides the orientation prior by
    ``pdf_orientation_mean``.  When directions are fixed or still uniformly
    initialised, that mean is simply the mean class probability.  The constant
    cancels from posteriors but is required for exact DLL/LL parity for K>1.
    """

    log_prior = exact_log_class_prior(class_probabilities)
    mean = class_probabilities.mean()
    if bool(torch.isfinite(mean) & (mean > 0.0)):
        log_prior = log_prior - torch.log(mean)
    return log_prior


def _relion_threshold_from_raw_weights(
    raw_weights: Tensor,
    adaptive_fraction: float,
    *, compact_positive: bool = False, counters=None,
) -> tuple[Tensor, Tensor, Tensor, Tensor]:
    """Return RELION's significant mask, reported count, threshold and sum.

    RELION determines the threshold from *unnormalised* positive weights.  It
    sorts them from high to low, accumulates until the sum is strictly greater
    than ``adaptive_fraction * sumweight``, reports the number visited, and then
    retains every original hypothesis whose raw weight is greater than or equal
    to the threshold.  The reported count can therefore be smaller than the
    number retained when several hypotheses tie at the threshold.
    """

    if raw_weights.ndim < 2:
        raise ValueError(
            "raw_weights must have a batch dimension and a hypothesis dimension"
        )
    flat = raw_weights.reshape(-1, raw_weights.shape[-1])
    if flat.shape[-1] == 0:
        empty_count = torch.zeros(flat.shape[0], device=flat.device, dtype=torch.long)
        empty_value = torch.zeros(flat.shape[0], device=flat.device, dtype=flat.dtype)
        return (
            torch.zeros_like(raw_weights, dtype=torch.bool),
            empty_count.reshape(raw_weights.shape[:-1]),
            empty_value.reshape(raw_weights.shape[:-1]),
            empty_value.reshape(raw_weights.shape[:-1]),
        )

    raw = torch.where(
        torch.isfinite(flat) & (flat > 0.0), flat, torch.zeros_like(flat)
    )
    # Use a scan in hypothesis traversal order for exp_sum_weight.  RELION's
    # threshold scan uses a separately sorted order, so at fraction=1 the two
    # floating-point accumulation orders can legitimately cross just before the
    # last positive value.
    sumweight = torch.cumsum(raw, dim=-1)[:, -1]
    positive_count = (raw > 0.0).sum(dim=-1)

    if compact_positive:
        from .positive_weights import sort_positive_weights
        sorted_weight = sort_positive_weights(raw, positive_count, counters=counters)
    else:
        sorted_weight = torch.sort(raw, dim=-1, descending=True).values
    cumulative = torch.cumsum(sorted_weight, dim=-1)
    ranks = torch.arange(sorted_weight.shape[-1], device=flat.device).unsqueeze(0)
    eligible = ranks < positive_count[:, None]
    target = float(adaptive_fraction) * sumweight[:, None]
    crossing = eligible & (cumulative > target)
    has_crossing = crossing.any(dim=-1)
    first_crossing = torch.argmax(crossing.to(torch.int64), dim=-1)
    reported_count = torch.where(
        has_crossing, first_crossing + 1, positive_count
    )

    safe_index = (reported_count - 1).clamp_min(0)
    threshold = sorted_weight.gather(1, safe_index[:, None]).squeeze(1)
    threshold = torch.where(
        reported_count > 0, threshold, torch.full_like(threshold, torch.inf)
    )
    significant = (raw > 0.0) & (raw >= threshold[:, None])
    leading = raw_weights.shape[:-1]
    return (
        significant.reshape(raw_weights.shape),
        reported_count.reshape(leading),
        threshold.reshape(leading),
        sumweight.reshape(leading),
    )


def significant_mask_batch(weights: Tensor, adaptive_fraction: float) -> Tensor:
    """Apply RELION's raw-weight significant-threshold rule.

    This compatibility helper treats ``weights`` as already unnormalised.  The
    likelihood engine uses :func:`relion_weight_selection_batch` so conversion
    from ``log_prior`` and ``diff2`` also follows RELION's exponent cutoff.
    """

    if weights.ndim < 2:
        raise ValueError("weights must have a batch dimension and a hypothesis dimension")
    mask, _count, _threshold, _sumweight = _relion_threshold_from_raw_weights(
        weights.to(torch.float64), adaptive_fraction
    )
    return mask


def significant_mask(weights: Tensor, adaptive_fraction: float) -> Tensor:
    if weights.ndim != 1:
        raise ValueError("weights must be one-dimensional")
    return significant_mask_batch(weights.unsqueeze(0), adaptive_fraction)[0]


@dataclass(slots=True)
class RelionWeightSelection:
    posterior: Tensor
    posterior64: Tensor
    significant: Tensor
    reported_significant_count: Tensor
    significant_weight: Tensor
    sumweight: Tensor
    log_evidence: Tensor
    best_index: Tensor
    pmax: Tensor


def relion_weight_selection_batch(
    log_prior: Tensor,
    diff2: Tensor,
    adaptive_fraction: float,
    *,
    exponent_cutoff: float | None = None,
    weight_dtype: torch.dtype = torch.float64,
    compact_positive: bool = False,
    counters=None,
    fusion_mode="off", detail_timer=None, detail_prefix="global",
) -> RelionWeightSelection:
    """Convert squared differences to RELION-style raw weights.

    ``weight_dtype=float32`` follows the accelerator representation: log-prior
    scores, exponentiation, traversal-order sum, sorted cumulative threshold
    and normalized posterior are all float32.  The exponent is shifted so the
    maximum argument is +50 and values below -88 are exactly zero, matching
    the RELION 3.1 CUDA helper.  ``float64`` preserves the historical PyTorch
    compatibility path.
    """

    if log_prior.shape != diff2.shape:
        raise ValueError("log_prior and diff2 must have identical shapes")
    if log_prior.ndim < 1 or log_prior.shape[-1] == 0:
        raise ValueError("at least one hypothesis is required")
    if weight_dtype not in (torch.float32, torch.float64):
        raise ValueError("weight_dtype must be float32 or float64")

    section = lambda name: detail_timer.section(name, full=True) if detail_timer is not None else nullcontext()
    with section(detail_prefix+'.posterior_weights'):
        original_shape = diff2.shape
        flat_prior = log_prior.reshape(-1, original_shape[-1]).to(weight_dtype)
        flat_diff = diff2.reshape(-1, original_shape[-1]).to(weight_dtype)
        valid = torch.isfinite(flat_prior) & torch.isfinite(flat_diff)
        if not bool(torch.all(valid.any(dim=-1))):
            raise RuntimeError("at least one particle has no finite hypothesis")
    
        if weight_dtype == torch.float32:
            # Native accelerator arithmetic stores log-prior - diff2 in XFLOAT.
            # Shift the largest exponent to +50; the helper then underflows values
            # below -88 to exact zero.  Keep the shifted raw weights because the
            # native significant_weight/sum_weight fields use this representation.
            score = torch.where(
                valid, flat_prior - flat_diff, torch.full_like(flat_diff, -torch.inf)
            )
            maximum = score.max(dim=-1).values
            shift = 50.0 - maximum
            raw = None
            if fusion_mode != 'off':
                from .global_fusion import raw_weights
                raw = raw_weights(score, valid, shift, mode=fusion_mode, counters=counters)
            if raw is None:
                exponent = score + shift[:, None]
                allowed = valid & (exponent >= -88.0)
                raw = torch.where(allowed, torch.exp(exponent), torch.zeros_like(exponent))
            log_evidence_shift = shift
        else:
            # Preserve the historical v0.2.12/double compatibility representation
            # exactly: reference the likelihood to min(diff2), exponentiate the
            # prior separately, and report threshold/sumweight on that raw scale.
            cutoff = 700.0 if exponent_cutoff is None else float(exponent_cutoff)
            minimum = torch.where(
                valid, flat_diff, torch.full_like(flat_diff, torch.inf)
            ).min(dim=-1).values
            relative = flat_diff - minimum[:, None]
            allowed = valid & (relative <= cutoff)
            prior = torch.where(allowed, torch.exp(flat_prior), torch.zeros_like(flat_prior))
            raw = torch.where(
                allowed, prior * torch.exp(-relative), torch.zeros_like(flat_prior)
            )
            log_evidence_shift = minimum

    with section(detail_prefix+'.posterior_threshold'):
        significant, reported_count, threshold, sumweight = (
            _relion_threshold_from_raw_weights(raw, adaptive_fraction, compact_positive=compact_positive, counters=counters)
        )
    flat_sum = sumweight.reshape(-1)
    if not bool(torch.all(torch.isfinite(flat_sum) & (flat_sum > 0.0))):
        raise RuntimeError("zero or non-finite sum of RELION weights")

    posterior_native = raw / flat_sum[:, None]
    best = torch.argmax(raw, dim=-1)
    pmax_native = posterior_native.gather(1, best[:, None]).squeeze(1)
    if weight_dtype == torch.float32:
        log_evidence_native = torch.log(flat_sum) - log_evidence_shift
    else:
        log_evidence_native = torch.log(flat_sum) - log_evidence_shift
    leading = original_shape[:-1]
    return RelionWeightSelection(
        posterior=posterior_native.to(diff2.dtype).reshape(original_shape),
        # Keep the public field for existing model/statistic code, but do not
        # regain precision: it is a cast of the native-precision posterior.
        posterior64=posterior_native.to(torch.float64).reshape(original_shape),
        significant=significant.reshape(original_shape),
        reported_significant_count=reported_count.reshape(leading),
        significant_weight=threshold.to(torch.float64).reshape(leading),
        sumweight=sumweight.to(torch.float64).reshape(leading),
        log_evidence=log_evidence_native.to(torch.float64).reshape(leading),
        best_index=best.reshape(leading),
        pmax=pmax_native.to(torch.float64).reshape(leading),
    )


def wrapped_angle_difference_deg(values: Tensor, centre: Tensor) -> Tensor:
    return torch.remainder(values - centre + 180.0, 360.0) - 180.0


def orientation_prior_weights(
    points: Sequence[SamplingPoint],
    centre_rot_tilt_psi: Tensor | None,
    sigma_rot_tilt_psi: tuple[float, float, float],
    *, device: torch.device, dtype: torch.dtype,
) -> Tensor:
    """Per-particle RELION-style local orientational prior, mean-normalised.

    Global searches pass zero sigmas and therefore receive a uniform prior.
    Rot/tilt are compared as directions on the unit sphere; psi is wrapped.
    """
    if centre_rot_tilt_psi is None or not any(s > 0 for s in sigma_rot_tilt_psi):
        return torch.ones(len(points), device=device, dtype=dtype)
    centre = centre_rot_tilt_psi.to(device=device, dtype=dtype)
    values = torch.tensor([(p.rot, p.tilt, p.psi) for p in points], device=device, dtype=dtype)
    rot = torch.deg2rad(values[:, 0]); tilt = torch.deg2rad(values[:, 1])
    crot = torch.deg2rad(centre[0]); ctilt = torch.deg2rad(centre[1])
    xyz = torch.stack((torch.sin(tilt) * torch.cos(rot), torch.sin(tilt) * torch.sin(rot), torch.cos(tilt)), -1)
    cxyz = torch.stack((torch.sin(ctilt) * torch.cos(crot), torch.sin(ctilt) * torch.sin(crot), torch.cos(ctilt)))
    angular = torch.rad2deg(torch.acos(torch.clamp(xyz @ cxyz, -1.0, 1.0)))
    sdir = max(float(sigma_rot_tilt_psi[0]), float(sigma_rot_tilt_psi[1]))
    exponent = torch.zeros(len(points), device=device, dtype=dtype)
    if sdir > 0:
        exponent = exponent + angular.square() / (2.0 * sdir * sdir)
    spsi = float(sigma_rot_tilt_psi[2])
    if spsi > 0:
        dpsi = wrapped_angle_difference_deg(values[:, 2], centre[2])
        exponent = exponent + dpsi.square() / (2.0 * spsi * spsi)
    weights = torch.exp(-exponent)
    mean = weights.mean()
    return weights / mean.clamp_min(torch.finfo(dtype).tiny)


@dataclass
class HypothesisTable:
    points: list[SamplingPoint]
    diff2: Tensor
    log_prior: Tensor
    posterior: Tensor
    posterior64: Tensor | None
    significant: Tensor
    projection_norm: Tensor | None = None
    cross_correlation: Tensor | None = None
    reported_significant_count: int = 0
    significant_weight: Tensor | None = None
    log_evidence: Tensor | None = None
    pmax: Tensor | None = None


@dataclass
class ParticleExpectation:
    coarse: HypothesisTable
    fine: HypothesisTable
    best_index: int
    best_point: SamplingPoint
    pmax: float
    log_likelihood_contribution: float
    highres_xi2_half: float
    log_sigma2: float


@dataclass
class AlignmentExpectationConfig:
    adaptive_fraction: float = 0.999
    firstiter_cc: bool = False
    skip_align: bool = False
    skip_rotate: bool = False
    adaptive_oversampling: int = 0
    sigma_offset_angstrom: float = 10.0
    sigma_rot_deg: float = 0.0
    sigma_tilt_deg: float = 0.0
    sigma_psi_deg: float = 0.0
    chunk_size: int = 256
    # Execution-only, opt-in for Class2D; shared 3-D alignment keeps its old path.
    cache_active_views: bool = False
    active_view_cache_bytes: int = 0
    # Shared optional execution layout; also valid for 3-D fine child tables.
    fine_score_mode: str = "sparse"
    dense_fine_execution: str = "auto"
    candidate_chunk_size: int = 0  # 0 preserves the original parent chunk
    candidate_work_bytes: int = 256 * 1024**2
    # Class2D can opt into RELION accelerator FP32 weight arithmetic; shared
    # Class3D/auto-refine callers retain float64 unless explicitly changed.
    weight_precision: str = "float64"
    # Appended to preserve positional construction of the existing config.
    cc_score_only: bool = False  # execution-only opt-in; diff2 is -CC in this mode


@dataclass(slots=True)
class GlobalProjectionBank:
    """Current-size projections shared by every particle in one iteration."""

    angles_deg: Tensor
    direction_indices: Tensor
    psi_indices: Tensor
    translations_angstrom: Tensor
    projections: Tensor
    phase_factors: Tensor
    image_size: int
    maximum_shell: int
    source_signature: tuple | None = None

    @property
    def number_of_classes(self) -> int:
        return int(self.projections.shape[0])

    @property
    def number_of_orientations(self) -> int:
        return int(self.projections.shape[1])

    @property
    def number_of_translations(self) -> int:
        return int(self.translations_angstrom.shape[0])


@dataclass(slots=True)
class FineProjectionBlocks:
    """Fine projections for the unique class/coarse-orientation blocks in a batch."""

    keys: Tensor
    class_indices: Tensor
    coarse_orientation_indices: Tensor
    angles_deg: Tensor
    projections: Tensor


@dataclass(slots=True)
class SparseAdaptiveBatchExpectation:
    """Sparse second-pass posterior for significant coarse parents.

    Each parent is one significant ``[particle,class,coarse orientation,coarse
    translation]`` entry.  Its dense local child tile is
    ``[orientation_child, translation_child]``; only these tiles are materialised.
    """

    coarse: "DenseBatchExpectation"
    projection_blocks: FineProjectionBlocks
    parent_projection_block_indices: Tensor
    parent_particle_indices: Tensor
    parent_class_indices: Tensor
    parent_orientation_indices: Tensor
    parent_translation_indices: Tensor
    child_angles_deg: Tensor
    child_direction_indices: Tensor
    child_orientation_ids: Tensor
    child_translations_angstrom: Tensor
    phase_factors: Tensor
    diff2: Tensor
    log_prior: Tensor
    posterior: Tensor
    significant: Tensor
    class_mass: Tensor
    parent_mass64: Tensor
    fine_reported_significant_count: Tensor
    fine_significant_weight: Tensor
    fine_log_evidence: Tensor
    best_parent_indices: Tensor
    best_orientation_child_indices: Tensor
    best_translation_child_indices: Tensor
    pmax: Tensor
    log_likelihood_contribution: Tensor
    highres_xi2_half: Tensor
    log_sigma2: Tensor
    cross_correlation: Tensor | None = None
    execution_stats: dict | None = None

    @property
    def retained_weights(self) -> Tensor:
        return self.posterior * self.significant.to(self.posterior.dtype)

    @property
    def significant_count(self) -> Tensor:
        # RELION writes the first-pass coarse significant count to the particle STAR.
        return self.coarse.reported_significant_count

    @property
    def number_of_parents(self) -> int:
        return int(self.parent_particle_indices.numel())

    @property
    def orientation_children(self) -> int:
        return int(self.diff2.shape[1])

    @property
    def translation_children(self) -> int:
        return int(self.diff2.shape[2])

    def best_values(self) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        parent = self.best_parent_indices
        orient = self.best_orientation_child_indices
        trans = self.best_translation_child_indices
        class_index = self.parent_class_indices.index_select(0, parent)
        angles = self.child_angles_deg[parent, orient]
        translations = self.child_translations_angstrom[parent, trans]
        directions = self.child_direction_indices[parent, orient]
        return class_index, angles, translations, directions


@dataclass(slots=True)
class DenseBatchExpectation:
    """Dense global-search posterior for a particle batch.

    Hypothesis order is ``[class, orientation, translation]`` with translation
    as the fastest varying dimension, identical to ``RelionSampling``'s coarse
    point order.
    """

    bank: GlobalProjectionBank
    diff2: Tensor
    log_prior: Tensor
    posterior: Tensor
    significant: Tensor
    class_mass: Tensor
    best_flat_index: Tensor
    pmax: Tensor
    log_likelihood_contribution: Tensor
    highres_xi2_half: Tensor
    log_sigma2: Tensor
    reported_significant_count: Tensor
    significant_weight: Tensor
    log_evidence: Tensor
    cross_correlation: Tensor | None = None
    # None for the unchanged global path; [B,local_width] GLOBAL IDs otherwise.
    orientation_indices: Tensor | None = None

    def global_orientations(self, rows, local_indices):
        return local_indices if self.orientation_indices is None else self.orientation_indices[rows, local_indices]

    @property
    def retained_weights(self) -> Tensor:
        return self.posterior * self.significant.to(self.posterior.dtype)

    @property
    def significant_count(self) -> Tensor:
        return self.reported_significant_count

    def decode_flat_indices(self, flat_indices: Tensor | None = None) -> tuple[Tensor, Tensor, Tensor]:
        indices = self.best_flat_index if flat_indices is None else flat_indices
        nt = self.bank.number_of_translations
        no = int(self.diff2.shape[2])
        translation = torch.remainder(indices, nt)
        orientation = torch.remainder(torch.div(indices, nt, rounding_mode="floor"), no)
        class_index = torch.div(indices, nt * no, rounding_mode="floor")
        if self.orientation_indices is not None:
            if indices.ndim < 1 or indices.shape[0] != len(self.orientation_indices):
                raise ValueError("Local flat indices must have a leading particle dimension")
            rows = torch.arange(len(self.orientation_indices), device=indices.device).reshape((-1,) + (1,) * (indices.ndim-1))
            orientation = self.global_orientations(rows, orientation)
        return class_index, orientation, translation


class AlignmentExpectation:
    def __init__(
        self,
        sampling: RelionSampling,
        size_state: FourierSizeState,
        projector: Projector,
        class_probabilities: Tensor,
        *,
        direction_priors: Tensor | None = None,
        config: AlignmentExpectationConfig | None = None,
    ) -> None:
        self.sampling = sampling
        self.sizes = size_state
        self.projector = projector
        self.class_probabilities = class_probabilities
        self.direction_priors = direction_priors
        self.config = config or AlignmentExpectationConfig()
        self._global_coarse_points: list[SamplingPoint] | None = None
        self._global_projection_banks: dict[tuple[int, int], GlobalProjectionBank] = {}
        self._fine_sampling_tensors: dict[int, tuple[Tensor, Tensor, Tensor, Tensor]] = {}
        self._fine_projection_block_cache: dict[tuple[int, int, int, int], Tensor] = {}
        self._fine_phase_cache: dict[tuple[int, int], Tensor] = {}
        self._cached_source_signature: tuple | None = None
        self._active_spectral_views: dict[tuple, tuple[Tensor, Tensor]] = {}
        self._active_view_bytes = 0
        self._active_view_peak_bytes = 0

    def _sync_source_caches(self) -> tuple:
        """Invalidate prediction caches after source/reference/support changes.

        Production adapters supply a cheap host-side identity/generation token.
        Plain projector callables in tests retain iteration-local caches. No
        angle tensor is copied from GPU and no per-hypothesis sync is introduced.
        """
        get_token = getattr(self.projector, "source_cache_token", None)
        token = get_token() if callable(get_token) else None
        signature = (int(self.sizes.current_size), token)
        if signature != self._cached_source_signature:
            self._global_projection_banks.clear()
            self._fine_projection_block_cache.clear()
            self._active_spectral_views.clear()
            self._active_view_bytes = 0
            self._cached_source_signature = signature
        return signature

    def _cached_spectral_view(self, key, source, mask, active_count):
        """Cache a pure indexing result within the configured byte budget.

        Holding the source avoids object-id reuse; no transformed values,
        weights, priors, CTFs or iteration-dependent particles are cached.
        """
        if not self.config.cache_active_views:
            return None
        key = (*key, bool(self.config.firstiter_cc), id(source), int(source._version))
        found = self._active_spectral_views.get(key)
        if found is not None:
            return found[1]
        rows = source.numel() // (source.shape[-2] * source.shape[-1])
        needed = rows * int(active_count) * source.element_size()
        if self._active_view_bytes + needed > self.config.active_view_cache_bytes:
            return None
        view = source[..., mask]
        self._active_spectral_views[key] = (source, view)
        self._active_view_bytes += needed
        self._active_view_peak_bytes = max(self._active_view_peak_bytes, self._active_view_bytes)
        return view

    @staticmethod
    def _window_rfft(x: Tensor, new_size: int) -> Tensor:
        old_size = x.shape[-2]
        if new_size == old_size:
            return x
        if new_size > old_size or new_size % 2:
            raise ValueError("Fourier window must be an even size not larger than input")
        top = new_size // 2 + 1
        bottom = new_size - top
        head = x[..., :top, :new_size // 2 + 1]
        return head if bottom == 0 else torch.cat((head, x[..., -bottom:, :new_size // 2 + 1]), dim=-2)

    def _select_weights(self, log_prior, diff2, adaptive_fraction):
        """Backend hook with an optional RELION-accelerator FP32 path."""
        dtype = torch.float32 if self.config.weight_precision == "float32" else torch.float64
        return relion_weight_selection_batch(
            log_prior, diff2, adaptive_fraction, weight_dtype=dtype
        )

    def _priors(
        self,
        points: Sequence[SamplingPoint],
        device: torch.device,
        dtype: torch.dtype,
        offset_prior_angstrom: Tensor,
        orientation_prior_deg: Tensor | None,
        *,
        direction_oversampling_order: int = 0,
    ) -> Tensor:
        # Take the logarithm before reducing to the score tensor dtype.  This
        # preserves finite log-priors for positive float64 class probabilities
        # that would otherwise underflow to zero during a float32 cast.
        class_probabilities64 = self.class_probabilities.to(
            device=device, dtype=torch.float64
        )
        class_log = exact_log_class_prior(class_probabilities64).to(dtype)
        class_probabilities = class_probabilities64.to(dtype)
        if not points:
            return torch.empty(0, device=device, dtype=dtype)
        classes = torch.as_tensor(
            [p.class_index for p in points], device=device, dtype=torch.long
        )
        directions = torch.as_tensor(
            [p.direction_index for p in points], device=device, dtype=torch.long
        )
        trans = torch.as_tensor(
            [(p.x, p.y) for p in points], device=device, dtype=dtype
        )
        trans_prior = gaussian_translation_priors(
            trans,
            offset_prior_angstrom.to(device=device, dtype=dtype),
            self.config.sigma_offset_angstrom,
        )
        orient_prior = orientation_prior_weights(
            points,
            orientation_prior_deg,
            (
                self.config.sigma_rot_deg,
                self.config.sigma_tilt_deg,
                self.config.sigma_psi_deg,
            ),
            device=device,
            dtype=dtype,
        )
        tiny = torch.finfo(dtype).tiny
        valid = (trans_prior > 0) & (orient_prior > 0) & torch.isfinite(class_log[classes])
        value = class_log[classes] + torch.log(trans_prior.clamp_min(tiny)) + torch.log(
            orient_prior.clamp_min(tiny)
        )
        if self.direction_priors is not None and not self.config.skip_rotate:
            # RELION stores pdf_direction as the joint class/direction
            # probability and divides that orientation prior by its global mean
            # over the sampled class/direction grid.  Internally we keep
            # q(direction | class) separately from P(class), so the equivalent
            # log prior is log P(class) + log q(direction | class) minus the
            # mean joint-probability constant.  Uniform initial direction PDFs
            # therefore leave both the posterior and DLL unchanged.
            conditional = self.direction_priors.to(device=device, dtype=dtype)
            row_sum = conditional.sum(dim=-1, keepdim=True)
            conditional = torch.where(
                row_sum > 0,
                conditional / row_sum.clamp_min(tiny),
                torch.full_like(conditional, 1.0 / conditional.shape[-1]),
            )
            class_probability = self.class_probabilities.to(
                device=device, dtype=dtype
            )
            joint_mean = (conditional * class_probability[:, None]).mean()
            coarse_direction = torch.bitwise_right_shift(
                directions, 2 * int(direction_oversampling_order)
            )
            if bool(torch.any(coarse_direction < 0)) or bool(
                torch.any(coarse_direction >= conditional.shape[1])
            ):
                raise IndexError("direction prior index outside coarse HEALPix grid")
            dp = conditional[classes, coarse_direction]
            valid &= dp > 0
            value = (
                value
                + torch.log(dp.clamp_min(tiny))
                - torch.log(joint_mean.clamp_min(tiny))
            )
        else:
            class_mean = class_probabilities.mean()
            value = value - torch.log(class_mean.clamp_min(tiny))
        return torch.where(valid, value, torch.full_like(value, -torch.inf))

    def _global_orientation_tensors(
        self, device: torch.device, dtype: torch.dtype
    ) -> tuple[Tensor, Tensor, Tensor]:
        directions = self.sampling.directions
        psi = self.sampling.psi_angles
        angles = np.empty((len(directions) * len(psi), 3), dtype=np.float64)
        direction_indices = np.empty(angles.shape[0], dtype=np.int64)
        psi_indices = np.empty(angles.shape[0], dtype=np.int64)
        cursor = 0
        for idir, (rot, tilt) in enumerate(directions):
            count = len(psi)
            angles[cursor : cursor + count, 0] = rot
            angles[cursor : cursor + count, 1] = tilt
            angles[cursor : cursor + count, 2] = psi
            direction_indices[cursor : cursor + count] = idir
            psi_indices[cursor : cursor + count] = np.arange(count, dtype=np.int64)
            cursor += count
        return (
            torch.as_tensor(angles, device=device, dtype=dtype),
            torch.as_tensor(direction_indices, device=device, dtype=torch.long),
            torch.as_tensor(psi_indices, device=device, dtype=torch.long),
        )

    @torch.no_grad()
    def build_global_projection_bank(
        self,
        *,
        pixel_size: float,
        image_size: int | None = None,
        maximum_shell: int | None = None,
    ) -> GlobalProjectionBank:
        """Generate all class/orientation projections once for this iteration."""

        if self.config.skip_align or self.config.skip_rotate:
            raise RuntimeError("global projection banks require rotation search")
        device = self.class_probabilities.device
        # Class probabilities are model state and may be float64.  Projection
        # banks follow the frozen numerical core's real/complex32 convention;
        # tying their dtype to the PDF vector would accidentally promote every
        # Fourier coordinate and matrix multiplication to float64.
        dtype = torch.float32
        size = self.sizes.likelihood_image_size(True) if image_size is None else int(image_size)
        shell = self.sizes.likelihood_shell(True) if maximum_shell is None else int(maximum_shell)
        source_signature = self._sync_source_caches()
        cache_key = (size, shell)
        cached = self._global_projection_banks.get(cache_key)
        if cached is not None:
            return cached
        angles, direction_indices, psi_indices = self._global_orientation_tensors(
            device, dtype
        )
        chunks: list[Tensor] = []
        for class_index in range(len(self.class_probabilities)):
            class_parts: list[Tensor] = []
            for start in range(0, int(angles.shape[0]), max(1, int(self.config.chunk_size))):
                projected = self.projector(
                    class_index,
                    angles[start : start + int(self.config.chunk_size)],
                    size,
                )
                if projected.ndim == 2:
                    projected = projected.unsqueeze(0)
                if tuple(projected.shape[-2:]) != (size, size // 2 + 1):
                    projected = self._window_rfft(projected, size)
                class_parts.append(projected)
            chunks.append(torch.cat(class_parts, dim=0))
        projections = torch.stack(chunks, dim=0).contiguous()
        translations = torch.as_tensor(
            self.sampling.translations, device=device, dtype=dtype
        )
        phase = phase_shift_rfft(
            (size, size // 2 + 1),
            translations / float(pixel_size),
            device,
            dtype,
            original_size=self.sizes.original_size,
        ).contiguous()
        bank = GlobalProjectionBank(
            angles_deg=angles,
            direction_indices=direction_indices,
            psi_indices=psi_indices,
            translations_angstrom=translations,
            projections=projections,
            phase_factors=phase,
            image_size=size,
            maximum_shell=shell,
            source_signature=source_signature,
        )
        self._global_projection_banks[cache_key] = bank
        return bank

    @staticmethod
    def _highres_terms_batch(
        particle_ft: Tensor,
        sigma2_by_shell: Tensor,
        current_shell: int,
    ) -> tuple[Tensor, Tensor]:
        if particle_ft.ndim == 2:
            particle_ft = particle_ft.unsqueeze(0)
        if sigma2_by_shell.ndim == 1:
            sigma2_by_shell = sigma2_by_shell.unsqueeze(0)
        if particle_ft.shape[0] != sigma2_by_shell.shape[0]:
            raise ValueError("particle and sigma2 batch sizes differ")
        n = int(particle_ft.shape[-2])
        shells = rounded_shell_indices_2d(n, particle_ft.device)
        ky = signed_fft_indices(n, device=particle_ft.device)
        duplicate = (
            torch.arange(n // 2 + 1, device=particle_ft.device)[None, :] == 0
        ) & (ky[:, None] < 0)
        independent = (
            (shells > 0)
            & (shells < sigma2_by_shell.shape[-1])
            & ~duplicate
        )
        high = independent & (shells > int(current_shell))
        power = particle_ft.real.square() + particle_ft.imag.square()
        highres = 0.5 * power[:, high].sum(dim=-1)

        current_size = min(n, max(2, 2 * int(current_shell)))
        current_shells = rounded_shell_indices_2d(current_size, particle_ft.device)
        normalizer_mask = independent_rfft_mask(
            current_size, int(current_shell), particle_ft.device
        )
        shell_index = current_shells[normalizer_mask]
        sigma = sigma2_by_shell.to(
            device=particle_ft.device, dtype=particle_ft.real.dtype
        )[:, shell_index]
        logsigma = torch.log(
            (2.0 * math.pi * sigma).clamp_min(
                torch.finfo(particle_ft.real.dtype).tiny
            )
        ).sum(dim=-1)
        return highres, logsigma

    def _dense_log_prior(
        self,
        bank: GlobalProjectionBank,
        batch_size: int,
        *,
        offset_prior_angstrom: Tensor,
        orientation_prior_deg: Tensor | None,
        dtype: torch.dtype,
        device: torch.device,
    ) -> Tensor:
        class_log = exact_log_class_prior(
            self.class_probabilities.to(device=device, dtype=torch.float64)
        ).to(dtype)
        translations = bank.translations_angstrom.to(device=device, dtype=dtype)
        centres = offset_prior_angstrom.to(device=device, dtype=dtype).reshape(batch_size, 1, 2)
        if self.config.sigma_offset_angstrom <= 0:
            trans_prior = torch.ones(
                (batch_size, translations.shape[0]), device=device, dtype=dtype
            )
        else:
            delta = translations.unsqueeze(0) - centres
            trans_prior = torch.exp(
                -0.5
                * delta.square().sum(dim=-1)
                / (self.config.sigma_offset_angstrom**2)
            )
            trans_prior = trans_prior / trans_prior.mean(dim=-1, keepdim=True).clamp_min(
                torch.finfo(dtype).tiny
            )
        trans_log = torch.log(trans_prior.clamp_min(torch.finfo(dtype).tiny))

        angles = bank.angles_deg.to(device=device, dtype=dtype)
        if orientation_prior_deg is None or not any(
            value > 0
            for value in (
                self.config.sigma_rot_deg,
                self.config.sigma_tilt_deg,
                self.config.sigma_psi_deg,
            )
        ):
            orient_log = torch.zeros(
                (batch_size, angles.shape[0]), device=device, dtype=dtype
            )
        else:
            centre = orientation_prior_deg.to(device=device, dtype=dtype).reshape(
                batch_size, 3
            )
            rot = torch.deg2rad(angles[:, 0])
            tilt = torch.deg2rad(angles[:, 1])
            xyz = torch.stack(
                (
                    torch.sin(tilt) * torch.cos(rot),
                    torch.sin(tilt) * torch.sin(rot),
                    torch.cos(tilt),
                ),
                dim=-1,
            )
            crot = torch.deg2rad(centre[:, 0])
            ctilt = torch.deg2rad(centre[:, 1])
            cxyz = torch.stack(
                (
                    torch.sin(ctilt) * torch.cos(crot),
                    torch.sin(ctilt) * torch.sin(crot),
                    torch.cos(ctilt),
                ),
                dim=-1,
            )
            angular = torch.rad2deg(
                torch.acos(torch.clamp(cxyz @ xyz.transpose(0, 1), -1.0, 1.0))
            )
            exponent = torch.zeros_like(angular)
            sdir = max(float(self.config.sigma_rot_deg), float(self.config.sigma_tilt_deg))
            if sdir > 0:
                exponent = exponent + angular.square() / (2.0 * sdir * sdir)
            if self.config.sigma_psi_deg > 0:
                dpsi = wrapped_angle_difference_deg(
                    angles[:, 2].unsqueeze(0), centre[:, 2].unsqueeze(1)
                )
                exponent = exponent + dpsi.square() / (
                    2.0 * self.config.sigma_psi_deg**2
                )
            orient_prior = torch.exp(-exponent)
            orient_prior = orient_prior / orient_prior.mean(
                dim=-1, keepdim=True
            ).clamp_min(torch.finfo(dtype).tiny)
            orient_log = torch.log(orient_prior.clamp_min(torch.finfo(dtype).tiny))

        if self.direction_priors is None:
            class_mean = self.class_probabilities.to(
                device=device, dtype=dtype
            ).mean()
            direction_log = torch.full(
                (len(class_log), bank.number_of_orientations),
                -torch.log(class_mean.clamp_min(torch.finfo(dtype).tiny)),
                device=device,
                dtype=dtype,
            )
        else:
            tiny = torch.finfo(dtype).tiny
            conditional = self.direction_priors.to(device=device, dtype=dtype)
            row_sum = conditional.sum(dim=-1, keepdim=True)
            conditional = torch.where(
                row_sum > 0,
                conditional / row_sum.clamp_min(tiny),
                torch.full_like(conditional, 1.0 / conditional.shape[-1]),
            )
            class_probability = self.class_probabilities.to(
                device=device, dtype=dtype
            )
            joint_mean = (conditional * class_probability[:, None]).mean()
            dp = conditional[:, bank.direction_indices.to(device=device)]
            direction_log = torch.where(
                dp > 0,
                torch.log(dp.clamp_min(tiny))
                - torch.log(joint_mean.clamp_min(tiny)),
                torch.full_like(dp, -torch.inf),
            )

        return (
            class_log.reshape(1, -1, 1, 1)
            + direction_log.reshape(1, len(class_log), -1, 1)
            + orient_log.reshape(batch_size, 1, -1, 1)
            + trans_log.reshape(batch_size, 1, 1, -1)
        )

    def run_local_batch(self, *args, **kwargs):
        from .local_search import run_local_batch
        return run_local_batch(self, *args, **kwargs)

    @torch.no_grad()
    def run_global_batch(
        self,
        particle_ft: Tensor,
        ctf: Tensor,
        sigma2_by_shell: Tensor,
        *,
        offset_prior_angstrom: Tensor,
        orientation_prior_deg: Tensor | None,
        pixel_size: float,
        bank: GlobalProjectionBank | None = None,
    ) -> DenseBatchExpectation:
        """Matrix-based global orientation/translation expectation."""

        if self.config.skip_align or self.config.skip_rotate:
            raise RuntimeError("run_global_batch is only valid for global rotation search")
        if particle_ft.ndim == 2:
            particle_ft = particle_ft.unsqueeze(0)
        if ctf.ndim == 2:
            ctf = ctf.unsqueeze(0)
        if sigma2_by_shell.ndim == 1:
            sigma2_by_shell = sigma2_by_shell.unsqueeze(0)
        batch_size = int(particle_ft.shape[0])
        if ctf.shape[0] != batch_size or sigma2_by_shell.shape[0] != batch_size:
            raise ValueError("particle, CTF and sigma2 batch sizes must match")
        source_signature = self._sync_source_caches()
        if bank is not None and bank.source_signature is not None and bank.source_signature != source_signature:
            raise RuntimeError("stale projection bank: source reference/support changed; rebuild the bank")
        bank = bank or self.build_global_projection_bank(pixel_size=pixel_size)
        device = particle_ft.device
        dtype = particle_ft.real.dtype
        size = bank.image_size
        image = self._window_rfft(particle_ft, size)
        ctf_window = self._window_rfft(ctf, size)
        mask = likelihood_rfft_mask(size, bank.maximum_shell, device, firstiter_cc=self.config.firstiter_cc)
        shells = rounded_shell_indices_2d(size, device)
        active_shells = shells[mask]
        image_active = image[:, mask]
        ctf_active = ctf_window[:, mask].to(dtype=dtype)
        invsigma = likelihood_inverse_noise(sigma2_by_shell.to(device=device, dtype=dtype),
            active_shells, firstiter_cc=self.config.firstiter_cc)
        highres, logsigma = self._highres_terms_batch(
            particle_ft, sigma2_by_shell, self.sizes.current_shell
        )

        phase_active = self._cached_spectral_view(
            ('coarse-phase', size, bank.maximum_shell), bank.phase_factors, mask, active_shells.numel())
        if phase_active is None:
            phase_active = bank.phase_factors.to(device=device)[:, mask]
        shifted = image_active.unsqueeze(1) * phase_active.unsqueeze(0)
        xnorm = (
            (image_active.real.square() + image_active.imag.square()) * invsigma
        ).sum(dim=-1)

        nc = bank.number_of_classes
        no = bank.number_of_orientations
        nt = bank.number_of_translations
        diff2 = torch.empty((batch_size, nc, no, nt), device=device, dtype=dtype)
        cc_all = (
            torch.empty_like(diff2) if self.config.firstiter_cc else None
        )
        projection_active = self._cached_spectral_view(
            ('coarse-projection', size, bank.maximum_shell), bank.projections, mask, active_shells.numel())
        if projection_active is None:
            projection_active = bank.projections.to(device=device)[..., mask]
        chunk = max(1, int(self.config.chunk_size))
        for start in range(0, no, chunk):
            stop = min(start + chunk, no)
            reference = projection_active[:, start:stop, :]
            prediction = reference.unsqueeze(0) * ctf_active[:, None, None, :]
            weighted_prediction = prediction * invsigma[:, None, None, :]
            flattened = weighted_prediction.reshape(batch_size, -1, prediction.shape[-1])
            cross = torch.bmm(
                shifted.real,
                flattened.real.transpose(1, 2),
            ) + torch.bmm(
                shifted.imag,
                flattened.imag.transpose(1, 2),
            )
            cross = cross.reshape(batch_size, nt, nc, stop - start).permute(
                0, 2, 3, 1
            )
            pnorm = (
                (prediction.real.square() + prediction.imag.square())
                * invsigma[:, None, None, :]
            ).sum(dim=-1)
            low_resolution_diff2 = 0.5 * (
                xnorm[:, None, None, None]
                + pnorm[..., None]
                - 2.0 * cross
            )
            # The matrix identity is algebraically non-negative; clamp only
            # cancellation-sized negative roundoff that a direct sum of squared
            # residuals cannot produce.
            diff2[:, :, start:stop, :] = torch.clamp(
                low_resolution_diff2, min=0.0
            ) + highres[:, None, None, None]

            if cc_all is not None:
                raw = prediction.reshape(batch_size, -1, prediction.shape[-1])
                raw_cross = torch.bmm(
                    shifted.real, raw.real.transpose(1, 2)
                ) + torch.bmm(shifted.imag, raw.imag.transpose(1, 2))
                raw_cross = raw_cross.reshape(
                    batch_size, nt, nc, stop - start
                ).permute(0, 2, 3, 1)
                raw_pnorm = (
                    prediction.real.square() + prediction.imag.square()
                ).sum(dim=-1)
                raw_xnorm = (
                    image_active.real.square() + image_active.imag.square()
                ).sum(dim=-1)
                cc_all[:, :, start:stop, :] = raw_cross / torch.sqrt(
                    (
                        raw_pnorm[..., None]
                        * raw_xnorm[:, None, None, None]
                    ).clamp_min(torch.finfo(dtype).tiny)
                )

        log_prior = self._dense_log_prior(
            bank,
            batch_size,
            offset_prior_angstrom=offset_prior_angstrom,
            orientation_prior_deg=orientation_prior_deg,
            dtype=torch.float64,
            device=device,
        )
        flat_prior = log_prior.reshape(batch_size, -1)
        flat_diff = diff2.reshape(batch_size, -1)
        valid = torch.isfinite(flat_prior)
        if not bool(torch.all(valid.any(dim=-1))):
            raise RuntimeError("at least one particle has no hypothesis with non-zero prior")

        if self.config.firstiter_cc:
            assert cc_all is not None
            flat_cc = cc_all.reshape(batch_size, -1)
            score = torch.where(valid, flat_cc, torch.full_like(flat_cc, -torch.inf))
            best = torch.argmax(score, dim=-1)
            posterior_flat = torch.zeros_like(score)
            posterior_flat.scatter_(1, best[:, None], 1.0)
            posterior64_flat = posterior_flat.to(torch.float64)
            significant_flat = posterior_flat.to(torch.bool)
            reported_count = torch.ones(
                batch_size, device=device, dtype=torch.long
            )
            significant_weight = torch.ones(
                batch_size, device=device, dtype=torch.float64
            )
            raw_log_evidence = score.gather(1, best[:, None]).squeeze(1).to(
                torch.float64
            )
            pmax = torch.ones(batch_size, device=device, dtype=torch.float64)
        else:
            selection = self._select_weights(
                flat_prior,
                flat_diff,
                self.config.adaptive_fraction,
            )
            posterior_flat = selection.posterior
            posterior64_flat = selection.posterior64
            significant_flat = selection.significant
            best = selection.best_index
            reported_count = selection.reported_significant_count
            significant_weight = selection.significant_weight
            raw_log_evidence = selection.log_evidence
            pmax = selection.pmax

        posterior = posterior_flat.reshape_as(diff2)
        significant = significant_flat.reshape_as(diff2)
        posterior64 = posterior64_flat.reshape_as(diff2)
        class_mass = (
            posterior64 * significant.to(torch.float64)
        ).sum(dim=(2, 3))
        dll = (
            raw_log_evidence
            if self.config.firstiter_cc
            else raw_log_evidence - logsigma.to(torch.float64)
        )
        return DenseBatchExpectation(
            bank=bank,
            diff2=diff2,
            log_prior=log_prior,
            posterior=posterior,
            significant=significant,
            class_mass=class_mass,
            best_flat_index=best,
            pmax=pmax,
            log_likelihood_contribution=dll,
            highres_xi2_half=highres,
            log_sigma2=logsigma,
            reported_significant_count=reported_count,
            significant_weight=significant_weight,
            log_evidence=raw_log_evidence,
            cross_correlation=cc_all,
        )

    def _fine_sampling_tensors_for_order(
        self,
        order: int,
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> tuple[Tensor, Tensor, Tensor, Tensor]:
        cached = self._fine_sampling_tensors.get(int(order))
        if cached is not None:
            return cached
        table: FineSamplingTable = self.sampling.fine_sampling_table(order)
        result = (
            torch.as_tensor(table.orientation_angles, device=device, dtype=dtype),
            torch.as_tensor(table.direction_indices, device=device, dtype=torch.long),
            torch.as_tensor(table.orientation_ids, device=device, dtype=torch.long),
            torch.as_tensor(table.translations, device=device, dtype=dtype),
        )
        self._fine_sampling_tensors[int(order)] = result
        return result

    @torch.no_grad()
    def _build_sparse_fine_projection_blocks(
        self,
        parent_class_indices: Tensor,
        parent_orientation_indices: Tensor,
        fine_angles: Tensor,
        *,
        order: int,
        image_size: int,
    ) -> tuple[FineProjectionBlocks, Tensor]:
        """Build/cache one child-orientation block per unique coarse parent pose."""

        self._sync_source_caches()
        coarse_orientations = int(fine_angles.shape[0])
        block_key = (
            parent_class_indices.to(torch.long) * coarse_orientations
            + parent_orientation_indices.to(torch.long)
        )
        unique_key, parent_inverse = torch.unique(
            block_key, sorted=True, return_inverse=True
        )
        unique_class = torch.div(
            unique_key, coarse_orientations, rounding_mode="floor"
        )
        unique_orientation = torch.remainder(unique_key, coarse_orientations)
        key_values = [int(value) for value in unique_key.detach().cpu().tolist()]
        class_values = [
            int(value) for value in unique_class.detach().cpu().tolist()
        ]
        orientation_values = [
            int(value) for value in unique_orientation.detach().cpu().tolist()
        ]

        missing_by_class: dict[int, list[tuple[int, int]]] = {}
        for position, key_value in enumerate(key_values):
            class_index = class_values[position]
            coarse_index = orientation_values[position]
            cache_key = (int(image_size), int(order), class_index, coarse_index)
            if cache_key not in self._fine_projection_block_cache:
                missing_by_class.setdefault(class_index, []).append(
                    (key_value, coarse_index)
                )

        orientation_children = int(fine_angles.shape[1])
        target_shape = (int(image_size), int(image_size) // 2 + 1)
        for class_index, rows in missing_by_class.items():
            coarse_index = torch.as_tensor(
                [row[1] for row in rows],
                device=fine_angles.device,
                dtype=torch.long,
            )
            angles = fine_angles.index_select(0, coarse_index).reshape(-1, 3)
            parts: list[Tensor] = []
            chunk = max(1, int(self.config.chunk_size))
            for start in range(0, int(angles.shape[0]), chunk):
                projected = self.projector(
                    class_index, angles[start : start + chunk], int(image_size)
                )
                if projected.ndim == 2:
                    projected = projected.unsqueeze(0)
                if tuple(projected.shape[-2:]) != target_shape:
                    projected = self._window_rfft(projected, int(image_size))
                parts.append(projected)
            projected_all = torch.cat(parts, dim=0).reshape(
                len(rows), orientation_children, *target_shape
            )
            for row_index, (_key_value, coarse_index_value) in enumerate(rows):
                cache_key = (
                    int(image_size),
                    int(order),
                    int(class_index),
                    int(coarse_index_value),
                )
                # Every row in projected_all is cached, so retaining views into
                # the shared contiguous allocation avoids one small CUDA clone
                # launch per coarse orientation without wasting backing storage.
                self._fine_projection_block_cache[cache_key] = projected_all[
                    row_index
                ]

        blocks = torch.stack(
            [
                self._fine_projection_block_cache[
                    (
                        int(image_size),
                        int(order),
                        class_values[position],
                        orientation_values[position],
                    )
                ]
                for position in range(len(key_values))
            ],
            dim=0,
        )
        block_angles = fine_angles.index_select(0, unique_orientation)
        return (
            FineProjectionBlocks(
                keys=unique_key,
                class_indices=unique_class,
                coarse_orientation_indices=unique_orientation,
                angles_deg=block_angles,
                projections=blocks,
            ),
            parent_inverse,
        )

    @torch.no_grad()
    def for_weighted_sums(self, result, *, pixel_size: float):
        """Restore current-size projections/phases without changing a posterior.

        Strict highres restricts E-step likelihoods only. Return a separate
        view for M-step consumers; never zero-pad a smaller Fourier projection.
        Class3D's overridden builders keep the resulting projection stores lazy
        and subject to the same bounded cache as the likelihood stores.
        """
        size = int(self.sizes.current_size)
        counters = getattr(self, 'memory_counters', None)
        if counters is not None:
            counters['weighted_sum_image_size_max'] = max(counters.get('weighted_sum_image_size_max', 0), size)
        if isinstance(result, DenseBatchExpectation):
            if result.bank.image_size == size:
                return result
            bank = self.build_global_projection_bank(
                pixel_size=pixel_size, image_size=size, maximum_shell=size // 2)
            return replace(result, bank=bank)
        if not isinstance(result, SparseAdaptiveBatchExpectation):
            return result
        if result.phase_factors.shape[-2] == size:
            return result
        order = int(self.config.adaptive_oversampling)
        device, dtype = result.child_angles_deg.device, result.child_angles_deg.dtype
        tensors, parent_geometry, original_ids = self._fine_geometry_for_parents(
            result.parent_orientation_indices,order,device=device,dtype=dtype)
        angles, _, _, translations = tensors
        blocks, parent_index = self._parent_projection_blocks(
            result.parent_class_indices,parent_geometry,angles,original_ids,order=order,image_size=size)
        key = (size, order)
        phases = self._fine_phase_cache.get(key)
        if phases is None:
            phases = phase_shift_rfft(
                (size, size // 2 + 1), translations.reshape(-1, 2) / float(pixel_size),
                device, dtype, original_size=self.sizes.original_size).reshape(
                    *translations.shape[:2], size, size // 2 + 1).contiguous()
            self._fine_phase_cache[key] = phases
        return replace(result, projection_blocks=blocks,
                       parent_projection_block_indices=parent_index, phase_factors=phases)

    def _fine_geometry_for_parents(self,parents,order,*,device,dtype):
        return self._fine_sampling_tensors_for_order(order,device=device,dtype=dtype),parents,None

    def _parent_projection_blocks(self,classes,parents,angles,original_ids,*,order,image_size):
        blocks,inverse=self._build_sparse_fine_projection_blocks(classes,parents,angles,order=order,image_size=image_size)
        if original_ids is not None:
            original=original_ids.index_select(0,blocks.coarse_orientation_indices)
            blocks=replace(blocks,coarse_orientation_indices=original,
                keys=blocks.class_indices*self.sampling.number_of_orientations+original)
            blocks.projections.original_parent_ids=original_ids.detach().cpu().numpy()
        return blocks,inverse

    @torch.no_grad()
    def run_sparse_adaptive_batch(
        self,
        particle_ft: Tensor,
        ctf: Tensor,
        sigma2_by_shell: Tensor,
        *,
        offset_prior_angstrom: Tensor,
        orientation_prior_deg: Tensor | None,
        pixel_size: float,
        coarse: DenseBatchExpectation | None = None,
        coarse_bank: GlobalProjectionBank | None = None,
        scores_only: bool = False,
        geometry_only: bool = False,
    ) -> SparseAdaptiveBatchExpectation:
        """Run a batched sparse RELION coarse-to-fine expectation pass.

        The first pass is the existing dense matrix scorer at ``coarse_size``.
        Only significant coarse parent tiles are expanded.  Fine projections are
        generated in vectorised class/coarse-orientation blocks and cached across
        particle batches for the duration of the iteration.
        """

        order = int(self.config.adaptive_oversampling)
        if order <= 0:
            raise RuntimeError("sparse adaptive expectation requires oversampling > 0")
        if self.config.skip_align or self.config.skip_rotate:
            raise RuntimeError("sparse adaptive expectation requires global rotation search")
        if particle_ft.ndim == 2:
            particle_ft = particle_ft.unsqueeze(0)
        if ctf.ndim == 2:
            ctf = ctf.unsqueeze(0)
        if sigma2_by_shell.ndim == 1:
            sigma2_by_shell = sigma2_by_shell.unsqueeze(0)
        batch_size = int(particle_ft.shape[0])
        if ctf.shape[0] != batch_size or sigma2_by_shell.shape[0] != batch_size:
            raise ValueError("particle, CTF and sigma2 batch sizes must match")

        if coarse is None:
            bank = coarse_bank or self.build_global_projection_bank(
                pixel_size=pixel_size,
                image_size=self.sizes.coarse_size,
                maximum_shell=self.sizes.likelihood_shell(False),
            )
            coarse = self.run_global_batch(
                particle_ft,
                ctf,
                sigma2_by_shell,
                offset_prior_angstrom=offset_prior_angstrom,
                orientation_prior_deg=orientation_prior_deg,
                pixel_size=pixel_size,
                bank=bank,
            )
        else:
            bank = coarse.bank
        source_signature = self._sync_source_caches()
        if bank.source_signature is not None and bank.source_signature != source_signature:
            raise RuntimeError("stale coarse result: source reference/support changed; rerun the coarse pass")

        parent = torch.nonzero(coarse.significant, as_tuple=False)
        if parent.numel() == 0:
            raise RuntimeError("adaptive coarse pass retained no parent hypotheses")
        parent_particle = parent[:, 0].to(torch.long)
        parent_class = parent[:, 1].to(torch.long)
        parent_local_orientation = parent[:, 2].to(torch.long)
        parent_orientation = coarse.global_orientations(parent_particle, parent_local_orientation)
        parent_translation = parent[:, 3].to(torch.long)
        parent_counts = torch.bincount(parent_particle, minlength=batch_size)
        if not bool(torch.all(parent_counts > 0)):
            raise RuntimeError("at least one particle has no significant coarse parent")

        device = particle_ft.device
        dtype = particle_ft.real.dtype
        with (self.detail_timer.section('local.fine_sampling',full=True) if getattr(self,'detail_timer',None) is not None and getattr(self,'local_buffer',None) is not None else nullcontext()):
            tensors,parent_geometry,original_ids=self._fine_geometry_for_parents(parent_orientation,order,device=device,dtype=dtype)
        fine_angles_all, fine_directions_all, fine_ids_all, fine_translations_all = tensors
        child_angles = fine_angles_all.index_select(0, parent_geometry)
        child_directions = fine_directions_all.index_select(0, parent_geometry)
        child_orientation_ids = fine_ids_all.index_select(0, parent_geometry)
        child_translations = fine_translations_all.index_select(
            0, parent_translation
        )
        projection_blocks, parent_block_index = (
            self._parent_projection_blocks(
                parent_class,
                parent_geometry,
                fine_angles_all,
                original_ids,
                order=order,
                image_size=self.sizes.likelihood_image_size(True),
            )
        )

        size = int(self.sizes.likelihood_image_size(True))
        maximum_shell = int(self.sizes.likelihood_shell(True))
        counters = getattr(self, 'memory_counters', None)
        if counters is not None:
            counters['fine_likelihood_image_size_max'] = max(counters.get('fine_likelihood_image_size_max', 0), size)
            counters['fine_likelihood_shell_max'] = max(counters.get('fine_likelihood_shell_max', 0), maximum_shell)
        mask = likelihood_rfft_mask(size, maximum_shell, device, firstiter_cc=self.config.firstiter_cc)
        shells = rounded_shell_indices_2d(size, device)
        active_shells = shells[mask]
        image = self._window_rfft(particle_ft, size)
        ctf_window = self._window_rfft(ctf, size).to(dtype=dtype)
        image_active = image[:, mask]
        ctf_active = ctf_window[:, mask]
        invsigma = likelihood_inverse_noise(sigma2_by_shell.to(device=device, dtype=dtype),
            active_shells, firstiter_cc=self.config.firstiter_cc)
        highres, logsigma = self._highres_terms_batch(
            particle_ft, sigma2_by_shell, self.sizes.current_shell
        )

        phase_cache_key = (size, order)
        phase_table = self._fine_phase_cache.get(phase_cache_key)
        if phase_table is None:
            phase_table = phase_shift_rfft(
                (size, size // 2 + 1),
                fine_translations_all.reshape(-1, 2) / float(pixel_size),
                device,
                dtype,
                original_size=self.sizes.original_size,
            ).reshape(
                fine_translations_all.shape[0],
                fine_translations_all.shape[1],
                size,
                size // 2 + 1,
            ).contiguous()
            self._fine_phase_cache[phase_cache_key] = phase_table

        phase_active_table = self._cached_spectral_view(
            ('fine-phase', size, order, maximum_shell), phase_table, mask, active_shells.numel())
        # Projection blocks are rebuilt for each particle batch. Mask once
        # before repeated parent lookup, but never retain old batch allocations.
        fine_projection_active = None
        if self.config.cache_active_views and not geometry_only:
            source = projection_blocks.projections
            needed = (source.shape[0] * source.shape[1] * active_shells.numel()
                      * source.element_size())
            if needed + self._active_view_bytes <= self.config.active_view_cache_bytes:
                fine_projection_active = source[..., mask]
                self._active_view_peak_bytes = max(
                    self._active_view_peak_bytes, self._active_view_bytes + needed)

        nparent = int(parent.shape[0])
        norient_child = int(child_angles.shape[1])
        ntrans_child = int(child_translations.shape[1])
        diff2 = torch.empty(
            (nparent, norient_child, ntrans_child),
            device=device,
            dtype=dtype,
        )
        cc_all = torch.empty_like(diff2) if self.config.firstiter_cc else None
        from .fine_scoring import gather_active_child_rows
        candidate_execution = self.config.candidate_chunk_size > 0 or self.config.fine_score_mode != "sparse"
        active_indices = torch.nonzero(mask.flatten(), as_tuple=False).squeeze(-1) if candidate_execution else None
        parent_chunk = max(1, int(self.config.chunk_size))
        per_parent = 0
        streaming = getattr(self,'local_buffer',None) is not None
        if self.config.candidate_chunk_size > 0 and (not self.config.firstiter_cc or streaming):
            # Cap gathers, shifted images, predictions and matmul intermediates.
            per_parent = max(1, int(active_shells.numel()) * image.element_size()
                             * (4*ntrans_child + 5*norient_child + 8)
                             + norient_child*ntrans_child*image.real.element_size()*12)
            cap=parent_chunk if self.config.firstiter_cc else self.config.candidate_chunk_size
            parent_chunk = max(1, min(cap, self.config.candidate_work_bytes // per_parent))

        if geometry_only:
            if self.config.firstiter_cc:
                raise ValueError('Deferred fine geometry requires Gaussian likelihood')
            from .fine_scores import FineScoreBatch
            prior = coarse.log_prior[parent_particle, parent_class, parent_local_orientation, parent_translation]
            return FineScoreBatch(dict(coarse=coarse, projection_blocks=projection_blocks,
                parent_projection_block_indices=parent_block_index, parent_particle_indices=parent_particle,
                parent_class_indices=parent_class, parent_orientation_indices=parent_orientation,
                parent_translation_indices=parent_translation, child_angles_deg=child_angles,
                child_direction_indices=child_directions, child_orientation_ids=child_orientation_ids,
                child_translations_angstrom=child_translations, phase_factors=phase_table),
                diff2, prior[:, None, None].expand_as(diff2), highres, logsigma, {},
                dict(image=image_active, invsigma=invsigma, mask=mask,
                     active=torch.nonzero(mask.flatten(), as_tuple=False).flatten(), size=size))

        dense_stats = None
        cost_stats: dict[str, int] = {}
        # CC is winner-take-all: last-bit GEMM differences can choose a different
        # member of an exactly/near-tied pair. Keep its original scorer/chunks.
        dense_attempted = False
        if not self.config.firstiter_cc and not (hasattr(projection_blocks.projections,"fusion_available") and projection_blocks.projections.fusion_available()):
            if self.config.fine_score_mode == "dense":
                dense_attempted = True
            elif self.config.fine_score_mode == "auto":
                from .fine_scoring import estimate_fine_score_costs, plan_dense_parent_blocks
                dense_plan = plan_dense_parent_blocks(
                    active_pixels=int(active_shells.numel()),
                    real_bytes=image.real.element_size(),
                    complex_bytes=image.element_size(),
                    coarse_translations=int(phase_table.shape[0]),
                    translation_children=ntrans_child,
                    orientation_children=norient_child,
                    work_bytes=self.config.candidate_work_bytes,
                    cc=False,
                )
                # Exact active (particle,class,coarse-orientation) block counts.
                # This is only B int64 values on the host and avoids the old
                # fixed-density heuristic entirely.
                active_blocks_per_particle = (
                    coarse.significant.any(dim=-1).sum(dim=(1, 2)).detach().cpu().numpy()
                )
                cost = estimate_fine_score_costs(
                    nparent=nparent,
                    active_blocks_per_particle=active_blocks_per_particle,
                    active_pixels=int(active_shells.numel()),
                    coarse_translations=int(phase_table.shape[0]),
                    translation_children=ntrans_child,
                    orientation_children=norient_child,
                    sparse_parent_chunk=parent_chunk,
                    dense_plan=dense_plan,
                )
                dense_attempted = bool(cost["choose_dense"])
                cost_stats = {
                    "fine_cost_model_batches": 1,
                    "fine_cost_model_dense_batches": int(dense_attempted),
                    "fine_cost_model_sparse_batches": int(not dense_attempted),
                    "fine_cost_workspace_rejected_batches": int(not cost["dense_workspace_fits"]),
                    "fine_cost_active_blocks": int(cost["active_blocks"]),
                    "fine_cost_dense_children": int(cost["dense_children"]),
                    "fine_cost_sparse_children": int(cost["sparse_children"]),
                    "fine_cost_dense_calls": int(cost["dense_calls"]),
                    "fine_cost_sparse_tiles": int(cost["sparse_tiles"]),
                    "fine_cost_dense_block_fill_ppm": int(round(float(cost["dense_block_fill"]) * 1_000_000)),
                    "fine_cost_dense_advantage_milli": int(round(float(cost["dense_advantage"]) * 1000)),
                    "fine_cost_dense_units": int(round(float(cost["dense_units"]))) if math.isfinite(float(cost["dense_units"])) else 0,
                    "fine_cost_sparse_units": int(round(float(cost["sparse_units"]))),
                    "fine_cost_active_pixels": int(cost["active_pixels"]),
                    "fine_cost_dense_workspace_bytes": int(dense_plan["workspace_bytes"]),
                }
        if dense_attempted:
            from .fine_scoring import score_dense_parent_blocks
            with (self.detail_timer.section('fine.score',full=True) if getattr(self,'detail_timer',None) is not None else nullcontext()):
                dense_stats = score_dense_parent_blocks(
                    image_active=image_active, ctf_active=ctf_active, invsigma=invsigma,
                    highres=highres, projection_blocks=projection_blocks.projections,
                    phase_table=phase_table, active_indices=active_indices,
                    projection_active=fine_projection_active, phase_active=phase_active_table,
                    parent_counts=parent_counts, parent_block_indices=parent_block_index,
                    parent_translation_indices=parent_translation, output=diff2, cc_output=cc_all,
                    work_bytes=self.config.candidate_work_bytes,
                    execution=self.config.dense_fine_execution)
        execution_stats = dense_stats or dict(fine_dense_tiles=0, fine_dense_batches=0,
                                              fine_dense_evaluated_children=0, fine_sparse_tiles=0)
        execution_stats.update(cost_stats)
        if dense_stats is None:
            execution_stats['fine_sparse_batches'] = 1
            execution_stats['fine_dense_workspace_fallbacks'] = int(dense_attempted)
            if self.config.firstiter_cc:
                execution_stats['fine_cc_reference_batches'] = 1
            elif self.config.candidate_chunk_size > 0:
                execution_stats['fine_workspace_estimate_bytes'] = parent_chunk*per_parent
        with (self.detail_timer.section('fine.input_plan',full=True) if getattr(self,'detail_timer',None) is not None else nullcontext()):
            fine_inputs = None
            if (dense_stats is None and not self.config.firstiter_cc and active_indices is not None
                    and hasattr(projection_blocks.projections, 'prepare_fine_inputs')):
                fine_inputs = projection_blocks.projections.prepare_fine_inputs(
                    parent_block_index, image_active, ctf_active, invsigma, highres,
                    phase_active_table if phase_active_table is not None else phase_table.flatten(-2),
                    active_indices, phase_active=phase_active_table is not None,
                    work_bytes=self.config.candidate_work_bytes)

        with (self.detail_timer.section('fine.score',full=True) if getattr(self,'detail_timer',None) is not None else nullcontext()):
            legacy_start = 0
            if fine_inputs is not None:
                indexed_chunk = fine_inputs.parent_chunk(parent_chunk, self.config.candidate_chunk_size,
                                                         self.config.candidate_work_bytes, ntrans_child)
                execution_stats['fine_indexed_parent_chunk_max'] = indexed_chunk
                execution_stats['fine_legacy_parent_chunk_max'] = parent_chunk
                execution_stats['fine_workspace_estimate_bytes'] = fine_inputs.estimated_bytes + indexed_chunk*fine_inputs.tile_bytes_per_parent(ntrans_child)
                for start in range(0, nparent, indexed_chunk):
                    stop = min(start+indexed_chunk, nparent)
                    if not fine_inputs.score(start, stop, parent_particle, parent_translation, diff2):
                        # Only scores were written, never additive statistics. Recompute
                        # the entire failed large tile in ORIGINAL bounded chunks.
                        legacy_start = start
                        fine_inputs = None
                        execution_stats['fine_indexed_chunk_fallbacks'] = 1
                        break
                    execution_stats['fine_sparse_tiles'] += 1
                    execution_stats['fine_fused_tiles'] = execution_stats.get('fine_fused_tiles', 0)+1
                    execution_stats['fine_indexed_input_tiles'] = execution_stats.get('fine_indexed_input_tiles', 0)+1
                    legacy_start = stop
            if dense_stats is None and legacy_start < nparent and streaming and per_parent > self.config.candidate_work_bytes:
                raise MemoryError('One fine parent exceeds candidate workspace; increase --candidate-work-mib; no candidates were removed')
            for start in range(legacy_start, nparent if dense_stats is None else 0, parent_chunk):
                execution_stats['fine_sparse_tiles'] += 1
                stop = min(start + parent_chunk, nparent)
                particle_index = parent_particle[start:stop]
                selected_image = image_active.index_select(0, particle_index)
                selected_ctf = ctf_active.index_select(0, particle_index)
                selected_invsigma = invsigma.index_select(0, particle_index)
                phases = (phase_active_table.index_select(0, parent_translation[start:stop])
                          if phase_active_table is not None else (gather_active_child_rows(phase_table, parent_translation[start:stop], active_indices)
                              if candidate_execution else phase_table.index_select(0, parent_translation[start:stop])[..., mask]))
                shifted = selected_image[:, None, :] * phases
                if not self.config.firstiter_cc and hasattr(projection_blocks.projections,'fused_score'):
                    fused=projection_blocks.projections.fused_score(parent_block_index[start:stop],shifted,selected_ctf,
                        selected_invsigma,highres.index_select(0,particle_index),active_indices)
                    if fused is not None:
                        diff2[start:stop]=fused
                        execution_stats['fine_fused_tiles']=execution_stats.get('fine_fused_tiles',0)+1
                        continue
                reference = (fine_projection_active.index_select(0, parent_block_index[start:stop])
                             if fine_projection_active is not None else
                             (gather_active_child_rows(projection_blocks.projections, parent_block_index[start:stop], active_indices)
                              if candidate_execution else projection_blocks.projections.index_select(0, parent_block_index[start:stop])[..., mask]))
                prediction = reference * selected_ctf[:, None, :]
                if self.config.firstiter_cc and self.config.cc_score_only:
                    from .score_tiles import score_prediction_tile
                    cc_all[start:stop] = score_prediction_tile(
                        shifted, prediction, selected_invsigma,
                        highres.index_select(0, particle_index), cc=True)
                    diff2[start:stop] = -cc_all[start:stop]
                    execution_stats['fine_cc_only_tiles'] = execution_stats.get('fine_cc_only_tiles', 0) + 1
                    continue
                weighted_prediction = prediction * selected_invsigma[:, None, :]
                cross = torch.bmm(
                    shifted.real,
                    weighted_prediction.real.transpose(1, 2),
                ) + torch.bmm(
                    shifted.imag,
                    weighted_prediction.imag.transpose(1, 2),
                )
                xnorm = (
                    (shifted.real.square() + shifted.imag.square())
                    * selected_invsigma[:, None, :]
                ).sum(dim=-1)
                pnorm = (
                    (prediction.real.square() + prediction.imag.square())
                    * selected_invsigma[:, None, :]
                ).sum(dim=-1)
                local = 0.5 * (
                    pnorm[:, :, None]
                    + xnorm[:, None, :]
                    - 2.0 * cross.transpose(1, 2)
                )
                diff2[start:stop] = torch.clamp(local, min=0.0) + highres.index_select(
                    0, particle_index
                )[:, None, None]

                if cc_all is not None:
                    raw_cross = torch.bmm(
                        shifted.real, prediction.real.transpose(1, 2)
                    ) + torch.bmm(
                        shifted.imag, prediction.imag.transpose(1, 2)
                    )
                    raw_xnorm = (
                        shifted.real.square() + shifted.imag.square()
                    ).sum(dim=-1)
                    raw_pnorm = (
                        prediction.real.square() + prediction.imag.square()
                    ).sum(dim=-1)
                    cc_all[start:stop] = raw_cross.transpose(1, 2) / torch.sqrt(
                        (raw_pnorm[:, :, None] * raw_xnorm[:, None, :]).clamp_min(
                            torch.finfo(dtype).tiny
                        )
                    )

        if scores_only:
            if self.config.firstiter_cc:
                raise ValueError('Deferred fine posterior requires Gaussian likelihood')
            from .fine_scores import FineScoreBatch
            prior = coarse.log_prior[parent_particle, parent_class, parent_local_orientation, parent_translation]
            return FineScoreBatch(dict(coarse=coarse, projection_blocks=projection_blocks,
                parent_projection_block_indices=parent_block_index, parent_particle_indices=parent_particle,
                parent_class_indices=parent_class, parent_orientation_indices=parent_orientation,
                parent_translation_indices=parent_translation, child_angles_deg=child_angles,
                child_direction_indices=child_directions, child_orientation_ids=child_orientation_ids,
                child_translations_angstrom=child_translations, phase_factors=phase_table),
                diff2, prior[:, None, None].expand_as(diff2), highres, logsigma, execution_stats)

        with (self.detail_timer.section('fine.posterior',full=True) if getattr(self,'detail_timer',None) is not None else nullcontext()):
            # The input plan is batch-scoped, but no longer needed while allocating
            # posterior/sort workspaces. Release its packed metadata and conversions.
            del fine_inputs
            weight_prior_dtype = (
                torch.float32 if self.config.weight_precision == "float32" else torch.float64
            )
            # Keep the public/debug prior at the historical coarse-prior dtype, but
            # pack the enormous per-particle fine-selection rectangle at native
            # hypothesis-weight precision. This removes FP64 fine-weight traffic
            # without changing the external SparseAdaptiveBatchExpectation API.
            parent_prior = coarse.log_prior[
                parent_particle, parent_class, parent_local_orientation, parent_translation
            ]
            parent_prior_weight = parent_prior.to(weight_prior_dtype)
            log_prior = parent_prior[:, None, None].expand(
                nparent, norient_child, ntrans_child
            )
            children_per_parent = norient_child * ntrans_child
            parent_offsets = torch.cumsum(parent_counts, dim=0) - parent_counts
            local_parent = torch.arange(nparent, device=device) - parent_offsets.index_select(
                0, parent_particle
            )
            child_linear = torch.arange(children_per_parent, device=device)
            slots = local_parent[:, None] * children_per_parent + child_linear[None, :]
            rows = parent_particle[:, None].expand_as(slots)
            maximum_hypotheses = int(parent_counts.max().item()) * children_per_parent
            packed_diff = torch.full(
                (batch_size, maximum_hypotheses),
                torch.inf,
                device=device,
                dtype=dtype,
            )
            packed_prior = torch.full(
                (batch_size, maximum_hypotheses),
                -torch.inf,
                device=device,
                dtype=weight_prior_dtype,
            )
            packed_diff[rows, slots] = diff2.reshape(nparent, children_per_parent)
            packed_prior[rows, slots] = parent_prior_weight[:, None].expand_as(slots)

            if self.config.firstiter_cc:
                if cc_all is None:
                    raise RuntimeError("first-iteration CC requested without CC scores")
                packed_cc = torch.full_like(packed_diff, -torch.inf)
                packed_cc[rows, slots] = cc_all.reshape(nparent, children_per_parent)
                valid = torch.isfinite(packed_prior)
                score = torch.where(valid, packed_cc, torch.full_like(packed_cc, -torch.inf))
                best_slot = torch.argmax(score, dim=-1)
                packed_posterior = torch.zeros_like(packed_diff)
                packed_posterior.scatter_(1, best_slot[:, None], 1.0)
                packed_posterior64 = packed_posterior.to(torch.float64)
                packed_significant = packed_posterior.to(torch.bool)
                fine_count = torch.ones(batch_size, device=device, dtype=torch.long)
                fine_threshold = torch.ones(
                    batch_size, device=device, dtype=torch.float64
                )
                fine_evidence = score.gather(1, best_slot[:, None]).squeeze(1).to(
                    torch.float64
                )
                pmax = torch.ones(batch_size, device=device, dtype=torch.float64)
            else:
                selection = self._select_weights(
                    packed_prior,
                    packed_diff,
                    self.config.adaptive_fraction,
                )
                packed_posterior = selection.posterior
                packed_posterior64 = selection.posterior64
                packed_significant = selection.significant
                best_slot = selection.best_index
                fine_count = selection.reported_significant_count
                fine_threshold = selection.significant_weight
                fine_evidence = selection.log_evidence
                pmax = selection.pmax

            posterior = packed_posterior[rows, slots].reshape_as(diff2)
            posterior64 = packed_posterior64[rows, slots].reshape_as(diff2)
            significant = packed_significant[rows, slots].reshape_as(diff2)
            parent_mass64 = (
                posterior64 * significant.to(torch.float64)
            ).sum(dim=(1, 2))
            class_mass_flat = torch.zeros(
                batch_size * coarse.bank.number_of_classes,
                device=device,
                dtype=torch.float64,
            )
            class_mass_flat.scatter_add_(
                0,
                parent_particle * coarse.bank.number_of_classes + parent_class,
                parent_mass64,
            )
            class_mass = class_mass_flat.reshape(
                batch_size, coarse.bank.number_of_classes
            )
            best_parent_local = torch.div(
                best_slot, children_per_parent, rounding_mode="floor"
            )
            best_parent = parent_offsets + best_parent_local
            best_child = torch.remainder(best_slot, children_per_parent)
            best_orientation_child = torch.div(
                best_child, ntrans_child, rounding_mode="floor"
            )
            best_translation_child = torch.remainder(best_child, ntrans_child)
            dll = (
                fine_evidence
                if self.config.firstiter_cc
                else fine_evidence - logsigma.to(torch.float64)
            )
            return SparseAdaptiveBatchExpectation(
                coarse=coarse,
                projection_blocks=projection_blocks,
                parent_projection_block_indices=parent_block_index,
                parent_particle_indices=parent_particle,
                parent_class_indices=parent_class,
                parent_orientation_indices=parent_orientation,
                parent_translation_indices=parent_translation,
                child_angles_deg=child_angles,
                child_direction_indices=child_directions,
                child_orientation_ids=child_orientation_ids,
                child_translations_angstrom=child_translations,
                phase_factors=phase_table,
                diff2=diff2,
                log_prior=log_prior,
                posterior=posterior,
                significant=significant,
                class_mass=class_mass,
                parent_mass64=parent_mass64,
                fine_reported_significant_count=fine_count,
                fine_significant_weight=fine_threshold,
                fine_log_evidence=fine_evidence,
                best_parent_indices=best_parent,
                best_orientation_child_indices=best_orientation_child,
                best_translation_child_indices=best_translation_child,
                pmax=pmax,
                log_likelihood_contribution=dll,
                highres_xi2_half=highres,
                log_sigma2=logsigma,
                cross_correlation=cc_all,
                execution_stats=execution_stats,
            )

    def _score_points(
        self,
        points: Sequence[SamplingPoint],
        particle_ft_full: Tensor,
        ctf_full: Tensor,
        invsigma2_by_shell: Tensor,
        *,
        maximum_shell: int,
        image_size: int,
        offset_prior_angstrom: Tensor,
        orientation_prior_deg: Tensor | None,
        pixel_size: float,
        highres_xi2_half: float,
        firstiter_cc: bool,
        direction_oversampling_order: int = 0,
        log_prior_override: Tensor | None = None,
    ) -> HypothesisTable:
        device = particle_ft_full.device
        real_dtype = particle_ft_full.real.dtype
        image = self._window_rfft(particle_ft_full, image_size)
        ctf = self._window_rfft(ctf_full, image_size)
        shells = rounded_shell_indices_2d(image_size, device)
        mask = likelihood_rfft_mask(image_size, maximum_shell, device, firstiter_cc=firstiter_cc)
        sigma_lookup = invsigma2_by_shell.to(device=device, dtype=real_dtype)
        invsigma = sigma_lookup[shells.clamp_max(len(sigma_lookup) - 1)]
        invsigma = torch.where(mask & (shells < len(sigma_lookup)), invsigma, torch.zeros_like(invsigma))
        if log_prior_override is None:
            log_prior = self._priors(
                points,
                device,
                torch.float64,
                offset_prior_angstrom,
                orientation_prior_deg,
                direction_oversampling_order=direction_oversampling_order,
            )
        else:
            if tuple(log_prior_override.shape) != (len(points),):
                raise ValueError("log_prior_override must have one value per point")
            log_prior = log_prior_override.to(device=device, dtype=torch.float64)
        count=len(points)
        diff2=torch.empty(count,device=device,dtype=real_dtype)
        cc_all=torch.empty_like(diff2)
        pnorm_all=torch.empty_like(diff2)
        groups: dict[tuple[int,float,float,float],list[int]]={}
        for idx,p in enumerate(points):
            key=(p.class_index,round(p.rot,10),round(p.tilt,10),round(p.psi,10))
            groups.setdefault(key,[]).append(idx)
        for (class_index,rot,tilt,psi),indices in groups.items():
            angle=torch.tensor([[rot,tilt,psi]],device=device,dtype=real_dtype)
            ref=self.projector(class_index,angle,image_size)
            if ref.ndim==2:ref=ref.unsqueeze(0)
            ref=ref[0]
            if tuple(ref.shape[-2:])!=tuple(image.shape[-2:]):ref=self._window_rfft(ref,image_size)
            prediction=ctf*ref
            ids=torch.tensor(indices,device=device,dtype=torch.long)
            xy_pixels=torch.tensor([(points[j].x/pixel_size,points[j].y/pixel_size) for j in indices],
                                   device=device,dtype=real_dtype)
            shifted=image.unsqueeze(0)*phase_shift_rfft(
                image.shape[-2:],
                xy_pixels,
                device,
                real_dtype,
                original_size=self.sizes.original_size,
            )
            residual=shifted-prediction.unsqueeze(0)
            d=0.5*torch.sum((residual.real.square()+residual.imag.square())*invsigma,dim=(-2,-1))
            d=d+float(highres_xi2_half)
            cross=torch.sum((shifted.conj()*prediction.unsqueeze(0)).real*mask,dim=(-2,-1))
            pnorm=torch.sum((prediction.real.square()+prediction.imag.square())*mask).expand(len(indices))
            xnorm=torch.sum((shifted.real.square()+shifted.imag.square())*mask,dim=(-2,-1))
            cc=cross/torch.sqrt((pnorm*xnorm).clamp_min(torch.finfo(real_dtype).tiny))
            diff2[ids]=d;cc_all[ids]=cc;pnorm_all[ids]=pnorm

        valid = torch.isfinite(log_prior)
        if not torch.any(valid):
            raise RuntimeError("all hypotheses have zero prior")
        if firstiter_cc:
            score = torch.where(valid, cc_all, torch.full_like(cc_all, -torch.inf))
            winner = int(torch.argmax(score))
            posterior = torch.zeros_like(score)
            posterior[winner] = 1.0
            posterior64 = posterior.to(torch.float64)
            sig = posterior.bool()
            reported_count = 1
            significant_weight = torch.ones((), device=device, dtype=torch.float64)
            log_evidence = score[winner].to(torch.float64)
            pmax = torch.ones((), device=device, dtype=torch.float64)
        else:
            selection = self._select_weights(
                log_prior.unsqueeze(0),
                diff2.unsqueeze(0),
                self.config.adaptive_fraction,
            )
            posterior = selection.posterior[0]
            posterior64 = selection.posterior64[0]
            sig = selection.significant[0]
            reported_count = int(selection.reported_significant_count[0].item())
            significant_weight = selection.significant_weight[0]
            log_evidence = selection.log_evidence[0]
            pmax = selection.pmax[0]
        return HypothesisTable(
            points=list(points),
            diff2=diff2,
            log_prior=log_prior,
            posterior=posterior,
            posterior64=posterior64,
            significant=sig,
            projection_norm=pnorm_all,
            cross_correlation=cc_all,
            reported_significant_count=reported_count,
            significant_weight=significant_weight,
            log_evidence=log_evidence,
            pmax=pmax,
        )

    @staticmethod
    def _highres_terms(
        particle_ft: Tensor,
        sigma2_by_shell: Tensor,
        current_shell: int,
    ) -> tuple[float, float]:
        """RELION class-independent high-resolution particle term and normalizer.

        The high-resolution ``Xi2`` term intentionally has no inverse-noise
        factor.  RELION's Gaussian normalizer covers only the current-size
        circular ``Mresol_fine`` support, not the high-resolution particle-only
        region of the original Fourier image.
        """
        n = particle_ft.shape[-2]
        shells = rounded_shell_indices_2d(n, particle_ft.device)
        ky = signed_fft_indices(n, device=particle_ft.device)
        duplicate = (torch.arange(n // 2 + 1, device=particle_ft.device)[None, :] == 0) & (ky[:, None] < 0)
        independent = (shells > 0) & (shells < len(sigma2_by_shell)) & ~duplicate
        high = independent & (shells > current_shell)
        power = particle_ft.real.square() + particle_ft.imag.square()
        highres_xi2_half = 0.5 * power[high].sum()
        sigma2 = sigma2_by_shell.to(device=particle_ft.device, dtype=particle_ft.real.dtype)
        current_size = min(n, max(2, 2 * int(current_shell)))
        current_shells = rounded_shell_indices_2d(current_size, particle_ft.device)
        normalizer_mask = independent_rfft_mask(
            current_size, int(current_shell), particle_ft.device
        )
        log_sigma = torch.log(
            (
                2.0
                * math.pi
                * sigma2[current_shells.clamp_max(len(sigma2) - 1)]
            ).clamp_min(torch.finfo(particle_ft.real.dtype).tiny)
        )
        return float(highres_xi2_half), float(log_sigma[normalizer_mask].sum())

    def run_particle(
        self,
        particle_ft: Tensor,
        ctf: Tensor,
        sigma2_by_shell: Tensor,
        *,
        fixed_angles: Sequence[float],
        fixed_translation_angstrom: Sequence[float],
        offset_prior_angstrom: Sequence[float] = (0.0, 0.0),
        orientation_prior_deg: Sequence[float] | None = None,
        pixel_size: float,
    ) -> ParticleExpectation:
        device = particle_ft.device
        dtype = particle_ft.real.dtype
        highres, logsigma = self._highres_terms(particle_ft, sigma2_by_shell, self.sizes.current_shell)
        invsigma = torch.zeros_like(sigma2_by_shell, device=device, dtype=dtype)
        positive = sigma2_by_shell.to(device=device, dtype=dtype) > 0
        invsigma[positive] = 1.0 / sigma2_by_shell.to(device=device, dtype=dtype)[positive]
        if not self.config.skip_align and not self.config.skip_rotate and self._global_coarse_points is not None:
            coarse_points=self._global_coarse_points
        else:
            coarse_points=list(self.sampling.coarse_points(
                len(self.class_probabilities), fixed_angles=np.asarray(fixed_angles),
                fixed_translation=fixed_translation_angstrom,
                skip_rotate=self.config.skip_rotate, skip_align=self.config.skip_align,
            ))
            if not self.config.skip_align and not self.config.skip_rotate:
                self._global_coarse_points=coarse_points
        offset_prior = torch.as_tensor(offset_prior_angstrom)
        orientation_prior = (
            None
            if orientation_prior_deg is None
            else torch.as_tensor(orientation_prior_deg)
        )
        fine_shell = self.sizes.likelihood_shell(True)
        if self.config.adaptive_oversampling <= 0:
            # RELION performs one expectation pass at current size when
            # adaptive oversampling is disabled.  Reusing the same table for the
            # public coarse/fine fields preserves the debug/API shape without a
            # second projector/scoring call.
            fine = self._score_points(
                coarse_points,
                particle_ft,
                ctf,
                invsigma,
                maximum_shell=fine_shell,
                image_size=self.sizes.likelihood_image_size(True),
                offset_prior_angstrom=offset_prior,
                orientation_prior_deg=orientation_prior,
                pixel_size=pixel_size,
                highres_xi2_half=highres,
                firstiter_cc=self.config.firstiter_cc,
                direction_oversampling_order=0,
            )
            coarse = fine
        else:
            coarse_shell = self.sizes.likelihood_shell(False)
            coarse = self._score_points(
                coarse_points, particle_ft, ctf, invsigma,
                maximum_shell=coarse_shell, image_size=self.sizes.coarse_size,
                offset_prior_angstrom=offset_prior,
                orientation_prior_deg=orientation_prior,
                pixel_size=pixel_size,
                highres_xi2_half=highres, firstiter_cc=self.config.firstiter_cc,
                direction_oversampling_order=0,
            )
            fine_points: list[SamplingPoint] = []
            fine_parent_positions: list[int] = []
            for parent_position, (p, keep) in enumerate(
                zip(coarse.points, coarse.significant.tolist())
            ):
                if keep:
                    children = self.sampling.fine_children(
                        p, self.config.adaptive_oversampling
                    )
                    fine_points.extend(children)
                    fine_parent_positions.extend(
                        [parent_position] * len(children)
                    )
            parent_index = torch.as_tensor(
                fine_parent_positions, device=device, dtype=torch.long
            )
            # RELION evaluates orientation and translation PDFs only at the
            # coarse sampling.  Every oversampled child inherits its parent's
            # prior; only the image likelihood is evaluated on the fine grid.
            fine_log_prior = coarse.log_prior.index_select(0, parent_index)
            fine = self._score_points(
                fine_points, particle_ft, ctf, invsigma,
                maximum_shell=fine_shell, image_size=self.sizes.likelihood_image_size(True),
                offset_prior_angstrom=offset_prior,
                orientation_prior_deg=orientation_prior,
                pixel_size=pixel_size,
                highres_xi2_half=highres, firstiter_cc=self.config.firstiter_cc,
                direction_oversampling_order=self.config.adaptive_oversampling,
                log_prior_override=fine_log_prior,
            )
        best = int(torch.argmax(fine.posterior))
        if fine.log_evidence is None:
            raise RuntimeError("hypothesis table is missing its log evidence")
        raw_log_evidence = fine.log_evidence
        dll = (
            float(raw_log_evidence)
            if self.config.firstiter_cc
            else float(raw_log_evidence) - logsigma
        )
        if fine.pmax is None:
            raise RuntimeError("hypothesis table is missing its maximum posterior")
        return ParticleExpectation(
            coarse, fine, best, fine.points[best], float(fine.pmax), dll, highres, logsigma
        )




def sparse_adaptive_debug_dict(
    result: SparseAdaptiveBatchExpectation,
) -> dict[str, np.ndarray]:
    return {
        "coarse_diff2": result.coarse.diff2.detach().cpu().numpy(),
        "coarse_log_prior": result.coarse.log_prior.detach().cpu().numpy(),
        "coarse_posterior": result.coarse.posterior.detach().cpu().numpy(),
        "coarse_significant": result.coarse.significant.detach().cpu().numpy(),
        "coarse_reported_significant_count": result.coarse.reported_significant_count.detach().cpu().numpy(),
        "parent_particle_indices": result.parent_particle_indices.detach().cpu().numpy(),
        "parent_class_indices": result.parent_class_indices.detach().cpu().numpy(),
        "parent_orientation_indices": result.parent_orientation_indices.detach().cpu().numpy(),
        "parent_translation_indices": result.parent_translation_indices.detach().cpu().numpy(),
        "child_angles_deg": result.child_angles_deg.detach().cpu().numpy(),
        "child_direction_indices": result.child_direction_indices.detach().cpu().numpy(),
        "child_orientation_ids": result.child_orientation_ids.detach().cpu().numpy(),
        "child_translations_angstrom": result.child_translations_angstrom.detach().cpu().numpy(),
        "fine_diff2": result.diff2.detach().cpu().numpy(),
        "fine_log_prior": result.log_prior.detach().cpu().numpy(),
        "fine_posterior": result.posterior.detach().cpu().numpy(),
        "fine_significant": result.significant.detach().cpu().numpy(),
        "fine_reported_significant_count": result.fine_reported_significant_count.detach().cpu().numpy(),
        "fine_significant_weight": result.fine_significant_weight.detach().cpu().numpy(),
        "fine_log_evidence": result.fine_log_evidence.detach().cpu().numpy(),
        "best_parent_indices": result.best_parent_indices.detach().cpu().numpy(),
        "best_orientation_child_indices": result.best_orientation_child_indices.detach().cpu().numpy(),
        "best_translation_child_indices": result.best_translation_child_indices.detach().cpu().numpy(),
        "pmax": result.pmax.detach().cpu().numpy(),
        "rlnLogLikeliContribution": result.log_likelihood_contribution.detach().cpu().numpy(),
        "highres_xi2_half": result.highres_xi2_half.detach().cpu().numpy(),
        "log_sigma2": result.log_sigma2.detach().cpu().numpy(),
    }


def dense_expectation_debug_dict(result: DenseBatchExpectation) -> dict[str, np.ndarray]:
    out = {
        "angles_deg": result.bank.angles_deg.detach().cpu().numpy(),
        "direction_indices": result.bank.direction_indices.detach().cpu().numpy(),
        "psi_indices": result.bank.psi_indices.detach().cpu().numpy(),
        "translations_angstrom": result.bank.translations_angstrom.detach().cpu().numpy(),
        "diff2": result.diff2.detach().cpu().numpy(),
        "log_prior": result.log_prior.detach().cpu().numpy(),
        "posterior": result.posterior.detach().cpu().numpy(),
        "significant": result.significant.detach().cpu().numpy(),
        "reported_significant_count": result.reported_significant_count.detach().cpu().numpy(),
        "significant_weight": result.significant_weight.detach().cpu().numpy(),
        "log_evidence": result.log_evidence.detach().cpu().numpy(),
        "best_flat_index": result.best_flat_index.detach().cpu().numpy(),
        "pmax": result.pmax.detach().cpu().numpy(),
        "rlnLogLikeliContribution": result.log_likelihood_contribution.detach().cpu().numpy(),
        "highres_xi2_half": result.highres_xi2_half.detach().cpu().numpy(),
        "log_sigma2": result.log_sigma2.detach().cpu().numpy(),
    }
    if result.cross_correlation is not None:
        out["cross_correlation"] = result.cross_correlation.detach().cpu().numpy()
    return out

def expectation_debug_dict(result: ParticleExpectation) -> dict[str, np.ndarray]:
    def points_array(points: Sequence[SamplingPoint]) -> np.ndarray:
        return np.asarray([
            (p.class_index, p.direction_index, p.psi_index, p.translation_index,
             p.rot, p.tilt, p.psi, p.x, p.y, p.parent_index)
            for p in points
        ], dtype=np.float64)
    return {
        "coarse_points": points_array(result.coarse.points),
        "coarse_diff2": result.coarse.diff2.detach().cpu().numpy(),
        "coarse_log_prior": result.coarse.log_prior.detach().cpu().numpy(),
        "coarse_posterior": result.coarse.posterior.detach().cpu().numpy(),
        "coarse_significant": result.coarse.significant.detach().cpu().numpy(),
        "coarse_reported_significant_count": np.asarray(
            result.coarse.reported_significant_count
        ),
        "coarse_significant_weight": (
            np.asarray(np.nan)
            if result.coarse.significant_weight is None
            else result.coarse.significant_weight.detach().cpu().numpy()
        ),
        "coarse_cross_correlation": result.coarse.cross_correlation.detach().cpu().numpy(),
        "fine_points": points_array(result.fine.points),
        "fine_diff2": result.fine.diff2.detach().cpu().numpy(),
        "fine_log_prior": result.fine.log_prior.detach().cpu().numpy(),
        "fine_posterior": result.fine.posterior.detach().cpu().numpy(),
        "fine_significant": result.fine.significant.detach().cpu().numpy(),
        "fine_reported_significant_count": np.asarray(
            result.fine.reported_significant_count
        ),
        "fine_significant_weight": (
            np.asarray(np.nan)
            if result.fine.significant_weight is None
            else result.fine.significant_weight.detach().cpu().numpy()
        ),
        "highres_xi2_half": np.asarray(result.highres_xi2_half),
        "log_sigma2": np.asarray(result.log_sigma2),
        "rlnLogLikeliContribution": np.asarray(result.log_likelihood_contribution),
    }
