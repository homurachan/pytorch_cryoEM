"""Regular GEMM execution for high-density sparse fine-search candidates.

Geometry-agnostic: both 2-D and 3-D orientation child tables are supported.
Scores are gathered back into the ORIGINAL parent/child order. Rectangular
padding/excluded coarse hypotheses NEVER participate in posterior selection.
"""
from __future__ import annotations

import math
import numpy as np
import torch


# Deterministic execution-cost calibration for the fine scorer.
#
# Dense scoring uses regular GEMMs over a complete translation rectangle while
# sparse scoring uses many tiny batched products. Equal child counts are not
# equal GPU work. These constants express that execution-efficiency difference
# in sparse-child-equivalent units; active-pixel and block-fill terms move the
# crossover with Fourier size and actual dense GEMM shape instead of imposing
# another fixed density threshold.
_DENSE_BASE_ADVANTAGE = 12.0
_DENSE_REFERENCE_ACTIVE_PIXELS = 4096.0
_DENSE_MIN_ADVANTAGE = 4.0
_DENSE_MAX_ADVANTAGE = 24.0
_DENSE_CALL_CHILD_EQUIVALENT = 1024.0
_SPARSE_TILE_CHILD_EQUIVALENT = 2048.0


def gather_active_child_rows(source, rows, active_indices):
    """Gather only selected pixels, not full Fourier planes before masking.

    This matters with --strict-highres-exp and a disabled active-view cache:
    a small likelihood support must not cause a huge full-plane gather tile.
    All indices are integers with host-known output sizes.
    """
    if hasattr(source, 'gather_active'):
        return source.gather_active(rows, active_indices)
    child = torch.arange(source.shape[1], device=rows.device)
    return source.flatten(-2)[rows[:, None, None], child[None, :, None], active_indices[None, None, :]]


def plan_dense_parent_blocks(*, active_pixels: int, real_bytes: int,
        complex_bytes: int, coarse_translations: int, translation_children: int,
        orientation_children: int, work_bytes: int, cc: bool = False,
        max_blocks: int = 256) -> dict[str, int | bool]:
    """Plan dense fine-score workspace without launching the scorer."""
    f = max(1, int(active_pixels))
    trans = max(1, int(coarse_translations))
    tc = max(1, int(translation_children))
    oc = max(1, int(orientation_children))
    total_t = trans * tc
    shift_bytes = total_t * f * (3 * int(complex_bytes) + 8 * int(real_bytes))
    per_block = oc * f * (3 * int(complex_bytes) + 8 * int(real_bytes))
    per_block += oc * total_t * int(real_bytes) * (16 if cc else 10)
    available = int(work_bytes) - int(shift_bytes)
    fits = bool(work_bytes > 0 and available >= per_block)
    block_chunk = (
        max(1, min(int(max_blocks), available // max(1, per_block))) if fits else 0
    )
    workspace = int(shift_bytes + block_chunk * per_block) if fits else int(shift_bytes + per_block)
    return {
        "fits": fits,
        "block_chunk": int(block_chunk),
        "shift_bytes": int(shift_bytes),
        "per_block_bytes": int(per_block),
        "workspace_bytes": int(workspace),
        "total_translation_children": int(total_t),
    }


def estimate_fine_score_costs(*, nparent: int, active_blocks_per_particle,
        active_pixels: int, coarse_translations: int, translation_children: int,
        orientation_children: int, sparse_parent_chunk: int,
        dense_plan: dict[str, int | bool]) -> dict[str, int | float | bool]:
    """Compare dense and sparse fine-score execution costs.

    ``active_blocks_per_particle`` is the exact number of retained
    ``(class, coarse-orientation)`` blocks for each particle. Dense scoring
    evaluates the complete translation rectangle for each such block; sparse
    scoring evaluates only retained parents. Cost units additionally account
    for active Fourier pixels, dense GEMM fill, and expected GEMM/tile calls.

    The model is deterministic: it never runtime-benchmarks the GPU, so layout
    selection cannot introduce timing-dependent scientific control flow.
    """
    nparent = max(0, int(nparent))
    f = max(1, int(active_pixels))
    trans = max(1, int(coarse_translations))
    tc = max(1, int(translation_children))
    oc = max(1, int(orientation_children))
    sparse_parent_chunk = max(1, int(sparse_parent_chunk))

    counts = np.asarray(active_blocks_per_particle, dtype=np.int64)
    active_blocks = int(counts.sum())
    block_chunk = int(dense_plan.get("block_chunk", 0))
    fits = bool(dense_plan.get("fits", False)) and block_chunk > 0

    dense_calls = int(((counts + block_chunk - 1) // block_chunk).sum()) if fits and active_blocks else 0
    sparse_tiles = int(math.ceil(nparent / sparse_parent_chunk)) if nparent else 0
    total_t = trans * tc
    dense_children = int(active_blocks * oc * total_t)
    sparse_children = int(nparent * oc * tc)

    if dense_calls > 0:
        average_blocks_per_call = active_blocks / dense_calls
        block_fill = min(1.0, average_blocks_per_call / max(1, block_chunk))
    else:
        block_fill = 0.0

    pixel_factor = math.sqrt(_DENSE_REFERENCE_ACTIVE_PIXELS / float(f))
    fill_factor = math.sqrt(max(block_fill, 1.0 / max(1, block_chunk))) if fits else 0.0
    dense_advantage = _DENSE_BASE_ADVANTAGE * pixel_factor * fill_factor
    dense_advantage = (
        min(_DENSE_MAX_ADVANTAGE, max(_DENSE_MIN_ADVANTAGE, dense_advantage))
        if fits else 0.0
    )

    dense_units = math.inf
    if fits:
        dense_units = (
            dense_children / max(dense_advantage, 1e-12)
            + dense_calls * _DENSE_CALL_CHILD_EQUIVALENT
        )
    sparse_units = (
        float(sparse_children)
        + sparse_tiles * _SPARSE_TILE_CHILD_EQUIVALENT
    )
    choose_dense = bool(fits and dense_units <= sparse_units)
    return {
        "choose_dense": choose_dense,
        "dense_workspace_fits": fits,
        "active_blocks": active_blocks,
        "dense_children": dense_children,
        "sparse_children": sparse_children,
        "dense_calls": dense_calls,
        "sparse_tiles": sparse_tiles,
        "dense_block_chunk": block_chunk,
        "dense_block_fill": float(block_fill),
        "dense_advantage": float(dense_advantage),
        "dense_units": float(dense_units),
        "sparse_units": float(sparse_units),
        "active_pixels": f,
    }


@torch.no_grad()
def score_dense_parent_blocks_reference(*, image_active, ctf_active, invsigma, highres,
        projection_blocks, phase_table, active_indices, projection_active, phase_active,
        parent_counts, parent_block_indices, parent_translation_indices,
        output, cc_output, work_bytes, max_blocks=256):
    """Return statistics, or None before scoring if the workspace cannot fit.

    One particle at a time, bounded projection-block tiles. A full translation
    table is needed for this fast layout; if even that cannot fit, the caller
    uses its bounded sparse-parent scorer instead. No full [B,K,O,T,F] tensor.
    Estimates cover named tensor temporaries, not BLAS/allocator workspaces.
    """
    trans, tc = phase_table.shape[:2]
    oc = projection_blocks.shape[1]
    f = active_indices.numel()
    total_t = int(trans*tc)
    workspace = plan_dense_parent_blocks(
        active_pixels=f,
        real_bytes=image_active.real.element_size(),
        complex_bytes=image_active.element_size(),
        coarse_translations=trans,
        translation_children=tc,
        orientation_children=oc,
        work_bytes=work_bytes,
        cc=cc_output is not None,
        max_blocks=max_blocks,
    )
    if not workspace["fits"]:
        return None
    block_chunk = int(workspace["block_chunk"])
    # One bulk metadata read, not one device sync per candidate or GEMM tile.
    counts = parent_counts.detach().cpu().numpy().astype(np.int64, copy=False)
    blocks_host = parent_block_indices.detach().cpu().numpy()
    phases = phase_active if phase_active is not None else phase_table.flatten(-2).index_select(-1, active_indices)
    phases = phases.reshape(total_t, f)
    calls = 0
    evaluated = 0
    start = 0
    for particle, count in enumerate(counts):
        end = start+int(count)
        if not int(count):
            start = end
            continue
        host = blocks_host[start:end]
        # Parent ordering from coarse.nonzero is particle/class/orientation/translation.
        # Class/orientation projection block keys are therefore nondecreasing here.
        boundaries = np.r_[0, np.flatnonzero(host[1:] != host[:-1])+1, len(host)]
        unique_blocks = host[boundaries[:-1]]
        if len(unique_blocks) > 1 and np.any(unique_blocks[1:] <= unique_blocks[:-1]):
            raise ValueError("fine dense scorer requires ordered unique projection-block runs")
        shifted = image_active[particle, None] * phases
        xp = shifted.real.square() + shifted.imag.square()
        xnorm = (xp * invsigma[particle, None]).sum(-1)
        if cc_output is not None:
            raw_xnorm = xp.sum(-1)
        for first in range(0, len(unique_blocks), block_chunk):
            last = min(first+block_chunk, len(unique_blocks))
            ids = torch.as_tensor(unique_blocks[first:last].copy(), device=output.device, dtype=torch.long)
            reference = (projection_active.index_select(0, ids) if projection_active is not None
                         else gather_active_child_rows(projection_blocks, ids, active_indices))
            prediction = reference.reshape(-1, f) * ctf_active[particle, None]
            weighted = prediction * invsigma[particle, None]
            cross = shifted.real @ weighted.real.T + shifted.imag @ weighted.imag.T
            pp = prediction.real.square() + prediction.imag.square()
            pnorm = (pp * invsigma[particle, None]).sum(-1)
            local = (0.5*(pnorm[:, None] + xnorm[None] - 2.*cross.T)).clamp_min(0.) + highres[particle]
            a = start+int(boundaries[first]); b = start+int(boundaries[last])
            local_block = torch.searchsorted(ids, parent_block_indices[a:b].contiguous())
            translations = parent_translation_indices[a:b]
            output[a:b] = local.reshape(last-first, oc, trans, tc).permute(0, 2, 1, 3)[local_block, translations]
            if cc_output is not None:
                raw_cross = shifted.real @ prediction.real.T + shifted.imag @ prediction.imag.T
                raw_pnorm = pp.sum(-1)
                cc = raw_cross.T / (raw_pnorm[:, None]*raw_xnorm[None]).clamp_min(
                    torch.finfo(image_active.real.dtype).tiny).sqrt()
                cc_output[a:b] = cc.reshape(last-first, oc, trans, tc).permute(0, 2, 1, 3)[local_block, translations]
            calls += 1
            evaluated += (last-first)*oc*total_t
        start = end
    return dict(fine_dense_tiles=calls, fine_dense_evaluated_children=evaluated,
                fine_dense_batches=1, fine_sparse_tiles=0,
                fine_workspace_estimate_bytes=int(workspace["workspace_bytes"]))


def score_dense_parent_blocks(*, execution='auto', **kwargs):
    """Retain the old scorer for CC and explicit execution A/B comparisons."""
    if execution not in ('auto','reference'):raise ValueError('Invalid dense execution mode')
    if execution=='reference' or kwargs['cc_output'] is not None:
        return score_dense_parent_blocks_reference(**kwargs)
    from .dense_reuse import score
    return score(**kwargs)
