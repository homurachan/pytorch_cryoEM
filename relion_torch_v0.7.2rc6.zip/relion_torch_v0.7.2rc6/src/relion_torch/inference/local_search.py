"""Compact coarse local search using the shared SPA scoring/posterior kernels.

Only real particle/orientation pairs are scored. The posterior has a per-batch
local padding width, never the global angular-grid width. Fine scoring consumes
the same DenseBatchExpectation with an explicit local-to-global index map.
"""
import numpy as np
import torch
from contextlib import nullcontext
from relion_torch.sampling.local import select_local_angular_support
from .alignment import (DenseBatchExpectation, likelihood_rfft_mask, likelihood_inverse_noise,
                        rounded_shell_indices_2d, relion_weight_selection_batch)
from .score_tiles import score_prediction_tile


class LocalSearchWorkspaceError(MemoryError):
    """The caller may retry an unchanged candidate set in smaller batches."""


def local_translation_log_prior(translations, centres, sigma):
    """Native coarse, unperturbed translation prior, mean normalized per row."""
    delta = (translations[None] - centres[:, None]).square().sum(-1)
    probability = (delta == 0).to(delta.dtype) if sigma**2 < .0001 else torch.exp(-.5*delta/sigma**2)
    probability = probability / probability.mean(-1, keepdim=True).clamp_min(torch.finfo(delta.dtype).tiny)
    return torch.where(probability > 0, probability.log(), -torch.inf)


@torch.no_grad()
def run_local_batch(engine, particle_ft, ctf, sigma2_by_shell, *, offset_prior_angstrom,
                    orientation_prior_deg, pixel_size, bank=None):
    if orientation_prior_deg is None:
        raise ValueError('Local angular search requires per-particle centres')
    if particle_ft.ndim == 2: particle_ft = particle_ft[None]
    if ctf.ndim == 2: ctf = ctf[None]
    if sigma2_by_shell.ndim == 1: sigma2_by_shell = sigma2_by_shell[None]
    b = len(particle_ft); device = particle_ft.device; dtype = particle_ft.real.dtype
    centres = (orientation_prior_deg.detach().cpu().numpy() if torch.is_tensor(orientation_prior_deg)
               else np.asarray(orientation_prior_deg))
    if centres.shape != (b, 3) or len(ctf) != b or len(sigma2_by_shell) != b:
        raise ValueError('Local search particle/CTF/noise/centre batch sizes differ')
    config = engine.config
    detail=getattr(engine,'detail_timer',None)
    section=lambda name:detail.section(name,full=True) if detail is not None else nullcontext()
    support = getattr(engine,"precomputed_support",None) or select_local_angular_support(engine.sampling.directions, engine.sampling.psi_angles,
        centres, (config.sigma_rot_deg, config.sigma_tilt_deg, config.sigma_psi_deg), symmetry=getattr(engine.sampling,"symmetry","C1"))
    counts = support.counts; width = int(counts.max()); k = len(engine.class_probabilities)
    nt = engine.sampling.number_of_translations
    # Allocation is checked BEFORE building padded arrays or posterior tensors.
    if hasattr(engine, 'check_local_budget'): engine.check_local_budget(b, width, nt)
    with section('local.coarse_setup'):
        host_ids, angular_log = support.padded()
        ids = torch.as_tensor(host_ids, device=device)
        coarse_size,coarse_shell=engine.sizes.coarse_likelihood_grid(config.adaptive_oversampling)
        bank = bank or engine.build_global_projection_bank(pixel_size=pixel_size,
            image_size=coarse_size,maximum_shell=coarse_shell)
        if bank.source_signature is not None and bank.source_signature != engine._sync_source_caches():
            raise RuntimeError('stale local projection bank; rebuild after source/support changes')
        size = bank.image_size
        mask = likelihood_rfft_mask(size, bank.maximum_shell, device, firstiter_cc=config.firstiter_cc)
        active = torch.nonzero(mask.flatten(), as_tuple=False).squeeze(1)
        fused_local=False
        if getattr(engine,'local_buffer',None) is not None and not config.firstiter_cc:
            from .fused_projection import available as fusion_available
            fused_local=fusion_available(device,getattr(bank.projections.fallback.projector,'fusion_mode','off'))
        counters=getattr(engine,'memory_counters',None)
        if counters is not None:
            for key,value in (('coarse_likelihood_image_size_max',size),
                              ('coarse_likelihood_shell_max',bank.maximum_shell),
                              ('coarse_likelihood_active_pixels_max',active.numel())):
                counters[key]=max(counters.get(key,0),int(value))
        # Include persistent shifted observations and full-image gathers when an
        # active-frequency bank cannot fit. Cache payloads have a separate budget.
        base_bytes = b*int(active.numel())*(nt*8+40+(8 if fused_local else 0))+nt*int(active.numel())*8
        # Includes the ragged host/device schedule and bounded sort temporaries.
        # Identical alive-class support shares one schedule; other supports replace it.
        base_bytes += b*width*(144 if fused_local else 112)
        if getattr(engine,'bulk_local',False):
            base_bytes += min(b,8)*int(active.numel())*(nt*8+32)
        # Each tile shares ONE particle's [T,F] shifted image across O angles.
        # Allow for projection gathers, CTF/noise products and scoring temporaries;
        # no [O,T,F] copy of the observation is materialized.
        bytes_per_orientation = max(1, int(active.numel())*8*18
                                    + size*(size//2+1)*8*3+nt*32+128)
        available = config.candidate_work_bytes-base_bytes
        if available < bytes_per_orientation:
            raise LocalSearchWorkspaceError('Local scoring observations/tile exceed --candidate-work-mib')
        limit = max(1, min(width, config.candidate_chunk_size, available//bytes_per_orientation))
        shells = rounded_shell_indices_2d(size, device)[mask]
        image = engine._window_rfft(particle_ft, size)[:, mask]
        factor = engine._window_rfft(ctf, size)[:, mask].to(dtype)
        inv = likelihood_inverse_noise(sigma2_by_shell.to(device=device, dtype=dtype),
                                       shells, firstiter_cc=config.firstiter_cc)
        highres, logsigma = engine._highres_terms_batch(particle_ft, sigma2_by_shell, engine.sizes.current_shell)
        phase = bank.phase_factors[:, mask]
        shifted = image[:, None] * phase[None]
        cc = config.firstiter_cc
        xpower = image.real.square() + image.imag.square()
        xnorm = (xpower if cc else xpower*inv).sum(-1)
        trans = torch.as_tensor(engine.sampling.prior_translations, device=device, dtype=torch.float64)
        tlog = local_translation_log_prior(trans, offset_prior_angstrom.to(device=device, dtype=torch.float64), config.sigma_offset_angstrom)
        log_prior = (torch.as_tensor(angular_log, device=device)[:, None, :, None] + tlog[:, None, None, :]).expand(b, k, width, nt).clone()
        # Local orientation priors replace the learned JOINT class/direction PDF.
        # Retain native dead-class and initialization class-range guards.
        alive = engine.class_probabilities.detach().cpu().numpy() > 0
        allowed = getattr(engine, 'allowed_classes', None)
        allowed = None if allowed is None else allowed.detach().cpu().numpy()
        class_support = np.broadcast_to(alive, (b, k)).copy()
        if allowed is not None: class_support &= np.arange(k)[None] == allowed[:, None]
        log_prior.masked_fill_(~torch.as_tensor(class_support, device=device)[:, :, None, None], -torch.inf)
        if not torch.isfinite(log_prior.flatten(1)).any(1).all():
            raise RuntimeError('at least one local-search particle has no hypothesis with non-zero prior')
        diff2 = torch.full((b, k, width, nt), torch.inf, device=device, dtype=dtype)
        counters = getattr(engine, 'memory_counters', {})
        # Ragged particle/class/angle blocks: [1,T,F] @ [1,F,O]. The sampler's
        # original host IDs avoid sending the same indices back from the GPU for
        # cache lookup. Only actual support is visited, with no padded scoring.
        counters['local_scoring_workspace_estimated_bytes'] = max(
            counters.get('local_scoring_workspace_estimated_bytes', 0), base_bytes+limit*bytes_per_orientation)
        counters['local_scoring_shifted_gather_bytes'] = 0
        scored = 0
        tiles = 0
        block_max = 0
    store = bank.projections
    store.local_coarse_mode=getattr(engine,'local_coarse_mode','auto')
    store.detail_timer=getattr(engine,'detail_timer',None)
    schedules={}
    observations=None
    if fused_local:
        from .fused_projection import prepare_score_observations
        with section('local.coarse_inputs'):
            observations=prepare_score_observations(shifted,factor,inv,highres,xnorm)
        counters['local_coarse_input_preparations']=counters.get('local_coarse_input_preparations',0)+1
        counters['local_coarse_input_reserved_bytes']=max(counters.get('local_coarse_input_reserved_bytes',0),b*int(active.numel())*8)
    with section('local.coarse_score'):
        for c in range(k):
            class_rows=np.flatnonzero(class_support[:,c])
            if not len(class_rows):continue
            if getattr(engine,'local_buffer',None) is not None and not cc:
                from .local_projection import score_local_blocks
                from .fused_projection import available as fusion_available
                union_limit=limit
                if fusion_available(device,getattr(store.fallback.projector,'fusion_mode','off')):
                    # Fused scoring keeps matrices and score rows, not O*F
                    # predictions. Bound worst-case pairs B*union, independently
                    # of a single particle's angular support width.
                    pair_bytes=4*(9*4+5*8+nt*4)
                    from .fused_projection import shared_budget
                    # The explicit coarse tile and the legacy reusable tile run
                    # sequentially, so reserve the larger scratch requirement.
                    coarse_budget=(min(64*2**20,store.buffer.max_bytes,
                        getattr(store.buffer,'work_bytes',0)//8,available//4)
                        if store.local_coarse_mode!='direct' else 0)
                    store.coarse_shared_budget=coarse_budget
                    shared_reserve=max(shared_budget(store),coarse_budget)
                    union_limit=max(1,min(config.candidate_chunk_size,max(1,available-shared_reserve)//max(1,b*pair_bytes)))
                    counters['local_fused_pair_workspace_estimated_bytes']=base_bytes+union_limit*b*pair_bytes+shared_reserve
                ntile,nmax,npairs=score_local_blocks(store,host_ids,counts,class_rows,c,union_limit,
                    shifted,factor,inv,highres,xnorm,diff2,score_prediction_tile,fallback_limit=limit,schedules=schedules,
                    prepared_inputs=observations)
                tiles+=ntile;block_max=max(block_max,nmax);scored+=npairs*nt
                continue
            if getattr(engine,'bulk_local',False) and not cc and hasattr(store,'gather_active_host'):
                # Equal-count buckets need no dummy orientations and retain the
                # native row order within each posterior. Bound B*O, not only O.
                for count in np.unique(counts[class_rows]):
                    bucket=class_rows[counts[class_rows]==count]
                    row_limit=max(1,min(8,limit))
                    for rb in range(0,len(bucket),row_limit):
                        rows=bucket[rb:rb+row_limit]
                        ri=torch.as_tensor(rows,device=device)
                        block=max(1,limit//len(rows))
                        xs=shifted.index_select(0,ri)
                        ct=factor.index_select(0,ri);noise=inv.index_select(0,ri)
                        hr=highres.index_select(0,ri);xn=xnorm.index_select(0,ri)
                        for start in range(0,int(count),block):
                            stop=min(start+block,int(count));width_tile=stop-start
                            request=host_ids[rows,start:stop].reshape(-1)
                            reference=store.gather_active_host(c,request).reshape(len(rows),width_tile,-1)
                            prediction=reference*ct[:,None]
                            score=score_prediction_tile(xs,prediction,noise,hr,image_norm=xn)
                            diff2[ri,c,start:stop]=score
                            scored+=len(rows)*width_tile*nt;tiles+=1
                            block_max=max(block_max,len(rows)*width_tile)
                        counters['local_bulk_particle_rows']=counters.get('local_bulk_particle_rows',0)+len(rows)
                continue
            for row in class_rows:
                count = int(counts[row])
                xs = shifted[row:row+1]
                ct, noise = factor[row:row+1], inv[row:row+1]
                hr, xn = highres[row:row+1], xnorm[row:row+1]
                for start in range(0, count, limit):
                    stop = min(start+limit, count)
                    if hasattr(store, 'gather_active_host'):
                        reference = store.gather_active_host(c, host_ids[row, start:stop])
                    else:
                        orientations = ids[row, start:stop]
                        if hasattr(store, 'gather_active'):
                            reference = store.gather_active(c, orientations)
                        elif hasattr(store, 'gather'):
                            reference = store.gather(c, orientations).flatten(-2).index_select(-1, active)
                        else:
                            reference = store[c].index_select(0, orientations)[:, mask]
                    prediction = reference[None] * ct[:, None]
                    score = score_prediction_tile(xs, prediction, noise, hr, cc=cc, image_norm=xn)[0]
                    diff2[row, c, start:stop] = -score if cc else score
                    scored += (stop-start)*nt
                    tiles += 1
                    block_max = max(block_max, stop-start)
    counters['local_score_tiles'] = counters.get('local_score_tiles', 0) + tiles
    counters['local_score_orientation_block_max'] = max(counters.get('local_score_orientation_block_max', 0), block_max)
    key = 'coarse_cc_scored_hypotheses' if cc else 'coarse_gaussian_scored_hypotheses'
    counters[key] = counters.get(key, 0) + scored
    counters['local_coarse_scored_hypotheses'] = counters.get('local_coarse_scored_hypotheses', 0) + scored
    counters['local_coarse_padded_hypotheses'] = counters.get('local_coarse_padded_hypotheses', 0) + diff2.numel()
    counters['local_orientation_candidates'] = counters.get('local_orientation_candidates', 0) + int(counts.sum())
    global_count=getattr(engine.sampling,'root',engine.sampling).number_of_orientations
    counters['local_coarse_global_hypotheses_avoided'] = counters.get('local_coarse_global_hypotheses_avoided', 0) + b*k*global_count*nt-scored
    flat = diff2.flatten(1); prior = log_prior.flatten(1)
    if cc:
        score = (-flat).masked_fill(~torch.isfinite(prior), -torch.inf)
        best = score.argmax(1)
        posterior = torch.zeros_like(flat).scatter_(1, best[:, None], 1.)
        posterior64 = posterior.double(); significant = posterior.bool()
        count = torch.ones(b, device=device, dtype=torch.long)
        threshold = pmax = torch.ones(b, device=device, dtype=torch.float64)
        evidence = score.gather(1, best[:, None])[:, 0].double()
    else:
        selection = relion_weight_selection_batch(prior, flat, config.adaptive_fraction,
            weight_dtype=torch.float32 if config.weight_precision == 'float32' else torch.float64,
            compact_positive=True, counters=counters, detail_timer=detail, detail_prefix='local')
        posterior, posterior64, significant = selection.posterior, selection.posterior64, selection.significant
        best, pmax, count = selection.best_index, selection.pmax, selection.reported_significant_count
        threshold, evidence = selection.significant_weight, selection.log_evidence
    posterior = posterior.reshape_as(diff2); significant = significant.reshape_as(diff2)
    class_mass = (posterior64.reshape_as(diff2)*significant).sum((2, 3))
    return DenseBatchExpectation(bank=bank, diff2=diff2, log_prior=log_prior,
        posterior=posterior, significant=significant, class_mass=class_mass, best_flat_index=best,
        pmax=pmax, log_likelihood_contribution=evidence if cc else evidence-logsigma.double(),
        highres_xi2_half=highres, log_sigma2=logsigma, reported_significant_count=count,
        significant_weight=threshold, log_evidence=evidence, cross_correlation=-diff2 if cc else None,
        orientation_indices=ids)
