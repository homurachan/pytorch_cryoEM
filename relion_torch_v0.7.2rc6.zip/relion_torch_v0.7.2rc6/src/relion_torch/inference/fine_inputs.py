"""Batch-scoped indexed inputs for the direct local fine scorer.

One parent-block metadata readback replaces per-tile readbacks. The observation
and phase buffers remain indexed on the device; only small integer schedules
are uploaded. Projectors are acquired per tile so class-pool limits still apply.
"""
import numpy as np
import torch
from . import fused_projection as fp


def prepare(fine, blocks, image, factor, inv, highres, phase, active, *,
            phase_active, work_bytes):
    arena = fine.store.buffer
    if (getattr(arena, 'fine_inputs', 'auto') == 'off'
            or getattr(arena, 'projection_reuse', 'off') != 'off'
            or not fine.fusion_available()):
        return None
    if (image.dtype != torch.complex64 or phase.dtype != torch.complex64
            or factor.dtype not in (torch.float32, torch.complex64)
            or inv.dtype != torch.float32 or highres.dtype != torch.float32
            or blocks.dtype != torch.long or active.dtype != torch.long):
        return None
    if (image.ndim != 2 or factor.shape != image.shape or inv.shape != image.shape
            or phase.ndim != 3 or image.shape[1] != active.numel()):
        return None
    # Bound the whole-batch metadata and all possible contiguous/conversion
    # copies BEFORE allocating; retain room for the existing tile workspace.
    needed = len(blocks) * (fine.oc + 3) * 8
    needed += image.numel() * 8 + factor.numel() * 8 + inv.numel() * 4
    needed += phase.numel() * 8 + highres.numel() * 4 + active.numel() * 8
    if needed > max(0, int(work_bytes)) // 4:
        fine.store._count('fine_input_budget_fallbacks')
        return None
    return FineInputPlan(fine, blocks, image, factor, inv, highres, phase,
                         active, phase_active=phase_active, estimated_bytes=needed)


class FineInputPlan:
    def __init__(self, fine, blocks, image, factor, inv, highres, phase, active,
                 *, phase_active, estimated_bytes):
        self.fine, self.store = fine, fine.store
        self.estimated_bytes = int(estimated_bytes)
        host = blocks.detach().cpu().numpy()
        if blocks.device.type != 'cpu':
            self.store._count('fine_input_metadata_d2h_calls')
            self.store._count('fine_input_metadata_d2h_bytes', blocks.numel() * blocks.element_size())
        classes = fine.host_classes[host]
        orientations = fine.host_orientations[host]
        self.sections = []
        for c in np.unique(classes):
            positions = np.flatnonzero(classes == c)
            angles = (orientations[positions, None] * fine.oc + np.arange(fine.oc)[None]).reshape(-1)
            self.sections.append((int(c), positions,
                torch.as_tensor(positions, device=fine.device, dtype=torch.long),
                torch.as_tensor(angles, device=fine.device, dtype=torch.long)))
        # These batch-sized conversions are done once, not once per parent or
        # fine orientation. Retain originals only for the first-use self-check.
        self.image, self.factor, self.inv, self.highres = image, factor, inv, highres
        self.phase, self.active, self.phase_active = phase, active, bool(phase_active)
        self.x = fp._complex_parts(image)
        self.c = fp._complex_parts(factor)
        self.noise = inv.contiguous()
        self.hr = highres.contiguous()
        self.phases = fp._complex_parts(phase)
        self.pixels = active.contiguous()
        self.index_sources = None
        self.store._count('fine_input_batches')
        self.store.buffer.count('fine_input_plan_estimated_bytes', estimated_bytes, peak=True)

    def tile_bytes_per_parent(self, translations):
        # Geometry gathering/Euler intermediates and compact output/index slack.
        # Large image/phase inputs are already charged once to estimated_bytes;
        # diff2/posterior storage remains covered by the separate posterior budget.
        return self.fine.oc*(512+4*int(translations))+128

    def parent_chunk(self, legacy, cap, work_bytes, translations):
        if getattr(self.store.buffer, 'fine_chunking', 'auto') == 'off' or int(cap)<=0:
            return legacy
        available = max(0, int(work_bytes)-self.estimated_bytes)
        bounded = available//self.tile_bytes_per_parent(translations)
        return max(1, min(max(1, int(cap)), bounded))

    def score(self, start, stop, particle, translation, output):
        """Write original parent/child slots; a failed tile may be overwritten.

        No posterior or additive statistics have been committed here. If a
        class fails after other classes wrote scores, the caller recomputes the
        ENTIRE tile through the existing path, never consuming partial output.
        """
        oc, t, f = self.fine.oc, self.phase.shape[1], self.active.numel()
        if (particle.dtype != torch.long or translation.dtype != torch.long
                or output.dtype != torch.float32 or not output.is_contiguous()):
            self.store._count('fine_input_fallbacks')
            return False
        if self.index_sources is None:
            self.index_sources = (particle, translation)
            self.particle = particle.contiguous()
            self.translation = translation.contiguous()
        elif particle is not self.index_sources[0] or translation is not self.index_sources[1]:
            raise ValueError('Fine input plan belongs to one particle batch and parent ordering')
        for c, positions, parents, angles in self.sections:
            lo, hi = np.searchsorted(positions, [start, stop])
            if lo == hi:
                continue
            selected = parents[lo:hi]
            payload = fp.inputs(self.store, c, angles[lo * oc:hi * oc])
            if payload is None:
                self.store._count('fine_input_fallbacks')
                return False
            projector, inverse, mode = payload
            try:
                import triton
                from .fine_input_cuda_kernel import fine_input_score_kernel
                fine_input_score_kernel[((hi - lo) * oc,)](
                    fp._complex_parts(projector.data), inverse, self.pixels,
                    selected, self.particle, self.translation, self.x, self.c, self.noise,
                    self.hr, self.phases, output,
                    P=projector.padded_size, S=self.fine.shape[-2],
                    R2=projector.source_radius_padded**2, PAD=projector.padding_factor,
                    F=f, T=t, OC=oc, PF=self.phase.shape[-1],
                    PHASE_ACTIVE=self.phase_active, BF=128,
                    BT=triton.next_power_of_2(t), enable_fp_fusion=False)
                check = ('fine_inputs', str(self.fine.device), self.fine.shape[-2],
                         projector.padded_size, f, t, oc, self.phase_active)
                if check not in fp._validated:
                    self._check(projector, inverse, selected, particle, translation, output)
                    fp._validated.add(check)
                    self.store._count('fine_input_self_checks')
            except Exception as exc:
                fp._failure(exc, mode)
                self.store._count('fine_input_fallbacks')
                return False
            self.store._count('fused_score_calls')
            self.store._count('fused_score_rows', (hi - lo) * oc)
            self.store._count('fine_input_score_calls')
            self.store._count('fine_input_score_rows', (hi - lo) * oc)
        self.store._count('fine_input_parent_rows', stop - start)
        per_parent = f * (self.image.element_size() + self.factor.element_size()
                         + self.inv.element_size() + 2 * t * self.phase.element_size())
        self.store._count('fine_input_gather_avoided_bytes', (stop - start) * per_parent)
        return True

    def _check(self, projector, inverse, parents, particle, translation, output):
        from .score_tiles import score_prediction_tile
        count = min(4, len(inverse))
        child = torch.arange(count, device=self.fine.device)
        parent = parents[child // self.fine.oc]
        rows = particle[parent]
        phases = self.phase.index_select(0, translation[parent])
        if not self.phase_active:
            phases = phases.index_select(-1, self.active)
        shifted = self.image.index_select(0, rows)[:, None] * phases
        reference = projector.project(inverse[:count], output_size=self.fine.shape[-2], rotations_are_inverse=True)
        prediction = reference.flatten(1).index_select(1, self.active) * self.factor.index_select(0, rows)
        expected = score_prediction_tile(shifted, prediction[:, None], self.inv.index_select(0, rows),
                                         self.highres.index_select(0, rows))[:, 0]
        actual = output[parent, child % self.fine.oc]
        torch.testing.assert_close(actual, expected, rtol=3e-4, atol=2e-4)
