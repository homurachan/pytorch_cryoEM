"""Local FP32 3D Fourier insertion; independent of reconstruction preweighting."""
import triton
import triton.language as tl


@triton.jit
def insert_kernel(NR,NI,DEN,X,W,M,N,S:tl.constexpr,P:tl.constexpr,
                  RADIUS2:tl.constexpr,MAPPED_RADIUS2:tl.constexpr,BLOCK:tl.constexpr):
    q=tl.program_id(0)*BLOCK+tl.arange(0,BLOCK)
    F:tl.constexpr=S*(S//2+1)
    row=q//F;f=q%F;x=(f%(S//2+1)).to(tl.float32)
    yi=f//(S//2+1);y=tl.where(yi<=S//2,yi,yi-S).to(tl.float32)
    mask=(q<N)&(x*x+y*y<=RADIUS2+1.e-5)&((x!=0)|(y>=0))
    mx=tl.load(M+row*9,mask,0)*x+tl.load(M+row*9+1,mask,0)*y
    my=tl.load(M+row*9+3,mask,0)*x+tl.load(M+row*9+4,mask,0)*y
    mz=tl.load(M+row*9+6,mask,0)*x+tl.load(M+row*9+7,mask,0)*y
    mask=mask&(mx*mx+my*my+mz*mz<=MAPPED_RADIUS2+1.e-5)
    neg=mx<0;mx=tl.where(neg,-mx,mx);my=tl.where(neg,-my,my);mz=tl.where(neg,-mz,mz)
    mask=mask&(mx>=-1.e-6)&(mx<=P/2.+1.e-6)
    bx=tl.floor(mx).to(tl.int32);by=tl.floor(my).to(tl.int32);bz=tl.floor(mz).to(tl.int32)
    fx=tl.where(bx>=P//2,0.,mx-bx);fy=my-by;fz=mz-bz
    bx=tl.minimum(tl.maximum(bx,0),P//2)
    vr=tl.load(X+2*q,mask,0);vi=tl.load(X+2*q+1,mask,0)
    vi=tl.where(neg,-vi,vi);vw=tl.load(W+q,mask,0)
    for dx in tl.static_range(2):
        for dy in tl.static_range(2):
            for dz in tl.static_range(2):
                ix=tl.minimum(bx+dx,P//2)
                iy=((by+dy)%P+P)%P;iz=((bz+dz)%P+P)%P
                at=(iz*P+iy)*(P//2+1)+ix
                weight=tl.where(dx==1,fx,1-fx)*tl.where(dy==1,fy,1-fy)*tl.where(dz==1,fz,1-fz)
                tl.atomic_add(NR+at,vr*weight,mask,sem='relaxed')
                tl.atomic_add(NI+at,vi*weight,mask,sem='relaxed')
                tl.atomic_add(DEN+at,vw*weight,mask,sem='relaxed')
