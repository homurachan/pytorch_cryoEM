"""Bounded cooperative coarse scoring, independent of cache replacement."""
from contextlib import nullcontext


def score_windows(engine, batches):
    generators = [engine._global_batch_requests(*args, **kwargs) for args, kwargs in batches]
    requests = {}
    results = [None]*len(generators)
    counts = engine.memory_counters
    reference = None
    try:
        for i, gen in enumerate(generators):
            try:requests[i] = next(gen)
            except StopIteration as done:results[i] = done.value
        while requests:
            first = next(iter(requests.values()))
            bank, c, start, stop, active = first
            # Bank identity includes reference generation, half, optics and
            # likelihood support. Never share across any of these boundaries.
            same = [i for i, r in requests.items()
                    if r[0] is bank and r[1:4] == (c, start, stop) and r[4] is active]
            detail = getattr(engine, 'detail_timer', None)
            section = detail.section('global.coarse_projection', full=True) if detail else nullcontext()
            with section:
                reference = bank.projections.slice_active(c, start, stop, active)
            if len(same)>1:
                counts['global_window_reused_projection_rows'] = counts.get('global_window_reused_projection_rows', 0)+(len(same)-1)*(stop-start)
            for i in same:
                try:requests[i] = generators[i].send(reference)
                except StopIteration as done:
                    results[i] = done.value
                    del requests[i]
            reference = None
        return results
    finally:
        reference = None
        for gen in generators:gen.close()
        requests.clear()
