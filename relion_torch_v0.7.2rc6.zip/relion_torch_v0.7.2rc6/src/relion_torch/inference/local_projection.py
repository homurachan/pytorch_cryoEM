"""Batch-scoped projections shared by Class3D and gold-standard refinement.

Multiple fine projection blocks survive through weighted statistics within a batch. The slab is reused, but its
contents never survive a particle batch, reference/optics change or half change.
Returned tensors own their data: later requests may safely overwrite the slab.
Projection interpolation temporaries and returned score tiles belong to the
candidate workspace; the slab has its own explicit payload budget.
"""
import numpy as np
import torch
from contextlib import nullcontext


def streaming_local(owner):
    return (owner.options.local_angular_search and
            getattr(owner.options, 'local_projection_mode', 'stream') == 'stream' and
            getattr(owner.options, 'auto_execution', 'optimized') != 'reference')


def merge_counters(target, source):
    for key, value in source.items():
        peak = any(x in key for x in ('bytes', '_max', 'capacity', 'total_rows',
                                      'budget', 'bounded', 'full_bank', 'second_chance'))
        target[key] = max(target.get(key, 0), int(value)) if peak else target.get(key, 0)+int(value)


class LocalProjectionBuffer:
    def __init__(self, max_bytes, device, *, counter_prefix="local_projection"):
        self.max_bytes = max(0, int(max_bytes))
        self.device = torch.device(device)
        self.projection_reuse = 'off'
        self.fine_inputs = 'auto'
        self.values = None
        self.token = None
        self.keys = np.empty(0, dtype=np.int64)
        self.counter_prefix = counter_prefix
        self.counts = {counter_prefix+'_budget_bytes': self.max_bytes}

    def count(self, key, value=1, peak=False):
        key = self.counter_prefix+'_'+key
        self.counts[key] = max(self.counts.get(key, 0), int(value)) if peak else self.counts.get(key, 0)+int(value)

    def begin_batch(self):
        self.token = None
        self.keys = np.empty(0, dtype=np.int64)
        self.count('batches')

    def release(self):
        self.values = None
        self.token = None
        self.keys = np.empty(0, dtype=np.int64)

    def save(self, token, keys, values):
        """Keep multiple requests until the batch ends; evict rows only on pressure."""
        row_size=int(np.prod(values.shape[1:])); capacity=self.max_bytes//(row_size*8)
        if not len(keys) or capacity<1:return
        if self.token is not token:
            self.token=token;self.keys=np.empty(0,dtype=np.int64)
            self._slots={};self._cursor=0;self._row_size=row_size
        required=capacity*row_size
        if self.values is None or self.values.numel()<required:
            self.values=None
            self.values=torch.empty(required,device=self.device,dtype=torch.complex64)
            self.count('buffer_allocations');self.count('peak_bytes',required*8,peak=True)
        else:self.count('buffer_reuses')
        # Keep a bounded suffix of an oversized request, with one batched copy.
        keys=np.asarray(keys,dtype=np.int64)[-capacity:];values=values[-capacity:]
        assigned=[]
        protected={self._slots[int(key)] for key in keys if int(key) in self._slots}
        reverse={slot:key for key,slot in self._slots.items()}
        for key in keys:
            key=int(key)
            if key in self._slots:slot=self._slots[key]
            else:
                while self._cursor in protected:self._cursor=(self._cursor+1)%capacity
                slot=self._cursor;self._cursor=(self._cursor+1)%capacity
                protected.add(slot)
                previous=reverse.pop(slot,None)
                if previous is not None:
                    del self._slots[previous];self.count('row_evictions')
                self._slots[key]=slot;reverse[slot]=key
            assigned.append(slot)
        ix=torch.as_tensor(assigned,device=self.device)
        self.values[:required].view(capacity,row_size).index_copy_(0,ix,values.reshape(len(keys),row_size))
        self.keys=np.asarray(sorted(self._slots),dtype=np.int64)

    def lookup(self, token, keys):
        if self.token is not token:return np.full(len(keys),-1,dtype=np.int64)
        return np.asarray([self._slots.get(int(k),-1) for k in keys],dtype=np.int64)


class BlockProjectionStore:
    """A lazy class/angle view backed by the current batch's single slab."""
    def __init__(self, fallback, active_indices, buffer):
        self.fallback, self.active_indices, self.buffer = fallback, active_indices, buffer
        self.shape, self.device, self.dtype = fallback.shape, fallback.device, fallback.dtype
        self.token = object()

    def element_size(self):
        return 8

    def _count(self, key, n=1):
        self.buffer.count(key, n)

    def release_storage(self):
        if self.buffer.token is self.token:
            self.buffer.token = None
            self.buffer.keys = np.empty(0, dtype=np.int64)

    def _gather(self, c, host, active=None, *, fused=False):
        host = np.asarray(host, dtype=np.int64).reshape(-1)
        if not 0 <= c < self.shape[0] or np.any((host < 0) | (host >= self.shape[1])):
            raise IndexError('Local projection outside class/orientation support')
        tail = self.shape[-2:]
        if not len(host):
            return torch.empty((0, active.numel()) if active is not None else (0, *tail),
                               device=self.device, dtype=self.dtype)
        unique, inverse = np.unique(host, return_inverse=True)
        keys = c*self.shape[1]+unique
        arena = self.buffer
        arena.count('requests'); arena.count('requested_rows', len(host))
        arena.count('unique_requested_rows', len(unique))
        arena.count('deduplicated_rows', len(host)-len(unique))
        out = torch.empty((len(unique), *tail), device=self.device, dtype=self.dtype)
        hit = np.zeros(len(unique), dtype=bool)
        slots=arena.lookup(self.token,keys)
        hit=slots>=0
        if hit.any():
            src=torch.as_tensor(slots[hit],device=self.device)
            dst=torch.as_tensor(np.flatnonzero(hit),device=self.device)
            capacity=arena.max_bytes//(int(np.prod(tail))*8)
            retained=arena.values[:capacity*int(np.prod(tail))].view(-1,*tail)
            out.index_copy_(0,dst,retained.index_select(0,src))
            del retained
        arena.count('reused_rows', hit.sum())
        missing = np.flatnonzero(~hit)
        for start in range(0, len(missing), self.fallback.max_chunk):
            positions = missing[start:start+self.fallback.max_chunk]
            ids = unique[positions]
            values=None
            if fused or getattr(self, 'fused_generation', False):
                from .fused_projection import project_rows
                values=project_rows(self,c,ids)
            if values is None:
                values = (self.fallback.project_host(c, ids) if hasattr(self.fallback, 'project_host')
                          else self.fallback.project(c, torch.as_tensor(ids, device=self.device)))
            out.index_copy_(0, torch.as_tensor(positions, device=self.device), values.reshape(-1, *tail))
            arena.count('generation_calls'); arena.count('generated_rows', len(ids))
            arena.count('generation_block_max', len(ids), peak=True)
            # Oversized requests retain their last generated block only.
            arena.save(self.token, keys[positions], values)
            del values
        if active is not None:
            out = out.flatten(1).index_select(1, active)
        if len(host) == len(unique) and np.array_equal(host, unique):
            return out
        return out.index_select(0, torch.as_tensor(inverse, device=self.device))

    def gather_host(self, c, ids):
        return self._gather(int(c), ids)

    def gather_shared(self,c,ids,active):
        return self._gather(int(c),ids,active,fused=True)

    def gather_active_host(self, c, ids):
        return self._gather(int(c), ids, self.active_indices)

    def gather_selected_host(self, c, ids, active_indices):
        return self._gather(int(c), ids, active_indices)

    def gather(self, c, ids):
        if ids.device.type != 'cpu': self._count('index_d2h_calls')
        return self.gather_host(c, ids.detach().cpu().numpy())


def score_local_blocks(store, host_ids, counts, class_rows, class_index, limit,
                       shifted, factor, inv, highres, xnorm, diff2, score, *, fallback_limit=None,schedules=None,prepared_inputs=None):
    """Project each class/angle once per union block, then score real pairs only.

    Distinct CTFs and noise spectra stay particle-specific. Ragged support is
    scattered back into its original order; no padded hypotheses are scored.
    """
    from .fused_projection import score as fused_score,available
    fused=available(store.device,getattr(store.fallback.projector,'fusion_mode','off'))
    mode=getattr(store,'local_coarse_mode','auto')
    schedules={} if schedules is None else schedules
    key=(tuple(class_rows),int(limit),mode)
    cached=schedules.get(key) if fused else None
    schedule=None
    if cached is not None:
        schedule,shared=cached;unique=schedule.unique
        store.buffer.count('pair_schedule_class_reuses')
    else:
        unique=np.unique(np.concatenate([host_ids[r,:counts[r]] for r in class_rows]))
        # A broad sigma alone is not evidence that materializing is cheaper.
        shared=(mode=='shared' or (mode=='auto' and counts[class_rows].mean()>=1024
                                 and counts[class_rows].sum()>=8*len(unique)))
        if shared and fused:
            budget=getattr(store,'coarse_shared_budget',0)
            cap=budget//(int(np.prod(store.shape[-2:]))*8*4+128)
            if cap:limit=min(limit,int(cap))
            else:shared=False
        if fused:
            from .local_schedule import LocalPairSchedule
            schedules.clear()  # bound ownership to one class-support group
            detail=getattr(store,'detail_timer',None)
            with (detail.section('local.pair_schedule',full=True) if detail else nullcontext()):
                schedule=LocalPairSchedule(host_ids,counts,class_rows,limit,store.device)
            schedules[key]=(schedule,shared)
            store.buffer.count('pair_schedule_builds')
            store.buffer.count('pair_schedule_peak_bytes',schedule.nbytes,peak=True)
            unique=schedule.unique
    tiles = 0
    maximum = 0
    blocks=(schedule.blocks(with_device_ids=True) if schedule is not None else
            ((unique[s:s+limit],None,None,None,None) for s in range(0,len(unique),limit)))
    for ids,pair,ri,oi,device_ids in blocks:
        if schedule is not None:
            fused=None
            if shared and (mode=='shared' or len(pair)>=2*len(ids)):
                from .fused_projection import score_shared_tile
                fused=score_shared_tile(store,class_index,ids,pair[:,2],shifted,factor,inv,highres,store.active_indices,ri,xnorm,
                    prepared_inputs=prepared_inputs)
            if fused is None:
                fused=fused_score(store,class_index,pair[:,2],shifted,factor,inv,highres,store.active_indices,ri,image_norm=xnorm,
                    prepared_inputs=prepared_inputs,device_ids=device_ids)
            if fused is not None:
                diff2[ri,class_index,oi]=fused
                tiles+=1;maximum=max(maximum,len(pair));store.buffer.count('coarse_union_blocks')
                store.buffer.count('coarse_orientation_upload_rows_avoided',len(pair))
                continue
        # A failed/unavailable fused dispatch must retain the smaller eager
        # workspace bound, even if the union tile was sized for fusion.
        eager_limit = max(1, fallback_limit or limit)
        for pos in range(0, len(ids), eager_limit):
            eager_ids = ids[pos:pos+eager_limit]
            reference = store.gather_active_host(class_index, eager_ids)
            for row in class_rows:
                support = host_ids[row, :counts[row]]
                lo = np.searchsorted(support, eager_ids[0], side='left')
                hi = np.searchsorted(support, eager_ids[-1], side='right')
                if hi <= lo: continue
                positions = np.searchsorted(eager_ids, support[lo:hi])
                selected = reference.index_select(0, torch.as_tensor(positions, device=reference.device))
                prediction = selected[None]*factor[row:row+1, None]
                diff2[row, class_index, lo:hi] = score(shifted[row:row+1], prediction,
                    inv[row:row+1], highres[row:row+1], image_norm=xnorm[row:row+1])[0]
                tiles += 1
                maximum = max(maximum, hi-lo)
                del selected, prediction
            store.buffer.count('coarse_union_blocks')
            del reference
    pairs = int(counts[class_rows].sum())
    store.buffer.count('coarse_requested_rows', pairs)
    store.buffer.count('coarse_unique_rows', len(unique))
    store.buffer.count('coarse_deduplicated_rows', pairs-len(unique))
    return tiles, maximum, pairs
