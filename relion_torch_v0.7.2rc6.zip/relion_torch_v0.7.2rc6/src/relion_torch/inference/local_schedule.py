"""One vectorized, bounded ragged schedule shared by classes in a local batch."""
import numpy as np
import torch


class LocalPairSchedule:
    def __init__(self,host_ids,counts,rows,limit,device):
        counts=counts[rows]
        orientations=np.concatenate([host_ids[r,:n] for r,n in zip(rows,counts)])
        self.unique,inverse=np.unique(orientations,return_inverse=True)
        row=np.repeat(rows,counts)
        position=np.arange(len(orientations))-np.repeat(np.cumsum(counts)-counts,counts)
        # Stable bucket order preserves the legacy particle-major order per tile.
        bucket=inverse//limit
        order=np.argsort(bucket,kind='stable')
        self.host=np.column_stack((row,position,orientations))[order]
        ntiles=(len(self.unique)+limit-1)//limit
        self.offsets=np.r_[0,np.cumsum(np.bincount(bucket,minlength=ntiles))]
        # Upload all three columns once. Column-major layout gives every tile
        # contiguous particle, position and orientation IDs without CUDA copies.
        self.device_indices=torch.as_tensor(self.host.T.copy(),device=device)
        self.limit=limit

    def blocks(self,*,with_device_ids=False):
        for i,(lo,hi) in enumerate(zip(self.offsets[:-1],self.offsets[1:])):
            block=(self.unique[i*self.limit:(i+1)*self.limit],self.host[lo:hi],
                   self.device_indices[0,lo:hi],self.device_indices[1,lo:hi])
            yield block+(self.device_indices[2,lo:hi],) if with_device_ids else block

    @property
    def nbytes(self):
        return self.host.nbytes+self.unique.nbytes+self.offsets.nbytes+self.device_indices.numel()*self.device_indices.element_size()
