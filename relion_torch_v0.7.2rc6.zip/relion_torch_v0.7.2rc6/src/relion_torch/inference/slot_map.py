"""Vectorized host slot lookup and second-chance replacement, no row objects."""
import numpy as np


class ClockSlotMap:
    def __init__(self, rows, capacity):
        self.capacity = max(0, min(int(rows), int(capacity)))
        self.row_to_slot = np.full(int(rows), -1, dtype=np.int64)
        self.slot_to_row = np.full(self.capacity, -1, dtype=np.int64)
        self.recent = np.zeros(self.capacity, dtype=bool)
        self.cursor = 0
        self.blocked = np.zeros(self.capacity, dtype=bool)

    def lookup(self, keys):
        slots = self.row_to_slot[keys]
        self.recent[slots[slots >= 0]] = True
        return slots

    def victims(self, count, *, protected=None):
        """Select slots in batches; hits receive a second chance.

        Protection is only needed by additive statistics, where a flush must
        not discard rows participating in the current insertion.
        """
        count = int(count)
        if not 0 <= count <= self.capacity:
            raise ValueError('invalid replacement count')
        blocked = self.blocked
        protected = np.unique(protected) if protected is not None else np.empty(0, dtype=np.int64)
        if count > self.capacity - len(protected):
            raise ValueError('insufficient unprotected cache slots')
        blocked[protected] = True
        result = []
        remaining = count
        while remaining:
            width = min(self.capacity, max(256, min(4096, remaining * 2)))
            slots = (np.arange(width, dtype=np.int64) + self.cursor) % self.capacity
            eligible = ~blocked[slots]
            ready = slots[eligible & ~self.recent[slots]][:remaining]
            self.recent[slots[eligible]] = False
            if len(ready):
                result.append(ready)
                blocked[ready] = True
                remaining -= len(ready)
                self.cursor = (int(ready[-1]) + 1) % self.capacity
            else:
                self.cursor = (self.cursor + width) % self.capacity
        selected = np.concatenate(result) if result else np.empty(0, dtype=np.int64)
        blocked[selected] = False
        blocked[protected] = False
        return selected

    def assign(self, keys, slots):
        old = self.slot_to_row[slots]
        self.row_to_slot[old[old >= 0]] = -1
        self.slot_to_row[slots] = keys
        self.row_to_slot[keys] = slots
        self.recent[slots] = True
        return old

    def release(self, slots):
        old = self.slot_to_row[slots]
        self.row_to_slot[old[old >= 0]] = -1
        self.slot_to_row[slots] = -1
        self.recent[slots] = False


class SparseClockSlotMap(ClockSlotMap):
    """Same replacement policy, with host metadata bounded by resident capacity."""
    def __init__(self, rows, capacity):
        super().__init__(min(int(rows),int(capacity)),capacity)
        self.row_to_slot={}

    def lookup(self, keys):
        slots=np.fromiter((self.row_to_slot.get(int(k),-1) for k in keys),dtype=np.int64,count=len(keys))
        self.recent[slots[slots>=0]]=True
        return slots

    def assign(self, keys, slots):
        old=self.slot_to_row[slots].copy()
        for key in old:self.row_to_slot.pop(int(key),None)
        self.slot_to_row[slots]=keys
        self.row_to_slot.update(zip(map(int,keys),map(int,slots)))
        self.recent[slots]=True
        return old

    def release(self, slots):
        for key in self.slot_to_row[slots]:self.row_to_slot.pop(int(key),None)
        self.slot_to_row[slots]=-1;self.recent[slots]=False
