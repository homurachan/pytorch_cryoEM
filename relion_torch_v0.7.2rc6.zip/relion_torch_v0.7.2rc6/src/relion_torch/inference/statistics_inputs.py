"""Batch-owned weighted inputs with original complex multiplication order."""
import torch
from . import fused_projection as fp


class StatisticsInputs:
    def __init__(self, unmasked, numerator_factor, denominator_factor, inverse_noise):
        self.unmasked = unmasked
        self.numerator_factor = numerator_factor*inverse_noise
        self.denominator_factor = denominator_factor*inverse_noise
        self.parts = None

    @property
    def nbytes(self):
        return sum(x.numel()*x.element_size() for x in (self.numerator_factor,self.denominator_factor))

    def eager(self, phase, rows, mass):
        return (phase*self.unmasked.index_select(0,rows)*self.numerator_factor.index_select(0,rows),
                mass[:,None,None]*self.denominator_factor.index_select(0,rows))

    def fused(self, phase, rows, mass, store):
        mode = getattr(store.fallback.projector,'fusion_mode','off')
        if (not fp.available(phase.device,mode) or phase.dtype!=torch.complex64
                or self.unmasked.dtype!=torch.complex64 or rows.dtype!=torch.long
                or mass.dtype!=torch.float32 or self.denominator_factor.dtype!=torch.float32
                or self.numerator_factor.dtype not in (torch.float32,torch.complex64)):
            return None
        try:
            import triton
            from .statistics_input_kernel import statistics_input_kernel
            if self.parts is None:
                self.parts = (fp._complex_parts(self.unmasked),fp._complex_parts(self.numerator_factor),
                              self.denominator_factor.contiguous())
                store._count('statistics_input_batches')
            numerator=torch.empty_like(phase, memory_format=torch.contiguous_format)
            denominator=torch.empty(phase.shape,device=phase.device,dtype=torch.float32)
            statistics_input_kernel[(triton.cdiv(phase.numel(),256),)](
                fp._complex_parts(phase),*self.parts,rows.contiguous(),mass.contiguous(),
                fp._complex_parts(numerator),denominator,phase.numel(),
                F=phase.shape[-2]*phase.shape[-1],BLOCK=256,enable_fp_fusion=False)
            key=('statistics_inputs',str(phase.device),phase.shape[-2],self.numerator_factor.is_complex())
            if key not in fp._validated:
                n=min(4,len(rows));expected=self.eager(phase[:n],rows[:n],mass[:n])
                for a,b in zip((numerator[:n],denominator[:n]),expected):
                    torch.testing.assert_close(a,b,rtol=3e-6,atol=3e-6)
                fp._validated.add(key);store._count('statistics_input_self_checks')
        except Exception as exc:
            fp._failure(exc,mode)
            return None
        store._count('statistics_input_fused_calls')
        store._count('statistics_input_fused_rows',len(rows))
        return numerator,denominator
