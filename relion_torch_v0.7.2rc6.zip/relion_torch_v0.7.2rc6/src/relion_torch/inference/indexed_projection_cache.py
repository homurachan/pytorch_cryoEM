"""Bounded contiguous projection storage for ragged SPA angular searches."""
import numpy as np
import torch
from .slot_map import ClockSlotMap, SparseClockSlotMap
from contextlib import nullcontext


class IndexedProjectionStore:
    """Contiguous projection rows addressed by global class/orientation IDs.

    A complete bank uses direct slots. Otherwise a fixed-capacity second-chance slab
    replaces the per-row tensor LRU. Only requested rows are projected, in
    batches. The caller plans a fine working-set reserve for a partial slab.
    Generic callers retain the legacy three-quarter default. Eviction discards GPU
    rows; it never transfers projection data to host memory.

    ``gather_active_host`` reuses sampler-owned NumPy IDs. Lookup/replacement
    is vectorized on the host, without GPU index readback or Python row loops.
    The tensor-ID API remains available for statistics and other consumers.
    Full planes are retained so those consumers receive ALL original pixels.
    """

    def __init__(self, fallback, active_indices, *, key, counters=None,
                 reserve_bytes=None, counter_prefix="local_projection_cache", cache_active=True, sparse_keys=False):
        self.counter_prefix = counter_prefix
        self.fallback = fallback
        self.shape = fallback.shape
        self.device, self.dtype = fallback.device, fallback.dtype
        self.active_indices = active_indices
        self.cache = fallback.cache
        self.counters = counters if counters is not None else {}
        self.total_rows = int(np.prod(self.shape[:2]))
        row_bytes = int(np.prod(self.shape[2:])) * self.element_size()
        pinned = sum(x.numel() * x.element_size() for x in self.cache.resident.values())
        available = max(0, self.cache.max_bytes - pinned)
        full_bytes = self.total_rows * row_bytes
        reserve = available // 4 if reserve_bytes is None else min(available, max(0, int(reserve_bytes)))
        budget = full_bytes if full_bytes <= available else available - reserve
        self.capacity = min(self.total_rows, budget // row_bytes)
        self.full_bank = self.capacity == self.total_rows
        self.values = (self.cache.reserve((key, 'slab'), (self.capacity, *self.shape[2:]),
                                         device=self.device, dtype=self.dtype)
                       if self.capacity else None)
        self.active_values = None
        if self.full_bank and cache_active and active_indices is not None:
            self.active_values = self.cache.reserve((key, 'active'),
                (self.capacity, active_indices.numel()), device=self.device, dtype=self.dtype)
        self.slot_type = SparseClockSlotMap if sparse_keys else ClockSlotMap
        self.slots = self.slot_type(self.total_rows, self.capacity)
        self.row_to_slot, self.slot_to_row = self.slots.row_to_slot, self.slots.slot_to_row
        self.calls = 0
        for suffix, value in dict(capacity_rows=self.capacity, total_rows=self.total_rows,
                full_bank=int(self.full_bank), bounded=int(0 < self.capacity < self.total_rows),
                index_d2h_calls=0, host_requests=0, row_evictions=0, fill_batches=0,
                projected_rows=0, hits=0, misses=0, capacity_bytes=self.capacity*row_bytes,
                partial_reserve_bytes=reserve, second_chance=1).items():
            self.counters[self.counter_prefix + '_' + suffix] = value

    def _count(self, suffix, n=1):
        key = self.counter_prefix + '_' + suffix
        self.counters[key] = self.counters.get(key, 0) + int(n)
        if suffix in ('projected_rows','row_evictions','hits','misses'):
            lifetime=self.counter_prefix+'_lifetime_'+suffix
            self.counters[lifetime]=self.counters.get(lifetime,0)+int(n)

    def release_storage(self):
        """Continue through the same exact lazy projector without retained rows."""
        self.values = self.active_values = None
        self.capacity = 0
        self.full_bank = False
        self.slots = self.slot_type(self.total_rows, 0)
        self.row_to_slot, self.slot_to_row = self.slots.row_to_slot, self.slots.slot_to_row

    @property
    def ready(self):
        if isinstance(self.row_to_slot, dict):
            raise RuntimeError('Sparse stores have no dense global ready mask; use slot lookup')
        return (self.row_to_slot >= 0).reshape(self.shape[:2])

    def element_size(self):
        return self.fallback.element_size()

    def _device_ids(self, ids):
        return torch.as_tensor(ids, device=self.device, dtype=torch.long)

    def _host_ids(self, ids):
        if torch.is_tensor(ids):
            if ids.device.type != 'cpu':
                self._count('index_d2h_calls')
            ids = ids.detach().cpu().numpy()
        return np.asarray(ids, dtype=np.int64).reshape(-1)

    def _detail(self, name):
        timer=getattr(self, "detail_timer", None)
        return timer.section("fine.cache."+name, full=True) if timer is not None else nullcontext()

    def _select(self, slots, active, active_indices=None):
        with self._detail("gather"):
            return self._select_impl(slots, active, active_indices)

    def _select_impl(self, slots, active, active_indices=None):
        ids = self._device_ids(slots)
        indices = self.active_indices if active_indices is None else active_indices
        if active:
            if self.active_values is not None and indices is self.active_indices:
                return self.active_values.index_select(0, ids)
            # Read only the requested pixels in one indexed GPU operation;
            # do not materialize full Fourier planes just to crop them again.
            self._count('active_gather_rows', len(slots))
            return self.values.flatten(-2)[ids[:, None], indices[None, :]]
        return self.values.index_select(0, ids)

    def _write(self, keys, value):
        if not self.capacity:
            return
        if self.full_bank:
            slots = keys
        else:
            # Requests can exceed capacity. Retain the last rows; the complete
            # result lives separately from the evictable slab.
            keys, value = keys[-self.capacity:], value[-self.capacity:]
            slots = self.slots.victims(len(keys))
            evicted = self.slot_to_row[slots]
            count = int((evicted >= 0).sum())
            self._count('row_evictions', count)
            self.cache.evictions += count
        ti = self._device_ids(slots)
        self.values.index_copy_(0, ti, value)
        if self.active_values is not None:
            self.active_values.index_copy_(0, ti, value.flatten(-2).index_select(-1, self.active_indices))
        self.slots.assign(keys, slots)

    def _gather_host(self, c, host, active, active_indices=None):
        indices = self.active_indices if active_indices is None else active_indices
        if not 0 <= c < self.shape[0] or np.any((host < 0) | (host >= self.shape[1])):
            raise IndexError('Projection class/orientation outside global sampling grid')
        out_shape = (len(host), indices.numel()) if active else (len(host), *self.shape[2:])
        if not len(host):
            return torch.empty(out_shape, device=self.device, dtype=self.dtype)
        # Local support is already sorted and unique. Arbitrary statistics
        # requests also accept duplicates and preserve their original order.
        if len(host) == 1 or np.all(host[1:] > host[:-1]):
            unique, inverse = host, None
        else:
            unique, inverse = np.unique(host, return_inverse=True)
        keys = c * self.shape[1] + unique
        with self._detail("lookup"):
            slots = self.slots.lookup(keys)
        hit = slots >= 0
        missing_positions = np.flatnonzero(~hit)
        self.cache.hits += int(hit.sum())
        self.cache.misses += len(missing_positions)
        self._count("hits", int(hit.sum()))
        self._count("misses", len(missing_positions))
        if not len(missing_positions):
            return self._select(slots if inverse is None else slots[inverse], active, indices)
        result = None
        if not self.full_bank:
            result = torch.empty((len(unique), *out_shape[1:]), device=self.device, dtype=self.dtype)
            positions = np.flatnonzero(hit)
            if len(positions):
                # Snapshot hits BEFORE inserting misses that may evict them.
                result.index_copy_(0, self._device_ids(positions), self._select(slots[positions], active, indices))
        for start in range(0, len(missing_positions), self.fallback.max_chunk):
            positions = missing_positions[start:start+self.fallback.max_chunk]
            with self._detail("project"):
                value = None
                if getattr(self, 'fused_generation', False):
                    from .fused_projection import project_rows
                    value = project_rows(self, c, unique[positions])
                    self._count('fused_generation_rows' if value is not None else 'eager_fallback_rows', len(positions))
                if value is not None:
                    pass
                elif hasattr(self.fallback, 'project_host'):
                    value = self.fallback.project_host(c, unique[positions])
                else:
                    selected = self._device_ids(unique[positions])
                    value = self.fallback.project(c, selected)
            if value.ndim == 2:
                value = value[None]
            with self._detail("write"):
                self._write(keys[positions], value)
            if result is not None:
                pixels = value.flatten(-2).index_select(-1, indices) if active else value
                result.index_copy_(0, self._device_ids(positions), pixels)
            self.calls += 1
            self._count('fill_batches')
            self._count('projected_rows', len(positions))
        if self.full_bank:
            return self._select(keys if inverse is None else keys[inverse], active, indices)
        return result if inverse is None else result.index_select(0, self._device_ids(inverse))

    def gather(self, c, ids):
        return self._gather_host(int(c), self._host_ids(ids), False)

    def gather_active(self, c, ids):
        return self._gather_host(int(c), self._host_ids(ids), True)

    def gather_active_host(self, c, ids):
        """Use sampler-owned host IDs, with no GPU-to-host index transfer."""
        if torch.is_tensor(ids):
            raise TypeError('gather_active_host expects host array indices')
        self._count('host_requests')
        return self._gather_host(int(c), np.asarray(ids, dtype=np.int64).reshape(-1), True)

    def gather_host(self, c, ids):
        self._count("host_requests")
        return self._gather_host(int(c), np.asarray(ids, dtype=np.int64).reshape(-1), False)

    def slice_active(self, c, start, stop, active):
        if active is self.active_indices:
            return self.gather_active_host(c, np.arange(start, stop, dtype=np.int64))
        return self.gather_host(c, np.arange(start, stop, dtype=np.int64)).flatten(-2).index_select(-1, active)

    def gather_selected_host(self, c, ids, active_indices):
        self._count('host_requests')
        return self._gather_host(int(c), np.asarray(ids, dtype=np.int64).reshape(-1), True, active_indices)
