"""Unnormalised fine scores for callers that add another latent dimension.

The ordinary alignment path still performs its original weight selection. A
scores-only caller must normalise all latent states together before using this
packet for weighted sums; a per-defocus posterior is never used as a prior.
"""
from dataclasses import dataclass
import torch


@dataclass
class FineScoreBatch:
    geometry: dict
    diff2: torch.Tensor
    log_prior: torch.Tensor
    highres_xi2_half: torch.Tensor
    log_sigma2: torch.Tensor
    execution_stats: dict
    scoring_inputs: dict | None = None

    def expectation(self, posterior, significant, *, evidence, significant_count, threshold):
        from .alignment import SparseAdaptiveBatchExpectation
        g = self.geometry
        rows, classes = g['parent_particle_indices'], g['parent_class_indices']
        b, k = g['coarse'].class_mass.shape
        mass = (posterior.double() * significant).sum((1, 2))
        class_mass = torch.zeros(b*k, device=rows.device, dtype=torch.float64)
        class_mass.index_add_(0, rows*k+classes, mass)
        # These per-slice maxima are not the joint metadata estimate. They keep
        # the standard expectation contract valid for generic/debug consumers.
        count = torch.bincount(rows, minlength=b)
        offset = count.cumsum(0)-count
        children = self.diff2.shape[1]*self.diff2.shape[2]
        slots = (torch.arange(len(rows), device=rows.device)-offset[rows])[:, None]*children
        slots = slots+torch.arange(children, device=rows.device)[None]
        packed = torch.full((b, int(count.max())*children), -1., device=rows.device, dtype=posterior.dtype)
        packed[rows[:, None], slots] = posterior.flatten(1)
        best = packed.argmax(1)
        parent = offset+best//children
        child = best % children
        return SparseAdaptiveBatchExpectation(**g, diff2=self.diff2, log_prior=self.log_prior,
            posterior=posterior, significant=significant, class_mass=class_mass.reshape(b, k),
            parent_mass64=mass, fine_reported_significant_count=significant_count,
            fine_significant_weight=threshold, fine_log_evidence=evidence,
            best_parent_indices=parent, best_orientation_child_indices=child//self.diff2.shape[2],
            best_translation_child_indices=child % self.diff2.shape[2], pmax=packed.max(1).values.double(),
            log_likelihood_contribution=evidence-self.log_sigma2.double(),
            highres_xi2_half=self.highres_xi2_half, log_sigma2=self.log_sigma2,
            execution_stats=self.execution_stats)
