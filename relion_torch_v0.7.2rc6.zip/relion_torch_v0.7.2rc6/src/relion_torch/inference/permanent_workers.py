"""Persistent spawn workers with immutable iteration models and exact sum reduction.

One process owns each device for the entire run. Only CPU tensors cross the
transport boundary; CUDA contexts, allocators and compiled kernels stay local.
Half identity belongs to a model slot, never to a particle scheduling decision.
"""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from multiprocessing.connection import wait
import copy
import math
import multiprocessing as mp
import os
import time
import traceback
import numpy as np
import torch

from relion_torch.relion_statistics import shell_to_angstrom


MODEL_FIELDS = ('class_prob','class_offsets','direction_priors','norm_corrections',
    'group_scales','rotation_accuracy_deg','translation_accuracy_angstrom','sigma2',
    'tau2','sigma2_class','data_vs_prior','fourier_coverage','orientability_contrib',
    'avg_norm_correction','refs_are_ctf_corrected','sigma_offset_angstrom',
    'generate_seeds','working_psnr_shell','working_current_size','psnr_shell',
    'last_completed_iteration','_iteration_history','_direction_prior_reset_pending',
    'last_ll','last_pmax','last_changes','initial_mode','original_psi_step',
    'original_offset_step','original_offset_range','sizes','_iteration_sizes',
    'controller_shell','final_iteration','fsc','_subset_state')


def tree(value, device='cpu'):
    if torch.is_tensor(value):return value.detach().to(device).clone()
    if isinstance(value, list):return [tree(v,device) for v in value]
    if isinstance(value, tuple):return tuple(tree(v,device) for v in value)
    if isinstance(value, dict):return {k:tree(v,device) for k,v in value.items()}
    return copy.deepcopy(value)


def devices(options):
    spec=getattr(options,'devices','')
    if not spec:return []
    result=[str(torch.device('cuda:'+x.strip() if x.strip().isdigit() else x.strip())) for x in spec.split(',')]
    result=['cuda:0' if d=='cuda' else d for d in result]
    if any(torch.device(d).type not in ('cpu','cuda') for d in result):
        raise ValueError('--devices accepts CUDA devices, or cpu,cpu for process validation')
    cuda=[d for d in result if d!='cpu']
    if len(set(cuda))!=len(cuda):raise ValueError('Each permanent CUDA worker must own a distinct device')
    if cuda and (not torch.cuda.is_available() or any(int(d.split(':')[-1])>=torch.cuda.device_count() for d in cuda)):
        raise ValueError('A requested CUDA worker device is unavailable')
    if 'cpu' in result and cuda:raise ValueError('Do not mix CPU validation workers with CUDA workers')
    return result


def configure_coordinator(options,n):
    """Host model slots need a valid projector bound before device planning."""
    if getattr(options,'devices','') and getattr(options,'auto_memory',False):
        from relion_torch.class3d.memory import volume_payloads
        projector,_,_=volume_payloads(n,n,options.padding_factor)
        options.projector_cache_mib=max(options.projector_cache_mib,projector/2**20)
        if not options.local_angular_search:
            from relion_torch.geometry.symmetry import direction_count
            psi=options.psi_step_deg or 360./(6*(1<<options.healpix_order))
            table=direction_count(options.healpix_order,options.symmetry)*math.ceil(360./psi)*(1+8**options.oversampling)*40
            options.sampling_work_mib=max(options.sampling_work_mib,math.ceil(table/2**20))


def export_model(o):
    sampling=copy.copy(o.sampling)
    if hasattr(sampling,'_tables'):sampling._tables={}
    return dict(attrs={k:tree(getattr(o,k)) for k in MODEL_FIELDS if hasattr(o,k)},
        references=tree(o.references),sigma2=tree(o.sigma2),sampling=sampling,
        rng=copy.deepcopy(o.generator.bit_generator.state),particles=o.dataset.particles.copy(),
        config=copy.deepcopy(o.config),options=copy.deepcopy(o.options),
        requested=copy.deepcopy(getattr(o,'requested_options',o.options)))


def import_model(o,state):
    device=o.device
    o.config=copy.deepcopy(state['config']);o.config.device=str(device)
    o.options=copy.deepcopy(state['options']);o.options.device=str(device)
    if hasattr(o,'requested_options'):o.requested_options=copy.deepcopy(state['requested'])
    for k,v in state['attrs'].items():setattr(o,k,tree(v,device))
    o.sampling=copy.deepcopy(state['sampling'])
    o.generator.bit_generator.state=copy.deepcopy(state['rng'])
    o.dataset.replace_particles(state['particles'].copy())
    o._set_references(state['references'])
    o._perf_norm_values=None;o._perf_prediction_scales=None


def batches(o,indices):
    """Each batch is claimed once. Preserve the worker's normal IO pooling."""
    channel=getattr(o,'_work_channel',None)
    if channel is None:
        yield from o.dataset.iter_image_batches(device=o.device,batch_size=(o._execution_read_batch_size() if hasattr(o,'_execution_read_batch_size') else o.config.batch_size),indices=indices)
        return
    done=[]
    while True:
        # Claim several compute batches so pooled IO can still read ahead.
        read_batch=o._execution_read_batch_size() if hasattr(o,'_execution_read_batch_size') else o.config.batch_size
        requested=max(read_batch,int(getattr(o.options,'worker_chunk_size',256)))
        channel.send(('batch',requested))
        rows=channel.recv()
        if rows is None:break
        for ix,raw in o.dataset.iter_image_batches(device=o.device,batch_size=read_batch,indices=rows):
            done.extend(np.asarray(ix,dtype=np.int64).tolist())
            yield ix,raw
    o._processed_indices=np.asarray(done,dtype=np.int64)


def pack_packet(o,packet):
    """Strip device owners/events; transport only additive sufficient statistics."""
    key='bps' if 'bps' in packet else 'backprojectors'
    arrays=[]
    for bp in packet[key].objects:
        arrays.append(replace(bp,numerator_real=bp.numerator_real.cpu().clone(),
            numerator_imag=bp.numerator_imag.cpu().clone(),denominator=bp.denominator.cpu().clone()))
    omitted={key,'timer','engine'}
    data={k:tree(v) for k,v in packet.items() if k not in omitted}
    data['_grids']=arrays;data['_grid_key']=key
    data['_processed']=o._processed_indices
    data['_report']=dict(pid=os.getpid(),device=str(o.device),particles=len(o._processed_indices),
        seconds=dict(packet['timer'].seconds),calls=dict(packet['timer'].calls),
        counters=dict(o._perf_counters),details=o._detail_timer.report(),
        cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(o.device) if o.device.type=='cuda' else 0)
    data['_report']['particle_io']=o.dataset.images.cache_report()
    plan=getattr(o,'_memory_plan',None)
    if plan is not None:data['_report']['automatic_plan']=plan.as_dict()
    return data


def unpack_packet(o,data):
    from relion_torch.alignment.core import ValidatedBackprojectorAdapter
    from relion_torch.class2d.performance import StageTimer
    data=dict(data);grids=data.pop('_grids');key=data.pop('_grid_key')
    if key=='bps' and o.device.type=='cuda':
        # Reconstruction visits classes sequentially. Preserve RAM spill rather
        # than copying every reduced class volume onto the leader GPU at once.
        from relion_torch.class3d.resources import BackprojectorPool
        first=grids[0]
        rowbytes=sum(x.numel()*x.element_size() for x in (first.numerator_real,first.numerator_imag,first.denominator))
        pool=BackprojectorPool(len(grids),first.original_size,first.current_size,first.padding_factor,
            o.device,rowbytes,int(o.options.backprojector_host_gib*2**30),o._perf_counters)
        pool.host=dict(enumerate(grids))
    else:
        pool=object.__new__(ValidatedBackprojectorAdapter)
        pool.objects=[replace(bp,numerator_real=bp.numerator_real.to(o.device),
            numerator_imag=bp.numerator_imag.to(o.device),denominator=bp.denominator.to(o.device)) for bp in grids]
    packet=tree(data,o.device);packet[key]=pool
    packet['timer']=StageTimer(getattr(o.options,'timing',False),o.device)
    packet['timer'].seconds.update(packet.pop('_root_seconds',{}))
    packet['timer'].calls.update(packet.pop('_root_calls',{}))
    packet['timer'].distributed=packet.pop('_distributed',{})
    return packet


def merge_packets(parts,selected,size):
    """Sum raw numerators/denominators and statistics, never reconstructed maps."""
    result=parts[0];seen=np.zeros(size,dtype=np.int8)
    additive3=('mass','direction','offset2','normpower','dll','pmax','groupmass','noisesum','gx','ga')
    additive2=('mass','offset_sum','offset_square','group_mass','noise_sum','group_xa','group_aa','norm_power')
    additive=additive3 if result['_grid_key']=='bps' else additive2
    reports=[]
    for number,part in enumerate(parts):
        ix=part['_processed'];seen[ix]+=1;reports.append(part['_report'])
        if number:
            for a,b in zip(result['_grids'],part['_grids']):
                if (a.current_size,a.padding_factor,a._point_group_enforced)!=(b.current_size,b.padding_factor,b._point_group_enforced):
                    raise RuntimeError('Incompatible distributed Fourier grids')
                a.numerator_real.add_(b.numerator_real);a.numerator_imag.add_(b.numerator_imag);a.denominator.add_(b.denominator)
                a.n_observations+=b.n_observations
            for key in additive:result[key]+=part[key]
            for col in part['updated']:
                if col not in result['updated']:result['updated'][col]=np.nan
                result['updated'].loc[ix,col]=part['updated'].loc[ix,col].to_numpy()
            if 'dlls' in result:result['dlls']+=part['dlls'];result['pmaxs']+=part['pmaxs']
    expected=np.zeros(size,dtype=np.int8);expected[selected]=1
    if not np.array_equal(seen,expected):raise RuntimeError('Worker particle coverage contains missing or duplicate rows')
    result['total']=float(result['mass'].sum())
    if not np.isfinite(result['total']) or result['total']<=0:raise FloatingPointError('No finite distributed posterior mass')
    result['_processed']=selected
    if 'selected' in result:result['selected']=selected;result['count']=len(selected)
    else:result['selected_indices']=selected;result['active_count']=len(selected)
    result['_distributed']=dict(worker_reports=reports,particles=len(selected),
        semantics='worker stage times are summed work, not parallel wall time; root seconds are wall time')
    return result


def reconstruct_grid(bp,device,normalise,options,fsc=None):
    """GPU reconstruction for final/FSC maps, without updating a half model."""
    from relion_torch.reconstruction.half_fsc import move_backprojector,unregularized_map
    from relion_torch.reconstruction.ssnr import update_ssnr_arrays
    from relion_torch.reconstruction import ReconstructionOptions,reconstruct_backprojector
    # CPU tensors sent by multiprocessing can share their storage with the
    # coordinator, but the dataclass's Hermitian-completed flag is not shared.
    # A read-only reconstruction RPC must not complete those shared arrays in
    # place and leave the sender liable to complete x=0 a second time. A device
    # transfer already owns new storage; clone only for a same-device RPC.
    bp=move_backprojector(bp,device,clone=bp.denominator.device==torch.device(device))
    if fsc is None:
        return dict(map=unregularized_map(bp,normalise=normalise,
            preweight_iterations=options['preweight_iterations'],skip_gridding=options.get('skip_gridding',False),backend=options.get('reconstruction_backend','auto')).cpu())
    from relion_torch.reconstruction.workspace import ReconstructionWorkspace
    workspace=ReconstructionWorkspace(bp)
    ssnr=update_ssnr_arrays(bp,options['tau2'].to(device),workspace=workspace,fsc=fsc.to(device),
        update_tau2_with_fsc=True,reconstruct_whole_map_from_fsc=True,tau2_fudge=options['tau2_fudge'])
    result=reconstruct_backprojector(bp,ReconstructionOptions(tau2=ssnr.tau2,
        tau2_fudge=options['tau2_fudge'],preweight_iterations=options['preweight_iterations'],
        normalise=normalise,min_resol_shell=options['minres_map'],sirm=options.get('sirm'),
        skip_gridding=options.get('skip_gridding',False),backend=options.get('reconstruction_backend','auto')),workspace=workspace)
    return dict(map=result.map.cpu(),tau2=ssnr.tau2.cpu(),sigma2_class=ssnr.sigma2.cpu(),
        data_vs_prior=ssnr.data_vs_prior.cpu(),fourier_coverage=ssnr.fourier_coverage.cpu())


def _create(kind,descriptor,state,device):
    from relion_torch.alignment.core import AlignmentDataset
    from relion_torch.io.particle_store import ParticleIOOptions
    from relion_torch.class2d.optimiser import Class2DOptimiser
    from relion_torch.class3d.optimiser import Class3DOptimiser
    from relion_torch.auto_refine.worker import HalfOptimiser,HalfDataset
    rows=descriptor['parent_particles'] if kind=='half' else state['particles']
    rows=rows.drop(columns=['__relion_torch_source_row'],errors='ignore')
    parent=AlignmentDataset(descriptor['star'],io_options=ParticleIOOptions.from_config(state['options']),
        preserve_noise_groups=True,metadata_tables=(descriptor['optics'],rows))
    parent.optics=descriptor['optics'].copy()
    # Both half slots (including odd device counts) map the SAME full raw
    # cache. HalfDataset only supplies logical row views, never raw copies.
    if parent.io_options.preread_images:
        try:
            shared=descriptor.get('shared_preread')
            if shared is None:
                raise RuntimeError('Permanent workers require a coordinator-owned shared preread cache')
            parent.images.attach_shared(shared)
        except BaseException:
            parent.close()
            raise
    if kind=='half':
        parent.replace_particles(descriptor['parent_particles'].copy())
        dataset=HalfDataset(parent,descriptor['half'])
    else:dataset=parent
    dataset.replace_particles(state['particles'].copy())
    base={'half':HalfOptimiser,'3d':Class3DOptimiser,'2d':Class2DOptimiser}[kind]
    if kind=='half' and getattr(state['options'],'combine_refine',False):
        from relion_torch.combine_refine.worker import CombineOptimiser
        base=CombineOptimiser
    # Constructor noise initialization consumes the supplied frozen spectrum.
    # Normal checkpoint migration is only performed once by the coordinator.
    class Replica(base):
        def restore_checkpoint(self,value):pass
    cfg=copy.deepcopy(state['config']);cfg.device=device
    opts=copy.deepcopy(state['options']);opts.device=device
    if kind=='2d':o=Replica(cfg,class2d_config=opts,dataset=dataset,initial_references=state['references'],checkpoint_state=state)
    else:o=Replica(cfg,options=opts,dataset=dataset,initial_references=state['references'],checkpoint_state=state,
                  **({'half_id':descriptor['half']} if kind=='half' else {}))
    import_model(o,state)
    if hasattr(o,'_startup_checkpoint'):o._startup_checkpoint=None
    return o,parent


def _worker(channel,device,log,threads):
    import sys
    stream=open(log,'a',encoding='utf-8',buffering=1);sys.stdout=sys.stderr=stream
    torch.set_num_threads(threads)
    slots={};parents=[];active=None
    try:
        if device.startswith('cuda'):torch.cuda.set_device(torch.device(device))
        channel.send(('ready',os.getpid()))
        while True:
            message=channel.recv()
            if message['op']=='close':break
            slot=message['slot'];state=message.get('state')
            if active is not None and active!=slot:
                # Odd device counts time-share halves, without retaining both
                # half models on a GPU. Process and JIT cache remain alive.
                from relion_torch.auto_refine.worker import HalfOptimiser
                old=slots[active];HalfOptimiser.move_to(old,'cpu')
            if slot not in slots:
                o,parent=_create(message['kind'],message['descriptor'],state,device)
                slots[slot]=o;parents.append(parent)
            o=slots[slot]
            if str(o.device)!=device:
                from relion_torch.auto_refine.worker import HalfOptimiser
                o.move_to(device)
            active=slot
            if state is not None:import_model(o,state)
            if message['op'] in ('accuracy','spectra'):
                from relion_torch.inference.memory_planning import CudaMemoryController
                with CudaMemoryController(device,getattr(o.options,'gpu_memory_percent',100.),automatic=getattr(o.options,'auto_memory',True)):
                    if message['op']=='spectra':channel.send(('result',tree(o._current_tau2())))
                    else:
                        o._calculate_expected_accuracies(o.sigma2,particle_indices=message['indices'])
                        channel.send(('result',{key:tree(getattr(o,key)) for key in
                            ('rotation_accuracy_deg','translation_accuracy_angstrom','orientability_contrib')}))
            elif message['op']=='expectation':
                from relion_torch.inference.memory_planning import CudaMemoryController
                o._distributed_prepared=True;o._work_channel=channel;o._processed_indices=np.empty(0,dtype=np.int64)
                o._distributed_selected=np.asarray(message['selected'],dtype=np.int64)
                with CudaMemoryController(device,getattr(o.options,'gpu_memory_percent',100.),automatic=getattr(o.options,'auto_memory',True)) as guard:
                    if hasattr(o,'memory_controller'):o.memory_controller=guard if guard.enabled and guard.automatic else None
                    packet=o.expectation_step(message['iteration'])
                    data=pack_packet(o,packet)
                    o._work_channel=None;o._distributed_prepared=False
                    channel.send(('result',data))
                    del packet,data
            elif message['op']=='reconstruction':
                from relion_torch.inference.memory_planning import CudaMemoryController
                if hasattr(o,'_projector_pool'):o._projector_pool.clear()
                with CudaMemoryController(device,getattr(o.options,'gpu_memory_percent',100.),automatic=getattr(o.options,'auto_memory',True)):
                    result=reconstruct_grid(message['grid'],device,message['normalise'],message['options'],message.get('fsc'))
                    channel.send(('result',result))
                    del result
            elif message['op']=='maximization':
                from relion_torch.class2d.performance import DetailTimer
                from relion_torch.inference.memory_planning import CudaMemoryController
                o._detail_timer=DetailTimer(o.options.timing,device,o.options.timing_detail_samples);o._perf_counters=message['counters']
                o._memory_plan=None
                if hasattr(o,'memory_controller'):o.memory_controller=None
                if 'fsc' in message:o.fsc=message['fsc'].to(device)
                with CudaMemoryController(device,getattr(o.options,'gpu_memory_percent',100.),automatic=getattr(o.options,'auto_memory',True)):
                    packet=unpack_packet(o,message['packet'])
                    o.maximization_step(message['iteration'],packet)
                    channel.send(('result',export_model(o)))
                del packet
            else:raise ValueError('Unknown worker operation')
    except BaseException:
        try:channel.send(('error',traceback.format_exc()))
        except (OSError,EOFError):pass
    finally:
        for parent in parents:parent.close()
        channel.close();stream.close()


class PermanentPool:
    def __init__(self,options):
        self.devices=devices(options);self.options=options;self.processes=[];self.channels=[];self.closed=False
        root=Path(str(options.output_root)+'_workers');root.mkdir(parents=True,exist_ok=True)
        ctx=mp.get_context('spawn')
        try:
            for i,device in enumerate(self.devices):
                a,b=ctx.Pipe();p=ctx.Process(target=_worker,args=(b,device,str(root/f'worker_{i}.log'),getattr(options,'worker_threads',1)))
                p.start();b.close();self.processes.append(p);self.channels.append(a)
            for ch in self.channels:
                tag,pid=self._receive(ch)
                if tag!='ready':raise RuntimeError(str(pid))
        except BaseException:self.close();raise
        print('Permanent workers: '+', '.join(f'{d} (PID {p.pid})' for d,p in zip(self.devices,self.processes)),flush=True)

    def _receive(self,ch):
        while not ch.poll(.2):
            p=self.processes[self.channels.index(ch)]
            if not p.is_alive():raise RuntimeError(f'GPU worker PID {p.pid} exited with code {p.exitcode}; see worker log')
        value=ch.recv()
        if value[0]=='error':raise RuntimeError('Permanent worker failed:\n'+value[1])
        return value

    def group(self,slot):
        n=len(self.devices)
        if slot in (1,2) and n%2==0:return list(range((slot-1)*(n//2),slot*(n//2)))
        return list(range(n))

    def bind(self,o,slot=0,parent=None):
        o._permanent_pool=self;o._model_slot=slot
        o._worker_descriptor=dict(star=str(o.dataset.star_path),optics=o.dataset.optics.copy())
        if o.dataset.io_options.preread_images:
            images=(parent if parent is not None else o.dataset).images
            shared=images.shared_descriptor()
            if shared is None:
                raise RuntimeError('Permanent workers require shared preread at dataset startup')
            o._worker_descriptor['shared_preread']=shared
        if slot:
            o._worker_descriptor.update(half=slot,parent_particles=parent.particles.copy())

    def expectation(self,o,iteration,selected,timer,begin):
        slot=o._model_slot;indices=np.arange(len(o.dataset)) if selected is None else np.asarray(selected,dtype=np.int64)
        schedule=o._execution_indices(indices) if hasattr(o,'_execution_indices') else indices
        # All raw grids pass through host RAM. Bound coordinator results and
        # transport copies explicitly; no silent unbounded host accumulation.
        if o.config.reference_dim==3:
            from relion_torch.class3d.memory import volume_payloads
            _,grid,_=volume_payloads(o.dataset.box_size,o.sizes.current_size,o.config.padding_factor)
            copies=2*len(self.devices)+4
            need=grid*len(o.references)*copies
            if need>o.options.backprojector_host_gib*2**30:
                raise MemoryError(f'Multi-GPU host reduction needs an estimated {need/2**30:.2f} GiB of grid RAM; increase --backprojector-host-gib.')
        state=export_model(o);group=self.group(slot);pending={self.channels[i]:i for i in group};parts={};cursor=0
        start=time.perf_counter();last_progress=start;completed=0;inflight={}
        message=dict(op='expectation',slot=slot,kind='half' if slot else ('3d' if o.config.reference_dim==3 else '2d'),
            descriptor=o._worker_descriptor,state=state,iteration=iteration,selected=indices)
        for ch in pending:ch.send(message)
        while pending:
            ready=wait(list(pending),timeout=.2)
            if not ready:
                for ch,i in pending.items():
                    if not self.processes[i].is_alive():self._receive(ch)
            for ch in ready:
                tag,value=self._receive(ch)
                if tag=='batch':
                    completed+=inflight.pop(ch,0)
                    rows=schedule[cursor:cursor+value];cursor+=len(rows)
                    inflight[ch]=len(rows)
                    ch.send(rows if len(rows) else None)
                    now=time.perf_counter()
                    if getattr(o.options,'progress',True) and now-last_progress>=30:
                        print(f'  {"Half "+str(slot) if slot else "Particles"}: {completed}/{len(indices)} completed across {len(group)} permanent workers',flush=True)
                        last_progress=now
                elif tag=='result':parts[pending.pop(ch)]=value
                else:raise RuntimeError('Invalid worker response')
        result=merge_packets([parts[i] for i in group],indices,len(o.dataset))
        elapsed=time.perf_counter()-start
        result['_root_seconds']=dict(timer.seconds);result['_root_seconds']['distributed_expectation_and_reduce']=elapsed
        result['_root_calls']=dict(timer.calls);result['_root_calls']['distributed_expectation_and_reduce']=1
        result['_distributed'].update(devices=[self.devices[i] for i in group],worker_pids=[self.processes[i].pid for i in group],half=slot)
        if hasattr(o,'_subset_state') and o._subset_state is not None:
            result['sub' if 'sub' in result else 'subset_info']['order_sha256']=o._subset_state.digest(indices)
        result['begin' if 'begin' in result else 'begun']=begin
        o._distributed_packet=result
        # The coordinator needs CPU grids for FSC; maximization is dispatched
        # back to a GPU worker using the same raw reduced packet.
        packet=unpack_packet(o,result)
        o._perf_counters={}
        for p in result['_distributed']['worker_reports']:
            for key,value in p['counters'].items():
                if any(x in key for x in ('bytes','peak','max','capacity','budget')):o._perf_counters[key]=max(o._perf_counters.get(key,0),value)
                else:o._perf_counters[key]=o._perf_counters.get(key,0)+value
        return packet

    def accuracy(self,o,indices):
        slot=o._model_slot;ch=self.channels[self.group(slot)[0]]
        ch.send(dict(op='accuracy',slot=slot,kind='half' if slot else ('3d' if o.config.reference_dim==3 else '2d'),
            descriptor=o._worker_descriptor,state=export_model(o),indices=indices))
        tag,state=self._receive(ch)
        for k,v in state.items():setattr(o,k,tree(v,o.device))

    def spectra(self,o):
        slot=o._model_slot;ch=self.channels[self.group(slot)[0]]
        ch.send(dict(op='spectra',slot=slot,kind='half' if slot else ('3d' if o.config.reference_dim==3 else '2d'),
            descriptor=o._worker_descriptor,state=export_model(o)))
        return self._receive(ch)[1]

    def maximization(self,o,iteration,packet):
        # Root FSC/optional low-resolution exchange may have changed the grids.
        raw=o._distributed_packet;key=raw['_grid_key']
        for name in ('begin','begun'):
            if name in packet:raw[name]=packet[name]
        raw['_grids']=list(packet[key].objects)
        slot=o._model_slot;leader=self.group(slot)[0];ch=self.channels[leader]
        msg=dict(op='maximization',slot=slot,packet=raw,iteration=iteration,counters=o._perf_counters)
        if slot:msg['fsc']=o.fsc.cpu()
        ch.send(msg);tag,state=self._receive(ch)
        import_model(o,state);o._distributed_packet=None
        if not slot:
            record=o._iteration_history[-1]
            shell=o.working_psnr_shell if o.config.reference_dim==2 else o.psnr_shell
            resolution=shell_to_angstrom(o.dataset.box_size,o.dataset.pixel_size,shell)
            print(f'Iteration {iteration}: resolution={resolution:.4g} A; LL={record["LL"]:.7g}; Pmax={record["Pmax"]:.6g}; combined model and checkpoint written.',flush=True)
        return o.references

    def reconstruct(self,slot,grid,normalise,options,fsc=None,tau2=None):
        ch=self.channels[self.group(slot)[0]]
        from relion_torch.reconstruction.sirm import sirm_options_from_config
        cfg=dict(sirm=sirm_options_from_config(options,fsc=fsc) if fsc is not None else None,
            preweight_iterations=options.preweight_iterations,tau2_fudge=options.tau2_fudge,
            skip_gridding=options.skip_gridding,reconstruction_backend=options.reconstruction_backend,
            minres_map=options.minres_map,tau2=tau2)
        ch.send(dict(op='reconstruction',slot=slot,grid=grid,normalise=normalise,options=cfg,fsc=fsc))
        return self._receive(ch)[1]

    def close(self):
        if self.closed:return
        self.closed=True
        for ch,p in zip(self.channels,self.processes):
            if p.is_alive():
                try:ch.send({'op':'close'})
                except (BrokenPipeError,OSError):pass
        for p in self.processes:
            p.join(3)
            if p.is_alive():p.terminate();p.join(3)
        for ch in self.channels:ch.close()


def parallel_halves(workers,options,operation,iteration,*args):
    def invoke(w):
        start=time.perf_counter();value=getattr(w,operation)(iteration,*args)
        return w.half_id,value,time.perf_counter()-start
    if getattr(workers[0].optimiser,'_permanent_pool',None) is not None and len(devices(options))%2==0:
        with ThreadPoolExecutor(max_workers=2) as executor:return list(executor.map(invoke,workers))
    return [invoke(w) for w in workers]


def accuracy(o,sigma,particle_indices=None):
    pool=getattr(o,'_permanent_pool',None)
    if pool is not None:return pool.accuracy(o,particle_indices)
    return o._calculate_expected_accuracies(sigma,particle_indices=particle_indices)
