"""Global-search epilogues. GEMMs, reductions and sorting retain PyTorch semantics."""
import triton
import triton.language as tl
from triton.language.extra.cuda import libdevice


@triton.jit
def score_epilogue_kernel(R, I, PN, XN, HIGH, OUT, N,
                          O: tl.constexpr, T: tl.constexpr, BLOCK: tl.constexpr):
    j = tl.program_id(0).to(tl.int64)*BLOCK+tl.arange(0, BLOCK)
    valid = j < N
    t, o, b = j % T, (j//T) % O, j//(T*O)
    src = (b*T+t)*O+o
    cross = tl.load(R+src, valid, 0)+tl.load(I+src, valid, 0)
    pn = tl.load(PN+b*O+o, valid, 0)
    xn = tl.load(XN+b, valid, 0)
    high = tl.load(HIGH+b, valid, 0)
    value = 0.5*((pn+xn)-2.0*cross)
    tl.store(OUT+j, tl.maximum(value, 0.0, propagate_nan=tl.PropagateNan.ALL)+high, valid)


@triton.jit
def raw_weights_kernel(SCORE, VALID, SHIFT, OUT, N, H: tl.constexpr, BLOCK: tl.constexpr):
    j = tl.program_id(0).to(tl.int64)*BLOCK+tl.arange(0, BLOCK)
    ok = j < N
    score = tl.load(SCORE+j, ok, -float('inf'))
    valid = tl.load(VALID+j, ok, 0)
    exponent = score+tl.load(SHIFT+j//H, ok, 0)
    # CUDA expf, not fast exp2; cutoff and the subsequent scan/sort stay unchanged.
    raw = tl.where(valid & (exponent >= -88.0), libdevice.exp(exponent), 0.0)
    tl.store(OUT+j, raw, ok)
