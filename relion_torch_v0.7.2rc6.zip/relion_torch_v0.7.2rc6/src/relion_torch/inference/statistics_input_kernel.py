"""Fused private gridding inputs; does not write a live backprojector."""
import triton
import triton.language as tl


@triton.jit
def statistics_input_kernel(PHASE, IMAGE, NUM_FACTOR, DEN_FACTOR, ROWS, MASS,
                            NUM, DEN, N, F: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0)*BLOCK+tl.arange(0, BLOCK)
    valid = i < N
    row, pixel = i//F, i % F
    particle = tl.load(ROWS+row, valid, 0)
    pos = particle*F+pixel
    pr = tl.load(PHASE+2*i, valid, 0)
    pi = tl.load(PHASE+2*i+1, valid, 0)
    xr = tl.load(IMAGE+2*pos, valid, 0)
    xi = tl.load(IMAGE+2*pos+1, valid, 0)
    ar, ai = pr*xr-pi*xi, pr*xi+pi*xr
    nr = tl.load(NUM_FACTOR+2*pos, valid, 0)
    ni = tl.load(NUM_FACTOR+2*pos+1, valid, 0)
    tl.store(NUM+2*i, ar*nr-ai*ni, valid)
    tl.store(NUM+2*i+1, ar*ni+ai*nr, valid)
    mass = tl.load(MASS+row, valid, 0)
    weight = tl.load(DEN_FACTOR+pos, valid, 0)
    tl.store(DEN+i, mass*weight, valid)
