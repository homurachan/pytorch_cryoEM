"""Execution-only limits: failures never overwrite the requested configuration.

Recovery probes are admitted at E-step boundaries, after all old stores have
been released. Successful statistical commits, not attempted scores, advance
the cooldown. Scientific sampling and posterior thresholds are never changed.
"""
from dataclasses import dataclass

UNLIMITED = 2**63-1
MIB = 2**20


def candidate_budget(owner):
    """Shared effective grant for scoring, CTFs, projection and statistics."""
    return min(int(owner.options.candidate_work_mib*MIB),
               getattr(owner, '_work_ceiling', UNLIMITED))


@dataclass
class ExecutionRecovery:
    batch: int = UNLIMITED
    cache: int = UNLIMITED
    work: int = UNLIMITED
    failures: int = 0
    successes: int = 0
    probes: int = 0
    healthy_epochs: int = 0
    epoch_failed: bool = False

    def backoff(self, batch, work):
        self.batch = min(self.batch, max(1, int(batch)//2))
        self.cache = 0
        self.work = min(self.work, max(MIB, int(work)//2))
        self.failures += 1
        self.successes = self.healthy_epochs = 0
        self.epoch_failed = True

    def committed(self):
        self.successes += 1

    def begin_epoch(self):
        if self.failures and not self.epoch_failed:
            self.healthy_epochs += 1
        # Two successful small E-steps also qualify, so short jobs do not get
        # stuck waiting for eight batches that they can never produce.
        eligible = self.successes >= min(64, 8*2**max(0, self.failures-1)) or self.healthy_epochs >= 2
        changed = self.cache != UNLIMITED and eligible
        if changed:
            self.probes += 1
            if self.healthy_epochs >= 2:
                self.batch = self.cache = self.work = UNLIMITED
            else:
                self.batch *= 2
                self.work *= 2
                self.cache = max(256*MIB, self.cache*2)
            self.successes = 0
        self.epoch_failed = False
        return changed

    def snapshot(self):
        return dict(execution_oom_backoffs_total=self.failures,
                    execution_recovery_probes_total=self.probes,
                    execution_recovery_pending=int(self.cache != UNLIMITED),
                    execution_committed_since_backoff=self.successes)


@dataclass(frozen=True)
class GlobalWindowPlan:
    """Additional live payload, charged outside the existing fine-pass budget."""
    micro_batch: int
    particles: int
    budget_bytes: int
    estimated_bytes: int

    @classmethod
    def make(cls, *, batch, orientations, translations, classes, original_size,
             coarse_pixels, available_bytes, maximum_bytes, maximum_batches=8):
        budget = max(0, min(int(available_bytes), int(maximum_bytes)))
        # Retained complete coarse arrays plus prepared images and shifted
        # scoring inputs for every particle in the window, including batch 1.
        # Selection temporaries for one microbatch use the existing posterior
        # grant; all other retained window payload is charged additionally.
        per = (classes*orientations*translations*40 + original_size**2*96
               + coarse_pixels*(translations*40+128))
        particles = min(batch*maximum_batches, budget//max(1, per))
        particles = particles//batch*batch
        if particles < 2*batch:particles = 0
        return cls(batch, particles, budget, particles*per)
