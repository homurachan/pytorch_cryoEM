"""Compact exact-zero posterior weights before sorting; no top-k truncation."""
import torch


def sort_positive_weights(raw, positive_count, *, counters=None):
    """Return descending weights padded only to the largest positive count.

    Dense populations fall back to full sorting to avoid a larger compaction
    workspace. The caller retains its original traversal-order total, strict
    probability threshold and tie handling. Only EXACT zeros are removed.
    """
    rows, columns = raw.shape
    maximum = int(positive_count.max().item()) if rows else 0
    compact = maximum < columns // 2
    width = max(1, maximum) if compact else columns
    if counters is not None:
        for key, amount in [('coarse_sort_input_values', raw.numel()),
                            ('coarse_sort_sorted_values', rows * width),
                            ('coarse_sort_compact_batches', int(compact)),
                            ('coarse_sort_dense_batches', int(not compact))]:
            counters[key] = counters.get(key, 0) + amount
    if not compact:
        return torch.sort(raw, dim=-1, descending=True).values
    packed = raw.new_zeros((rows, width))
    if maximum:
        positions = torch.nonzero(raw > 0, as_tuple=False)
        row, column = positions.unbind(1)
        starts = torch.cumsum(positive_count, 0) - positive_count
        slot = torch.arange(len(row), device=raw.device) - starts.index_select(0, row)
        packed[row, slot] = raw[row, column]
    return torch.sort(packed, dim=-1, descending=True).values
