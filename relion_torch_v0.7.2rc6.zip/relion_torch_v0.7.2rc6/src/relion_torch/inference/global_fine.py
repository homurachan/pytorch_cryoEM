"""Independent global projection generation, score and statistics policies.

Auto retains reusable fine rows and fuses only cache-miss interpolation. An
oversized bank alone does not justify repeating interpolation per translation.
Explicit stream mode retains rc3's low-memory direct scoring path.
"""
from dataclasses import replace
from relion_torch.inference.memory_planning import MIB


def eligible(owner, firstiter_cc):
    o, c = owner.options, owner.config
    return (not o.local_angular_search and owner.device.type == 'cuda'
            and not getattr(o, 'combine_refine', False)
            and getattr(o, 'auto_execution', 'optimized') != 'reference'
            and getattr(o, 'performance_mode', 'optimized') != 'reference'
            and not firstiter_cc and c.oversampling > 0
            and not (c.skip_align or c.skip_rotate)
            and owner.sizes.strict_shell() is None
            and o.dense_fine_execution != 'reference')


def choose(owner, full_coarse, full_fine, firstiter_cc):
    """Compatibility predicate: only an explicit request enables streaming."""
    return backend(owner, full_coarse, full_fine, firstiter_cc) == 'stream'


def backend(owner, full_coarse, full_fine, firstiter_cc):
    mode = owner.options.global_fine_mode
    if mode == 'cached' or not eligible(owner, firstiter_cc):
        return 'cached'
    if mode == 'stream':
        return 'stream'
    from relion_torch.inference.fused_projection import available
    if (mode == 'hybrid' or (full_coarse and not full_fine)) and available(owner.device, 'auto'):
        return 'hybrid'
    return 'cached'


def partition(limit, coarse_bytes, requested):
    """Both stores share one grant, including a zero-cache/OOM retry grant."""
    coarse = min(max(0, int(limit)), max(0, int(coarse_bytes)))
    fine = min(max(0, int(requested)), max(0, int(limit)-coarse))
    return coarse, fine


def plan_execution(owner, plan, firstiter_cc):
    mode = backend(owner, plan.full_coarse, plan.full_fine, firstiter_cc)
    plan = replace(plan, global_fine_backend=mode)
    if mode != 'stream':return plan
    coarse_bytes = plan.full_coarse_bytes + (plan.full_coarse_active_bytes if plan.cache_active else 0)
    coarse, fine = partition(plan.projection_bytes, coarse_bytes, owner.options.global_fine_mib*MIB)
    freed = plan.projection_bytes-coarse-fine
    return replace(plan, projection_bytes=coarse+fine, fine_stream_bytes=fine,
                   global_fine_stream=True, fine_cache_bytes=0, full_fine=False,
                   fine_reserve_bytes=0,
                   estimated_estep_extra_bytes=max(0, plan.estimated_estep_extra_bytes-freed))


def configure(owner, engine):
    plan = owner._memory_plan
    if plan is not None:
        mode = plan.global_fine_backend
        coarse_bytes = plan.full_coarse_bytes + (plan.full_coarse_active_bytes if plan.cache_active else 0)
    else:
        size, shell = owner.sizes.coarse_likelihood_grid(owner.config.oversampling)
        rows = len(owner.references)*owner.sampling.number_of_orientations
        # Manual planning is deliberately conservative about active copies.
        coarse_bytes = rows*size*(size//2+1)*16
        n = owner.sizes.current_size
        full_fine = rows*8**owner.config.oversampling*n*(n//2+1)*8
        mode = backend(owner, coarse_bytes <= engine.cache.max_bytes,
                         coarse_bytes+full_fine <= engine.cache.max_bytes, engine.config.firstiter_cc)
    if mode == 'cached':
        return
    engine.global_fine_backend = mode
    engine.global_fine_statistics = getattr(owner.options, 'global_fine_statistics', 'auto')
    engine.memory_counters['global_fine_hybrid_enabled'] = int(mode == 'hybrid')
    if mode == 'hybrid':
        # Keep the same byte grant and source-scoped persistent slab. Fine-only
        # callback wrapping happens after half/optics adapters are installed.
        return
    from relion_torch.inference.local_projection import LocalProjectionBuffer
    from relion_torch.inference.fused_projection import available
    coarse, fine = partition(engine.cache.max_bytes, coarse_bytes, owner.options.global_fine_mib*MIB)
    buffer = LocalProjectionBuffer(fine, owner.device, counter_prefix='fine_stream_projection')
    buffer.counts = engine.memory_counters
    buffer.count('budget_bytes', fine, peak=True)
    buffer.work_bytes = engine.config.candidate_work_bytes
    buffer.fine_chunking = 'auto'
    buffer.statistics_inputs = 'auto'
    buffer.statistics_reduction = 'auto'
    engine.fine_buffer = buffer
    engine.fine_coarse_bytes = coarse_bytes
    engine.cache.max_bytes = coarse
    engine.fine_reserve_bytes = 0
    engine.projector.fusion_mode = 'auto'
    engine.memory_counters.update(global_fine_stream_enabled=1,
        global_fine_fusion_available=int(available(owner.device, 'auto')),
        global_fine_coarse_budget_bytes=coarse)
    if not available(owner.device, 'auto'):
        print('  Global fine CUDA fusion unavailable; using bounded PyTorch streaming.', flush=True)


class FineProjector:
    """Enable guarded interpolation without changing the coarse callback."""
    fusion_mode = 'auto'
    def __init__(self, callback):self.callback = callback
    def __getattr__(self, name):return getattr(self.callback, name)
    def __call__(self, *args, **kwargs):return self.callback(*args, **kwargs)


def configure_store(engine, store):
    mode = getattr(engine, 'global_fine_backend', 'cached')
    if mode == 'cached':return
    statistics = engine.global_fine_statistics
    store.fine_score_fusion = mode == 'stream'
    store.fine_statistics_fusion = (mode == 'stream') if statistics == 'auto' else statistics == 'fused'
    store.fused_generation = mode == 'hybrid' or not store.fine_statistics_fusion
    if mode == 'hybrid' and store.fine_statistics_fusion:
        # Only the metadata/settings interface is needed by explicitly requested
        # fused statistics. No second projection allocation or cache is created.
        from .local_projection import LocalProjectionBuffer
        store.buffer = LocalProjectionBuffer(0, store.device)
        store.buffer.work_bytes = engine.config.candidate_work_bytes
        store.buffer.statistics_inputs = 'auto'
        store.buffer.statistics_reduction = 'auto'
    engine.memory_counters.update(global_fine_score_fused=int(store.fine_score_fusion),
        global_fine_statistics_fused=int(store.fine_statistics_fusion))
