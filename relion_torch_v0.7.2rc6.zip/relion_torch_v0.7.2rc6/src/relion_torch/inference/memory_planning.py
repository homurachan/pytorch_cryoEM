"""Shared, phase-aware CUDA payload planning for SPA inference.

The percentage limits the PyTorch allocator; driver/library allocations are not
controlled by that allocator. Exact retained payloads and conservative temporary
estimates are planned separately. No plan is allowed to change scientific support.
"""
from dataclasses import asdict, dataclass
import math
import torch
from .posterior_estimates import local_posterior_bytes

MIB = 2**20
GIB = 2**30


@dataclass(frozen=True)
class MemorySnapshot:
    total: int
    free: int
    allocated: int
    reserved: int

    @classmethod
    def read(cls, device):
        free, total = torch.cuda.mem_get_info(device)
        return cls(int(total), int(free), int(torch.cuda.memory_allocated(device)),
                   int(torch.cuda.memory_reserved(device)))


def desktop_reserve(total):
    return min(GIB, max(256*MIB, int(total)//32))


def memory_limits(snapshot, percent, allocator_fraction=1.):
    if not math.isfinite(percent) or not 0 < percent <= 100:
        raise ValueError('gpu-memory-percent must be finite and in (0, 100]')
    reserve = desktop_reserve(snapshot.total)
    ceiling = min(int(snapshot.total*percent/100), snapshot.total-reserve,
                  int(snapshot.total*allocator_fraction))
    # Reserved includes allocated. Only unused reserved blocks are added back to
    # driver free memory. Fragmentation is covered by a separate planning margin.
    reusable = max(0, snapshot.reserved-snapshot.allocated)
    headroom = min(ceiling-snapshot.allocated, snapshot.free+reusable-reserve)
    margin = max(256*MIB, min(GIB, ceiling//32))
    return ceiling, reserve, margin, max(0, headroom-margin)


@dataclass(frozen=True)
class InferenceWorkload:
    classes: int
    orientations: int
    translations: int
    coarse_size: int
    current_size: int
    original_size: int
    oversampling: int
    requested_batch: int
    projector_per_class: int
    backprojector_per_class: int
    reconstruction_workspace: int
    # For local search this is a sampled LOCAL window width, never the global
    # grid. Each real batch is checked using its actual support before allocation.
    posterior_width: int
    active_pixels: int
    local: bool = False
    fixed: bool = False
    sampling_table_bytes: int | None = None
    prefer_full_fine: bool = False
    projection_max_bytes: int | None = None
    auto_batch_max: int = 0
    # Strict-highres can retain a separate fine likelihood bank in addition
    # to the current-size projections used for weighted sums.
    fine_likelihood_size: int | None = None


@dataclass(frozen=True)
class MemoryPlan:
    process_ceiling_bytes: int
    desktop_reserve_bytes: int
    safety_margin_bytes: int
    baseline_allocated_bytes: int
    available_bytes: int
    estimated_estep_extra_bytes: int
    estimated_reconstruction_extra_bytes: int
    projector_bytes: int
    backprojector_bytes: int
    projection_bytes: int
    full_coarse_bytes: int
    candidate_bytes: int
    posterior_bytes: int
    preprocess_bytes: int
    geometry_bytes: int
    fine_reserve_bytes: int
    particle_batch: int
    full_coarse: bool
    cache_active: bool
    local: bool
    posterior_width: int
    full_fine_bytes: int = 0
    fine_cache_bytes: int = 0
    full_fine: bool = False
    # Class3D/auto-refine adapter records the exact likelihood geometry used
    # to size full/active coarse planes. None for adapters without this metadata.
    coarse_image_size: int | None = None
    coarse_maximum_shell: int | None = None
    coarse_active_pixels: int | None = None
    fine_likelihood_image_size: int | None = None
    weighted_sum_image_size: int | None = None
    full_coarse_active_bytes: int | None = None

    global_fine_stream: bool = False
    global_fine_backend: str = 'cached'
    fine_stream_bytes: int = 0

    def as_dict(self):
        return asdict(self)


def plan_inference(snapshot, workload, percent=100., *, allocator_fraction=1.,
                   observed_posterior_per_particle=0, pressure_bytes=0,
                   observed_local_coarse_per_particle=0):
    """Prefer complete coarse storage, optionally also complete global fine storage.

    All cache limits are actual useful tensor payloads, not the sum of old CLI
    maxima. E-step and reconstruction peaks are alternatives, not additive.
    """
    w = workload
    ceiling, reserve, margin, available = memory_limits(snapshot, percent, allocator_fraction)
    available = max(0, available-int(pressure_bytes))
    cp = w.coarse_size*(w.coarse_size//2+1)
    fp = w.current_size*(w.current_size//2+1)
    oc = 8**w.oversampling
    full = 0 if w.fixed else w.classes*w.orientations*cp*8
    active = 0 if w.fixed else w.classes*w.orientations*w.active_pixels*8
    likelihood_size = w.current_size if w.fine_likelihood_size is None else w.fine_likelihood_size
    lp = likelihood_size*(likelihood_size//2+1)
    if w.fixed:
        fine_full = 0
    elif w.oversampling:
        fine_full = w.classes*w.orientations*oc*(fp+(lp if lp!=fp else 0))*8
    else:
        # A strict-cutoff dense posterior still needs a distinct current-size
        # bank for weighted sums, without an unused active-frequency duplicate.
        fine_full = w.classes*w.orientations*fp*8 if cp!=fp else 0
    table = (0 if w.fixed else w.orientations*(64+oc*64)) if w.sampling_table_bytes is None else int(w.sampling_table_bytes)
    per_posterior = max(1, local_posterior_bytes(1,w.classes,w.posterior_width,w.translations)
                        if w.local else w.classes*w.posterior_width*w.translations*112)
    if w.local:
        # Probe widths are not a bound on every later batch. Local streaming
        # does not need to protect a full global projection bank from feedback.
        # Keep 1/16 slack and let the ordinary whole-plan checks limit the grant.
        # Track coarse widths separately: a one-batch fine outlier must not
        # force every batch of the next iteration down to its worst-case size.
        per_posterior=(max(per_posterior,math.ceil(observed_local_coarse_per_particle))*17+15)//16
    # Keep all class FFTs/accumulators whenever possible. Excess accumulator
    # classes can spill to the existing bounded host pool without approximation.
    pc = bc = w.classes
    while bc > 1 and bc*w.backprojector_per_class+w.reconstruction_workspace > available:
        bc -= 1
    reconstruction = bc*w.backprojector_per_class+w.reconstruction_workspace
    if reconstruction > available:
        raise MemoryError('Automatic GPU budget cannot fit one reconstruction and its FFT workspace; '
                          'increase --gpu-memory-percent or use a larger GPU (sampling was not reduced).')

    def candidates(pc, bc):
        pools = pc*w.projector_per_class+bc*w.backprojector_per_class
        batches=[w.requested_batch,max(1,w.requested_batch//2),max(1,w.requested_batch//4),1]
        if w.local and w.auto_batch_max>w.requested_batch:
            target=w.auto_batch_max
            while target>w.requested_batch:
                batches.insert(0,target);target//=2
            batches=sorted(set(batches),reverse=True)
        for batch in dict.fromkeys(batches):
            # The fine posterior is data dependent. Last-iteration feedback is
            # scaled to this batch, capped to avoid starving the full coarse bank.
            posterior = max(64*MIB, batch*per_posterior,
                            min(2*GIB, int(batch*observed_posterior_per_particle*1.25)),
                            min(512*MIB, available//16))
            for candidate in ((2*GIB,GIB,512*MIB,256*MIB,128*MIB) if w.local and w.auto_batch_max else (GIB,512*MIB,256*MIB,128*MIB)):
                geometry = min(128*MIB, candidate//8)
                prep = max(64*MIB, min(256*MIB, available//32))
                # Coarse posterior stays alive during the fine pass; grouped
                # statistics stay alive while scoring the next particle batch.
                # Account for both, plus FFT construction and raw/prepared images.
                fixed = (pools + table + 32*MIB + 2*w.projector_per_class + prep
                         + batch*w.original_size**2*80 + w.translations*fp*8)
                extra = fixed + candidate*3//2 + geometry + posterior*2
                space = available-extra
                if space < 0:
                    continue
                if w.projection_max_bytes is not None:
                    space=min(space,max(0,int(w.projection_max_bytes)))
                fine_goal = (min(fine_full, max(64*MIB, batch*256*oc*fp*8))
                             if fine_full else 0)
                fine_target=(fine_full if w.prefer_full_fine and not w.local and full+fine_full<=space else fine_goal)
                cache_active = bool(full and full+active+fine_target <= space)
                useful = full+(active if cache_active else 0)+fine_full
                projection = min(space, useful)
                fine_reserve = min(fine_goal, max(0, projection-full)) if full <= projection else min(fine_goal, projection//4)
                coarse_used=full+(active if cache_active else 0) if full<=projection else projection-fine_reserve
                fine_capacity=min(fine_full,max(0,projection-coarse_used))
                yield MemoryPlan(ceiling, reserve, margin+int(pressure_bytes), snapshot.allocated,
                    available, extra+projection, reconstruction,
                    pc*w.projector_per_class, bc*w.backprojector_per_class,
                    projection, full, candidate, posterior, prep, geometry, fine_reserve,
                    batch, full <= projection, cache_active, w.local, w.posterior_width,
                    fine_full,fine_capacity,bool(fine_full and fine_capacity>=fine_full))

    fallback = None
    while bc >= 1:
        pc = w.classes
        while pc >= 1:
            first_full_coarse=None
            for plan in candidates(pc, bc):
                if fallback is None:
                    fallback = plan
                if plan.full_coarse:
                    if not (w.prefer_full_fine and not w.local and fine_full) or plan.full_fine:
                        return plan
                    if first_full_coarse is None:first_full_coarse=plan
            if first_full_coarse is not None:return first_full_coarse
            # Avoid rebuilding large FFTs on every class switch merely to gain a
            # complete projection bank. Reduce residency only if no plan fits.
            if fallback is not None:
                return fallback
            pc -= 1
        bc -= 1
        reconstruction = bc*w.backprojector_per_class+w.reconstruction_workspace
    raise MemoryError('Automatic GPU budget cannot fit one particle and the minimum model/workspaces; '
                      'increase --gpu-memory-percent or use a larger GPU. No candidates were truncated.')


class CudaMemoryController:
    """Per-run guard plus iteration-boundary feedback; never stored as a fixed plan."""
    def __init__(self, device, percent=100., enabled=True, automatic=True):
        self.device = torch.device(device)
        self.enabled = bool(enabled and self.device.type == 'cuda')
        self.percent = float(percent)
        self.automatic = automatic
        self.previous_fraction = None
        self.allocator_fraction = 1.
        self.last_plan = None
        self.observed_posterior_per_particle = 0
        self.observed_local_coarse_per_particle = 0
        self.pressure_bytes = 0
        self.oom_recoveries = 0

    def __enter__(self):
        if not self.enabled:
            return self
        snapshot = MemorySnapshot.read(self.device)
        get_fraction = getattr(torch.cuda, 'get_per_process_memory_fraction', None)
        if get_fraction is not None:
            # Unlike most CUDA APIs, the fraction getter requires an explicit
            # index. Honor the current device for the documented 'cuda' alias.
            if self.device.index is None:
                self.device = torch.device('cuda', torch.cuda.current_device())
            self.previous_fraction = float(get_fraction(self.device))
            self.allocator_fraction = self.previous_fraction
        ceiling, reserve, _, _ = memory_limits(snapshot, self.percent, self.allocator_fraction)
        if snapshot.allocated >= ceiling:
            raise MemoryError('Existing PyTorch allocations already exceed the requested GPU memory budget')
        # On older PyTorch without a getter, do not overwrite an unknown limit
        # belonging to an embedding application. Payload planning still applies.
        if self.previous_fraction is not None:
            torch.cuda.set_per_process_memory_fraction(float(ceiling/snapshot.total), self.device)
        print(f'GPU memory: requested {self.percent:g}%, allocator ceiling '
              f'{ceiling/GIB:.2f} GiB, desktop reserve {reserve/MIB:.0f} MiB; '
              f'allocator guard={self.previous_fraction is not None}.', flush=True)
        if self.automatic:
            print('  Automatic caches/workspaces supersede legacy byte flags; --no-auto-memory restores manual budgets.', flush=True)
        return self

    def __exit__(self, *exc):
        if self.previous_fraction is not None:
            torch.cuda.set_per_process_memory_fraction(self.previous_fraction, self.device)

    def plan(self, workload):
        self.last_plan = plan_inference(MemorySnapshot.read(self.device), workload,
            self.percent, allocator_fraction=self.allocator_fraction,
            observed_posterior_per_particle=self.observed_posterior_per_particle,
            pressure_bytes=self.pressure_bytes,
            observed_local_coarse_per_particle=self.observed_local_coarse_per_particle)
        return self.last_plan

    def observe(self, counters):
        self.observed_posterior_per_particle = max(
            float(counters.get('posterior_observed_bytes_per_particle', 0)),
            self.observed_posterior_per_particle*.5)
        if 'local_posterior_observed_bytes_per_particle' in counters:
            self.observed_local_coarse_per_particle=max(
                float(counters['local_posterior_observed_bytes_per_particle']),
                self.observed_local_coarse_per_particle*.5)

    def posterior_capacity(self, required_bytes, projection_limit, resident_bytes):
        """Admit a complete posterior using LIVE headroom, including empty caches.

        Called after failed, uncommitted scoring temporaries have been released.
        Preserve the planner's two posterior passes and ALL other planned work.
        Charging the latter in full is conservative: some model/workspace payloads
        may already be resident. Never infer free memory from a cache limit.
        A second call after releasing storage verifies the actual reclaimed bytes.
        Manual budgets remain manual; no plan means no automatic admission.
        """
        if not self.automatic or self.last_plan is None:
            return None
        plan = self.last_plan
        snapshot = MemorySnapshot.read(self.device)
        _, _, _, available = memory_limits(snapshot, self.percent, self.allocator_fraction)
        available = max(0, available-int(self.pressure_bytes))
        other = max(0, plan.estimated_estep_extra_bytes-plan.projection_bytes-2*plan.posterior_bytes)
        workspace = other+2*int(required_bytes)
        capacity = available+max(0, int(resident_bytes))-workspace
        return dict(projection_bytes=min(max(0, int(projection_limit)), max(0, capacity)),
                    admitted=capacity>=0, available_bytes=available,
                    reserved_work_bytes=workspace)

    def recovered_oom(self):
        self.oom_recoveries += 1
        self.pressure_bytes = min(2*GIB, self.pressure_bytes+256*MIB)

    def successful_epoch(self, previous_oom_count):
        """Release temporary pressure reserve only after a clean E-step."""
        if self.oom_recoveries == previous_oom_count:
            self.pressure_bytes //= 2
