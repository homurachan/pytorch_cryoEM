"""Dense fine scoring with bounded, call-local projection reuse.

The shared schedule changes loop order only. Each particle scores its original
orientation blocks against the original full translation rectangle, and only
original parent/child positions are written back. No cross-half/source cache.
"""
import numpy as np
import torch
from .fine_scoring import plan_dense_parent_blocks, gather_active_child_rows


def plan_reuse(base, *, particles, pixels, children, real_bytes, complex_bytes, work_bytes):
    # The old plan covers one shifted image and its temporaries. Shared scheduling
    # retains real/imag shifts plus norms for other particles, and one additional
    # shared reference tile while the current particle selects its own rows.
    extra=max(0,particles-1)*base['total_translation_children']*(pixels*complex_bytes+2*real_bytes)
    per=base['per_block_bytes']+children*pixels*complex_bytes
    chunk=max(0,min(base['block_chunk'],(int(work_bytes)-base['shift_bytes']-extra)//max(1,per)))
    return dict(block_chunk=chunk,workspace_bytes=base['shift_bytes']+extra+chunk*per,
                retained_input_bytes=extra)


@torch.no_grad()
def score(*, image_active, ctf_active, invsigma, highres, projection_blocks,
        phase_table, active_indices, projection_active, phase_active,
        parent_counts, parent_block_indices, parent_translation_indices,
        output, cc_output, work_bytes, max_blocks=256):
    assert cc_output is None  # CC keeps the original winner/tie-sensitive path.
    trans,tc=phase_table.shape[:2];oc=projection_blocks.shape[1];f=active_indices.numel()
    base=plan_dense_parent_blocks(active_pixels=f,real_bytes=image_active.real.element_size(),
        complex_bytes=image_active.element_size(),coarse_translations=trans,
        translation_children=tc,orientation_children=oc,work_bytes=work_bytes,max_blocks=max_blocks)
    if not base['fits']:return None
    counts=parent_counts.detach().cpu().numpy().astype(np.int64,copy=False)
    host=parent_block_indices.detach().cpu().numpy()
    schedules=[];start=0
    for count in counts:
        end=start+int(count);blocks=host[start:end]
        if len(blocks):
            boundaries=np.r_[0,np.flatnonzero(blocks[1:]!=blocks[:-1])+1,len(blocks)]
            unique=blocks[boundaries[:-1]]
            if np.any(unique[1:]<=unique[:-1]):raise ValueError('fine dense scorer requires ordered unique projection-block runs')
        else:boundaries=np.array([0],dtype=np.int64);unique=np.empty(0,dtype=np.int64)
        schedules.append((start,boundaries,unique));start=end
    if start!=len(host):raise ValueError('Parent counts do not match block metadata')
    participating=sum(bool(len(s[2])) for s in schedules)
    union=np.unique(np.concatenate([s[2] for s in schedules])) if participating>1 else None
    requests=sum(len(s[2]) for s in schedules)
    reuse=plan_reuse(base,particles=participating,pixels=f,children=oc,
        real_bytes=image_active.real.element_size(),complex_bytes=image_active.element_size(),work_bytes=work_bytes)
    shared=bool(union is not None and len(union) and requests>=1.25*len(union)
        and reuse['block_chunk']>=max(1,base['block_chunk']//2))
    chunk=reuse['block_chunk'] if shared else base['block_chunk']
    phases=phase_active if phase_active is not None else phase_table.flatten(-2).index_select(-1,active_indices)
    phases=phases.reshape(trans*tc,f)
    calls=evaluated=gathers=gathered=0

    def inputs(p):
        shifted=image_active[p,None]*phases
        # Pack once per particle, rather than leaving strided complex views for
        # BLAS to repack on every orientation tile. Preserve norm arithmetic.
        real=shifted.real.contiguous();imag=shifted.imag.contiguous()
        norm=((real.square()+imag.square())*invsigma[p,None]).sum(-1)
        return real,imag,norm

    def reference(ids):
        nonlocal gathers,gathered
        gathers+=1;gathered+=len(ids)
        if projection_active is None and hasattr(projection_blocks,'gather_active_host'):
            return projection_blocks.gather_active_host(ids,active_indices)
        device_ids=torch.as_tensor(np.array(ids,copy=True),device=output.device,dtype=torch.long)
        return (projection_active.index_select(0,device_ids) if projection_active is not None
                else gather_active_child_rows(projection_blocks,device_ids,active_indices))

    def tile(p,first,last,ref,prepared):
        nonlocal calls,evaluated
        start,boundaries,unique=schedules[p]
        real,imag,xnorm=prepared
        prediction=ref.reshape(-1,f)*ctf_active[p,None]
        weighted=prediction*invsigma[p,None]
        cross=real@weighted.real.T
        cross.add_(imag@weighted.imag.T)
        pnorm=((prediction.real.square()+prediction.imag.square())*invsigma[p,None]).sum(-1)
        # Same arithmetic order as the reference expression, reusing storage.
        local=pnorm[:,None]+xnorm[None]
        cross.mul_(2.);local.sub_(cross.T).mul_(.5).clamp_min_(0.).add_(highres[p])
        a=start+int(boundaries[first]);b=start+int(boundaries[last])
        mapping=np.repeat(np.arange(last-first,dtype=np.int64),np.diff(boundaries[first:last+1]))
        ix=torch.as_tensor(mapping,device=output.device)
        output[a:b]=local.reshape(last-first,oc,trans,tc).permute(0,2,1,3)[ix,parent_translation_indices[a:b]]
        calls+=1;evaluated+=(last-first)*oc*trans*tc

    if shared:
        prepared={p:inputs(p) for p,s in enumerate(schedules) if len(s[2])}
        for begin in range(0,len(union),chunk):
            ids=union[begin:begin+chunk];ref=reference(ids)
            for p,(_,_,unique) in enumerate(schedules):
                first,last=np.searchsorted(unique,[ids[0],ids[-1]],side='left')
                if last<len(unique) and unique[last]==ids[-1]:last+=1
                if first==last:continue
                selected=unique[first:last]
                if len(selected)==len(ids):value=ref
                else:
                    take=torch.as_tensor(np.searchsorted(ids,selected),device=output.device)
                    value=ref.index_select(0,take)
                tile(p,int(first),int(last),value,prepared[p])
                del value
            del ref
    else:
        for p,(_,_,unique) in enumerate(schedules):
            if not len(unique):continue
            prepared=inputs(p)
            for first in range(0,len(unique),chunk):
                last=min(first+chunk,len(unique));ref=reference(unique[first:last])
                tile(p,first,last,ref,prepared)
                del ref
    return dict(fine_dense_tiles=calls,fine_dense_evaluated_children=evaluated,
        fine_dense_batches=1,fine_sparse_tiles=0,
        fine_workspace_estimate_bytes=int(reuse['workspace_bytes'] if shared else base['workspace_bytes']),
        fine_dense_optimized_batches=1,fine_dense_shared_batches=int(shared),
        fine_dense_projection_gathers=gathers,fine_dense_gathered_blocks=gathered,
        fine_dense_reused_blocks=requests-gathered,fine_dense_prepared_particles=participating)
