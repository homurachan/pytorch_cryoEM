"""Preflight-checked, private-output fusion for the global coarse pass."""
import torch
from relion_torch.reconstruction.volume_fusion import _ready, _failed

_validated = set()


def _check_score(device):
    import triton
    from .global_kernels import score_epilogue_kernel
    real = torch.linspace(-2., 2., 30, device=device).reshape(6, 5)
    imag = real.flip(0).contiguous()
    pnorm = torch.linspace(0., 2., 10, device=device).reshape(2, 5)
    xnorm = torch.tensor([.1, 1.], device=device)
    high = torch.tensor([.2, .3], device=device)
    out = torch.empty((2, 5, 3), device=device)
    score_epilogue_kernel[(1,)](real, imag, pnorm, xnorm, high, out, 30,
                                O=5, T=3, BLOCK=256, enable_fp_fusion=False)
    cross = (real+imag).reshape(2, 3, 5).transpose(1, 2)
    expected = (.5*(pnorm[:, :, None]+xnorm[:, None, None]-2*cross)).clamp_min(0)+high[:, None, None]
    torch.testing.assert_close(out, expected, rtol=2e-6, atol=2e-6)


def _check_weights(device):
    from .global_kernels import raw_weights_kernel
    score = torch.tensor([[50., 49., 0., -88., -88.1, -float('inf')],
                          [51., 51., 1., -87., -87.1, -float('inf')]], device=device)
    shift = torch.tensor([0., -1.], device=device)
    valid = torch.isfinite(score)
    out = torch.empty_like(score)
    raw_weights_kernel[(1,)](score, valid, shift, out, out.numel(), H=6, BLOCK=256, enable_fp_fusion=False)
    exponent = score+shift[:, None]
    expected = torch.where(valid & (exponent >= -88.), exponent.exp(), 0.)
    torch.testing.assert_close(out, expected, rtol=2e-6, atol=0)
    if not torch.equal(out == 0, expected == 0):
        raise RuntimeError('Global posterior exponent cutoff mismatch')


def _count(counters, key):
    if counters is not None:
        counters[key] = counters.get(key, 0)+1


def score_epilogue(real, imag, pnorm, xnorm, highres, *, translations, mode='auto', counters=None):
    if not _ready(real, mode, 'global_score'):
        return None
    if any(x.dtype != torch.float32 or not x.is_contiguous() for x in (imag, pnorm, xnorm, highres)):
        if mode == 'required':
            raise RuntimeError('Global score fusion requires contiguous FP32 inputs')
        return None
    try:
        import triton
        from .global_kernels import score_epilogue_kernel
        key = ('score', str(real.device))
        if key not in _validated:
            _check_score(real.device)
            _validated.add(key)
        b, o = pnorm.shape
        out = torch.empty((b, o, translations), device=real.device, dtype=real.dtype)
        score_epilogue_kernel[(triton.cdiv(out.numel(), 256),)](
            real, imag, pnorm, xnorm, highres, out, out.numel(),
            O=o, T=translations, BLOCK=256, enable_fp_fusion=False)
        _count(counters, 'global_fused_score_calls')
        return out
    except Exception as exc:
        _failed('global_score', mode, exc)
        return None


def raw_weights(score, valid, shift, *, mode='auto', counters=None):
    if not _ready(score, mode, 'global_posterior'):
        return None
    try:
        import triton
        from .global_kernels import raw_weights_kernel
        key = ('posterior', str(score.device))
        if key not in _validated:
            _check_weights(score.device)
            _validated.add(key)
        out = torch.empty_like(score)
        raw_weights_kernel[(triton.cdiv(out.numel(), 256),)](
            score, valid, shift, out, out.numel(), H=score.shape[-1], BLOCK=256, enable_fp_fusion=False)
        _count(counters, 'global_fused_posterior_calls')
        return out
    except Exception as exc:
        _failed('global_posterior', mode, exc)
        return None
