"""Optional Triton kernels. Imported only by the CUDA dispatcher.

Triton is supplied with supported Linux PyTorch CUDA installations; it is not
a mandatory package dependency. Direct kernels avoid materialized references;
shared kernels consume bounded rows from the existing local projection cache.
"""
import triton
import triton.language as tl


@triton.jit
def _project(V, M, orientation, pixels, mask, P:tl.constexpr, S:tl.constexpr,
             R2:tl.constexpr, PAD:tl.constexpr):
    x=(pixels%(S//2+1)).to(tl.float32)
    y=(pixels//(S//2+1)).to(tl.float32)
    y=tl.where(y<=S//2,y,y-S)
    mx=(tl.load(M+orientation*9+0)*x+tl.load(M+orientation*9+1)*y)*PAD
    my=(tl.load(M+orientation*9+3)*x+tl.load(M+orientation*9+4)*y)*PAD
    mz=(tl.load(M+orientation*9+6)*x+tl.load(M+orientation*9+7)*y)*PAD
    mask=mask&(x*x+y*y<=(S//2)*(S//2))&(mx*mx+my*my+mz*mz<=R2)
    neg=mx<0;mx=tl.where(neg,-mx,mx);my=tl.where(neg,-my,my);mz=tl.where(neg,-mz,mz)
    bx=tl.floor(mx).to(tl.int32);by=tl.floor(my).to(tl.int32);bz=tl.floor(mz).to(tl.int32)
    fx=mx-bx;fy=my-by;fz=mz-bz
    real=tl.full(pixels.shape,0,tl.float32);imag=tl.full(pixels.shape,0,tl.float32)
    for dx in tl.static_range(2):
        for dy in tl.static_range(2):
            for dz in tl.static_range(2):
                ix=bx+dx;iy=by+dy;iz=bz+dz
                valid=mask&(ix>=0)&(ix<=P//2)&(iy>-P//2)&(iy<=P//2)&(iz>-P//2)&(iz<=P//2)&(ix*ix+iy*iy+iz*iz<=R2)
                offset=(((iz+P)%P)*P+(iy+P)%P)*(P//2+1)+ix
                weight=tl.where(dx==1,fx,1-fx)*tl.where(dy==1,fy,1-fy)*tl.where(dz==1,fz,1-fz)
                real+=tl.load(V+2*offset,valid,other=0)*weight
                imag+=tl.load(V+2*offset+1,valid,other=0)*weight
    return real,tl.where(neg,-imag,imag)


@triton.jit
def score_kernel(V,M,PIX,ROWS,X,C,INV,HIGH,XN,OUT,
                 P:tl.constexpr,S:tl.constexpr,R2:tl.constexpr,PAD:tl.constexpr,
                 F:tl.constexpr,T:tl.constexpr,HAS_XN:tl.constexpr,
                 BF:tl.constexpr,BT:tl.constexpr):
    o=tl.program_id(0);row=tl.load(ROWS+o)
    ts=tl.arange(0,BT)
    cross=tl.full((BT,),0,tl.float32);xn=tl.full((BT,),0,tl.float32);pn=tl.full((),0,tl.float32)
    for block in range((F+BF-1)//BF):
        f=block*BF+tl.arange(0,BF);valid=f<F
        pixels=tl.load(PIX+f,valid,0)
        rr,ri=_project(V,M,o,pixels,valid,P,S,R2,PAD)
        cr=tl.load(C+2*(row*F+f),valid,0);ci=tl.load(C+2*(row*F+f)+1,valid,0)
        pr=rr*cr-ri*ci;pi=rr*ci+ri*cr
        inv=tl.load(INV+row*F+f,valid,0)
        at=(row*T+ts[:,None])*F+f[None,:]
        xr=tl.load(X+2*at,(ts[:,None]<T)&valid[None,:],0)
        xi=tl.load(X+2*at+1,(ts[:,None]<T)&valid[None,:],0)
        cross+=tl.sum((xr*pr[None,:]+xi*pi[None,:])*inv[None,:],1)
        if not HAS_XN:xn+=tl.sum((xr*xr+xi*xi)*inv[None,:],1)
        pn+=tl.sum((pr*pr+pi*pi)*inv,0)
    if HAS_XN:xn=tl.full((BT,),0,tl.float32)+tl.load(XN+row)
    score=tl.maximum(.5*(pn+xn-2*cross),0)+tl.load(HIGH+row)
    tl.store(OUT+o*T+ts,score,ts<T)


@triton.jit
def statistics_kernel(V,M,PIX,ROWS,X,C,PHASE,IMAGE_WEIGHT,MASS,RES,CROSS,POWER,
                      P:tl.constexpr,S:tl.constexpr,R2:tl.constexpr,PAD:tl.constexpr,
                      F:tl.constexpr,BF:tl.constexpr):
    o=tl.program_id(0);f=tl.program_id(1)*BF+tl.arange(0,BF);valid=f<F
    row=tl.load(ROWS+o);pixels=tl.load(PIX+f,valid,0)
    rr,ri=_project(V,M,o,pixels,valid,P,S,R2,PAD)
    cr=tl.load(C+2*(row*F+f),valid,0);ci=tl.load(C+2*(row*F+f)+1,valid,0)
    pr=rr*cr-ri*ci;pi=rr*ci+ri*cr
    xr=tl.load(X+2*(row*F+f),valid,0);xi=tl.load(X+2*(row*F+f)+1,valid,0)
    ar=tl.load(PHASE+2*(o*F+f),valid,0);ai=tl.load(PHASE+2*(o*F+f)+1,valid,0)
    br=xr*ar-xi*ai;bi=xr*ai+xi*ar
    power=tl.load(MASS+o)*(pr*pr+pi*pi);cross=pr*br+pi*bi
    image_power=(xr*xr+xi*xi)*tl.load(IMAGE_WEIGHT+o*F+f,valid,0)
    at=o*F+f
    tl.store(POWER+at,power,valid);tl.store(CROSS+at,cross,valid)
    tl.store(RES+at,tl.maximum(image_power+power-2*cross,0),valid)


@triton.jit
def project_rows_kernel(V,M,OUT,P:tl.constexpr,S:tl.constexpr,R2:tl.constexpr,
                        PAD:tl.constexpr,F:tl.constexpr,BF:tl.constexpr):
    o=tl.program_id(0);f=tl.program_id(1)*BF+tl.arange(0,BF)
    rr,ri=_project(V,M,o,f,f<F,P,S,R2,PAD)
    tl.store(OUT+2*(o*F+f),rr,f<F)
    tl.store(OUT+2*(o*F+f)+1,ri,f<F)


@triton.jit
def shared_score_kernel(REF,IDS,ROWS,X,C,INV,HIGH,XN,OUT,
                        F:tl.constexpr,T:tl.constexpr,HAS_XN:tl.constexpr,
                        BF:tl.constexpr,BT:tl.constexpr):
    o=tl.program_id(0);row=tl.load(ROWS+o);ref=tl.load(IDS+o)
    ts=tl.arange(0,BT)
    cross=tl.full((BT,),0,tl.float32);xn=tl.full((BT,),0,tl.float32);pn=tl.full((),0,tl.float32)
    for block in range((F+BF-1)//BF):
        f=block*BF+tl.arange(0,BF);valid=f<F
        rr=tl.load(REF+2*(ref*F+f),valid,0);ri=tl.load(REF+2*(ref*F+f)+1,valid,0)
        cr=tl.load(C+2*(row*F+f),valid,0);ci=tl.load(C+2*(row*F+f)+1,valid,0)
        pr=rr*cr-ri*ci;pi=rr*ci+ri*cr
        inv=tl.load(INV+row*F+f,valid,0)
        at=(row*T+ts[:,None])*F+f[None,:]
        xr=tl.load(X+2*at,(ts[:,None]<T)&valid[None,:],0)
        xi=tl.load(X+2*at+1,(ts[:,None]<T)&valid[None,:],0)
        cross+=tl.sum((xr*pr[None,:]+xi*pi[None,:])*inv[None,:],1)
        if not HAS_XN:xn+=tl.sum((xr*xr+xi*xi)*inv[None,:],1)
        pn+=tl.sum((pr*pr+pi*pi)*inv,0)
    if HAS_XN:xn=tl.full((BT,),0,tl.float32)+tl.load(XN+row)
    value=tl.maximum(.5*(pn+xn-2*cross),0)+tl.load(HIGH+row)
    tl.store(OUT+o*T+ts,value,ts<T)


@triton.jit
def reduced_statistics_kernel(V,M,REF,IDS,PIX,ROWS,X,C,PHASE,IW,MASS,SHELL,SCALE,
                              NOISE,CROSS,POWER,P:tl.constexpr,S:tl.constexpr,
                              R2:tl.constexpr,PAD:tl.constexpr,F:tl.constexpr,
                              NS:tl.constexpr,SHARED:tl.constexpr,BF:tl.constexpr):
    o=tl.program_id(0);f=tl.program_id(1)*BF+tl.arange(0,BF);valid=f<F
    row=tl.load(ROWS+o)
    if SHARED:
        ref=tl.load(IDS+o)
        rr=tl.load(REF+2*(ref*F+f),valid,0);ri=tl.load(REF+2*(ref*F+f)+1,valid,0)
    else:
        pixels=tl.load(PIX+f,valid,0)
        rr,ri=_project(V,M,o,pixels,valid,P,S,R2,PAD)
    cr=tl.load(C+2*(row*F+f),valid,0);ci=tl.load(C+2*(row*F+f)+1,valid,0)
    pr=rr*cr-ri*ci;pi=rr*ci+ri*cr
    xr=tl.load(X+2*(row*F+f),valid,0);xi=tl.load(X+2*(row*F+f)+1,valid,0)
    ar=tl.load(PHASE+2*(o*F+f),valid,0);ai=tl.load(PHASE+2*(o*F+f)+1,valid,0)
    br=xr*ar-xi*ai;bi=xr*ai+xi*ar
    power=tl.load(MASS+o)*(pr*pr+pi*pi);cross=pr*br+pi*bi
    residual=tl.maximum((xr*xr+xi*xi)*tl.load(IW+o*F+f,valid,0)+power-2*cross,0)
    shell=tl.load(SHELL+f,valid,0);scale=tl.load(SCALE+f,valid,0)
    tl.atomic_add(NOISE+o*NS+shell,residual,valid,sem='relaxed')
    tl.atomic_add(CROSS+o,tl.sum(tl.where(valid&scale,cross,0),0),sem='relaxed')
    tl.atomic_add(POWER+o,tl.sum(tl.where(valid&scale,power,0),0),sem='relaxed')
