"""Direct fine scoring from batch-owned observations and a shared phase table.

Only metadata is tiled. No parent-sized image/CTF/noise gathers or shifted
image tensor is materialized. Arithmetic and child ordering match score_kernel.
"""
import triton
import triton.language as tl
from .fused_cuda_kernels import _project


@triton.jit
def fine_input_score_kernel(V, M, PIX, PARENTS, PARTICLE, TRANSLATION,
                            X, C, INV, HIGH, PHASE, OUT,
                            P: tl.constexpr, S: tl.constexpr, R2: tl.constexpr,
                            PAD: tl.constexpr, F: tl.constexpr, T: tl.constexpr,
                            OC: tl.constexpr, PF: tl.constexpr,
                            PHASE_ACTIVE: tl.constexpr,
                            BF: tl.constexpr, BT: tl.constexpr):
    q = tl.program_id(0)
    parent = tl.load(PARENTS + q // OC)
    row = tl.load(PARTICLE + parent)
    translation = tl.load(TRANSLATION + parent)
    ts = tl.arange(0, BT)
    cross = tl.full((BT,), 0, tl.float32)
    xn = tl.full((BT,), 0, tl.float32)
    pn = tl.full((), 0, tl.float32)
    for block in range((F + BF - 1) // BF):
        f = block * BF + tl.arange(0, BF)
        valid = f < F
        pixels = tl.load(PIX + f, valid, 0)
        rr, ri = _project(V, M, q, pixels, valid, P, S, R2, PAD)
        cr = tl.load(C + 2 * (row * F + f), valid, 0)
        ci = tl.load(C + 2 * (row * F + f) + 1, valid, 0)
        pr = rr * cr - ri * ci
        pi = rr * ci + ri * cr
        inv = tl.load(INV + row * F + f, valid, 0)
        xr = tl.load(X + 2 * (row * F + f), valid, 0)
        xi = tl.load(X + 2 * (row * F + f) + 1, valid, 0)
        if PHASE_ACTIVE:
            at = (translation * T + ts[:, None]) * PF + f[None, :]
        else:
            at = (translation * T + ts[:, None]) * PF + pixels[None, :]
        mask = (ts[:, None] < T) & valid[None, :]
        ar = tl.load(PHASE + 2 * at, mask, 0)
        ai = tl.load(PHASE + 2 * at + 1, mask, 0)
        # Preserve the existing complex multiply and reduction order. In
        # particular, do not assume |phase| is exactly one in floating point.
        shifted_r = xr[None, :] * ar - xi[None, :] * ai
        shifted_i = xr[None, :] * ai + xi[None, :] * ar
        cross += tl.sum((shifted_r * pr[None, :] + shifted_i * pi[None, :]) * inv[None, :], 1)
        xn += tl.sum((shifted_r * shifted_r + shifted_i * shifted_i) * inv[None, :], 1)
        pn += tl.sum((pr * pr + pi * pi) * inv, 0)
    score = tl.maximum(.5 * (pn + xn - 2 * cross), 0) + tl.load(HIGH + row)
    tl.store(OUT + (parent * OC + q % OC) * T + ts, score, ts < T)
