"""Preflight guarded insertion. Never replay a possibly committed atomic update."""
import importlib.util
import warnings
import torch

_validated=set()
_disabled=False
_warned=False


def _arguments(bp,images,weights,inverse):
    from .fused_projection import _complex_parts
    args=(bp.numerator_real,bp.numerator_imag,bp.denominator,
          _complex_parts(images),weights.contiguous(),inverse.contiguous(),images.numel())
    size=images.shape[-2]
    meta=dict(S=size,P=bp.compact_size,RADIUS2=min(bp.r_max,size/2.)**2,
              MAPPED_RADIUS2=bp.max_r2_padded,BLOCK=256,enable_fp_fusion=False)
    return args,meta


def _self_check(device):
    import triton
    from .gridding_cuda_kernel import insert_kernel
    from relion_torch.fourier.backprojector import FourierBackprojector
    from relion_torch.alignment.core import _euler_matrix
    g=torch.Generator(device=device).manual_seed(511)
    images=torch.randn((3,8,5),device=device,dtype=torch.complex64,generator=g)
    weights=torch.rand((3,8,5),device=device,generator=g)
    angles=torch.tensor([[0.,0.,0.],[53.,128.,-19.],[182.,91.,74.]],device=device)
    rotations=_euler_matrix(angles)
    ref=FourierBackprojector.create(8,padding_factor=1.5,device=device)
    out=FourierBackprojector.create(8,padding_factor=1.5,device=device)
    ref.accumulate(images,rotations,weights)
    inverse=torch.linalg.inv(rotations)*out.padding_factor
    args,meta=_arguments(out,images,weights,inverse)
    insert_kernel[(triton.cdiv(images.numel(),256),)](*args,**meta)
    for name in ('numerator_real','numerator_imag','denominator'):
        torch.testing.assert_close(getattr(out,name),getattr(ref,name),rtol=4e-4,atol=3e-5)


def accumulate(bp,images,rotations,weights,*,mode='auto',counters=None):
    global _disabled,_warned
    if mode=='off':return False
    supported=(bp.reference_dim==3 and images.device.type=='cuda' and images.dtype==torch.complex64
               and bp.denominator.dtype==torch.float32 and rotations.dtype==torch.float32
               and weights.dtype==torch.float32 and rotations.shape[-2:]==(3,3))
    ready=supported and not _disabled and importlib.util.find_spec('triton') is not None
    if not ready:
        if mode=='required':raise RuntimeError('Fused gridding needs CUDA, Triton and FP32 3D inputs')
        return False
    if not images.numel():return True
    # Compile/validate before writing the caller's live sufficient statistics.
    try:
        import triton
        from .gridding_cuda_kernel import insert_kernel
        key=str(images.device)
        if key not in _validated:
            _self_check(images.device);_validated.add(key)
            if counters is not None:counters['fused_gridding_self_checks']=counters.get('fused_gridding_self_checks',0)+1
        inverse=(torch.linalg.inv(rotations)*bp.padding_factor).contiguous()
        args,meta=_arguments(bp,images,weights,inverse)
        grid=(triton.cdiv(images.numel(),256),)
        insert_kernel.warmup(*args,grid=grid,**meta)
    except Exception as exc:
        if isinstance(exc,(torch.cuda.OutOfMemoryError,MemoryError)) or mode=='required':raise
        _disabled=True
        if not _warned:
            warnings.warn('Fused gridding preflight failed; using PyTorch insertion: '+str(exc),RuntimeWarning)
            _warned=True
        return False
    # DO NOT catch this launch and retry: an atomic update might have committed.
    insert_kernel[grid](*args,**meta)
    if counters is not None:
        counters['fused_gridding_calls']=counters.get('fused_gridding_calls',0)+1
        counters['fused_gridding_input_pixels']=counters.get('fused_gridding_input_pixels',0)+images.numel()
    return True
