"""Guarded fused CUDA dispatch, with an explicit reproducible eager fallback."""
import importlib.util
import warnings
import numpy as np
import torch
from contextlib import nullcontext

_disabled=False
_warned=False
_validated=set()


def available(device,mode='auto'):
    ok=(mode!='off' and not _disabled and torch.device(device).type=='cuda'
        and importlib.util.find_spec('triton') is not None)
    if not ok and mode=='required':raise RuntimeError('local-fusion=required needs CUDA and a working Triton installation')
    return ok


def _complex_parts(x):
    if not x.is_complex():x=torch.complex(x,torch.zeros_like(x))
    return torch.view_as_real(x.resolve_conj().contiguous()).flatten()


def _failure(exc,mode):
    global _disabled,_warned
    if isinstance(exc,(torch.cuda.OutOfMemoryError,MemoryError)) or mode=='required':raise exc
    _disabled=True
    if not _warned:
        warnings.warn('Fused local CUDA kernel unavailable; using bounded PyTorch path: '+str(exc),RuntimeWarning)
        _warned=True


def inputs(store,c,ids):
    fallback=store.fallback
    callback=fallback.projector
    mode=getattr(callback,'fusion_mode','off')
    if not available(store.device,mode):return None
    ids=torch.as_tensor(ids,device=store.device,dtype=torch.long)
    if fallback.geometry is not None:inverse=fallback.geometry.gather(fallback.angles,ids)
    else:
        from relion_torch.alignment.core import _euler_matrix
        inverse=torch.linalg.inv(_euler_matrix(fallback.angles.index_select(0,ids)))
    projector,inverse=callback.fusion_inputs(c,inverse)
    if projector.data.dtype!=torch.complex64 or projector.interpolation!='linear' or projector.reference_dim!=3:
        if mode=='required':raise ValueError('Fused kernels require a complex64 linear 3D projector')
        return None
    copied = int(not projector.data.is_contiguous())
    store._count('source_layout_copy_requests', copied)
    store._count('source_layout_copy_bytes', copied*projector.data.numel()*projector.data.element_size())
    return projector,inverse.contiguous(),mode


def shared_budget(store):
    arena=store.buffer
    if getattr(arena,'projection_reuse','off')=='off':return 0
    return min(32*2**20,arena.max_bytes//4,getattr(arena,'work_bytes',512*2**20)//16)


def shared_batches(store,c,ids):
    """Split oversized reusable unions so the default tile actually shares.

    Disjoint angle groups keep every pair exactly once and never allocate a
    full orientation bank. Low-reuse unions retain the original direct kernel.
    """
    host=np.asarray(ids,dtype=np.int64).reshape(-1)
    full=np.arange(len(host),dtype=np.int64)
    budget=shared_budget(store)
    if not budget or not len(host):return [full]
    unique,inverse,counts=np.unique(host,return_inverse=True,return_counts=True)
    per_row=int(np.prod(store.shape[-2:]))*8*4+128
    cost=per_row+counts*16
    if cost.sum()<=budget or cost.max()>budget:return [full]
    hits=int((store.buffer.lookup(store.token,c*store.shape[1]+unique)>=0).sum())
    if len(host)<2*len(unique) and hits*2<len(unique):return [full]
    order=np.argsort(inverse,kind='stable');offsets=np.r_[0,np.cumsum(counts)]
    parts=[];first=0;used=0
    for j,amount in enumerate(cost):
        if used+amount>budget:
            parts.append(order[offsets[first]:offsets[j]])
            first=j;used=0
        used+=amount
    parts.append(order[offsets[first]:offsets[-1]])
    return parts


def shared_plan(store,c,ids):
    """Bounded policy: share high-reuse tiles or already retained rows.

    The cache remains the existing batch/half/optics-scoped arena. Reserve
    scratch for full planes, gathers, and active-pixel views, not just output.
    """
    arena=store.buffer
    if getattr(arena,'projection_reuse','off')=='off':return None
    host=ids.detach().cpu().numpy() if torch.is_tensor(ids) else np.asarray(ids,dtype=np.int64)
    unique,inverse=np.unique(host,return_inverse=True)
    full=int(np.prod(store.shape[-2:]))
    budget=shared_budget(store)
    scratch=len(unique)*(full*8*4+128)+len(host)*16
    if not len(unique) or scratch>budget:return None
    hits=int((arena.lookup(store.token,c*store.shape[1]+unique)>=0).sum())
    if len(host)<2*len(unique) and hits*2<len(unique):return None
    return unique,inverse,scratch


def shared_reference(store,c,ids,active):
    plan=shared_plan(store,c,ids)
    if plan is None:return None
    unique,inverse,scratch=plan
    reference=store.gather_shared(c,unique,active)
    store._count('shared_projection_requests',len(ids))
    store._count('shared_projection_unique_rows',len(unique))
    store._count('shared_projection_saved_rows',len(ids)-len(unique))
    store.buffer.count('shared_projection_scratch_peak_bytes',scratch,peak=True)
    return reference,torch.as_tensor(inverse,device=store.device,dtype=torch.long)


def project_rows(store,c,ids):
    payload=inputs(store,c,ids)
    if payload is None:return None
    projector,inverse,mode=payload
    size=store.shape[-2];f=size*(size//2+1)
    out=torch.empty((len(ids),size,size//2+1),device=store.device,dtype=torch.complex64)
    try:
        import triton
        from .fused_cuda_kernels import project_rows_kernel
        project_rows_kernel[(len(ids),triton.cdiv(f,256))](_complex_parts(projector.data),inverse,
            _complex_parts(out),P=projector.padded_size,S=size,R2=projector.source_radius_padded**2,
            PAD=projector.padding_factor,F=f,BF=256,enable_fp_fusion=False)
        key=('project_rows',str(store.device),size,projector.padded_size)
        if key not in _validated:
            count=min(4,len(ids))
            expected=projector.project(inverse[:count],output_size=size,rotations_are_inverse=True)
            torch.testing.assert_close(out[:count],expected,rtol=3e-4,atol=2e-4)
            _validated.add(key);store._count('shared_projection_self_checks')
    except Exception as exc:
        _failure(exc,mode);return None
    store._count('shared_projection_generation_calls')
    store._count('shared_projection_generated_rows',len(ids))
    return out


def prepare_score_observations(shifted,factor,inv,highres,image_norm):
    """Batch-owned kernel inputs; especially real-to-complex CTF conversion.

    Pass explicitly to coarse tiles, never retain on a model/store cache.
    """
    return (_complex_parts(shifted),_complex_parts(factor),inv.contiguous(),highres.contiguous(),
            highres if image_norm is None else image_norm.contiguous())


def score(store,c,ids,shifted,factor,inv,highres,active,rows=None,image_norm=None,*,prepared_inputs=None,device_ids=None):
    if not available(store.device,getattr(store.fallback.projector,'fusion_mode','off')):return None
    host=ids.detach().cpu().numpy() if torch.is_tensor(ids) else np.asarray(ids,dtype=np.int64)
    parts=shared_batches(store,c,host)
    if len(parts)>1:
        output=torch.empty((len(host),shifted.shape[1]),device=store.device,dtype=torch.float32)
        for part in parts:
            ix=torch.as_tensor(part,device=store.device,dtype=torch.long)
            selected=None if rows is None else rows.index_select(0,ix)
            values=score(store,c,host[part],shifted,factor,inv,highres,active,selected,image_norm,
                prepared_inputs=prepared_inputs,device_ids=None if device_ids is None else device_ids.index_select(0,ix))
            if values is None:return None
            output.index_copy_(0,ix,values)
        store._count('shared_projection_split_tiles',len(parts))
        return output
    payload=inputs(store,c,ids if device_ids is None else device_ids)
    if payload is None:return None
    projector,inverse,mode=payload
    if shifted.dtype!=torch.complex64 or inv.dtype!=torch.float32:return None
    rows=(torch.zeros(len(ids),device=store.device,dtype=torch.long) if rows is None else rows.to(device=store.device,dtype=torch.long))
    output=torch.empty((len(ids),shifted.shape[1]),device=store.device,dtype=torch.float32)
    try:
        import triton
        from .fused_cuda_kernels import score_kernel,shared_score_kernel
        shared=shared_reference(store,c,ids,active)
        common=(*(prepare_score_observations(shifted,factor,inv,highres,image_norm)
                  if prepared_inputs is None else prepared_inputs),output)
        params=dict(F=active.numel(),T=shifted.shape[1],HAS_XN=image_norm is not None,
            BF=128,BT=triton.next_power_of_2(shifted.shape[1]),enable_fp_fusion=False)
        if shared is None:
            score_kernel[(len(ids),)](_complex_parts(projector.data),inverse,active.contiguous(),rows.contiguous(),
                *common,P=projector.padded_size,S=store.shape[-2],R2=projector.source_radius_padded**2,
                PAD=projector.padding_factor,**params)
        else:
            reference,mapping=shared
            shared_score_kernel[(len(ids),)](_complex_parts(reference),mapping,rows.contiguous(),*common,**params)
            store._count('shared_fused_score_calls');store._count('shared_fused_score_rows',len(ids))
        check=('score',str(store.device),store.shape[-2],shared is not None)
        if check not in _validated:
            from .score_tiles import score_prediction_tile
            count=min(4,len(ids));ri=rows[:count]
            ref=projector.project(inverse[:count],output_size=store.shape[-2],rotations_are_inverse=True)
            prediction=ref.flatten(1).index_select(1,active)*factor.index_select(0,ri)
            expected=score_prediction_tile(shifted.index_select(0,ri),prediction[:,None],inv.index_select(0,ri),
                highres.index_select(0,ri),image_norm=None if image_norm is None else image_norm.index_select(0,ri))[:,0]
            torch.testing.assert_close(output[:count],expected,rtol=3e-4,atol=2e-4)
            _validated.add(check);store._count('fused_score_self_checks')
    except Exception as exc:
        _failure(exc,mode);return None
    store._count('fused_score_calls');store._count('fused_score_rows',len(ids))
    return output


def score_shared_tile(store,c,unique,ids,shifted,factor,inv,highres,active,rows,image_norm,*,prepared_inputs=None):
    """Generate one bounded coarse tile; share it across real particle pairs."""
    mode=getattr(store.fallback.projector,'fusion_mode','off')
    if not available(store.device,mode) or shifted.dtype!=torch.complex64 or inv.dtype!=torch.float32:return None
    detail=getattr(store,'detail_timer',None)
    with (detail.section('local.coarse_shared_projection',full=True) if detail else nullcontext()):
        reference=project_rows(store,c,unique)
    if reference is None:return None
    reference=reference.flatten(1).index_select(1,active)
    mapping=torch.as_tensor(np.searchsorted(unique,ids),device=store.device,dtype=torch.long)
    output=torch.empty((len(ids),shifted.shape[1]),device=store.device,dtype=torch.float32)
    try:
        import triton
        from .fused_cuda_kernels import shared_score_kernel
        observation=(prepare_score_observations(shifted,factor,inv,highres,image_norm)
                     if prepared_inputs is None else prepared_inputs)
        with (detail.section('local.coarse_shared_score',full=True) if detail else nullcontext()):
            shared_score_kernel[(len(ids),)](_complex_parts(reference),mapping,rows.contiguous(),
                *observation,output,F=active.numel(),T=shifted.shape[1],HAS_XN=True,
                BF=128,BT=triton.next_power_of_2(shifted.shape[1]),enable_fp_fusion=False)
        key=('local_coarse_shared',str(store.device),store.shape[-2])
        if key not in _validated:
            from .score_tiles import score_prediction_tile
            count=min(4,len(ids));ri=rows[:count]
            prediction=reference.index_select(0,mapping[:count])*factor.index_select(0,ri)
            expected=score_prediction_tile(shifted.index_select(0,ri),prediction[:,None],inv.index_select(0,ri),
                highres.index_select(0,ri),image_norm=image_norm.index_select(0,ri))[:,0]
            torch.testing.assert_close(output[:count],expected,rtol=3e-4,atol=2e-4)
            _validated.add(key)
    except Exception as exc:
        _failure(exc,mode);return None
    store._count('coarse_shared_score_calls');store._count('coarse_shared_projected_rows',len(unique))
    store._count('coarse_shared_scored_pairs',len(ids))
    return output


class StatisticsReferences:
    """Lazy fine references consumed directly by the residual/scale CUDA kernel."""
    def __init__(self,fine,blocks,*,host_schedule=None):
        self.fine=fine;self.blocks=blocks;self.host_schedule=host_schedule

    def metadata(self):
        if self.host_schedule is not None:
            c,orientations=self.host_schedule
            coarse=np.asarray(orientations,dtype=np.int64)
            if len(coarse)!=len(self.blocks):raise ValueError('Statistics schedule row count mismatch')
            mapping=getattr(self.fine,'original_parent_ids',None)
            if mapping is not None:
                mapped=np.searchsorted(mapping,coarse)
                if np.any(mapped>=len(mapping)) or np.any(mapping[mapped]!=coarse):
                    raise ValueError('Statistics parent outside compact fine geometry')
                coarse=mapped
            self.fine.store._count('statistics_metadata_readbacks_avoided')
            return np.full(len(coarse),int(c),dtype=np.int64),coarse
        host=self.blocks.detach().cpu().numpy()
        return self.fine.host_classes[host],self.fine.host_orientations[host]
    def reduced_statistics(self,rows,image,factor,phase,image_weight,mass,active,dtype,spec):
        """Private compact outputs; fallback is safe before caller commits them."""
        if dtype!=torch.float32 or image.dtype!=torch.complex64 or phase.dtype!=torch.complex64:return None
        fine=self.fine
        if getattr(fine.store.buffer,'statistics_reduction','auto')=='off':return None
        shells,ns,scale=spec
        classes,coarse=self.metadata()
        oc=fine.oc;n=len(coarse)*oc;f=active.numel()
        output=[torch.empty((n,ns),device=rows.device,dtype=torch.float32),
                torch.empty(n,device=rows.device,dtype=torch.float32),torch.empty(n,device=rows.device,dtype=torch.float32)]
        batches=[]
        for c in np.unique(classes):
            groups=np.flatnonzero(classes==c)
            positions=(groups[:,None]*oc+np.arange(oc)[None]).reshape(-1)
            ids=(coarse[groups,None]*oc+np.arange(oc)[None]).reshape(-1)
            for part in shared_batches(fine.store,int(c),ids):batches.append((c,positions[part],ids[part]))
        for c,positions,ids in batches:
            payload=inputs(fine.store,int(c),ids)
            if payload is None:return None
            projector,inverse,mode=payload
            direct=len(positions)==n and np.array_equal(positions,np.arange(n))
            ix=None if direct else torch.as_tensor(positions,device=rows.device)
            ri=(rows if direct else rows.index_select(0,ix)).contiguous()
            ph=(phase if direct else phase.index_select(0,ix)).contiguous()
            iw=(image_weight if direct else image_weight.index_select(0,ix)).contiguous()
            ms=(mass if direct else mass.index_select(0,ix)).contiguous()
            selected=[torch.zeros((len(ids),ns),device=rows.device,dtype=torch.float32),
                      torch.zeros(len(ids),device=rows.device,dtype=torch.float32),torch.zeros(len(ids),device=rows.device,dtype=torch.float32)]
            try:
                import triton
                from .fused_cuda_kernels import reduced_statistics_kernel
                shared=shared_reference(fine.store,int(c),ids,active)
                reference,mapping=(shared if shared is not None else (image,rows))
                reduced_statistics_kernel[(len(ids),triton.cdiv(f,256))](
                    _complex_parts(projector.data),inverse,_complex_parts(reference),mapping,
                    active.contiguous(),ri,_complex_parts(image),_complex_parts(factor),_complex_parts(ph),iw,ms,
                    shells.contiguous(),scale.contiguous(),*selected,P=projector.padded_size,S=fine.shape[-2],
                    R2=projector.source_radius_padded**2,PAD=projector.padding_factor,F=f,NS=ns,
                    SHARED=shared is not None,BF=256,enable_fp_fusion=False)
                key=('reduced_statistics',str(rows.device),fine.shape[-2],shared is not None,ns)
                if key not in _validated:
                    count=min(4,len(ids));r=ri[:count]
                    ref=projector.project(inverse[:count],output_size=fine.shape[-2],rotations_are_inverse=True)
                    pred=ref.flatten(1).index_select(1,active)*factor.index_select(0,r)
                    im=image.index_select(0,r)
                    power=ms[:count,None]*pred.abs().square();cross=(pred.conj()*im*ph[:count]).real
                    residual=(im.abs().square()*iw[:count]+power-2*cross).clamp_min(0)
                    noise=torch.zeros((count,ns),device=rows.device)
                    noise.scatter_add_(1,shells[None].expand(count,-1),residual)
                    for actual,wanted in zip(selected,(noise,cross[:,scale].sum(-1),power[:,scale].sum(-1))):
                        torch.testing.assert_close(actual[:count],wanted,rtol=5e-4,atol=5e-4)
                    _validated.add(key);fine.store._count('reduced_statistics_self_checks')
            except Exception as exc:
                _failure(exc,mode);return None
            if direct:
                output=selected
                fine.store._count('statistics_identity_gathers_avoided')
            else:
                for out,part in zip(output,selected):out.index_copy_(0,ix,part)
            fine.store._count('reduced_statistics_calls');fine.store._count('reduced_statistics_rows',len(ids))
            fine.store._count('reduced_statistics_avoided_bytes',max(0,len(ids)*(3*f-ns-2)*4))
        return output

    def fused_statistics(self,rows,image,factor,phase,image_weight,mass,active,dtype):
        if image.dtype!=torch.complex64 or phase.dtype!=torch.complex64:return None
        fine=self.fine;classes,coarse=self.metadata()
        oc=fine.oc;n=len(coarse)*oc;f=active.numel()
        result=[torch.empty((n,f),device=rows.device,dtype=torch.float32) for _ in range(3)]
        for c in np.unique(classes):
            groups=np.flatnonzero(classes==c)
            positions=(groups[:,None]*oc+np.arange(oc)[None]).reshape(-1)
            ids=(coarse[groups,None]*oc+np.arange(oc)[None]).reshape(-1)
            payload=inputs(fine.store,int(c),ids)
            if payload is None:return None
            projector,inverse,mode=payload
            ix=torch.as_tensor(positions,device=rows.device)
            selected=[torch.empty((len(ids),f),device=rows.device,dtype=torch.float32) for _ in range(3)]
            try:
                import triton
                from .fused_cuda_kernels import statistics_kernel
                statistics_kernel[(len(ids),triton.cdiv(f,256))](_complex_parts(projector.data),inverse,
                    active.contiguous(),rows.index_select(0,ix).contiguous(),_complex_parts(image),_complex_parts(factor),
                    _complex_parts(phase.index_select(0,ix)),image_weight.index_select(0,ix).contiguous(),
                    mass.index_select(0,ix).contiguous(),*selected,P=projector.padded_size,S=fine.shape[-2],
                    R2=projector.source_radius_padded**2,PAD=projector.padding_factor,F=f,BF=256,enable_fp_fusion=False)
                check=('statistics',str(rows.device),fine.shape[-2])
                if check not in _validated:
                    count=min(4,len(ids));ri=rows.index_select(0,ix)[:count]
                    ref=projector.project(inverse[:count],output_size=fine.shape[-2],rotations_are_inverse=True)
                    pred=ref.flatten(1).index_select(1,active)*factor.index_select(0,ri)
                    ph=phase.index_select(0,ix)[:count];im=image.index_select(0,ri)
                    power=mass.index_select(0,ix)[:count,None]*pred.abs().square()
                    cross=(pred.conj()*im*ph).real
                    residual=(im.abs().square()*image_weight.index_select(0,ix)[:count]+power-2*cross).clamp_min(0)
                    for actual,wanted in zip(selected,(residual,cross,power)):
                        torch.testing.assert_close(actual[:count],wanted,rtol=3e-4,atol=2e-4)
                    _validated.add(check);fine.store._count('fused_statistics_self_checks')
            except Exception as exc:
                _failure(exc,mode);return None
            for out,part in zip(result,selected):out.index_copy_(0,ix,part)
            fine.store._count('fused_statistics_calls');fine.store._count('fused_statistics_rows',len(ids))
        result[0]=result[0].to(dtype)
        return result
    def materialize(self):return self.fine.index_select(0,self.blocks).flatten(0,1)
