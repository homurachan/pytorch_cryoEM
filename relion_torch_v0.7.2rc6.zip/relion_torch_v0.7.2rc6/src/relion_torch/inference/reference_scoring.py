"""Factor CTF/noise out of the shared-reference orientation axis."""
import torch


class PreparedReferenceScorer:
    """Prepare once per particle batch; reuse across classes/direction blocks.

    [B*T,F] @ [F,O] avoids a materialized [B,O,F] prediction. Formulas
    are the same Gaussian/normalized-CC objective, with reordered products.
    All arithmetic uses the input precision (no TF32/FP16 policy change).
    """
    def __init__(self, shifted, ctf, invsigma, highres, image_norm, *, cc=False, fusion_mode="off", counters=None):
        self.cc = bool(cc)
        self.fusion_mode, self.counters = fusion_mode, counters
        self.parent_nbytes = 0
        self.batch, self.translations, self.frequencies = shifted.shape
        weight = ctf if cc else ctf * invsigma
        self.real = (shifted.real * weight[:, None]).contiguous()
        self.imag = (shifted.imag * weight[:, None]).contiguous()
        self.power_weight = ctf.square() if cc else ctf.square() * invsigma
        self.image_norm, self.highres = image_norm, highres

    def select(self, ids):
        result = object.__new__(type(self))
        result.cc = self.cc
        result.fusion_mode, result.counters = self.fusion_mode, self.counters
        result.parent_nbytes = self.nbytes + self.parent_nbytes
        result.translations, result.frequencies = self.translations, self.frequencies
        for name in ('real', 'imag', 'power_weight', 'image_norm', 'highres'):
            setattr(result, name, getattr(self, name)[ids])
        result.batch = result.real.shape[0]
        return result

    @property
    def nbytes(self):
        return sum(x.numel() * x.element_size() for x in (self.real, self.imag, self.power_weight))

    def plan(self, orientations, work_bytes, requested=0):
        # Includes gathered reference, power, GEMM and score temporaries.
        per = max(1, (self.frequencies * 10 + self.batch * self.translations * 8 + self.batch * 4) * self.real.element_size())
        fixed = self.nbytes * 2 + self.parent_nbytes
        available = int(work_bytes) - fixed
        if available < per:
            raise MemoryError('coarse scoring tile exceeds candidate workspace')
        target = int(requested) if requested else 2048
        rows = max(1, min(int(orientations), target, available // per))
        return rows, fixed + rows * per

    def score(self, reference):
        b, t, f = self.batch, self.translations, self.frequencies
        cross_real = self.real.reshape(b*t, f) @ reference.real.T
        cross_imag = self.imag.reshape(b*t, f) @ reference.imag.T
        power = reference.real.square() + reference.imag.square()
        pnorm = self.power_weight @ power.T
        if not self.cc and self.fusion_mode != 'off':
            from .global_fusion import score_epilogue
            output = score_epilogue(cross_real, cross_imag, pnorm, self.image_norm, self.highres,
                                    translations=t, mode=self.fusion_mode, counters=self.counters)
            if output is not None:
                return output
        cross = (cross_real+cross_imag).reshape(b, t, -1).transpose(1, 2)
        xnorm = self.image_norm[:, None, None]
        if self.cc:
            return cross / (pnorm[:, :, None] * xnorm).clamp_min(torch.finfo(reference.real.dtype).tiny).sqrt()
        return (.5 * (pnorm[:, :, None] + xnorm - 2 * cross)).clamp_min(0) + self.highres[:, None, None]
