"""Initial-reference handling for Class2D."""
from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
from typing import Any, Sequence

import mrcfile
import numpy as np
import torch

from relion_torch.fourier.conventions import relion_soft_mask_outside_map
from relion_torch.io.mrc import write_mrc
from relion_torch.io.star import read_star


@dataclass(slots=True, frozen=True)
class ParticleLocator:
    index0: int
    path: Path
    image_name: str


def _find_block(blocks: dict[str, Any], *needles: str) -> Any:
    lowered = tuple(value.lower() for value in needles)
    for key, value in blocks.items():
        key_lower = str(key).lower()
        columns = {str(column).lstrip("_").lower() for column in getattr(value, "columns", [])}
        if any(needle in key_lower for needle in lowered):
            return value
        if "rlnimagename" in columns and "particle" in lowered:
            return value
        if "rlnopticsgroup" in columns and "optics" in lowered and "rlnimagename" not in columns:
            return value
    raise KeyError(f"Could not locate STAR block matching {needles!r}")


def _column(table: Any, name: str, default: Any = None) -> Any:
    canonical = name.lstrip("_")
    for candidate in (canonical, "_" + canonical):
        if candidate in table:
            return table[candidate]
    return default


def _resolve_path(name: str, star_path: Path) -> Path:
    candidate = Path(name).expanduser()
    probes = [candidate, star_path.parent / candidate, Path.cwd() / candidate]
    probes.extend(parent / candidate for parent in star_path.parents)
    seen: set[Path] = set()
    for probe in probes:
        try:
            resolved = probe.resolve()
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        if resolved.is_file():
            return resolved
    raise FileNotFoundError(f"Cannot resolve {name!r} relative to {star_path}")


def particle_locators(star_path: str | Path) -> tuple[Any, Any, list[ParticleLocator]]:
    path = Path(star_path).expanduser().resolve()
    blocks = read_star(path)
    particles = _find_block(blocks, "particle")
    try:
        optics = _find_block(blocks, "optics")
    except KeyError:
        optics = None
    image_names = _column(particles, "rlnImageName")
    if image_names is None:
        raise ValueError(f"{path} has no rlnImageName column")
    locators: list[ParticleLocator] = []
    for raw in image_names.astype(str).tolist():
        if "@" not in raw:
            raise ValueError(f"Expected RELION index@stack syntax, got {raw!r}")
        index_text, stack_name = raw.split("@", 1)
        index0 = int(index_text) - 1
        if index0 < 0:
            raise ValueError(f"Invalid one-based image index in {raw!r}")
        locators.append(ParticleLocator(index0, _resolve_path(stack_name, path), raw))
    return optics, particles, locators


def _pixel_size(optics: Any, particles: Any) -> float:
    for table in (optics, particles):
        if table is None:
            continue
        values = _column(table, "rlnImagePixelSize")
        if values is None:
            values = _column(table, "rlnPixelSize")
        if values is not None and len(values):
            value = float(values.iloc[0] if hasattr(values, "iloc") else values[0])
            if value > 0:
                return value
    raise ValueError("Could not determine particle pixel size")


def _load_particle(locator: ParticleLocator) -> np.ndarray:
    from relion_torch.io.mrc_stack import MRCStackCache
    with MRCStackCache(max_open=1) as cache:
        return cache.image(locator.path, locator.index0+1)


def _integer_shift_no_wrap(image: np.ndarray, x: int, y: int) -> np.ndarray:
    out = np.zeros_like(image)
    height, width = image.shape
    src_x0, src_x1 = max(0, -x), min(width, width - x)
    src_y0, src_y1 = max(0, -y), min(height, height - y)
    if src_x1 <= src_x0 or src_y1 <= src_y0:
        return out
    dst_x0, dst_x1 = src_x0 + x, src_x1 + x
    dst_y0, dst_y1 = src_y0 + y, src_y1 + y
    out[dst_y0:dst_y1, dst_x0:dst_x1] = image[src_y0:src_y1, src_x0:src_x1]
    return out


def _rotate_bilinear(image: np.ndarray, angle_deg: float) -> np.ndarray:
    if abs(float(angle_deg)) < 1.0e-12:
        return image
    tensor = torch.from_numpy(np.ascontiguousarray(image))[None, None].float()
    angle = math.radians(float(angle_deg))
    cosine, sine = math.cos(angle), math.sin(angle)
    theta = torch.tensor(
        [[[cosine, -sine, 0.0], [sine, cosine, 0.0]]], dtype=torch.float32
    )
    grid = torch.nn.functional.affine_grid(theta, tensor.shape, align_corners=False)
    rotated = torch.nn.functional.grid_sample(
        tensor,
        grid,
        mode="bilinear",
        padding_mode="zeros",
        align_corners=False,
    )
    return rotated[0, 0].numpy()


def _mask_image(image: np.ndarray, radius_pixels: float, edge_pixels: float) -> np.ndarray:
    tensor = torch.from_numpy(np.ascontiguousarray(image)).float()
    masked = relion_soft_mask_outside_map(
        tensor,
        radius_pixels=float(radius_pixels),
        cosine_width_pixels=float(edge_pixels),
        noise=None,
        ndim=2,
    )
    return masked.cpu().numpy().astype(np.float32, copy=False)


def _emit_reference(output_root, class_index, image, pixel_size, reference_collector=None):
    # Standalone legacy helper calls retain their file-based API. The Class2D
    # runner supplies a collector, so production startup creates no per-class
    # temporary MRCs and passes the same in-memory seeds to the optimiser.
    if reference_collector is not None:
        return reference_collector.emit(class_index, image)
    path = Path(f"{output_root}_init_class{class_index:03d}.mrc").resolve()
    write_mrc(path, image, pixel_size_angstrom=pixel_size)
    return path


def split_reference_stack(
    reference: str | Path,
    output_root: str | Path,
    number_of_classes: int,
    *,
    pixel_size_angstrom: float | None = None,
    reference_collector=None,
) -> list[Path]:
    """Return K individual reference files from a 2-D MRC or MRCS stack."""

    source = Path(reference).expanduser().resolve()
    with mrcfile.open(source, mode="r", permissive=True) as handle:
        array = np.asarray(handle.data, dtype=np.float32)
        voxel = float(handle.voxel_size.x)
    if array.ndim == 2:
        if number_of_classes != 1:
            raise ValueError(
                f"{source} is one 2-D image but --K={number_of_classes}; supply K references or a K-image stack"
            )
        images = array[None]
    elif array.ndim == 3:
        images = array
    else:
        raise ValueError(f"Class2D reference must be 2-D or a 3-D stack, got {array.shape}")
    if int(images.shape[0]) != int(number_of_classes):
        raise ValueError(
            f"Reference stack has {images.shape[0]} images but --K={number_of_classes}"
        )
    pixel = pixel_size_angstrom or (voxel if voxel > 0 else None)
    root = Path(output_root)
    root.parent.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for class_index, image in enumerate(images, start=1):
        paths.append(_emit_reference(root,class_index,image,pixel,reference_collector))
    return paths


def prepare_supplied_references(
    references: Sequence[str | Path] | str | Path,
    output_root: str | Path,
    number_of_classes: int,
    *,
    pixel_size_angstrom: float | None = None,
    reference_collector=None,
) -> list[Path]:
    """Normalise repeated MRC references or one K-image stack to individual files."""

    if isinstance(references, (str, Path)):
        references = (references,)
    paths = [Path(value).expanduser().resolve() for value in references]
    if not paths:
        raise ValueError("No references were supplied")
    if len(paths) == 1:
        return split_reference_stack(
            paths[0], output_root, number_of_classes, pixel_size_angstrom=pixel_size_angstrom,
            reference_collector=reference_collector
        )
    if len(paths) != number_of_classes:
        raise ValueError(f"Expected {number_of_classes} references, received {len(paths)}")
    output: list[Path] = []
    for index, path in enumerate(paths, start=1):
        with mrcfile.open(path, mode="r", permissive=True) as handle:
            image = np.asarray(handle.data, dtype=np.float32)
            voxel = float(handle.voxel_size.x)
        if image.ndim != 2:
            raise ValueError(f"Reference {path} is not a single 2-D image: {image.shape}")
        output.append(_emit_reference(output_root,index,image,
            pixel_size_angstrom or (voxel if voxel > 0 else None),reference_collector))
    return output


def generate_initial_references(
    input_star: str | Path,
    output_root: str | Path,
    number_of_classes: int,
    *,
    particle_diameter_angstrom: float | None,
    mask_edge_pixels: float,
    seed: int,
    mode: str = "random-subsets",
    subset_size: int = 64,
    use_input_alignment: bool = False,
    dataset=None,
    reference_collector=None,
) -> list[Path]:
    """Generate deterministic Class2D starting references.

    This is intentionally deterministic and suitable for regression testing.  It
    does not claim bit-identical reproduction of RELION's C-library random stream.
    For strict RELION/PyTorch comparisons, supply the same initial class stack to
    both programs.
    """

    if number_of_classes < 1:
        raise ValueError("number_of_classes must be positive")
    optics, particles, locators = particle_locators(input_star)
    if len(locators) < number_of_classes:
        raise ValueError("There are fewer particles than requested classes")
    first = _load_particle(locators[0]) if dataset is None else dataset.load_image(0)
    if first.ndim != 2 or first.shape[0] != first.shape[1]:
        raise ValueError("Class2D requires square two-dimensional particles")
    size = int(first.shape[0])
    pixel = _pixel_size(optics, particles)
    diameter = (
        float(particle_diameter_angstrom)
        if particle_diameter_angstrom is not None
        else (float(size) - float(mask_edge_pixels)) * pixel
    )
    radius = diameter / (2.0 * pixel)
    rng = np.random.default_rng(int(seed))
    order = rng.permutation(len(locators))
    psi = _column(particles, "rlnAnglePsi")
    origin_x = _column(particles, "rlnOriginXAngst")
    origin_y = _column(particles, "rlnOriginYAngst")
    norm = _column(particles, "rlnNormCorrection")

    root = Path(output_root)
    root.parent.mkdir(parents=True, exist_ok=True)
    results: list[Path] = []
    for class_index in range(number_of_classes):
        if mode == "random-particles":
            selected = [int(order[class_index])]
        elif mode == "random-subsets":
            selected = [
                int(value)
                for value in order[class_index::number_of_classes][
                    : max(1, int(subset_size))
                ]
            ]
        else:
            raise ValueError(f"Unsupported initialisation mode {mode!r}")
        accumulator = np.zeros_like(first, dtype=np.float64)
        for row in selected:
            image = _load_particle(locators[row]) if dataset is None else dataset.load_image(row)
            if norm is not None:
                norm_value = float(norm.iloc[row] if hasattr(norm, "iloc") else norm[row])
                if math.isfinite(norm_value) and norm_value > 0.0:
                    image = image / norm_value
            if use_input_alignment:
                ox = 0.0 if origin_x is None else float(origin_x.iloc[row])
                oy = 0.0 if origin_y is None else float(origin_y.iloc[row])
                angle = 0.0 if psi is None else float(psi.iloc[row])
                image = _integer_shift_no_wrap(
                    image, -int(round(ox / pixel)), -int(round(oy / pixel))
                )
                image = _rotate_bilinear(image, -angle)
            accumulator += _mask_image(image, radius, mask_edge_pixels)
        reference = (accumulator / max(1, len(selected))).astype(np.float32)
        reference -= np.float32(reference.mean())
        rms = float(np.sqrt(np.mean(reference.astype(np.float64) ** 2)))
        if rms > 0.0:
            reference /= np.float32(rms)
        results.append(_emit_reference(root,class_index+1,reference,pixel,reference_collector))
    return results


def relion_c_random_values(seed: int, count: int) -> list[int]:
    """Native Linux C rand sequence, reseeded per particle by RELION 3.1.

    Keep calls under the same lock as the shared accuracy code. Other platforms
    have a different C random stream, just as native RELION does.
    """
    import ctypes
    from relion_torch.optimiser.alignment import _c_random_functions, _C_RAND_LOCK
    srand, rand = _c_random_functions()
    with _C_RAND_LOCK:
        srand(ctypes.c_uint(int(seed) & 0xffffffff))
        return [int(rand()) for _ in range(int(count))]


def prepare_relion_references(config, output_root, pixel_size, *, dataset=None, startup=None, reference_collector=None):
    """Resolve distinct-reference, common-reference and reference-free states.

    A STAR file or repeated --ref gives distinct classes. --ref-stack is an
    explicit PyTorch extension for a K-image stack. A lone non-STAR --ref uses
    its first image and replicates it, as the RELION 3.1 single-reference branch.
    """
    supplied=list(config.references)
    if not supplied:
        if config.init_mode in ("random-subsets", "random-particles"):
            refs=generate_initial_references(config.input_star,output_root,config.number_of_classes,
                particle_diameter_angstrom=config.particle_diameter_angstrom,
                mask_edge_pixels=config.mask_edge_pixels,seed=config.random_seed,
                mode=config.init_mode,subset_size=config.init_subset_size,
                use_input_alignment=config.use_input_alignment_for_init, dataset=dataset, reference_collector=reference_collector)
            return refs,"custom-"+config.init_mode,False,False
        refs=generate_relion_initial_references(config,output_root,dataset=dataset,startup=startup,reference_collector=reference_collector)
        return refs,"reference-free-fourier",False,True
    if len(supplied)==1 and str(supplied[0]).lower().endswith(".star"):
        star=Path(supplied[0]).expanduser().resolve()
        tables=read_star(star)
        frame=next((t for t in tables.values() if "rlnReferenceImage" in t),None)
        if frame is None:
            raise ValueError("reference STAR has no rlnReferenceImage column")
        if len(frame)!=config.number_of_classes:
            raise ValueError("reference STAR class count differs from --K")
        refs=[]
        for c,value in enumerate(frame["rlnReferenceImage"].astype(str),1):
            if "@" in value:
                index,name=value.split("@",1);index=int(index)-1
            else:
                name=value;index=None
            source=_resolve_path(name,star)
            with mrcfile.open(source,permissive=True) as f:
                array=np.asarray(f.data,dtype=np.float32)
                image=array[index] if index is not None and array.ndim==3 else array
                if image.ndim!=2:
                    raise ValueError(f"reference {value} is not a 2-D image")
                image=image.copy()
            refs.append(_emit_reference(output_root,c,image,pixel_size,reference_collector))
        return refs,"supplied-star",False,False
    if len(supplied)>1 or getattr(config,"reference_stack",False):
        refs=prepare_supplied_references(supplied,output_root,config.number_of_classes,
                                        pixel_size_angstrom=pixel_size,reference_collector=reference_collector)
        return refs,"supplied-k",False,False
    source=Path(supplied[0]).expanduser().resolve()
    with mrcfile.open(source,permissive=True) as f:
        array=np.asarray(f.data,dtype=np.float32)
        image=(array[0] if array.ndim==3 else array).copy()
    if image.ndim!=2:
        raise ValueError("common reference must contain a 2-D image")
    refs=[]
    for c in range(config.number_of_classes):
        refs.append(_emit_reference(output_root,c+1,image,pixel_size,reference_collector))
    return refs,"common-reference",config.number_of_classes>1,False


def resolve_reference_free_ini_high(config, box_size: int, pixel_size: float) -> float | None:
    """Resolve RELION's no-reference default before creating any seed maps.

    Missing/negative ini_high corresponds to the native -1 default. Explicit
    positive values are preserved; zero retains its historical disabled meaning.
    Supplied-reference and continuation branches do not call this helper.
    """
    from relion_torch.relion_statistics import relion_round_positive
    value = config.initial_high_resolution
    if value is not None and not math.isfinite(float(value)):
        raise ValueError("--ini-high must be finite")
    if box_size < 2 or pixel_size <= 0 or not math.isfinite(float(pixel_size)):
        raise ValueError("invalid box size or pixel size for initial resolution")
    automatic = value is None or float(value) < 0
    if automatic:
        # max(1, ...) only protects tiny synthetic boxes whose rounded shell is 0.
        shell = max(1, int(relion_round_positive(0.07 * box_size)))
        config.initial_high_resolution = box_size * float(pixel_size) / shell
        config.initial_high_resolution_auto = True
    return config.initial_high_resolution


@torch.no_grad()
def generate_relion_initial_references(config, output_root, *, dataset=None, startup=None, reference_collector=None):
    from relion_torch.alignment.core import AlignmentDataset
    if dataset is None:
        with AlignmentDataset.from_config(config) as owned:
            return _generate_relion_initial_references(config, output_root, owned, startup=startup,reference_collector=reference_collector)
    return _generate_relion_initial_references(config, output_root, dataset, startup=startup,reference_collector=reference_collector)


def _generate_relion_initial_references(config, output_root, dataset, *, startup=None, reference_collector=None):
    """Random class/psi, CTF-aware Fourier insertion, unregularised reconstruction.

    Unlike the historical random-subset initializer, this never scales individual
    class averages to unit RMS. The seed generator is reset for every image.
    """
    from relion_torch.alignment.core import AlignmentDataset, ValidatedBackprojectorAdapter, centered_rfft2, ctf_rfft, _euler_matrix
    from relion_torch.inference.alignment import AlignmentExpectation
    from relion_torch.reconstruction.reconstruct import ReconstructionOptions, reconstruct_backprojector
    from relion_torch.sampling.relion_sampling import relion_round
    if getattr(config,'initialization_mode','batched') == 'batched':
        return _generate_relion_initial_references_batched(config,output_root,dataset,startup=startup,reference_collector=reference_collector)
    device=torch.device(config.device if config.device!="cuda" or torch.cuda.is_available() else "cpu")
    n,pixel=dataset.box_size,dataset.pixel_size
    resolve_reference_free_ini_high(config, n, pixel)
    # Literal ver3.1 calculateSumOfPowerSpectraAndAverageImage initialization.
    if config.initial_high_resolution and config.initial_high_resolution>0:
        initial_size=int(relion_round(n*pixel/config.initial_high_resolution))
    else:
        initial_size=int(n*pixel/max(1,int(relion_round(.07*n))))
    initial_size=min(n,max(2,initial_size));initial_size-=initial_size%2
    label = "RELION no-reference default" if config.initial_high_resolution_auto else "explicit"
    print(f"Initial reference low-pass: {config.initial_high_resolution:g} A ({label}); "
          f"initial Fourier size={initial_size}; final reference box={n}")
    bps=ValidatedBackprojectorAdapter(config.number_of_classes,n,initial_size,config.padding_factor,device,reference_dim=2)
    diameter=config.particle_diameter_angstrom or ((n-config.mask_edge_pixels)*pixel)
    for indices, raw_images in dataset.iter_image_batches(device=device, batch_size=1,
            pool_size=dataset.io_options.effective_pool(config.batch_size)):
        i = indices[0]
        record=dataset.record(i)
        image=raw_images[0]
        if config.zero_mask:
            image=relion_soft_mask_outside_map(image,radius_pixels=diameter/(2*pixel),cosine_width_pixels=config.mask_edge_pixels,noise=None,ndim=2)
        from relion_torch.optics.aberrations import demodulate_records_
        from relion_torch.optics.ctf import CTFFrequencyGrid2D
        transform = centered_rfft2(image)
        demodulate_records_([record], CTFFrequencyGrid2D.create(n, pixel,
            device=device, dtype=transform.real.dtype), transform[None])
        transform=AlignmentExpectation._window_rfft(transform,initial_size)
        draws=relion_c_random_values(config.random_seed+i,2)
        rand_max=32767. if __import__('sys').platform.startswith('win') else 2147483647.
        psi=draws[0]/rand_max*360.
        cls=min(config.number_of_classes-1,int(draws[1]/rand_max*config.number_of_classes))
        raw=ctf_rfft(record,n,device,torch.float32,phase_flipped_input=config.ctf_phase_flipped,
            only_flip_phases=config.only_flip_phases,intact_first_peak=config.intact_first_peak) if config.use_ctf else torch.ones((n,n//2+1),device=device)
        raw=AlignmentExpectation._window_rfft(raw,initial_size)
        numerator=transform*raw;weight=raw.square()
        bps.add(cls,numerator,_euler_matrix(torch.tensor([[0.,0.,psi]],device=device))[0],
                torch.ones_like(weight),weight)
    output=[]
    for c,bp in enumerate(bps.objects):
        if float(bp.denominator.sum())>0:
            result=reconstruct_backprojector(bp,ReconstructionOptions(tau2=None,
                preweight_iterations=config.preweight_iterations,normalise=1.0))
            image=result.map
        else:
            image=torch.zeros((n,n),device=device)
        output.append(_emit_reference(output_root,c+1,image,pixel,reference_collector))
    return output


@torch.no_grad()
def _generate_relion_initial_references_batched(config, output_root, dataset, *, startup=None, reference_collector=None):
    from relion_torch.alignment.initialization import (InitialNoiseAccumulator,
        iter_initial_fourier_batches, section, count)
    from relion_torch.alignment.core import ValidatedBackprojectorAdapter, _euler_matrix
    from relion_torch.alignment.preparation import ctf_rfft_batch
    from relion_torch.inference.alignment import AlignmentExpectation
    from relion_torch.reconstruction.reconstruct import ReconstructionOptions, reconstruct_backprojector
    from relion_torch.sampling.relion_sampling import relion_round
    device=torch.device(config.device if config.device!='cuda' or torch.cuda.is_available() else 'cpu')
    n,pixel=dataset.box_size,dataset.pixel_size
    resolve_reference_free_ini_high(config,n,pixel)
    value=config.initial_high_resolution
    initial_size=int(relion_round(n*pixel/value)) if value and value>0 else int(n*pixel/max(1,int(relion_round(.07*n))))
    initial_size=min(n,max(2,initial_size));initial_size-=initial_size%2
    label='RELION no-reference default' if config.initial_high_resolution_auto else 'explicit'
    print(f'Initial reference low-pass: {value:g} A ({label}); initial Fourier size={initial_size}; final reference box={n}')
    bps=ValidatedBackprojectorAdapter(config.number_of_classes,n,initial_size,config.padding_factor,device,reference_dim=2)
    noise=InitialNoiseAccumulator(dataset,device) if startup is not None else None
    diameter=config.particle_diameter_angstrom or ((n-config.mask_edge_pixels)*pixel)
    work=int(getattr(config,'preprocess_work_mib',256.)*1024**2)
    cache=int(getattr(config,'preprocess_cache_mib',32.)*1024**2)
    rand_max=32767. if __import__('sys').platform.startswith('win') else 2147483647.
    for indices,ft,geo in iter_initial_fourier_batches(dataset,device=device,batch_size=config.batch_size,
            particle_diameter=diameter,mask_edge_pixels=config.mask_edge_pixels,zero_mask=config.zero_mask,
            work_bytes=work,cache_bytes=cache,context=startup):
        if noise is not None:
            with section(startup,'noise_spectrum'):
                noise.add(ft,indices)
            count(startup,'noise_particles',len(indices))
        with section(startup,'reference_seed_metadata'):
            draws=[relion_c_random_values(config.random_seed+i,2) for i in indices]
            angles=torch.tensor([[0.,0.,d[0]/rand_max*360.] for d in draws],device=device,dtype=torch.float32)
            classes=np.asarray([min(config.number_of_classes-1,int(d[1]/rand_max*config.number_of_classes)) for d in draws])
        with section(startup,'ctf'):
            raw=ctf_rfft_batch([dataset.record(i) for i in indices],n,device,
                frequency_grid=geo.ctf_grid,phase_flipped_input=config.ctf_phase_flipped,
                only_flip_phases=config.only_flip_phases,intact_first_peak=config.intact_first_peak,
                max_work_bytes=work) if config.use_ctf else torch.ones_like(ft.real)
        with section(startup,'initial_backprojection'):
            from relion_torch.optics.aberrations import demodulate_records_
            # The initial noise estimator above keeps RELION's raw-spectrum
            # convention; only reference insertion consumes demodulated data.
            demodulate_records_([dataset.record(i) for i in indices], geo.ctf_grid, ft)
            transform=AlignmentExpectation._window_rfft(ft,initial_size)
            raw=AlignmentExpectation._window_rfft(raw,initial_size)
            numerator=transform*raw;weight=raw.square();rotations=_euler_matrix(angles)
            for c in np.unique(classes):
                selected=torch.tensor(np.flatnonzero(classes==c),device=device,dtype=torch.long)
                num=numerator.index_select(0,selected);den=weight.index_select(0,selected)
                bps.add(int(c),num,rotations.index_select(0,selected),torch.ones_like(den),den,
                    orientation_chunk_size=config.backprojector_chunk_size)
                count(startup,'initial_backprojector_calls')
            count(startup,'reference_particles',len(indices))
    if noise is not None:
        with section(startup,'noise_finalize'):
            startup.noise_spectra=noise.finish()
            startup.noise_group_ids=noise.groups
        count(startup,'shared_fourier_passes')
    output=[]
    with section(startup,'initial_reconstruction_and_write'):
        for c,bp in enumerate(bps.objects):
            if float(bp.denominator.sum())>0:
                image=reconstruct_backprojector(bp,ReconstructionOptions(tau2=None,
                    preweight_iterations=config.preweight_iterations,normalise=1.0)).map
            else:
                image=torch.zeros((n,n),device=device)
            output.append(_emit_reference(output_root,c+1,image,pixel,reference_collector))
    return output
