"""Bounded reduction of already-clamped Class2D residuals.

The destination dtype is caller-selected.  The optimized Class2D path uses
float32 to match the native RELION accelerator weight/statistic precision;
float64 remains available for regression comparisons.
"""
from __future__ import annotations

import torch


class ParticleNoiseAccumulator:
    """Reduce [row,pixel] residuals by particle, then by Fourier shell."""
    def __init__(self, destination: torch.Tensor, shell_indices: torch.Tensor,
                 *, max_pixel_bytes: int, allow_float32: bool = False):
        allowed = (torch.float64, torch.float32) if allow_float32 else (torch.float64,)
        if destination.ndim != 2 or destination.dtype not in allowed:
            raise ValueError("noise destination has an unsupported dtype")
        if shell_indices.ndim != 1 or shell_indices.dtype != torch.long:
            raise ValueError("shell_indices must be a one-dimensional int64 tensor")
        if shell_indices.device != destination.device:
            raise ValueError("noise and shell indices must be on the same device")
        self.destination = destination
        self.shell_indices = shell_indices
        size = destination.shape[0] * shell_indices.numel() * destination.element_size()
        self.uses_pixels = bool(size > 0 and size <= max(0, int(max_pixel_bytes)))
        self.reserved_bytes = size if self.uses_pixels else 0
        self.pixels = (destination.new_zeros((destination.shape[0], shell_indices.numel()))
                       if self.uses_pixels else None)
        self.finished = False

    def add(self, rows: torch.Tensor, residual: torch.Tensor) -> None:
        if self.finished:
            raise RuntimeError("cannot add residuals after finishing noise reduction")
        if residual.ndim != 2 or residual.shape != (rows.numel(), self.shell_indices.numel()):
            raise ValueError("residual must have shape [number_of_rows, active_pixels]")
        if residual.dtype != self.destination.dtype:
            raise ValueError("residual dtype must match noise destination dtype")
        if self.pixels is not None:
            self.pixels.index_add_(0, rows, residual)
        else:
            radial = self.destination.new_zeros((rows.numel(), self.destination.shape[1]))
            radial.scatter_add_(1, self.shell_indices[None].expand(rows.numel(), -1), residual)
            self.destination.index_add_(0, rows, radial)

    def finish(self) -> None:
        if not self.finished and self.pixels is not None:
            self.destination.scatter_add_(1, self.shell_indices[None].expand(self.destination.shape[0], -1),
                                          self.pixels)
            self.pixels = None
        self.finished = True
