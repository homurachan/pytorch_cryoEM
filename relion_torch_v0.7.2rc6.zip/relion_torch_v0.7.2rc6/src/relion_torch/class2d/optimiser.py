"""Class2D EM state machine using the shared validated Fourier kernels.

Large image/projection/backprojection tensors are complex64/float32. Small
posterior, class occupancy and correction statistics remain float64. Dense,
sparse-adaptive and fixed-pose searches feed the *same* moment accumulator.
"""
from __future__ import annotations
from relion_torch.geometry.grids import signed_fft_indices


from dataclasses import dataclass, asdict
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterator, Sequence
import json
import math
import os
import time
import warnings

import numpy as np
import pandas as pd
import torch

from relion_torch.alignment.core import (
    ReferenceProjector, ValidatedBackprojectorAdapter, ctf_rfft, prepare_particle,
    centered_rfft2, _euler_matrix, prepare_particle_batch, ctf_rfft_batch, ParticlePreparationCache,
)
from relion_torch.fourier.conventions import relion_soft_mask_outside_map
from relion_torch.alignment.model_statistics import (
    accumulate_scale_statistics_, add_high_resolution_power_, lowpass_model_spectra)
from relion_torch.inference.alignment import (
    AlignmentExpectation, AlignmentExpectationConfig, DenseBatchExpectation,
    SparseAdaptiveBatchExpectation, likelihood_rfft_mask, likelihood_inverse_noise, rounded_shell_indices_2d,
    phase_shift_rfft, relion_weight_selection_batch,
)
from relion_torch.io.mrc import write_mrc
from relion_torch.io.star import write_star
from relion_torch.optimiser.alignment import AlignmentConfig, AlignmentOptimiser
from .expectation import Class2DExpectation
from .performance import StageTimer, DetailTimer, class_selection_schedule
from .semantics import (
    Class2DSampling, class_translation_log_prior, update_group_scales,
    update_norm_corrections, solvent_mask, lowpass_reference, coarser_sampling,
    translation_prior_centres,
)


@dataclass
class Prepared:
    indices: list[int]
    groups: torch.Tensor
    like: torch.Tensor
    unmasked: torch.Tensor
    prediction: torch.Tensor
    numerator: torch.Tensor
    denominator: torch.Tensor
    sigma: torch.Tensor
    integer: torch.Tensor
    residual: torch.Tensor
    angles: torch.Tensor
    centres: torch.Tensor
    old_scales: torch.Tensor


@dataclass
class FixedResult:
    projections: torch.Tensor                 # [B,K,H,W]
    translations: torch.Tensor                # [B,1,2]
    angles: torch.Tensor                      # [B,3]
    posterior: torch.Tensor                   # [B,K]
    significant: torch.Tensor
    class_mass: torch.Tensor
    best_index: torch.Tensor
    pmax: torch.Tensor
    log_likelihood_contribution: torch.Tensor
    significant_count: torch.Tensor
    diff2: torch.Tensor
    log_prior: torch.Tensor


@dataclass
class Moments:
    backprojectors: ValidatedBackprojectorAdapter
    class_mass: torch.Tensor
    offset_sum: torch.Tensor
    offset_square: torch.Tensor
    noise: torch.Tensor                      # [B,S], before group reduction
    xa: torch.Tensor                         # [B]
    aa: torch.Tensor


def _jsonable(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


class Class2DOptimiser(AlignmentOptimiser):
    _defer_reference_output = True
    def __init__(self, config: AlignmentConfig, *, flatten_solvent=False,
                 class2d_config=None, initial_mode="supplied-k", generate_seeds=False,
                 checkpoint_state=None, dataset=None, startup=None, initial_references=None):
        if config.reference_dim != 2:
            raise ValueError("Class2DOptimiser requires reference_dim=2")
        self.options = class2d_config or SimpleNamespace()
        self._startup_checkpoint = checkpoint_state
        self._startup_context = startup
        self.flatten_solvent = bool(getattr(self.options, "flatten_solvent", flatten_solvent))
        self.initial_mode = initial_mode
        self.generate_seeds = bool(generate_seeds)
        self.use_ctf = bool(self.option("use_ctf", True))
        self.refs_are_ctf_corrected = bool(self.option("ctf_corrected_ref", True))
        self.do_norm = bool(self.option("do_norm_correction", False))
        self.do_scale = bool(self.option("do_scale_correction", False))
        self.avg_norm_correction = 1.0
        self.debug_dimensionally_consistent_prior = bool(self.option("debug_dimensionally_consistent_prior", False))
        self.translation_prior_normalization = self.option("translation_prior_normalization", "gpu")
        super().__init__(config, dataset=dataset, initial_references=initial_references)
        self._check_optics_capabilities()
        if len(self.group_ids) == 1:
            self.do_scale = False  # upstream disables a redundant one-group scale
        self.group_scales = torch.ones(len(self.group_ids), device=self.device, dtype=torch.float64)
        self.class_offsets = torch.zeros((len(self.references), 2), device=self.device, dtype=torch.float64)
        # pandas (notably Copy-on-Write/Arrow-backed columns) can expose a
        # read-only NumPy view. Own the host storage BEFORE the torch bridge;
        # .clone() after as_tensor() would be too late to avoid that warning.
        norm_column = self.dataset.particles.get(
            "rlnNormCorrection", pd.Series(np.ones(len(self.dataset))))
        norm_values = np.array(
            norm_column.to_numpy(dtype=np.float64, na_value=np.nan),
            dtype=np.float64, order="C", copy=True)
        self.norm_corrections = torch.as_tensor(
            norm_values, device=self.device, dtype=torch.float64)
        if self.do_norm and (not bool(torch.isfinite(self.norm_corrections).all()) or
                             bool((self.norm_corrections <= 0).any())):
            raise ValueError("all input rlnNormCorrection values must be positive and finite")
        self.ctf_premultiplied = bool(self.option("ctf_premultiplied", False))
        self.has_premultiplied = self.ctf_premultiplied or any(
            record.ctf_premultiplied for record in self.dataset._records)
        if self.has_premultiplied and not self.use_ctf:
            raise ValueError("CTF-premultiplied particles require --ctf")
        self.original_psi_step = self.sampling.actual_psi_step
        self.original_offset_step = self.sampling.offset_step
        self.original_offset_range = self.sampling.offset_range
        self.generator = np.random.default_rng(config.random_seed)
        self.last_completed_iteration = config.iteration_offset
        self._replace_sampling(self.original_psi_step, self.original_offset_step, q=0.0)
        self.sampling.advance(self.generator)   # sampling.initialise() reset
        self._solvent_mask = self._load_solvent_mask()
        self._lowpass_mask = self._load_optional_mask("lowpass_mask")
        self._second_mask = self._load_optional_mask("solvent_mask2")
        self._iteration_history = []
        self._subset_state = None
        if self.option('fast_subsets',False):
            from relion_torch.optimiser.subsets import FastSubsetState
            optics = self.dataset.particles['rlnOpticsGroup'].to_numpy(dtype=np.int64)
            self._subset_state = FastSubsetState(optics,config.random_seed,len(self.references),2)
        initial_lowpass = self.option("initial_high_resolution", None)
        if config.iteration_offset == 0 and initial_lowpass and initial_lowpass > 0:
            self._set_references([lowpass_reference(x, initial_lowpass, self.dataset.pixel_size)
                                  for x in self.references])
            self.tau2 = [self._reference_tau2(x) for x in self.references]
            self.data_vs_prior = [self._initial_data_vs_prior(c) for c in range(len(self.references))]
            self._refresh_fourier_sizes()

    def _check_optics_capabilities(self):
        """Odd/even aberrations are consumed by shared preparation/CTF code."""
        for _, row in self.dataset.optics.iterrows():
            mtf = str(row.get("rlnMtfFileName", "None"))
            if mtf not in ("None", "none", "nan", "?", ".", ""):
                raise NotImplementedError("Optics MTF correction is not implemented in Class2D yet")
            for label, neutral in (("rlnMagMat00",1.),("rlnMagMat11",1.),("rlnMagMat01",0.),("rlnMagMat10",0.)):
                if label in row and abs(float(row[label])-neutral)>1.e-12:
                    raise NotImplementedError(f"Non-trivial {label} observation correction is not implemented")

    def option(self, name, default=None):
        return getattr(self.options, name, default)

    def _optimized_execution(self):
        return self.option("performance_mode", "optimized") in ("optimized", "v029", "v028")

    def _candidate_execution(self):
        return self.option("performance_mode", "optimized") in ("optimized", "v029")

    def _batch_execution(self):
        return self.option("performance_mode", "optimized") == "optimized"

    def _shared_phase_execution(self):
        return self._batch_execution() and self.option("accumulation_mode", "auto") != "v029"

    def _streamlined_statistics(self):
        """Keep a local v0.2.11 numerical reference path for A/B checks."""
        return (self._shared_phase_execution() and
                self.option("accumulation_statistics", "optimized") == "optimized")

    def _statistics_dtype(self):
        return (torch.float32 if self.option("accumulation_precision", "float32") == "float32"
                else torch.float64)

    def _orientation_major_requested(self):
        layout = self.option("weighted_sum_layout", "auto")
        return (self._batch_execution()
                and self.option("accumulation_statistics", "optimized") == "optimized"
                and layout in ("auto", "orientation"))

    def _detail_start(self, name):
        timer = getattr(self, '_detail_timer', None)
        return timer.start(name) if timer is not None else None

    def _detail_stop(self, token):
        if token is not None:
            self._detail_timer.stop(token)

    def _candidate_work_bytes(self):
        return max(1, int(float(self.option("candidate_work_mib", 256.0)) * 1024**2))

    def _execution_cache_bytes(self):
        return max(0, int(float(self.option("performance_cache_mib", 256.0)) * 1024**2))

    def _parent_candidate_plan(self, orientation_children: int, translation_children: int):
        """Workspace limit for parent-major Class2D statistics.

        Shared by the legacy per-class compact scheduler and the v0.2.16
        cross-class sparse supertile fallback so both layouts obey the same
        candidate-work budget and numerical tensor shapes.
        """
        size = int(self.sizes.current_size)
        oc = max(1, int(orientation_children))
        tc = max(1, int(translation_children))
        budget = max(1, int(self._accum_workspace.tile_bytes) -
                     int(getattr(self, '_noise_pixel_reserve_bytes', 0)))
        per_parent = max(1, size*(size//2+1)*8*(tc+4*oc+10) + 256*oc*tc)
        tile = max(1, min(int(self.option('candidate_chunk_size',4096)),
                          budget//per_parent))
        return budget, per_parent, tile

    def _prepare_execution_scalars(self):
        # Immutable during an E-step; use the SAME Python-float normalization
        # as 0.2.7 without a GPU scalar read for every particle.
        self._perf_norm_values = None
        self._perf_prediction_scales = None
        if not self._optimized_execution():
            return
        if self.do_norm:
            self._perf_norm_values = self.norm_corrections.detach().cpu().tolist()
        if self.do_scale:
            values = self.group_scales.detach().cpu().tolist()
            scales = []
            for group, value in enumerate(values):
                scale = self.group_scales[group]
                if value < .001:
                    scale = torch.full_like(scale, .001)
                    value = .001
                if value > 10000 or not math.isfinite(value):
                    raise FloatingPointError("group scale exceeds RELION prediction bounds")
                scales.append(scale)
            self._perf_prediction_scales = scales
        else:
            scale = torch.ones((), device=self.device)
            self._perf_prediction_scales = [scale] * len(self.group_ids)

    def _backprojection_plan_for(self, result, backprojectors):
        if not self._optimized_execution() or isinstance(result, FixedResult):
            return None
        if getattr(self, '_perf_plan_owner', None) is backprojectors:
            return self._perf_plan
        self._perf_plan_owner = backprojectors
        self._perf_plan = None
        budget = self._execution_cache_bytes() // 2
        if budget <= 0:
            return None
        from relion_torch.fourier.backprojection_plan import BackprojectionPlan2D
        if isinstance(result, SparseAdaptiveBatchExpectation):
            table = self.sampling.fine_sampling_table(self.config.oversampling)
            angles = torch.as_tensor(table.orientation_angles, device=self.device,
                                     dtype=torch.float32).reshape(-1, 3)
        else:
            angles = result.bank.angles_deg
        self._perf_plan = BackprojectionPlan2D.build(
            backprojectors.objects[0], _euler_matrix(angles), self.sizes.current_size,
            max_bytes=budget, static_insert=self._candidate_execution())
        return self._perf_plan

    def _initial_noise(self):
        # A checkpoint already contains the E-step noise state; do not reread
        # every particle merely to overwrite a fresh noise estimate afterward.
        if self._startup_checkpoint is not None:
            values = self._startup_checkpoint["sigma2"]
            if self._startup_context is not None:
                self._startup_context.counters["noise_spectrum_from_checkpoint"] = 1
            if len(values) != len(self.group_ids):
                raise ValueError("checkpoint noise-group count differs from particle metadata")
            return [x.to(device=self.device,dtype=torch.float32).clone() for x in values]
        startup = self._startup_context
        if startup is not None and startup.noise_spectra is not None:
            if startup.noise_group_ids != self.group_ids:
                raise ValueError('initial shared noise groups differ from dataset')
            values = startup.noise_spectra
            startup.noise_spectra = None  # one-shot ownership transfer
            startup.counters['noise_spectrum_reused'] = 1
            return values
        if self.option('initialization_mode','batched') == 'batched':
            from relion_torch.alignment.initialization import initialize_noise_batched
            return initialize_noise_batched(self.dataset,device=self.device,batch_size=self.config.batch_size,
                particle_diameter=self.particle_diameter_angstrom,mask_edge_pixels=self.config.mask_edge_pixels,
                zero_mask=self.config.zero_mask,work_bytes=int(self.option('preprocess_work_mib',256.)*1024**2),
                cache_bytes=int(self.option('preprocess_cache_mib',32.)*1024**2),context=startup)
        if startup is not None:
            with startup.timer.section('legacy_noise_spectrum_pass'):
                return super()._initial_noise()
        return super()._initial_noise()


    def _replace_sampling(self, psi, offset_step, *, q):
        self.sampling = Class2DSampling(2, 0, float(psi), float(self.original_offset_range),
            float(offset_step), self.config.oversampling,
            float(self.option("perturbation_factor", 0.5)), float(q))

    def _raw_ctf(self,record,n,dtype):
        if not self.use_ctf:
            return torch.ones((n,n//2+1),device=self.device,dtype=dtype)
        return ctf_rfft(record,n,self.device,dtype,
            phase_flipped_input=bool(self.option("ctf_phase_flipped",False)),
            only_flip_phases=bool(self.option("only_flip_phases",False)),
            intact_first_peak=bool(self.option("intact_first_peak",False)))

    def _accuracy_ctf(self, record, n, dtype):
        raw = self._raw_ctf(record,n,dtype)
        # calculateExpectedAngularErrors() is a model-difference diagnostic:
        # upstream applies the physical CTF (twice for premultiplied data),
        # independently of the E-step's refs_are_ctf_corrected/scale switches.
        # Do not change _prepare(): its observation-model rules are different.
        return raw.square() if (self.ctf_premultiplied or record.ctf_premultiplied) else raw

    def _load_optional_mask(self, name):
        path = self.option(name, None)
        if path is None:
            return None
        import mrcfile
        with mrcfile.open(path, permissive=True) as handle:
            mask = torch.as_tensor(np.asarray(handle.data).copy(), device=self.device, dtype=torch.float32)
        if tuple(mask.shape) != tuple(self.references[0].shape):
            raise ValueError(f"{name}: mask shape does not match reference")
        if not bool(torch.isfinite(mask).all()) or bool(((mask < 0) | (mask > 1)).any()):
            raise ValueError(f"{name}: mask values must be in [0,1]")
        return mask

    def _load_solvent_mask(self):
        explicit = self._load_optional_mask("solvent_mask")
        if explicit is not None:
            return explicit
        return solvent_mask(self.dataset.box_size,
            self.particle_diameter_angstrom / (2*self.dataset.pixel_size),
            self.config.mask_edge_pixels, self.device)

    def _set_references(self, maps):
        self.references = [m.to(device=self.device, dtype=torch.float32) for m in maps]
        self.projectors = [ReferenceProjector(m, self.config.padding_factor,
                                             self.config.projector_backend,
                                             current_size=self.sizes.current_size) for m in self.references]

    def _prepare(self, indices, sigma_old, raw_images=None):
        if self._batch_execution() and self.option("batch_preprocess", True):
            return self._prepare_batch(indices, sigma_old, raw_images)
        return self._prepare_legacy(indices, sigma_old, raw_images)

    def _raw_ctf_batch(self,records,indices,n,dtype,**kwargs):
        return ctf_rfft_batch(records,n,self.device,dtype,**kwargs)

    def _prepare_batch(self, indices, sigma_old, raw_images=None):
        dt = getattr(self, '_detail_timer', None)
        counts = getattr(self, '_perf_counters', None)
        token = self._detail_start('prepare.metadata')
        records = [self.dataset.record(i) for i in indices]
        host_groups = [self.group_to_index[r.group_number] for r in records]
        groups = torch.tensor(host_groups, device=self.device, dtype=torch.long)
        sigma = torch.stack(sigma_old).index_select(0, groups)
        # One bulk metadata read outside the hot image loop, not B GPU scalars.
        norms = getattr(self, '_perf_norm_values', None)
        factors = None
        if self.do_norm:
            if norms is None:
                norms = self.norm_corrections.detach().cpu().tolist()
            factors = [self.avg_norm_correction / norms[i] for i in indices]
        if raw_images is None:
            raw_images = np.stack([self.dataset.load_image(i) for i in indices])
        cache_budget = max(0,int(float(self.option('preprocess_cache_mib',32.))*1024**2))
        cache = getattr(self, '_preparation_cache', None)
        if cache is None or cache.max_bytes != cache_budget:
            cache = self._preparation_cache = ParticlePreparationCache(cache_budget)
        self._detail_stop(token)
        work = max(1,int(float(self.option('preprocess_work_mib',256.))*1024**2))
        n,pixel = self.dataset.box_size,self.dataset.pixel_size
        like,unmasked,integer,residual = prepare_particle_batch(
            raw_images,records,particle_diameter=self.particle_diameter_angstrom,
            mask_edge_pixels=self.config.mask_edge_pixels,zero_mask=self.config.zero_mask,
            sigma2_by_shell=sigma,device=self.device,
            seed=self.config.random_seed + self.last_completed_iteration*max(1,len(self.dataset)),
            normalization_factors=factors,cache=cache,max_work_bytes=work,timer=dt,counters=counts)
        if self.use_ctf:
            geo=cache.get(n,pixel,self.particle_diameter_angstrom,self.config.mask_edge_pixels,self.device,torch.float32)
            raw=self._raw_ctf_batch(records,indices,n,like.real.dtype,frequency_grid=geo.ctf_grid,
                phase_flipped_input=bool(self.option('ctf_phase_flipped',False)),
                only_flip_phases=bool(self.option('only_flip_phases',False)),
                intact_first_peak=bool(self.option('intact_first_peak',False)),
                max_work_bytes=work,timer=dt,counters=counts,cache=cache)
        else:
            raw=torch.ones((len(indices),n,n//2+1),device=self.device,dtype=like.real.dtype)
        token = self._detail_start('prepare.observation_factors')
        cached = getattr(self, '_perf_prediction_scales', None)
        if cached is not None:
            scale = torch.stack(cached).index_select(0,groups)
        elif self.do_scale:
            values=self.group_scales.detach().cpu().tolist()
            if any(not math.isfinite(v) or v>10000 for v in values):
                raise FloatingPointError('group scale exceeds RELION prediction bounds')
            scale=self.group_scales.clamp_min(.001).index_select(0,groups)
        else:
            scale=torch.ones(len(indices),device=self.device)
        premul=torch.tensor([self.ctf_premultiplied or r.ctf_premultiplied for r in records],
                            device=self.device,dtype=torch.bool)[:,None,None]
        prediction=torch.where(premul,raw.square(),raw)
        if not self.refs_are_ctf_corrected:
            prediction=torch.ones_like(prediction)
        effscale=scale.to(like.real.dtype)[:,None,None]
        prediction=prediction*effscale
        effective=raw*effscale
        numerator=torch.where(premul,torch.ones_like(raw),effective)
        denominator=effective.square()
        integer=integer.to(torch.float32)
        centres, angles = self._observation_pose(records, indices, integer, pixel)
        self._detail_stop(token)
        return Prepared(list(indices),groups,like,unmasked,prediction,numerator,denominator,
                        sigma,integer,residual*pixel,angles,centres,scale)

    def _observation_pose(self, records, indices, integer, pixel):
        """Reference-dimensional hook for shared 2-D observation preparation."""
        centres = translation_prior_centres(integer,self.class_offsets,pixel,
            dimensionally_consistent=self.debug_dimensionally_consistent_prior)
        angles = torch.tensor([[0.,0.,r.psi] for r in records],device=self.device,dtype=torch.float32)
        return centres, angles

    def _prepare_legacy(self, indices, sigma_old, raw_images=None):
        fields = {key: [] for key in ("groups", "like", "unmasked", "prediction", "numerator",
                    "denominator", "sigma", "integer", "residual", "angles", "centres", "old_scales")}
        n, pixel = self.dataset.box_size, self.dataset.pixel_size
        for local_index, i in enumerate(indices):
            record = self.dataset.record(i)
            group = self.group_to_index[record.group_number]
            image = self.dataset.load_image(i) if raw_images is None else raw_images[local_index]
            if self.do_norm:
                host_norm = getattr(self, '_perf_norm_values', None)
                norm = host_norm[i] if host_norm is not None else float(self.norm_corrections[i])
                image = image * (self.avg_norm_correction / norm)
            like, unmasked, integer, residual = prepare_particle(
                image, record, particle_diameter=self.particle_diameter_angstrom,
                mask_edge_pixels=self.config.mask_edge_pixels, zero_mask=self.config.zero_mask,
                sigma2_by_shell=sigma_old[group], device=self.device,
                seed=self.config.random_seed + self.last_completed_iteration * max(1,len(self.dataset)))
            raw = self._raw_ctf(record,n,like.real.dtype)
            cached_scales = getattr(self, '_perf_prediction_scales', None)
            if cached_scales is not None:
                scale = cached_scales[group]
            else:
                scale = self.group_scales[group] if self.do_scale else torch.ones((), device=self.device)
                if float(scale) < 0.001:
                    scale = torch.full_like(scale, 0.001)  # upstream prediction-time guard
                if float(scale) > 10000 or not bool(torch.isfinite(scale)):
                    raise FloatingPointError("group scale exceeds RELION prediction bounds")
            premultiplied = self.ctf_premultiplied or record.ctf_premultiplied
            prediction = raw.square() if premultiplied else raw
            if not self.refs_are_ctf_corrected:
                prediction = torch.ones_like(prediction)
            prediction = prediction * scale.to(like.real.dtype)
            effective = raw * scale.to(like.real.dtype)
            numerator = torch.ones_like(raw) if premultiplied else effective
            denominator = effective.square()
            integer = integer.to(self.device, dtype=torch.float32)
            # This representation is for prior distances only. The actual
            # sampling/Fourier shifts remain in their existing physical units.
            centres = translation_prior_centres(integer[None], self.class_offsets,
                pixel, dimensionally_consistent=self.debug_dimensionally_consistent_prior)[0]
            values = (group, like, unmasked, prediction, numerator, denominator,
                      sigma_old[group], integer, residual.to(self.device) * pixel,
                      torch.tensor([0.,0.,record.psi],device=self.device), centres, scale)
            for key, value in zip(fields, values):
                fields[key].append(value)
        return Prepared(list(indices), **{
            key: torch.as_tensor(value, device=self.device, dtype=torch.long) if key == "groups"
                 else torch.stack(value).to(device=self.device)
            for key, value in fields.items()})

    def _make_engine(self, iteration):
        def project(c, angles, size):
            return self.projectors[int(c)](angles, int(size))
        project.source_cache_token = lambda: tuple(p.source_cache_token for p in self.projectors)
        engine = Class2DExpectation(self.sampling, self.sizes, project, self.class_prob,
            config=AlignmentExpectationConfig(adaptive_fraction=self.config.adaptive_fraction,
                firstiter_cc=self.config.firstiter_cc and iteration == 1,
                adaptive_oversampling=self.config.oversampling,
                sigma_offset_angstrom=self.sigma_offset_angstrom,
                chunk_size=self.config.orientation_chunk_size,
                cache_active_views=self._optimized_execution(),
                active_view_cache_bytes=self._execution_cache_bytes() // 2,
                fine_score_mode=self.option("fine_score_mode", "auto") if self._candidate_execution() else "sparse",
                candidate_chunk_size=int(self.option("candidate_chunk_size", 4096)) if self._candidate_execution() else 0,
                candidate_work_bytes=self._candidate_work_bytes(),
                weight_precision=self.option("weight_precision", "float32")),
            debug_dimensionally_consistent_prior=self.debug_dimensionally_consistent_prior,
            translation_prior_normalization=self.translation_prior_normalization)
        return engine

    def _allowed_classes(self, indices, iteration):
        if not self.generate_seeds:
            return None
        if self.config.firstiter_cc and iteration == 1:
            return torch.zeros(len(indices), device=self.device, dtype=torch.long)
        seed_iteration = 2 if self.config.firstiter_cc else 1
        if iteration != seed_iteration:
            return None
        from .initialise import relion_c_random_values
        # Native srand(seed+particle_position), rand()%K; independent of batch size.
        return torch.tensor([relion_c_random_values(self.config.random_seed + i, 1)[0] % len(self.references)
                             for i in indices], device=self.device, dtype=torch.long)

    def _fixed_expectation(self, prepared, engine):
        size, b, k = self.sizes.likelihood_image_size(True), len(prepared.indices), len(self.references)
        projected = torch.stack([p(prepared.angles, self.sizes.current_size) for p in self.projectors], dim=1)
        scoring_projected=(projected if size==self.sizes.current_size else
            torch.stack([p(prepared.angles,size) for p in self.projectors],dim=1))
        phase = phase_shift_rfft((size,size//2+1), prepared.residual/self.dataset.pixel_size,
                    self.device, torch.float32, original_size=self.dataset.box_size)
        x = engine._window_rfft(prepared.like, size) * phase
        pred = scoring_projected * engine._window_rfft(prepared.prediction, size)[:,None]
        active = likelihood_rfft_mask(size, self.sizes.likelihood_shell(True), self.device,
                                     firstiter_cc=engine.config.firstiter_cc)
        shell = rounded_shell_indices_2d(size,self.device)[active]
        inverse = likelihood_inverse_noise(prepared.sigma,shell,firstiter_cc=engine.config.firstiter_cc)
        highres, logsigma = engine._highres_terms_batch(prepared.like, prepared.sigma, self.sizes.current_shell)
        diff2 = .5 * ((pred[:,:,active]-x[:,None,active]).abs().square()*inverse[:,None]).sum(-1)
        diff2 = diff2 + highres[:,None]
        prior = class_translation_log_prior(prepared.residual[:,None], prepared.centres,
                    self.sigma_offset_angstrom, self.class_prob, engine.allowed_classes,
                    normalization=self.translation_prior_normalization).squeeze(-1)
        if engine.config.firstiter_cc:
            cross = (pred[:,:,active].conj()*x[:,None,active]).real.sum(-1)
            cc = cross / torch.sqrt((pred[:,:,active].abs().square().sum(-1)*
                  x[:,active].abs().square().sum(-1)[:,None]).clamp_min(1e-30))
            best = cc.masked_fill(~torch.isfinite(prior), -torch.inf).argmax(-1)
            weights = torch.zeros((b,k),device=self.device,dtype=torch.float64)
            weights.scatter_(1,best[:,None],1)
            significant=weights.bool()
            pmax=torch.ones(b,device=self.device,dtype=torch.float64)
            dll=cc.gather(1,best[:,None]).squeeze(1).to(torch.float64)
            count=torch.ones(b,device=self.device,dtype=torch.long)
        else:
            selection=engine._select_weights(prior,diff2,self.config.adaptive_fraction)
            weights,significant=selection.posterior64,selection.significant
            best,pmax=selection.best_index,selection.pmax
            dll=selection.log_evidence-logsigma.to(torch.float64)
            count=selection.reported_significant_count
        return FixedResult(projected,prepared.residual[:,None],prepared.angles,
            weights,significant,weights*significant,best,pmax,dll,count,diff2,prior)

    def _compact_candidate_tiles(self, result):
        """One compact D2H transfer, one CPU grouping, one H2D index buffer."""
        from .candidate_execution import compact_schedule_host, CompactCandidateSchedule
        outer = self._detail_start('accumulate.schedule')
        token = self._detail_start('accumulate.schedule.nonzero_filter')
        retained = result.retained_weights
        shape = tuple(map(int, result.coarse.significant.shape))
        b, k, o, t = shape
        # int32 is exact for normal batch grids; promote for huge dimensions.
        integer = torch.int32 if b*k*o*t <= np.iinfo(np.int32).max else torch.int64
        counts = torch.count_nonzero(retained.flatten(1), dim=1).to(integer)
        code = (((result.parent_particle_indices.to(integer)*k+
                  result.parent_class_indices.to(integer))*o+
                  result.parent_orientation_indices.to(integer))*t+
                  result.parent_translation_indices.to(integer))
        transfer = torch.stack((counts, code), dim=1)
        self._detail_stop(token)
        token = self._detail_start('accumulate.schedule.device_to_host')
        host = transfer.detach().cpu().numpy()
        self._detail_stop(token)
        del transfer, counts, code
        oc, tc = retained.shape[-2:]
        budget, per_parent, tile = self._parent_candidate_plan(oc, tc)
        token = self._detail_start('accumulate.schedule.cpu_grouping')
        diagnostics={}
        values, descriptors, count, merged = compact_schedule_host(host[:,1], host[:,0], shape, tile, oc,
            diagnostics=diagnostics, with_weights=(self._orientation_major_requested() or
                (self.option('accumulation_mode','auto')=='auto' and self.option('group_backprojection',True))))
        nonzero_children = int(host[:,0].sum(dtype=np.int64))
        transfer_bytes = host.nbytes
        del host
        self._detail_stop(token)
        token = self._detail_start('accumulate.schedule.index_to_device')
        flat = torch.as_tensor(values, dtype=torch.long, device=self.device)
        schedule = CompactCandidateSchedule(flat, count, descriptors, values.nbytes, merged)
        self._detail_stop(token)
        counters = getattr(self, '_perf_counters', None)
        if counters is not None:
            for name, value in dict(fine_nonzero_parents=count,
                fine_zero_parents_skipped=result.number_of_parents-count,
                fine_nonzero_children=nonzero_children, schedule_d2h_bytes=transfer_bytes,
                schedule_h2d_bytes=values.nbytes, schedule_tiles=len(descriptors),
                schedule_regular_layout_batches=diagnostics.get('regular_layout',0),
                schedule_premerge_tiles=merged, schedule_phase_tiles=len(descriptors)-merged).items():
                counters[name] = counters.get(name,0)+int(value)
            counters['schedule_regular_grid_peak_bytes']=max(counters.get('schedule_regular_grid_peak_bytes',0), diagnostics.get('regular_grid_buffer_bytes',0))
            counters.update(accumulation_tile_budget_bytes=budget, accumulation_bytes_per_parent=per_parent)
            for name, value in dict(accumulation_effective_chunk_max=tile,
                    accumulation_workspace_estimate_bytes=tile*per_parent).items():
                counters[name]=max(counters.get(name,0),int(value))
            counters['accumulation_minimum_workspace_over_budget']=counters.get('accumulation_minimum_workspace_over_budget',0)+int(per_parent>budget)
        self._detail_stop(outer)
        child_ids = torch.arange(oc, device=self.device)
        for ids, groups in schedule.tiles():
            rows = result.parent_particle_indices.index_select(0,ids)
            classes = result.parent_class_indices.index_select(0,ids)
            orientations = result.parent_orientation_indices.index_select(0,ids)
            translations = result.parent_translation_indices.index_select(0,ids)
            blocks = result.parent_projection_block_indices.index_select(0,ids)
            yield (rows, classes, result.child_angles_deg.index_select(0,ids),
                   result.projection_blocks.projections.index_select(0,blocks),
                   retained.index_select(0,ids), result.child_translations_angstrom.index_select(0,ids),
                   result.phase_factors.index_select(0,translations),
                   orientations[:,None]*oc+child_ids[None], groups)

    def _orientation_major_schedule(self, result, active_pixels, retained=None):
        """Dedicated Class2D orientation-major scheduler.

        Unlike the parent iterator, this transfers only compact integer parent
        metadata and plans work from the compressed orientation-row count. It
        never gathers parent-sized references, phase tensors, child angles or
        child translations before grouping.
        """
        if not (self._orientation_major_requested() and
                isinstance(result, SparseAdaptiveBatchExpectation) and
                self._shared_phase_execution() and
                self.option('candidate_schedule','grouped') == 'grouped'):
            return None, None
        from .orientation_wsum import (
            compact_orientation_schedule_dense_host,
            compact_sparse_parent_supertile_dense_host,
            estimate_orientation_major_cost_dense_host,
            plan_orientation_major_workspace,
        )
        retained = result.retained_weights if retained is None else retained
        shape = tuple(map(int, result.coarse.significant.shape))
        b, k, o, t = shape
        oc, tc = retained.shape[-2:]
        self._pending_sparse_parent_schedule = None
        total = max(1, self._accum_workspace.tile_bytes -
                    getattr(self, '_noise_pixel_reserve_bytes', 0))
        workspace = plan_orientation_major_workspace(
            total, size=self.sizes.current_size, active_pixels=int(active_pixels),
            orientation_children=int(oc), translation_slots=int(t*tc))
        counters = getattr(self, '_perf_counters', None)
        if counters is not None:
            counters.update(
                orientation_workspace_total_bytes=workspace.total_bytes,
                orientation_workspace_phase_basis_bytes=workspace.phase_basis_bytes,
                orientation_workspace_tile_bytes=workspace.tile_bytes,
                orientation_workspace_bytes_per_row=workspace.bytes_per_orientation,
                orientation_workspace_max_rows=workspace.max_orientation_rows,
                orientation_workspace_max_coarse_groups=workspace.max_coarse_groups,
            )
        outer = self._detail_start('accumulate.orientation_schedule')
        token = self._detail_start('accumulate.orientation_schedule.nonzero_filter')
        # Pack one dense coarse-grid marker: 0=not a coarse parent, 1=coarse
        # parent with no nonzero fine child, >1=1+nonzero child count.  This
        # replaces the v0.2.14 per-parent (count, code) D2H metadata stream.
        counts = torch.count_nonzero(retained.flatten(1), dim=1)
        max_children = int(oc*tc)
        marker_dtype = torch.uint8 if max_children < 255 else torch.int16
        marker = torch.zeros(b*k*o*t, device=self.device, dtype=marker_dtype)
        code = (((result.parent_particle_indices*k+result.parent_class_indices)*o+
                  result.parent_orientation_indices)*t+result.parent_translation_indices)
        marker.index_copy_(0, code.to(torch.long), (counts+1).to(marker_dtype))
        self._detail_stop(token)
        token = self._detail_start('accumulate.orientation_schedule.device_to_host')
        host_marker = marker.detach().cpu().numpy()
        self._detail_stop(token)
        del marker, counts, code
        token = self._detail_start('accumulate.orientation_schedule.group_and_index')
        force_orientation = (self.option('weighted_sum_layout','auto') == 'orientation')
        cost = estimate_orientation_major_cost_dense_host(
            host_marker, shape, translation_children=int(tc),
            force_orientation=force_orientation)
        if cost.use_orientation:
            schedule, cost = compact_orientation_schedule_dense_host(
                host_marker, shape, orientation_children=int(oc),
                translation_children=int(tc), max_coarse_groups=workspace.max_coarse_groups,
                device=self.device, force_orientation=force_orientation,
                precomputed_cost=cost)
        else:
            _budget, _per_parent, parent_tile = self._parent_candidate_plan(oc, tc)
            self._pending_sparse_parent_schedule = compact_sparse_parent_supertile_dense_host(
                host_marker, shape, children=int(oc), tile_size=parent_tile,
                device=self.device)
            schedule = None
        self._detail_stop(token)
        self._detail_stop(outer)
        if counters is not None:
            counters['orientation_cost_parent_rows'] = counters.get('orientation_cost_parent_rows',0) + int(cost.parent_rows)
            counters['orientation_cost_coarse_groups'] = counters.get('orientation_cost_coarse_groups',0) + int(cost.coarse_groups)
            counters['orientation_cost_parent_units_milli'] = counters.get('orientation_cost_parent_units_milli',0) + int(round(1000*cost.parent_units))
            counters['orientation_cost_orientation_units_milli'] = counters.get('orientation_cost_orientation_units_milli',0) + int(round(1000*cost.orientation_units)) if math.isfinite(cost.orientation_units) else counters.get('orientation_cost_orientation_units_milli',0)
            counters['orientation_cost_density_ppm_sum'] = counters.get('orientation_cost_density_ppm_sum',0) + int(round(1_000_000*cost.density))
            counters['orientation_cost_batches'] = counters.get('orientation_cost_batches',0) + 1
            if not cost.use_orientation:
                counters['orientation_cost_rejected_batches'] = counters.get('orientation_cost_rejected_batches',0) + 1
        if schedule is None:
            sparse = getattr(self, '_pending_sparse_parent_schedule', None)
            if counters is not None:
                counters['orientation_major_fallback_batches'] = counters.get(
                    'orientation_major_fallback_batches', 0) + 1
                if sparse is not None:
                    budget, per_parent, parent_tile = self._parent_candidate_plan(oc, tc)
                    counters['fine_nonzero_parents'] = counters.get('fine_nonzero_parents',0) + sparse.parent_count
                    counters['fine_zero_parents_skipped'] = counters.get('fine_zero_parents_skipped',0) + (
                        result.number_of_parents - sparse.parent_count)
                    counters['fine_nonzero_children'] = counters.get('fine_nonzero_children',0) + sparse.nonzero_children
                    counters['sparse_parent_supertile_batches'] = counters.get('sparse_parent_supertile_batches',0) + 1
                    counters['sparse_parent_supertiles'] = counters.get('sparse_parent_supertiles',0) + len(sparse.descriptors)
                    counters['sparse_parent_parent_rows'] = counters.get('sparse_parent_parent_rows',0) + sparse.parent_count
                    counters['sparse_parent_class_groups'] = counters.get('sparse_parent_class_groups',0) + sparse.class_groups
                    counters['sparse_parent_marker_d2h_bytes'] = counters.get('sparse_parent_marker_d2h_bytes',0) + int(host_marker.nbytes)
                    counters['sparse_parent_h2d_bytes'] = counters.get('sparse_parent_h2d_bytes',0) + sparse.h2d_bytes
                    counters['orientation_schedule_d2h_bytes'] = counters.get('orientation_schedule_d2h_bytes',0) + int(host_marker.nbytes)
                    counters['orientation_schedule_h2d_bytes'] = counters.get('orientation_schedule_h2d_bytes',0) + sparse.h2d_bytes
                    counters['sparse_parent_supertile_row_peak'] = max(
                        counters.get('sparse_parent_supertile_row_peak',0), sparse.row_peak)
                    counters['sparse_parent_supertile_tile_limit'] = max(
                        counters.get('sparse_parent_supertile_tile_limit',0), parent_tile)
                    counters['accumulation_tile_budget_bytes'] = budget
                    counters['accumulation_bytes_per_parent'] = per_parent
                    counters['accumulation_effective_chunk_max'] = max(
                        counters.get('accumulation_effective_chunk_max',0), parent_tile)
                    counters['accumulation_workspace_estimate_bytes'] = max(
                        counters.get('accumulation_workspace_estimate_bytes',0), parent_tile*per_parent)
                    counters['accumulation_minimum_workspace_over_budget'] = counters.get(
                        'accumulation_minimum_workspace_over_budget',0) + int(per_parent>budget)
                    # The dense orientation marker was already the only D2H
                    # schedule transfer; sparse fallback reuses it and sends
                    # only compact parent row IDs back to the GPU.
                    counters['schedule_h2d_bytes'] = counters.get('schedule_h2d_bytes',0) + sparse.h2d_bytes
                    counters['schedule_tiles'] = counters.get('schedule_tiles',0) + len(sparse.descriptors)
                    counters['schedule_phase_tiles'] = counters.get('schedule_phase_tiles',0) + len(sparse.descriptors)
            return None, workspace
        if counters is not None:
            counters['fine_nonzero_parents'] = counters.get('fine_nonzero_parents',0) + schedule.parent_count
            counters['fine_zero_parents_skipped'] = counters.get('fine_zero_parents_skipped',0) + (
                result.number_of_parents - schedule.parent_count)
            counters['fine_nonzero_children'] = counters.get('fine_nonzero_children',0) + schedule.nonzero_children
            counters['orientation_schedule_d2h_bytes'] = counters.get('orientation_schedule_d2h_bytes',0) + schedule.d2h_bytes
            counters['orientation_schedule_h2d_bytes'] = counters.get('orientation_schedule_h2d_bytes',0) + schedule.h2d_bytes
            counters['orientation_schedule_regular_layout_batches'] = counters.get(
                'orientation_schedule_regular_layout_batches',0) + schedule.regular_layout
            counters['orientation_schedule_regular_grid_peak_bytes'] = max(
                counters.get('orientation_schedule_regular_grid_peak_bytes',0),
                schedule.regular_grid_buffer_bytes)
            counters['orientation_major_supertiles'] = counters.get('orientation_major_supertiles',0) + len(schedule.descriptors)
        return schedule, workspace

    def _sparse_parent_supertile_tiles(self, result, schedule):
        """Materialise bounded Fourier tensors once for several tiny classes.

        This is the late-iteration fallback selected only after the orientation
        cost model rejects dense orientation-major execution.  The parent order
        matches the previous compact parent scheduler; only tile boundaries can
        cross class boundaries.
        """
        retained = result.retained_weights
        oc = int(retained.shape[-2])
        child_ids = torch.arange(oc, device=self.device)
        for supertile in schedule.tiles():
            ids = supertile.parent_ids.to(torch.long)
            rows = result.parent_particle_indices.index_select(0, ids)
            classes = result.parent_class_indices.index_select(0, ids)
            orientations = result.parent_orientation_indices.index_select(0, ids)
            translations = result.parent_translation_indices.index_select(0, ids)
            blocks = result.parent_projection_block_indices.index_select(0, ids)
            yield (
                rows, classes, result.child_angles_deg.index_select(0, ids),
                result.projection_blocks.projections.index_select(0, blocks),
                retained.index_select(0, ids),
                result.child_translations_angstrom.index_select(0, ids),
                result.phase_factors.index_select(0, translations),
                orientations[:, None] * oc + child_ids[None],
                list(supertile.class_groups),
            )

    def _candidate_tiles(self, result):
        """Prune only exact zero retained weights; retain original parent order.

        Bulk metadata reads are per particle batch. No CUDA masked_select,
        nonzero, unique or scalar transfer is performed inside the tile loop.
        """
        if (self._shared_phase_execution() and self.option('candidate_schedule','grouped') == 'grouped'):
            yield from self._compact_candidate_tiles(result)
            return
        from .candidate_execution import candidate_schedule, candidate_schedule_with_weights
        detail_token = self._detail_start('accumulate.schedule')
        retained = result.retained_weights
        counts = torch.count_nonzero(retained.flatten(1), dim=1).detach().cpu().numpy()
        keep_host = np.flatnonzero(counts).astype(np.int64, copy=False)
        keep = torch.as_tensor(keep_host, device=self.device, dtype=torch.long)
        counters = getattr(self, '_perf_counters', None)
        if counters is not None:
            for key, value in [('fine_nonzero_parents', len(keep_host)),
                               ('fine_zero_parents_skipped', result.number_of_parents-len(keep_host)),
                               ('fine_nonzero_children', int(counts.sum()))]:
                counters[key] = counters.get(key, 0) + int(value)
        if not len(keep_host):
            self._detail_stop(detail_token)
            return
        oc, tc = retained.shape[-2:]
        size = self.sizes.current_size
        coefficient_bytes = size * (size//2+1) * retained.element_size()*2
        budget = self._candidate_work_bytes() // (2 if self.option('group_backprojection', True) else 1)
        per_parent = max(1, coefficient_bytes * (3*tc + 6*oc + 12))
        if self._shared_phase_execution():
            budget = max(1, self._accum_workspace.tile_bytes -
                         getattr(self, '_noise_pixel_reserve_bytes', 0))
            # Fewer full-plane temporaries, with slack for active views and
            # bounded coalesced weight rectangles (density >= 1/4).
            per_parent = max(1, size*(size//2+1)*8*(tc+4*oc+10) + 256*oc*tc)
        if counters is not None:
            counters['accumulation_tile_budget_bytes'] = budget
            counters['accumulation_bytes_per_parent'] = per_parent
        tile = max(1, min(int(self.option('candidate_chunk_size', 4096)), budget//per_parent))
        if counters is not None:
            counters['accumulation_workspace_estimate_bytes'] = max(
                counters.get('accumulation_workspace_estimate_bytes', 0), tile*per_parent)
        with_weights = (self._shared_phase_execution() and (self._orientation_major_requested() or
                        (self.option('accumulation_mode','auto')=='auto' and self.option('group_backprojection',True))))
        if with_weights:
            metadata=torch.stack((result.parent_class_indices.index_select(0,keep),
                result.parent_orientation_indices.index_select(0,keep),
                result.parent_particle_indices.index_select(0,keep),
                result.parent_translation_indices.index_select(0,keep)),-1).cpu().numpy()
            schedule=candidate_schedule_with_weights(metadata[:,0],metadata[:,1],metadata[:,2],metadata[:,3],
                                                     tile,oc,self.device)
        else:
            metadata = torch.stack((result.parent_class_indices.index_select(0, keep),
                                    result.parent_orientation_indices.index_select(0, keep)), -1).cpu().numpy()
            schedule = candidate_schedule(metadata[:,0], metadata[:,1], tile, oc, self.device)
        if counters is not None:
            counters['accumulation_effective_chunk_max']=max(counters.get('accumulation_effective_chunk_max',0),tile)
            counters['accumulation_minimum_workspace_over_budget']=counters.get('accumulation_minimum_workspace_over_budget',0)+int(per_parent>budget)
        self._detail_stop(detail_token)
        child_ids = torch.arange(oc, device=self.device)
        for number, start in enumerate(range(0, len(keep_host), tile)):
            ids = keep[start:start+tile]
            rows = result.parent_particle_indices.index_select(0, ids)
            classes = result.parent_class_indices.index_select(0, ids)
            orientations = result.parent_orientation_indices.index_select(0, ids)
            translations = result.parent_translation_indices.index_select(0, ids)
            blocks = result.parent_projection_block_indices.index_select(0, ids)
            yield (rows, classes, result.child_angles_deg.index_select(0, ids),
                   result.projection_blocks.projections.index_select(0, blocks),
                   retained.index_select(0, ids), result.child_translations_angstrom.index_select(0, ids),
                   result.phase_factors.index_select(0, translations),
                   orientations[:,None]*oc + child_ids[None], schedule[number])

    def _tile_iterator(self, prepared, result):
        """Same row/orientation tiles as 0.2.7; cache, never regroup, their data.

        The last three fields are phase values, angular-table IDs and a stable
        class-selection schedule. The reference path leaves these empty.
        """
        if self._candidate_execution() and isinstance(result, SparseAdaptiveBatchExpectation):
            yield from self._candidate_tiles(result)
            return
        chunk = max(1, int(self.config.orientation_chunk_size))
        device = self.device
        size = self.sizes.current_size
        coefficient_bytes = size * (size // 2 + 1) * 8
        budget = max(1, 256 * 1024**2 - getattr(self, "_noise_pixel_reserve_bytes", 0))
        optimized = self._optimized_execution()
        def rows_per_tile(oc, tc):
            return max(1, min(chunk, budget // (coefficient_bytes * (3*tc+6*oc+12))))
        # Crucially, retained_weights is a property which MULTIPLIES arrays,
        # not a cheap field. Evaluate once, not once for every output tile.
        retained = result.retained_weights if optimized and not isinstance(result, FixedResult) else None
        if isinstance(result, SparseAdaptiveBatchExpectation):
            oc, tc = result.posterior.shape[-2:] if optimized else result.retained_weights.shape[-2:]
            tile = rows_per_tile(oc, tc)
            schedule = (class_selection_schedule(result.parent_class_indices.cpu().tolist(), tile, device)
                        if optimized else None)
            child_ids = torch.arange(oc, device=device)
            for number, start in enumerate(range(0, result.number_of_parents, tile)):
                sl = slice(start, start+tile)
                blocks = result.parent_projection_block_indices[sl]
                phase = result.phase_factors.index_select(0, result.parent_translation_indices[sl]) if optimized else None
                angular_ids = (result.parent_orientation_indices[sl, None] * oc + child_ids[None]) if optimized else None
                yield (result.parent_particle_indices[sl], result.parent_class_indices[sl],
                       result.child_angles_deg[sl], result.projection_blocks.projections[blocks],
                       retained[sl] if optimized else result.retained_weights[sl],
                       result.child_translations_angstrom[sl], phase, angular_ids,
                       schedule[number] if optimized else None)
        elif isinstance(result, DenseBatchExpectation):
            b, k, orientations, translations = result.posterior.shape
            ids = torch.arange(b*k, device=device)
            oc = min(chunk, orientations)
            tile = rows_per_tile(oc, translations)
            schedule = (class_selection_schedule([i % k for i in range(b*k)], tile, device)
                        if optimized else None)
            for number, start in enumerate(range(0, len(ids), tile)):
                idx = ids[start:start+tile]; rows = idx//k; classes = idx%k
                for first_o in range(0, orientations, oc):
                    sl = slice(first_o, first_o+oc)
                    angular_ids = (torch.arange(first_o, min(first_o+oc, orientations), device=device)
                                   [None].expand(len(idx),-1)) if optimized else None
                    phase = result.bank.phase_factors[None].expand(len(idx),-1,-1,-1) if optimized else None
                    yield (rows, classes,
                           result.bank.angles_deg[None,sl].expand(len(idx),-1,-1),
                           result.bank.projections[classes,sl],
                           retained[rows,classes,sl] if optimized else result.retained_weights[rows,classes,sl],
                           result.bank.translations_angstrom[None].expand(len(idx),-1,-1),
                           phase, angular_ids, ([(c, ix, tuple(range(first_o, min(first_o+oc, orientations))))
                                               for c, ix in schedule[number]]
                                              if self._candidate_execution() else schedule[number]) if optimized else None)
        else:
            b, k = result.posterior.shape
            ids = torch.arange(b*k, device=device)
            tile = rows_per_tile(1, 1)
            schedule = (class_selection_schedule([i % k for i in range(b*k)], tile, device)
                        if optimized else None)
            for number, start in enumerate(range(0, len(ids), tile)):
                idx = ids[start:start+tile]; rows = idx//k; classes = idx%k
                yield (rows,classes,result.angles[rows,None],result.projections[rows,classes,None],
                       result.class_mass[rows,classes,None,None].to(torch.float32),
                       result.translations[rows], None, None, schedule[number] if optimized else None)

    def _accumulate(self, prepared, result, backprojectors):
        b,k,n=len(prepared.indices),len(self.references),self.dataset.box_size
        s=self.sizes.current_size; ns=n//2+1
        # Fixed-pose diagnostics are not a hot adaptive path; retain their
        # historical double statistics for exact regression semantics.
        stat_dtype=(torch.float64 if isinstance(result,FixedResult) else self._statistics_dtype())
        noise=torch.zeros((b,ns),device=self.device,dtype=stat_dtype)
        xa=torch.zeros(b,device=self.device,dtype=stat_dtype);aa=torch.zeros_like(xa)
        offset_sum=torch.zeros((k,2),device=self.device,dtype=stat_dtype)
        offset_square=torch.zeros((),device=self.device,dtype=stat_dtype)
        shells=rounded_shell_indices_2d(s,self.device)
        ky=signed_fft_indices(s,device=self.device)
        active=(shells<=self.sizes.current_shell)&~((torch.arange(s//2+1,device=self.device)[None]==0)&(ky[:,None]<0))
        si=shells[active]; f=si.numel()
        active_indices = torch.nonzero(active.flatten(), as_tuple=False).squeeze(-1) if self._candidate_execution() else None
        like=AlignmentExpectation._window_rfft(prepared.like,s)
        unmasked=AlignmentExpectation._window_rfft(prepared.unmasked,s)
        pred_factor=AlignmentExpectation._window_rfft(prepared.prediction,s)
        num_factor=AlignmentExpectation._window_rfft(prepared.numerator,s)
        den_factor=AlignmentExpectation._window_rfft(prepared.denominator,s)
        sigma=prepared.sigma[:,shells.clamp_max(ns-1)]
        inv=torch.where(active[None]&(sigma>0),1/sigma,0)
        old_dvp=torch.stack(self.data_vs_prior)
        shared_phase = None
        plan = self._backprojection_plan_for(result, backprojectors)
        counters = getattr(self, '_perf_counters', None)
        grouper = None
        shared_phase_execution = self._shared_phase_execution()
        streamlined = self._streamlined_statistics()
        if self._candidate_execution() and self.option('group_backprojection', True) and not isinstance(result, FixedResult):
            from .candidate_execution import GroupedBackprojection2D, plan_candidate_workspace
            persistent = (shared_phase_execution and self.option('group_cache_scope','iteration')=='iteration'
                          and getattr(self,'_inside_run_iteration',False))
            existing=getattr(self,'_iteration_grouper',None) if persistent else None
            if existing is not None and existing.backprojectors is backprojectors:
                grouper=existing
            else:
                if isinstance(result, SparseAdaptiveBatchExpectation):
                    table = self.sampling.fine_sampling_table(self.config.oversampling)
                    all_angles = torch.as_tensor(table.orientation_angles, device=self.device, dtype=torch.float32).reshape(-1, 3)
                else:
                    all_angles = result.bank.angles_deg
                if shared_phase_execution:
                    self._accum_workspace=plan_candidate_workspace(self._candidate_work_bytes(),k,len(all_angles),s)
                    cache_bytes=self._accum_workspace.group_cache_bytes
                else:
                    cache_bytes=self._candidate_work_bytes()//2
                grouper = GroupedBackprojection2D(backprojectors, all_angles, plan,
                    max_bytes=cache_bytes,
                    orientation_chunk_size=self.config.backprojector_chunk_size, counters=counters)
                if persistent:
                    self._iteration_grouper=grouper
            if shared_phase_execution and counters is not None:
                wp=self._accum_workspace
                counters.update(group_cache_budget_bytes=wp.group_cache_bytes,
                    group_flush_reserve_bytes=wp.group_flush_reserve_bytes,
                    group_cache_class_capacity=wp.cached_class_capacity,
                    group_cache_full_class_resident=int(wp.cached_class_capacity >= k),
                    group_bytes_per_class=wp.bytes_per_class)
        elif shared_phase_execution:
            from .candidate_execution import plan_candidate_workspace
            self._accum_workspace=plan_candidate_workspace(self._candidate_work_bytes(),k,1,s,grouping=False)
        # v0.2.12: sum already-clamped residuals by particle/pixel, then
        # scatter to radial shells once per batch. Reserve from tile workspace;
        # if the pixel buffer would be large, retain per-parent radial reduction.
        from .accumulation_statistics import ParticleNoiseAccumulator
        available = (self._accum_workspace.tile_bytes if shared_phase_execution else 0)
        noise_accumulator = ParticleNoiseAccumulator(
            noise, si, max_pixel_bytes=min(32 * 1024**2, available // 8)
            if streamlined else 0, allow_float32=(stat_dtype == torch.float32))
        self._noise_pixel_reserve_bytes = noise_accumulator.reserved_bytes
        if counters is not None:
            counters['noise_pixel_buffer_peak_bytes'] = max(
                counters.get('noise_pixel_buffer_peak_bytes', 0), noise_accumulator.reserved_bytes)
            name = 'noise_particle_pixel_batches' if noise_accumulator.uses_pixels else 'noise_parent_radial_batches'
            counters[name] = counters.get(name, 0) + 1
        if shared_phase_execution:
            like_active_view=like.flatten(-2).index_select(-1,active_indices)
            pred_active_factor=pred_factor.flatten(-2).index_select(-1,active_indices)
        fine_translation_table = None
        fine_angle_table = None
        if self._orientation_major_requested() and isinstance(result, SparseAdaptiveBatchExpectation):
            fine_table = self.sampling.fine_sampling_table(self.config.oversampling)
            fine_translation_table = torch.as_tensor(
                fine_table.translations, device=self.device, dtype=torch.float32)
            fine_angle_table = torch.as_tensor(
                fine_table.orientation_angles, device=self.device, dtype=torch.float32).reshape(-1,3)
        if isinstance(result, DenseBatchExpectation) and not self._optimized_execution():
            shared_phase = phase_shift_rfft((s,s//2+1),result.bank.translations_angstrom/self.dataset.pixel_size,
                self.device,torch.float32,original_size=n)

        # v0.2.14: the Class2D orientation-major path has its own iterator and
        # compressed-row workspace. Crucially, it runs BEFORE _tile_iterator(),
        # so no parent-sized refs/phase/angle/translation Fourier tensors are
        # materialised merely to discard them after grouping.
        orientation_processed = False
        if (fine_translation_table is not None and
                isinstance(result, SparseAdaptiveBatchExpectation) and
                self._orientation_major_requested()):
            retained_orientation = result.retained_weights
            orientation_schedule, orientation_workspace = self._orientation_major_schedule(
                result, f, retained_orientation)
            if orientation_schedule is not None:
                from .orientation_wsum import (
                    build_orientation_major_phase_basis,
                    orientation_major_class_sums,
                )
                basis_token = self._detail_start('accumulate.orientation_basis')
                phase_basis = build_orientation_major_phase_basis(
                    result.phase_factors, fine_translation_table, active_indices)
                self._detail_stop(basis_token)
                if counters is not None:
                    counters['orientation_phase_basis_bytes'] = max(
                        counters.get('orientation_phase_basis_bytes',0),
                        phase_basis.matrix.numel()*phase_basis.matrix.element_size())
                token_major = self._detail_start('accumulate.orientation_major')
                for supertile in orientation_schedule.tiles():
                    ids = supertile.parent_ids.to(torch.long)
                    c = supertile.class_id
                    early_plan = supertile.build_plan(
                        result, retained_orientation.shape[-2])
                    weights_major = retained_orientation.index_select(0, ids).to(torch.float32)
                    # Only one representative reference per coarse
                    # particle/orientation group is gathered; parent-sized refs
                    # and cached phase tensors are never constructed.
                    representative_parent_ids = ids.index_select(0, early_plan.representatives)
                    representative_blocks = result.parent_projection_block_indices.index_select(
                        0, representative_parent_ids)
                    representative_refs = result.projection_blocks.projections.index_select(
                        0, representative_blocks)
                    reliable = (old_dvp[c,si] > 3.0) if self.do_scale else None
                    major = orientation_major_class_sums(
                        weights=weights_major,
                        plan=early_plan,
                        phase_basis=phase_basis,
                        representative_refs=representative_refs,
                        like_active=like_active_view,
                        unmasked=unmasked,
                        pred_active_factor=pred_active_factor,
                        num_factor=num_factor,
                        den_factor=den_factor,
                        inv=inv,
                        active_indices=active_indices,
                        integer_offsets=prepared.integer,
                        old_scales=prepared.old_scales,
                        class_offset=self.class_offsets[c],
                        reliable_shell_mask=reliable,
                        pixel_size=self.dataset.pixel_size,
                        dimensionally_consistent_prior=self.debug_dimensionally_consistent_prior,
                        statistics_dtype=stat_dtype,
                    )
                    token_noise=self._detail_start('accumulate.noise_pixel_add')
                    noise_accumulator.add(major.rows, major.residual)
                    self._detail_stop(token_noise)
                    if self.do_scale:
                        xa.index_add_(0, major.rows, major.xa)
                        aa.index_add_(0, major.rows, major.aa)
                    offset_sum[c].add_(major.offset_sum)
                    offset_square.add_(major.offset_square)
                    if counters is not None:
                        counters['accumulation_tiles'] += 1
                        counters['orientation_major_tiles']=counters.get('orientation_major_tiles',0)+1
                        counters['statistics_active_phase_tiles']=counters.get('statistics_active_phase_tiles',0)+1
                        counters['orientation_major_parent_rows']=counters.get('orientation_major_parent_rows',0)+major.parent_rows
                        counters['orientation_major_rows']=counters.get('orientation_major_rows',0)+major.orientation_rows
                        counters['orientation_major_translation_slots']=counters.get('orientation_major_translation_slots',0)+major.translation_slots
                        counters['orientation_major_gemm_calls']=counters.get('orientation_major_gemm_calls',0)+1
                        counters['orientation_major_gemm_rows']=counters.get('orientation_major_gemm_rows',0)+major.orientation_rows
                        counters['orientation_major_gemm_row_peak']=max(
                            counters.get('orientation_major_gemm_row_peak',0), major.orientation_rows)
                        counters['orientation_major_gemm_k']=phase_basis.translation_slots
                        counters['orientation_major_gemm_n']=phase_basis.matrix.shape[1]
                        counters['orientation_major_supertile_parent_peak']=max(
                            counters.get('orientation_major_supertile_parent_peak',0), major.parent_rows)
                        counters['orientation_major_supertile_row_peak']=max(
                            counters.get('orientation_major_supertile_row_peak',0), major.orientation_rows)
                        avoided=max(0,(major.parent_rows*weights_major.shape[1]-major.orientation_rows)*s*(s//2+1))
                        counters['statistics_full_phase_values_avoided']=counters.get('statistics_full_phase_values_avoided',0)+avoided
                        counters['premerged_parent_rows']=counters.get('premerged_parent_rows',0)+major.parent_rows
                        counters['premerged_particle_orientation_groups']=counters.get('premerged_particle_orientation_groups',0)+early_plan.groups
                        counters['premerged_tiles']=counters.get('premerged_tiles',0)+1
                        if self.do_scale:
                            counters['statistics_reused_scale_tiles']=counters.get('statistics_reused_scale_tiles',0)+1
                    if grouper is not None:
                        token_group=self._detail_start('accumulate.group_insert')
                        grouper.add(c, major.numerator, major.denominator,
                                    major.angular_ids, supertile.host_angular_ids)
                        self._detail_stop(token_group)
                    elif plan is not None:
                        if counters is not None:
                            counters['backprojector_calls'] += 1
                            counters['backprojected_orientation_rows'] = counters.get('backprojected_orientation_rows',0)+major.orientation_rows
                        plan.accumulate(backprojectors.objects[c], major.numerator,
                            major.denominator, major.angular_ids,
                            orientation_chunk_size=self.config.backprojector_chunk_size)
                    else:
                        if counters is not None:
                            counters['backprojector_calls'] += 1
                            counters['backprojected_orientation_rows'] = counters.get('backprojected_orientation_rows',0)+major.orientation_rows
                        mats=_euler_matrix(fine_angle_table.index_select(0,major.angular_ids))
                        backprojectors.add(c,major.numerator,mats,
                            torch.ones_like(major.denominator),major.denominator,
                            orientation_chunk_size=self.config.backprojector_chunk_size)
                self._detail_stop(token_major)
                orientation_processed = True

        sparse_parent_schedule = getattr(self, '_pending_sparse_parent_schedule', None)
        if orientation_processed:
            tile_iter = ()
        elif sparse_parent_schedule is not None:
            tile_iter = self._sparse_parent_supertile_tiles(result, sparse_parent_schedule)
        else:
            tile_iter = self._tile_iterator(prepared,result)
        for (rows,classes,angles,refs,weights,translations,cached_phase,angular_ids,class_groups
             ) in tile_iter:
            nt,oc,tc=weights.shape
            if counters is not None:
                counters['accumulation_tiles'] += 1
            # If the dedicated orientation-major scheduler rejected this
            # sparse batch, deliberately use the mature parent-major path.
            if self._orientation_major_requested() and counters is not None:
                counters['orientation_major_fallback_tiles']=counters.get(
                    'orientation_major_fallback_tiles',0)+1
            # Physical shifts always use the original image size, not the window size.
            phase = cached_phase
            if phase is None:
                phase = shared_phase[None].expand(nt,-1,-1,-1) if shared_phase is not None else phase_shift_rfft(
                    (s,s//2+1),translations.reshape(-1,2)/self.dataset.pixel_size,
                    self.device,torch.float32,original_size=n).reshape(nt,tc,s,s//2+1)
            detail_token=self._detail_start('accumulate.weighted_phase')
            w=weights.to(torch.float32)
            orient_mass=w.sum(-1)
            weighted_phase=None
            # A full weighted phase is unnecessary only when EVERY class
            # selection in this tile has its own early-weight plan. Mixed
            # tiles and all direct/fixed/dense paths retain the full plane.
            active_phase_only = bool(streamlined and grouper is not None and
                isinstance(result, SparseAdaptiveBatchExpectation) and
                class_groups and all(len(entry) > 3 and entry[3] is not None
                                     for entry in class_groups))
            if shared_phase_execution:
                phase_active=phase.flatten(-2).index_select(-1,active_indices)
                if active_phase_only:
                    phase_sum_active=self._batch_matrix_weighted_sum(w,phase_active)
                    xbar_active=like_active_view[rows,None]*phase_sum_active
                else:
                    weighted_phase=self._batch_matrix_weighted_sum(w,phase)
                    xbar=like[rows,None]*weighted_phase
                    xbar_active=xbar.flatten(-2).index_select(-1,active_indices)
                shifted_active=like_active_view[rows,None]*phase_active
                prediction_active=(refs.flatten(-2).index_select(-1,active_indices)*
                    pred_active_factor[rows,None])
                if counters is not None:
                    name = 'statistics_active_phase_tiles' if active_phase_only else 'statistics_full_phase_tiles'
                    counters[name] = counters.get(name, 0) + 1
                    if active_phase_only:
                        counters['statistics_full_phase_values_avoided'] = counters.get(
                            'statistics_full_phase_values_avoided', 0) + nt*oc*(s*(s//2+1)-f)
            else:
                shifted=like[rows,None]*phase
                unshifted=unmasked[rows,None]*phase
                xbar=self._batch_matrix_weighted_sum(w,shifted)
                ubar=self._batch_matrix_weighted_sum(w,unshifted)
                prediction=refs*pred_factor[rows,None]
                if active_indices is not None:
                    shifted_active = shifted.flatten(-2).index_select(-1, active_indices)
                    prediction_active = prediction.flatten(-2).index_select(-1, active_indices)
                    xbar_active = xbar.flatten(-2).index_select(-1, active_indices)
                else:
                    shifted_active, prediction_active, xbar_active = shifted[:,:,active], prediction[:,:,active], xbar[:,:,active]
            self._detail_stop(detail_token)
            detail_token=self._detail_start('accumulate.noise_scale')
            xpower=(w.sum(1)[...,None]*shifted_active.abs().square()).sum(1)
            # Reuse exactly the same FP32 expressions for both noise/scale;
            # no modulus-of-phase approximation and no moved clamp.
            power_by_o=orient_mass[...,None]*prediction_active.abs().square()
            cross_by_o=(prediction_active.conj()*xbar_active).real
            ppower=power_by_o.sum(1)
            cross=cross_by_o.sum(1)
            residual=(xpower+ppower-2*cross).clamp_min(0).to(stat_dtype)
            token_noise=self._detail_start('accumulate.noise_pixel_add')
            noise_accumulator.add(rows,residual)
            self._detail_stop(token_noise)
            if self.do_scale:
                reliable=old_dvp[classes[:,None],si[None]]>3.0
                if not streamlined:
                    # Literal v0.2.11 path for regression isolation.
                    cross_by_o=(prediction_active.conj()*xbar_active).real
                    power_by_o=orient_mass[...,None]*prediction_active.abs().square()
                elif counters is not None:
                    counters['statistics_reused_scale_tiles'] = counters.get('statistics_reused_scale_tiles',0)+1
                accumulate_scale_statistics_(xa,aa,rows,cross_by_o,power_by_o,reliable,prepared.old_scales[rows])
            self._detail_stop(detail_token)
            detail_token=self._detail_start('accumulate.offsets')
            absolute=translations.to(stat_dtype)+prepared.integer[rows,None].to(stat_dtype)*self.dataset.pixel_size
            translation_mass=w.to(stat_dtype).sum(1)
            offset_sum.index_add_(0,classes,(translation_mass[...,None]*absolute).sum(1))
            prior_centre = self.class_offsets[classes, None]
            if not self.debug_dimensionally_consistent_prior:
                prior_centre = prior_centre * self.dataset.pixel_size
            delta = absolute - prior_centre
            offset_square+=(translation_mass*delta.square().sum(-1)).sum()
            self._detail_stop(detail_token)
            detail_token=self._detail_start('accumulate.contributions_and_group')
            if not shared_phase_execution:
                numerator=ubar*(num_factor[rows]*inv[rows])[:,None]
                denominator=orient_mass[...,None,None]*(den_factor[rows]*inv[rows])[:,None]
            if class_groups is None:
                class_groups = [(c, classes == c) for c in torch.unique(classes).cpu().tolist()]
            for entry in class_groups:
                c, selected = entry[:2]
                early_plan=entry[3] if len(entry)>3 else None
                ids=None if angular_ids is None else angular_ids[selected].reshape(-1)
                if shared_phase_execution and early_plan is not None and grouper is not None:
                    from .candidate_execution import coalesced_weight_contributions
                    token_merge=self._detail_start('accumulate.premerge_weights')
                    num,den,ids=coalesced_weight_contributions(w[selected],early_plan,result.phase_factors,
                        unmasked,num_factor,den_factor,inv)
                    self._detail_stop(token_merge)
                    if counters is not None:
                        counters['premerged_parent_rows']=counters.get('premerged_parent_rows',0)+(nt if isinstance(selected,slice) else len(selected))
                        counters['premerged_particle_orientation_groups']=counters.get('premerged_particle_orientation_groups',0)+early_plan.groups
                        counters['premerged_tiles']=counters.get('premerged_tiles',0)+1
                elif shared_phase_execution:
                    rr=rows[selected]
                    u=unmasked[rr,None]*weighted_phase[selected]
                    num=(u*(num_factor[rr]*inv[rr])[:,None]).reshape(-1,s,s//2+1)
                    den=(orient_mass[selected,...,None,None]*(den_factor[rr]*inv[rr])[:,None]).reshape(-1,s,s//2+1)
                    if counters is not None:
                        counters['unmerged_parent_rows']=counters.get('unmerged_parent_rows',0)+num.shape[0]//oc
                else:
                    num = numerator[selected].reshape(-1,s,s//2+1)
                    den = denominator[selected].reshape(-1,s,s//2+1)
                if grouper is not None:
                    token_group=self._detail_start('accumulate.group_insert')
                    grouper.add(c, num, den, ids, entry[2])
                    self._detail_stop(token_group)
                    continue
                if counters is not None:
                    counters['backprojector_calls'] += 1
                    counters['backprojected_orientation_rows'] = counters.get('backprojected_orientation_rows', 0) + num.shape[0]
                if plan is not None:
                    plan.accumulate(backprojectors.objects[c], num, den,
                        angular_ids[selected].reshape(-1),
                        orientation_chunk_size=self.config.backprojector_chunk_size)
                else:
                    mats=_euler_matrix(angles[selected].reshape(-1,3))
                    backprojectors.add(c,num,mats,torch.ones_like(den),den,
                        orientation_chunk_size=self.config.backprojector_chunk_size)
            self._detail_stop(detail_token)
        if grouper is not None and grouper is not getattr(self,'_iteration_grouper',None):
            token=self._detail_start('accumulate.group_flush')
            grouper.finish()
            self._detail_stop(token)
        token=self._detail_start('accumulate.noise_radial_finalize')
        noise_accumulator.finish()
        self._detail_stop(token)
        self._noise_pixel_reserve_bytes = 0
        self._pending_sparse_parent_schedule = None
        token=self._detail_start('accumulate.high_resolution_power')
        # High-resolution particle-only power is added once per image (not per
        # retained class). Its denominator is still the retained group mass.
        add_high_resolution_power_(noise,prepared.like,self.sizes.current_size)
        self._detail_stop(token)
        # Keep the public/debug Moments interface in float64; all hot tile and
        # per-batch reductions above were already performed at stat_dtype.
        return Moments(backprojectors,result.class_mass.sum(0).to(torch.float64),
                       offset_sum.to(torch.float64),offset_square.to(torch.float64),
                       noise.to(torch.float64),xa.to(torch.float64),aa.to(torch.float64))

    def _model_blocks(self,*args,**kwargs):
        blocks=super()._model_blocks(*args,**kwargs)
        blocks["model_general"]["rlnNormCorrectionAverage"]=self.avg_norm_correction
        blocks["model_general"]["rlnDoCorrectCtf"]=int(self.use_ctf)
        blocks["model_general"]["rlnCtfCorrectedReference"]=int(self.refs_are_ctf_corrected)
        if hasattr(self,"group_scales"):
            blocks["model_groups"]["rlnGroupScaleCorrection"]=self.group_scales.cpu().numpy()
            blocks["model_classes"]["rlnClassPriorOffsetX"]=self.class_offsets[:,0].cpu().numpy()
            blocks["model_classes"]["rlnClassPriorOffsetY"]=self.class_offsets[:,1].cpu().numpy()
        return blocks

    def _postprocess_references(self,iteration,cc):
        maps=self.references
        ini=self.option("initial_high_resolution",None)
        if cc and ini and ini>0:
            maps=[lowpass_reference(x,ini,self.dataset.pixel_size) for x in maps]
            self.tau2,self.data_vs_prior=lowpass_model_spectra(
                self.tau2,self.data_vs_prior,original_size=self.dataset.box_size,
                pixel_size=self.dataset.pixel_size,resolution=ini)
        if cc and self.generate_seeds and len(maps)>1:
            maps=[maps[0].clone() for _ in maps]
            self.tau2=[self.tau2[0].clone() for _ in maps]
            self.data_vs_prior=[self.data_vs_prior[0].clone() for _ in maps]
            self.class_prob.fill_(1./len(maps))
        # Native Class2D writes an additional unmasked stack, overwritten each
        # iteration. The normal itNNN class stack contains solvent-flattened maps.
        from relion_torch.io.reference_output import write_reference_images
        token=self._detail_start('output.unmasked_stack')
        write_reference_images(maps, f"{self.config.output_root}_unmasked", reference_dim=2,
            pixel_size_angstrom=self.dataset.pixel_size, counters=getattr(self, '_perf_counters', None))
        self._detail_stop(token)
        if self.flatten_solvent:
            filtered=[]
            for image in maps:
                out=image*self._solvent_mask
                if self._lowpass_mask is not None:
                    res=self.option("solvent_lowpass_resolution",None)
                    if res is None or res<=0:
                        raise ValueError("a lowpass mask requires a positive lowpass resolution")
                    out=out+lowpass_reference(image*self._lowpass_mask,res,self.dataset.pixel_size)
                if self._second_mask is not None:
                    # inverse soft mask: user 1 marks solvent/replacement region
                    replacement=self._second_mask
                    total=replacement.sum()
                    average=(out*replacement).sum()/total if float(total)>0 else out.new_zeros(())
                    out=out*(1-replacement)+average*replacement
                filtered.append(out)
            maps=filtered
        self._set_references(maps)
        token=self._detail_start('output.class_stack')
        self._write_reference_maps(self.references, iteration)
        self._detail_stop(token)

    def _sampling_state(self):
        return dict(psi_step=self.sampling.actual_psi_step,offset_step=self.sampling.offset_step,
                    offset_range=self.sampling.offset_range,random_perturbation=self.sampling.random_perturbation,
                    original_psi_step=self.original_psi_step,original_offset_step=self.original_offset_step,
                    original_offset_range=self.original_offset_range)

    def _write_sampling(self,iteration):
        state=self._sampling_state()
        write_star({"sampling_general":pd.DataFrame([{
            "rlnIs3DSampling":0,"rlnIs3DTranslationalSampling":0,
            "rlnPsiStep":state["psi_step"],"rlnOffsetStep":state["offset_step"],
            "rlnOffsetRange":state["offset_range"],"rlnPsiStepOriginal":self.original_psi_step,
            "rlnOffsetStepOriginal":self.original_offset_step,"rlnOffsetRangeOriginal":self.original_offset_range,
            "rlnSamplingPerturbInstance":state["random_perturbation"],
            "rlnSamplingPerturbFactor":self.sampling.perturbation_factor}])},
            f"{self.config.output_root}_it{iteration:03d}_sampling.star")

    def save_checkpoint(self,iteration):
        root=f"{self.config.output_root}_it{iteration:03d}"
        config=asdict(self.options) if hasattr(self.options,"__dataclass_fields__") else vars(self.options)
        state={"format":"relion-torch-class2d-v1","iteration":iteration,
            "source_row_indices":torch.from_numpy(self.dataset.source_row_indices()),
            "subset_state": None if self._subset_state is None else self._subset_state.state_dict(),
            "options":_jsonable(config),"initial_mode":self.initial_mode,"generate_seeds":self.generate_seeds,
            "sampling":self._sampling_state(),"rng_state":_jsonable(self.generator.bit_generator.state),
            "refs_are_ctf_corrected":self.refs_are_ctf_corrected,
            "avg_norm_correction":self.avg_norm_correction,"sigma_offset":self.sigma_offset_angstrom,
            "class_prob":self.class_prob.cpu(),"class_offsets":self.class_offsets.cpu(),
            "norm_corrections":self.norm_corrections.cpu(),"group_scales":self.group_scales.cpu(),
            "sigma2":[x.cpu() for x in self.sigma2],"tau2":[x.cpu() for x in self.tau2],
            "sigma2_class":[x.cpu() for x in self.sigma2_class],
            "data_vs_prior":[x.cpu() for x in self.data_vs_prior],
            "fourier_coverage":[x.cpu() for x in self.fourier_coverage],
            "references":[x.cpu() for x in self.references], # masked working references
            "rotation_accuracy":self.rotation_accuracy_deg.cpu(),
            "translation_accuracy":self.translation_accuracy_angstrom.cpu(),
            "orientability":None if self.orientability_contrib is None else [x.cpu() for x in self.orientability_contrib],
            "working_psnr_shell":self.working_psnr_shell,"working_current_size":self.working_current_size,
            "history":self._iteration_history,
            "data_star":str(Path(root+"_data.star").resolve()),"model_star":str(Path(root+"_model.star").resolve())}
        destination=Path(root+"_state.pt");tmp=Path(str(destination)+".tmp")
        torch.save(state,tmp);os.replace(tmp,destination)
        write_star({"optimiser_general":pd.DataFrame([{
            "rlnCurrentIteration":iteration,"rlnModelStarFile":str(Path(root+"_model.star").resolve()),
            "rlnExperimentalDataStarFile":str(Path(root+"_data.star").resolve()),
            "rlnOrientSamplingStarFile":str(Path(root+"_sampling.star").resolve()),
            "rlnDoCorrectNorm":int(self.do_norm),"rlnDoCorrectScale":int(self.do_scale),
            "rlnDoCorrectCtf":int(self.use_ctf),"rlnRefsAreCtfCorrected":int(self.refs_are_ctf_corrected),
            "rlnDoSolventFlattening":int(self.flatten_solvent),"rlnDoFirstIterCC":int(self.config.firstiter_cc),
            "rlnDoGenerateSeeds":int(self.generate_seeds),"rlnAdaptiveOversampleOrder":self.config.oversampling,
            "rlnAdaptiveOversampleFraction":self.config.adaptive_fraction,"rlnRandomSeed":self.config.random_seed,
            "rlnParticleDiameter":self.particle_diameter_angstrom,"rlnWidthMaskEdge":self.config.mask_edge_pixels,
            "rlnMinResolutionMap":self.config.minres_map,"rlnDoSkipAlign":int(self.config.skip_align),
            "rlnDoZeroMask":int(self.config.zero_mask),
            "rlnCtfDataArePhaseFlipped":int(self.option("ctf_phase_flipped",False)),
            "rlnDoOnlyFlipCtfPhases":int(self.option("only_flip_phases",False)),
            "rlnDoIgnoreCtfUntilFirstPeak":int(self.option("intact_first_peak",False)),
            "rlnUseTooCoarseSampling":int(self.option("auto_sampling",False)),
            "rlnSolventMaskName":str(self.option("solvent_mask",None) or "None"),
            "rlnSolventMask2Name":str(self.option("solvent_mask2",None) or "None"),
            "rlnTorchDebugDimensionallyConsistentPrior":int(self.debug_dimensionally_consistent_prior),
            "rlnTorchTranslationPriorNormalization":self.translation_prior_normalization,
            "rlnDoFastSubsetOptimisation":int(bool(self.option("fast_subsets",False))),
            "rlnTorchCheckpoint":str(destination.resolve())}])},root+"_optimiser.star")

    def restore_checkpoint(self,state):
        if state.get("format")!="relion-torch-class2d-v1":
            raise ValueError("unsupported Class2D checkpoint schema")
        # v0.2.15 data STAR files are written in immutable source-row order.
        # If a future/internal execution path had reordered rows before the
        # checkpoint, remap per-particle tensors and fast-subset indices onto
        # that source-ordered continuation table. Older checkpoints simply use
        # their historical row order.
        source_rows = state.get("source_row_indices")
        particle_order = None
        subset_state = state.get('subset_state')
        if source_rows is not None:
            source_np=np.asarray(source_rows.cpu(),dtype=np.int64)
            if not np.array_equal(np.sort(source_np),np.arange(len(source_np),dtype=np.int64)):
                raise ValueError("checkpoint source-row mapping is not a permutation")
            particle_order=torch.as_tensor(np.argsort(source_np,kind='stable'),dtype=torch.long)
            if subset_state is not None:
                subset_state=dict(subset_state)
                old_order=np.asarray(subset_state['order'].cpu(),dtype=np.int64)
                old_optics=np.asarray(subset_state['optics'].cpu(),dtype=np.int64)
                subset_state['order']=torch.from_numpy(source_np[old_order].copy())
                subset_state['optics']=torch.from_numpy(old_optics[np.argsort(source_np,kind='stable')].copy())
        for name in ("class_prob","class_offsets","norm_corrections","group_scales"):
            value=state[name]
            if name == "norm_corrections" and particle_order is not None:
                value=value.index_select(0,particle_order)
            setattr(self,name,value.to(self.device,dtype=torch.float64))
        for name in ("sigma2","tau2","sigma2_class","data_vs_prior","fourier_coverage"):
            setattr(self,name,[x.to(self.device) for x in state[name]])
        self._set_references(state["references"])
        self.refs_are_ctf_corrected=bool(state["refs_are_ctf_corrected"])
        self.avg_norm_correction=float(state["avg_norm_correction"])
        self.sigma_offset_angstrom=float(state["sigma_offset"])
        self.generate_seeds=bool(state["generate_seeds"]);self.initial_mode=state["initial_mode"]
        self.last_completed_iteration=int(state["iteration"])
        if self._subset_state is not None:
            if subset_state is not None:
                self._subset_state.load_state_dict(subset_state)
                if self._subset_state.iteration != self.last_completed_iteration:
                    raise ValueError('checkpoint fast-subset iteration differs')
            else:
                warnings.warn('Enabling fast_subsets on a checkpoint without a saved permutation; replaying native seed/order rules only. Earlier full-data iterations are not changed.',RuntimeWarning)
                for completed in range(1,self.last_completed_iteration+1):
                    self._subset_state.select(completed)
        self.rotation_accuracy_deg=state["rotation_accuracy"].to(self.device)
        self.translation_accuracy_angstrom=state["translation_accuracy"].to(self.device)
        orientability = state.get("orientability")
        self.orientability_contrib = None if orientability is None else [x.to(self.device) for x in orientability]
        sm=state["sampling"]
        for name in ("original_psi_step","original_offset_step","original_offset_range"):
            setattr(self,name,float(sm[name]))
        self._replace_sampling(sm["psi_step"],sm["offset_step"],q=sm["random_perturbation"])
        self.generator.bit_generator.state=state["rng_state"]
        self._iteration_history=state.get("history",[])
        self.working_psnr_shell=state["working_psnr_shell"]
        self.working_current_size=state["working_current_size"]
        self._refresh_fourier_sizes()

    def _log_resolution(self, iteration: int, *, after_maximization: bool) -> dict:
        """Report SSNR resolution separately from the active Fourier support.

        After M-step ``working_psnr_shell`` is the updated value written as
        rlnCurrentResolution, while current_size still denotes this iteration's
        Fourier arrays. Neither is replaced by a per-class reporting cutoff.
        """
        from relion_torch.relion_statistics import shell_to_angstrom

        n, pixel = self.dataset.box_size, self.dataset.pixel_size
        current = shell_to_angstrom(n, pixel, self.working_psnr_shell)
        classes = [shell_to_angstrom(n, pixel, s) for s in self._class_resolution_shells()]
        stage = "after M-step" if after_maximization else "before E-step"
        class_text = ", ".join(f"{i + 1}={value:.6g} A" for i, value in enumerate(classes))
        print(f"  Current resolution ({stage}, iteration {iteration}): {current:.6g} A "
              f"(SSNR shell {self.working_psnr_shell}); class resolutions: {class_text}")
        if not after_maximization:
            fine = shell_to_angstrom(n, pixel, self.sizes.current_size // 2)
            coarse = shell_to_angstrom(n, pixel, self.sizes.coarse_size // 2)
            print(f"  Fourier support: current size={self.sizes.current_size} "
                  f"(nominal cutoff {fine:.6g} A); coarse size={self.sizes.coarse_size} "
                  f"(nominal cutoff {coarse:.6g} A); support cutoff is not an estimated resolution")
        return {"current_resolution_angstrom": current,
                "current_resolution_shell": int(self.working_psnr_shell),
                "class_estimated_resolution_angstrom": classes}

    @torch.no_grad()
    def run(self):
        root=Path(self.config.output_root);root.parent.mkdir(parents=True,exist_ok=True)
        pixel=self.dataset.pixel_size;n=self.dataset.box_size;ns=n//2+1;k=len(self.references)
        if self.config.write_initial_state:
            self._write_initial_state()
            self._write_sampling(0)
            self.save_checkpoint(0)
        if self._startup_context is not None:
            self._startup_context.finish(root,continued=self.config.iteration_offset>0)
        print(f"Class2D: init={self.initial_mode}; seeds={self.generate_seeds}; CTF={self.use_ctf}; "
              f"corrected-ref={self.refs_are_ctf_corrected}; norm={self.do_norm}; scale={self.do_scale}; "
              f"flatten_solvent={self.flatten_solvent}; firstiter_cc={self.config.firstiter_cc}")
        print("Translation prior: " +
              ("dimensionally-consistent (DEBUG)" if self.debug_dimensionally_consistent_prior else "RELION 3.1 native numeric coordinates") +
              f"; normalization={self.translation_prior_normalization}; Fourier shifts unchanged")
        start=self.config.iteration_offset+1
        full_shell=rounded_shell_indices_2d(n,self.device)
        fy=signed_fft_indices(n,device=self.device)
        unique=(full_shell<ns)&~((torch.arange(n//2+1,device=self.device)[None]==0)&(fy[:,None]<0))
        shell_counts=torch.bincount(full_shell[unique],minlength=ns).to(torch.float64)
        for iteration in range(start,start+self.config.iterations):
            packet=self.expectation_step(iteration)
            self.maximization_step(iteration,packet)
        return self.references

    @torch.no_grad()
    def expectation_step(self,iteration):
        from relion_torch.optimiser.subsets import FastSubsetState
        from relion_torch.inference.permanent_workers import accuracy,batches
        root=Path(self.config.output_root);pixel=self.dataset.pixel_size;n=self.dataset.box_size;ns=n//2+1;k=len(self.references)
        begun=time.perf_counter();cc=self.config.firstiter_cc and iteration==1
        print('=============================',flush=True)
        timer = StageTimer(self.option('timing', False), self.device)
        self._detail_timer=DetailTimer(timer.enabled,self.device,int(self.option('timing_detail_samples',32)))
        self._iteration_grouper=None
        self._inside_run_iteration=True
        if timer.enabled and self.device.type=='cuda':
            torch.cuda.reset_peak_memory_stats(self.device)
        self._perf_plan_owner = None
        self._perf_plan = None
        self._perf_counters = dict(batches=0, particles=0, coarse_hypotheses=0,
            fine_parents=0, fine_children=0, accumulation_tiles=0, backprojector_calls=0)
        selected_indices = getattr(self,'_distributed_selected',None)
        if self._subset_state is not None and not getattr(self,'_distributed_prepared',False):
            # Native STAR-only continuation cannot carry the saved permutation.
            while self._subset_state.iteration < iteration-1:
                self._subset_state.select(self._subset_state.iteration+1)
            selected_indices = timer.call('subset_selection',self._subset_state.select,iteration)
        active_count = len(self.dataset) if selected_indices is None else len(selected_indices)
        self._perf_counters.update(total_particles=len(self.dataset), selected_particles=active_count,
            fast_subsets=int(self._subset_state is not None))
        subset_info = dict(enabled=self._subset_state is not None, total=len(self.dataset),
            selected=active_count, fraction=active_count/len(self.dataset))
        if selected_indices is not None:
            subset_info['order_sha256']=FastSubsetState.digest(selected_indices)
            print(f'  fast_subsets: iteration={iteration}; selected={active_count}/{len(self.dataset)}; seed={self.config.random_seed}')
        self._prepare_execution_scalars()
        self._refresh_fourier_sizes()
        ini=self.option("initial_high_resolution",None)
        if ini and ini>0 and (iteration==1 or (iteration==2 and self.config.firstiter_cc)):
            self.psnr_shell=min(n//2-1,max(1,int(math.floor(n*pixel/ini+.5))))
            self.sizes=self._fourier_size_state()
        self.working_psnr_shell=self.psnr_shell;self.working_current_size=self.sizes.current_size
        sigma_old=[x.clone() for x in self.sigma2]
        current_tau=self._current_tau2();self.tau2=[x.clone() for x in current_tau]
        if not getattr(self,'_distributed_prepared',False) and not self.config.skip_align and not cc and not self.config.skip_expected_accuracy:
            timer.call('expected_accuracy',accuracy,self,sigma_old,particle_indices=selected_indices)
        if not getattr(self,'_distributed_prepared',False) and self.option("auto_sampling",False) and k>1 and not self.config.skip_align and not cc:
            useful=self.class_prob>=.01
            if bool(useful.any()):
                psi,step=coarser_sampling(float(self.rotation_accuracy_deg[useful].min()),
                    float(self.translation_accuracy_angstrom[useful].min()),self.config.oversampling,
                    self.original_psi_step,self.original_offset_step,self.original_offset_range)
                self._replace_sampling(psi,step,q=self.sampling.random_perturbation)
                self.sizes=self._fourier_size_state()
        if not self.config.skip_align and not getattr(self,'_distributed_prepared',False):
            self.sampling.advance(self.generator)
        from relion_torch.relion_statistics import shell_to_angstrom
        resolution=shell_to_angstrom(n,pixel,self.working_psnr_shell)
        print(f"Iteration {iteration}: {'CC' if cc else 'Gaussian'}; resolution={resolution:.4g} A; "
              f"coarse={self.sizes.coarse_size}; psi={self.sampling.actual_psi_step:g}; "
              f"offset_step={self.sampling.offset_step:g} A; q={self.sampling.random_perturbation:g}",flush=True)
        self._log_resolution(iteration, after_maximization=False)
        if getattr(self,'_permanent_pool',None) is not None:
            return self._permanent_pool.expectation(self,iteration,selected_indices,timer,begun)
        engine=self._make_engine(iteration)
        bank=None
        if not self.config.skip_align:
            bank=timer.call('coarse_projection_bank', engine.build_global_projection_bank, pixel_size=pixel,
                image_size=self.sizes.likelihood_image_size(self.config.oversampling==0),
                maximum_shell=self.sizes.likelihood_shell(self.config.oversampling==0))
        backprojectors=ValidatedBackprojectorAdapter(k,n,self.sizes.current_size,
                     self.config.padding_factor,self.device,reference_dim=2)
        run_stat_dtype=self._statistics_dtype()
        mass=torch.zeros(k,device=self.device,dtype=run_stat_dtype)
        offset_sum=torch.zeros((k,2),device=self.device,dtype=run_stat_dtype)
        offset_square=torch.zeros((),device=self.device,dtype=run_stat_dtype)
        group_mass=torch.zeros(len(self.group_ids),device=self.device,dtype=run_stat_dtype)
        noise_sum=torch.zeros((len(self.group_ids),ns),device=self.device,dtype=run_stat_dtype)
        group_xa=torch.zeros_like(group_mass);group_aa=torch.zeros_like(group_mass)
        norm_power=torch.zeros(len(self.dataset),device=self.device,dtype=run_stat_dtype)
        updated=self.dataset.particles.copy();dlls=[];pmaxs=[]
        for name in ("rlnAnglePsi","rlnOriginXAngst","rlnOriginYAngst",
                     "rlnLogLikeliContribution","rlnMaxValueProbDistribution"):
            updated[name]=updated[name].astype(float) if name in updated else np.zeros(len(updated),dtype=float)
        for indices, raw_images in timer.batches(batches(self,selected_indices)):
            self._perf_counters['batches'] += 1
            self._perf_counters['particles'] += len(indices)
            first = indices[0]
            prepared=timer.call('prepare_particles', self._prepare, indices,sigma_old,raw_images)
            engine.allowed_classes=self._allowed_classes(indices,iteration)
            if self.config.skip_align:
                result=timer.call('fixed_expectation', self._fixed_expectation, prepared,engine)
                best=result.best_index;angles=prepared.angles;translation=prepared.residual
            else:
                coarse=timer.call('coarse_expectation', engine.run_global_batch, prepared.like,prepared.prediction,prepared.sigma,
                    offset_prior_angstrom=prepared.centres,orientation_prior_deg=None,pixel_size=pixel,bank=bank)
                self._perf_counters['coarse_hypotheses'] += coarse.diff2.numel()
                if self.config.oversampling>0:
                    result=timer.call('fine_expectation', engine.run_sparse_adaptive_batch, prepared.like,prepared.prediction,prepared.sigma,
                        offset_prior_angstrom=prepared.centres,orientation_prior_deg=None,pixel_size=pixel,coarse=coarse)
                    self._perf_counters['fine_parents'] += result.number_of_parents
                    self._perf_counters['fine_children'] += result.diff2.numel()
                    for key, value in (result.execution_stats or {}).items():
                        if key.endswith('_bytes'):
                            self._perf_counters[key] = max(self._perf_counters.get(key, 0), int(value))
                        else:
                            self._perf_counters[key] = self._perf_counters.get(key, 0) + int(value)
                    best,angles,translation,_=result.best_values()
                else:
                    result=coarse;best,orientation,t=result.decode_flat_indices()
                    angles=bank.angles_deg[orientation];translation=bank.translations_angstrom[t]
            result=engine.for_weighted_sums(result,pixel_size=pixel)
            moments=timer.call('accumulate', self._accumulate, prepared,result,backprojectors)
            mass+=moments.class_mass.to(run_stat_dtype)
            offset_sum+=moments.offset_sum.to(run_stat_dtype)
            offset_square+=moments.offset_square.to(run_stat_dtype)
            retained=result.class_mass.sum(1).to(run_stat_dtype)
            group_mass.index_add_(0,prepared.groups,retained)
            noise_sum.index_add_(0,prepared.groups,moments.noise.to(run_stat_dtype))
            group_xa.index_add_(0,prepared.groups,moments.xa.to(run_stat_dtype))
            group_aa.index_add_(0,prepared.groups,moments.aa.to(run_stat_dtype))
            norm_power[indices]=moments.noise.sum(1).to(run_stat_dtype)
            origin=prepared.integer*pixel+translation
            detail_token=self._detail_start('output.batch_metadata')
            updated.loc[indices,"rlnClassNumber"]=best.cpu().numpy()+1
            updated.loc[indices,"rlnAnglePsi"]=angles[:,2].cpu().numpy()
            updated.loc[indices,"rlnOriginXAngst"]=origin[:,0].cpu().numpy()
            updated.loc[indices,"rlnOriginYAngst"]=origin[:,1].cpu().numpy()
            updated.loc[indices,"rlnLogLikeliContribution"]=result.log_likelihood_contribution.cpu().numpy()
            updated.loc[indices,"rlnMaxValueProbDistribution"]=result.pmax.cpu().numpy()
            updated.loc[indices,"rlnNrOfSignificantSamples"]=result.significant_count.cpu().numpy()
            self._detail_stop(detail_token)
            dlls.append(result.log_likelihood_contribution);pmaxs.append(result.pmax)
            if self.config.write_debug:
                debug={"particle_indices":indices,"diff2":result.diff2.cpu(),"log_prior":result.log_prior.cpu(),
                       "posterior":result.posterior.cpu(),"significant":result.significant.cpu(),
                       "class_mass":result.class_mass.cpu(),"pmax":result.pmax.cpu(),
                       "dll":result.log_likelihood_contribution.cpu()}
                if isinstance(result,SparseAdaptiveBatchExpectation):
                    for field in ("parent_particle_indices","parent_class_indices","parent_orientation_indices",
                                  "parent_translation_indices","child_angles_deg","child_translations_angstrom"):
                        debug[field]=getattr(result,field).cpu()
                    debug["coarse_diff2"]=result.coarse.diff2.cpu()
                    debug["coarse_log_prior"]=result.coarse.log_prior.cpu()
                torch.save(debug,f"{root}_it{iteration:03d}_batch{first:08d}_debug.pt")
        if getattr(self,'_distributed_prepared',False):
            selected_indices=self._processed_indices;active_count=len(selected_indices)
        # Flush before inspecting grids or performing M-step/checkpointing.
        if self._iteration_grouper is not None:
            timer.call('flush_grouped_backprojection',self._iteration_grouper.finish)
            self._iteration_grouper=None
        self._inside_run_iteration=False
        # The scalar snapshots are valid only while the E-step state is
        # frozen. Do not expose stale values to post-run/debug _prepare().
        self._perf_norm_values = None
        self._perf_prediction_scales = None
        total=float(mass.sum())
        if (total<=0 or not math.isfinite(total)) and not getattr(self,'_distributed_prepared',False):
            raise FloatingPointError("iteration has no finite retained posterior mass")
        if self.config.write_debug and not getattr(self,'_distributed_prepared',False):
            for c,bp in enumerate(backprojectors.objects):
                torch.save({"numerator":bp.numerator.cpu(),"denominator":bp.denominator.cpu(),
                    "tau2":current_tau[c].cpu(),"class_mass":mass[c].cpu(),
                    "sigma2_old":[x.cpu() for x in sigma_old],"minres_map":self.config.minres_map,
                    "tau2_fudge":self.config.tau2_fudge,"preweight_iterations":self.config.preweight_iterations,
                    "current_size":self.sizes.current_size},f"{root}_it{iteration:03d}_class{c+1:03d}_wsums.pt")
        return dict(mass=mass,offset_sum=offset_sum,offset_square=offset_square,group_mass=group_mass,noise_sum=noise_sum,group_xa=group_xa,group_aa=group_aa,norm_power=norm_power,updated=updated,dlls=dlls,pmaxs=pmaxs,current_tau=current_tau,selected_indices=selected_indices,active_count=active_count,subset_info=subset_info,ini=ini,cc=cc,begun=begun,total=total,backprojectors=backprojectors,timer=timer,active_view_peak_bytes=engine._active_view_peak_bytes)

    @torch.no_grad()
    def maximization_step(self,iteration,packet):
        if getattr(self,'_permanent_pool',None) is not None:
            return self._permanent_pool.maximization(self,iteration,packet)
        root=Path(self.config.output_root);pixel=self.dataset.pixel_size;n=self.dataset.box_size;ns=n//2+1;k=len(self.references)
        mass=packet['mass']
        offset_sum=packet['offset_sum']
        offset_square=packet['offset_square']
        group_mass=packet['group_mass']
        noise_sum=packet['noise_sum']
        group_xa=packet['group_xa']
        group_aa=packet['group_aa']
        norm_power=packet['norm_power']
        updated=packet['updated']
        dlls=packet['dlls']
        pmaxs=packet['pmaxs']
        current_tau=packet['current_tau']
        selected_indices=packet['selected_indices']
        active_count=packet['active_count']
        subset_info=packet['subset_info']
        ini=packet['ini']
        cc=packet['cc']
        begun=packet['begun']
        total=packet['total']
        backprojectors=packet['backprojectors']
        timer=packet['timer']
        full_shell=rounded_shell_indices_2d(n,self.device);fy=signed_fft_indices(n,device=self.device)
        unique=(full_shell<ns)&~((torch.arange(n//2+1,device=self.device)[None]==0)&(fy[:,None]<0))
        shell_counts=torch.bincount(full_shell[unique],minlength=ns).to(torch.float64)
        # Preserve the shared old-probability/denominator/empty-class lifecycle.
        timer.call('reconstruct_and_model', self._finish_maximization,
            backprojectors,mass.to(torch.float64),torch.zeros((k,1),device=self.device),iteration,current_tau)
        self.class_offsets=torch.where(
            mass[:,None]>0, offset_sum.to(torch.float64)/total,
            torch.zeros((k,2),device=self.device,dtype=torch.float64))
        self.sigma_offset_angstrom=math.sqrt(max(0.,float(offset_square)/(2*total)))
        if self.do_norm:
            if selected_indices is not None and active_count < len(self.dataset):
                selected_tensor=torch.as_tensor(selected_indices,device=self.device,dtype=torch.long)
                norms,avg=update_norm_corrections(self.norm_corrections.index_select(0,selected_tensor),
                    self.avg_norm_correction,norm_power.index_select(0,selected_tensor).to(torch.float64),total)
                # Unvisited particle metadata/norms must remain untouched.
                self.norm_corrections.index_copy_(0,selected_tensor,norms)
                self.avg_norm_correction=avg
            else:
                self.norm_corrections,self.avg_norm_correction=update_norm_corrections(
                    self.norm_corrections,self.avg_norm_correction,norm_power.to(torch.float64),total)
            updated["rlnNormCorrection"]=self.norm_corrections.cpu().numpy()
            if bool((self.norm_corrections>10).any()):
                warnings.warn("Particle norm correction exceeds 10; verify normalized input particles, "
                              "class occupancy and reference intensity scale (no artificial clipping applied).",RuntimeWarning)
        if self.do_scale and not cc:
            self.group_scales=update_group_scales(
                group_xa.to(torch.float64),group_aa.to(torch.float64),self.group_particle_counts)
        if not cc:
            for g in range(len(self.group_ids)):
                if float(noise_sum[g].sum())==0 or float(group_mass[g])<=0:
                    continue
                spectrum=noise_sum[g].to(torch.float64)/(2*group_mass[g].to(torch.float64)*shell_counts.clamp_min(1))
                if self.has_premultiplied:
                    spectrum=spectrum.clamp_min(1e-15)
                for shell in range(1,ns):
                    spectrum[shell]=torch.where(spectrum[shell]<1e-14,spectrum[shell-1],spectrum[shell])
                self.sigma2[g]=spectrum.to(torch.float32)
        if self.use_ctf:
            self.refs_are_ctf_corrected=True
        timer.call('postprocess_references', self._postprocess_references, iteration,cc)
        # upstream iterate(): updateCurrentResolution AFTER maximization,
        # before writing; current_size still denotes this iteration's array.
        self.working_psnr_shell=self._safe_psnr_shell(self.data_vs_prior)
        if cc and ini and ini>0:
            self.working_psnr_shell=min(n//2-1,max(1,int(math.floor(n*pixel/ini+.5))))
        detail_token=self._detail_start('output.star_and_records')
        write_particles = self.dataset.particles_in_source_order(updated)
        write_star({"optics":self.dataset.optics,"particles":write_particles},f"{root}_it{iteration:03d}_data.star")
        self._perf_counters['output_source_order_rows'] = len(write_particles)
        self._perf_counters['output_source_order_restored'] = int(
            not np.array_equal(
                self.dataset.source_row_indices(),
                np.arange(len(self.dataset),dtype=np.int64)))
        self.dataset.replace_particles(updated)
        ll=float(torch.cat(dlls).sum())/(total if cc else 1.)
        pmax=float(torch.cat(pmaxs).sum())/total
        paths=self._reference_image_names(iteration)
        model_token=self._detail_start('output.model_star_once')
        write_star(self._model_blocks(paths,log_likelihood=ll,average_pmax=pmax),f"{root}_it{iteration:03d}_model.star")
        self._detail_stop(model_token)
        self._perf_counters['model_star_writes'] = 1
        self._perf_counters['model_star_readbacks'] = 0
        self._detail_stop(detail_token)
        self.last_completed_iteration=iteration
        self._write_sampling(iteration)
        self._log_resolution(iteration, after_maximization=True)
        self._iteration_history.append({"iteration":iteration,"LL":ll,"Pmax":pmax,
            "class_probability":self.class_prob.cpu().tolist(),"sampling":self._sampling_state(),
            "current_size":self.sizes.current_size,"subset":subset_info,"elapsed_seconds":time.perf_counter()-begun})
        detail_token=self._detail_start('output.checkpoint')
        self.save_checkpoint(iteration)
        self._detail_stop(detail_token)
        details=self._detail_timer.report()
        elapsed = time.perf_counter() - begun
        plan = self._perf_plan
        self._perf_counters['geometry_cache_bytes'] = plan.byte_size if plan is not None else 0
        self._perf_counters['geometry_cached_calls'] = plan.calls if plan is not None else 0
        self._perf_counters['geometry_cached_orientations'] = plan.inserted_orientations if plan is not None else 0
        self._perf_counters['geometry_singleton_fallbacks'] = plan.singleton_fallbacks if plan is not None else 0
        self._perf_counters['geometry_static_calls'] = plan.static_calls if plan is not None else 0
        self._perf_counters['current_fourier_size'] = self.working_current_size
        self._perf_counters['candidate_chunk_size'] = int(self.option('candidate_chunk_size', 4096))
        self._perf_counters['active_view_peak_bytes'] = packet['active_view_peak_bytes']
        memory={}
        if timer.enabled and self.device.type=='cuda':
            memory=dict(cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(self.device),
                cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved(self.device),
                cuda_allocated_bytes=torch.cuda.memory_allocated(self.device),
                cuda_reserved_bytes=torch.cuda.memory_reserved(self.device))
        timer.write(root, iteration=iteration, total_seconds=elapsed,
                    counters=self._perf_counters, mode=self.option('performance_mode', 'optimized'),
                    details=details,memory=memory,subset=subset_info)
        print(f"  LL={ll:.8g}; average Pmax={pmax:.6g}; class mass={mass.cpu().tolist()}")
        print(f"  Iteration elapsed: {elapsed:.3f} s; performance={self.option('performance_mode', 'optimized')}")
        # Do not retain K old accumulators or the geometry table at the
        # next iteration's reconstruction/allocation boundary.
        self._perf_plan_owner = None
        self._perf_plan = None
        del plan
        return self.references
