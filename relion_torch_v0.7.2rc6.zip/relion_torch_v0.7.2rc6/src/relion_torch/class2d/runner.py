"""High-level Class2D orchestration."""
from __future__ import annotations

from dataclasses import dataclass, fields, asdict, replace
import json
from pathlib import Path
from typing import Sequence

from relion_torch.class2d.initialise import (
    generate_initial_references,
    particle_locators,
    prepare_supplied_references,
    prepare_relion_references,
)
from relion_torch.class2d.optimiser import Class2DOptimiser
from relion_torch.class2d.state import ContinuationState, discover_continuation, install_state
from relion_torch.optimiser.alignment import AlignmentConfig
from relion_torch.version import __version__


@dataclass(slots=True)
class Class2DConfig:
    input_star: Path
    output_root: Path
    number_of_classes: int
    references: tuple[Path, ...] = ()
    iterations: int = 25
    device: str = "cuda"
    devices: str = ""
    worker_threads: int = 1
    worker_chunk_size: int = 256
    batch_size: int = 8
    preread_images: bool = False
    io_batch_size: int = 256
    pool_size: int | None = None
    max_open_stacks: int = 8
    particle_io: str = "read"
    preread_max_gib: float | None = None
    psi_step_deg: float = 12.0
    offset_range_pixels: float = 5.0
    offset_step_pixels: float = 1.0
    oversampling: int = 1
    adaptive_fraction: float = 0.999
    skip_align: bool = False
    firstiter_cc: bool = True
    particle_diameter_angstrom: float | None = None
    mask_edge_pixels: float = 5.0
    zero_mask: bool = True
    tau2_fudge: float = 2.0
    padding_factor: float = 2.0
    preweight_iterations: int = 10
    random_seed: int = 0
    orientation_chunk_size: int = 256
    backprojector_chunk_size: int = 128
    skip_expected_accuracy: bool = False
    expected_accuracy_trials: int = 10
    init_mode: str = "relion"
    init_subset_size: int = 64
    use_input_alignment_for_init: bool = False
    continue_from: Path | None = None
    flatten_solvent: bool = False
    do_norm_correction: bool = False
    do_scale_correction: bool = False
    auto_sampling: bool = False
    write_debug: bool = False
    use_ctf: bool = False
    ctf_corrected_ref: bool = False
    ctf_premultiplied: bool = False
    reference_stack: bool = False
    perturbation_factor: float = 0.5
    initial_high_resolution: float | None = None
    initial_high_resolution_auto: bool = False
    minres_map: int = 5
    solvent_mask: Path | None = None
    solvent_mask2: Path | None = None
    lowpass_mask: Path | None = None
    solvent_lowpass_resolution: float | None = None
    current_size: int | None = None
    strict_highres_angstrom: float | None = None
    gpu_psi_grid: bool = False
    ctf_phase_flipped: bool = False
    only_flip_phases: bool = False
    intact_first_peak: bool = False
    debug_dimensionally_consistent_prior: bool = False
    translation_prior_normalization: str = "gpu"
    performance_mode: str = "optimized"
    performance_cache_mib: float = 256.0
    timing: bool = False
    # Execution layout only; no change to the coarse/fine sampling or priors.
    candidate_chunk_size: int = 4096
    candidate_work_mib: float = 256.0
    fine_score_mode: str = "auto"
    group_backprojection: bool = True
    batch_preprocess: bool = True
    preprocess_work_mib: float = 256.0
    preprocess_cache_mib: float = 32.0
    accumulation_mode: str = "auto"   # auto: bounded early weight coalescing
    group_cache_scope: str = "iteration"
    timing_detail_samples: int = 32
    accumulation_statistics: str = "optimized"
    weighted_sum_layout: str = "auto"  # auto: orientation-major when dense, parent fallback
    weight_precision: str = "float32"   # RELION accelerator-compatible hypothesis weights
    accumulation_precision: str = "float32"
    candidate_schedule: str = "grouped"
    initialization_mode: str = "batched"
    # None preserves a checkpoint option; new runs resolve None to False.
    fast_subsets: bool | None = None


@dataclass(slots=True, frozen=True)
class Class2DResult:
    output_root: Path
    input_star: Path
    references: tuple[str | Path, ...]
    start_iteration: int
    final_iteration: int
    class_stacks: tuple[Path, ...]
    manifest: Path


def _input_pixel_size(star_path: Path) -> float:
    optics, particles, _ = particle_locators(star_path)
    for table in (optics, particles):
        if table is None:
            continue
        for label in ("rlnImagePixelSize", "_rlnImagePixelSize", "rlnPixelSize", "_rlnPixelSize"):
            if label in table and len(table[label]):
                value = float(table[label].iloc[0])
                if value > 0:
                    return value
    raise ValueError("Unable to determine particle pixel size")


def _validate(config: Class2DConfig) -> None:
    from relion_torch.io.particle_store import ParticleIOOptions
    ParticleIOOptions.from_config(config).validate(config.batch_size)
    import math
    if config.performance_mode not in ("optimized", "v029", "v028", "reference"):
        raise ValueError("--performance-mode must be optimized, v029, v028 or reference")
    if not math.isfinite(config.performance_cache_mib) or config.performance_cache_mib < 0:
        raise ValueError("--performance-cache-mib must be finite and non-negative")
    if config.candidate_chunk_size < 1:
        raise ValueError("--candidate-chunk-size must be positive")
    if not math.isfinite(config.candidate_work_mib) or config.candidate_work_mib <= 0:
        raise ValueError("--candidate-work-mib must be positive and finite")
    if config.fine_score_mode not in ("auto", "sparse", "dense"):
        raise ValueError("--fine-score-mode must be auto, sparse or dense")
    if config.accumulation_mode not in ("auto", "phase", "v029"):
        raise ValueError("--accumulation-mode must be auto, phase or v029")
    if config.accumulation_statistics not in ('optimized', 'v0211'):
        raise ValueError('--accumulation-statistics must be optimized or v0211')
    if config.weighted_sum_layout not in ('auto', 'orientation', 'parent'):
        raise ValueError('--weighted-sum-layout must be auto, orientation or parent')
    if config.weight_precision not in ('float32', 'float64'):
        raise ValueError('--weight-precision must be float32 or float64')
    if config.accumulation_precision not in ('float32', 'float64'):
        raise ValueError('--accumulation-precision must be float32 or float64')
    if config.group_cache_scope not in ("batch", "iteration"):
        raise ValueError("--group-cache-scope must be batch or iteration")
    if not math.isfinite(config.preprocess_work_mib) or config.preprocess_work_mib <= 0:
        raise ValueError("--preprocess-work-mib must be positive and finite")
    if not math.isfinite(config.preprocess_cache_mib) or config.preprocess_cache_mib < 0:
        raise ValueError("--preprocess-cache-mib must be nonnegative and finite")
    if config.timing_detail_samples < 0:
        raise ValueError("--timing-detail-samples must be nonnegative")
    if config.candidate_schedule not in ('grouped','v0210'):
        raise ValueError('--candidate-schedule must be grouped or v0210')
    if config.initialization_mode not in ('batched','legacy'):
        raise ValueError('--initialization-mode must be batched or legacy')
    if config.fast_subsets and config.continue_from is None and config.iterations < 20:
        raise ValueError('RELION --fast_subsets requires at least 20 total iterations')
    if config.number_of_classes < 1:
        raise ValueError("--K must be positive")
    if config.iterations < 1:
        raise ValueError("--iter must be positive")
    if config.oversampling < 0:
        raise ValueError("--oversampling must be non-negative")
    if not 0.0 < config.adaptive_fraction <= 1.0:
        raise ValueError("--adaptive-fraction must lie in (0,1]")
    if not 0 <= config.perturbation_factor <= 1:
        raise ValueError("--perturb must be in [0,1]")
    if config.batch_size < 1 or config.orientation_chunk_size < 1 or config.backprojector_chunk_size < 1:
        raise ValueError("batch and chunk sizes must be positive")
    if config.translation_prior_normalization not in ("gpu", "cpu"):
        raise ValueError("--translation-prior-normalization must be gpu or cpu")
    if config.minres_map < 0:
        raise ValueError("--minres-map must be non-negative")
    if config.ctf_premultiplied and not config.use_ctf:
        raise ValueError("--ctf-premultiplied requires --ctf")


def _alignment_config(
    config: Class2DConfig,
    input_star: Path,
    references: Sequence[Path],
    start_iteration: int,
) -> AlignmentConfig:
    return AlignmentConfig(
        input_star=input_star,
        references=list(references),
        output_root=config.output_root,
        iterations=config.iterations,
        device=config.device,
        batch_size=config.batch_size,
        preread_images=config.preread_images, io_batch_size=config.io_batch_size,
        pool_size=config.pool_size, max_open_stacks=config.max_open_stacks,
        particle_io=config.particle_io, preread_max_gib=config.preread_max_gib,
        reference_dim=2,
        healpix_order=0,
        psi_step=config.psi_step_deg,
        offset_range_angstrom=config.offset_range_pixels,
        offset_step_angstrom=config.offset_step_pixels,
        offset_values_are_angstrom=False,
        oversampling=0 if config.skip_align else config.oversampling,
        adaptive_fraction=config.adaptive_fraction,
        skip_align=config.skip_align,
        skip_rotate=False,
        skip_maximize=False,
        firstiter_cc=config.firstiter_cc,
        particle_diameter=config.particle_diameter_angstrom,
        mask_edge_pixels=config.mask_edge_pixels,
        zero_mask=config.zero_mask,
        tau2_fudge=config.tau2_fudge,
        padding_factor=config.padding_factor,
        minres_map=config.minres_map,
        current_size=config.current_size,
        strict_highres_angstrom=config.strict_highres_angstrom,
        preweight_iterations=config.preweight_iterations,
        random_seed=config.random_seed,
        orientation_chunk_size=config.orientation_chunk_size,
        backprojector_chunk_size=config.backprojector_chunk_size,
        skip_expected_accuracy=config.skip_expected_accuracy or config.skip_align,
        expected_accuracy_trials=config.expected_accuracy_trials,
        write_debug=config.write_debug,
        iteration_offset=start_iteration,
        write_initial_state=start_iteration == 0,
    )


def _load_saved_state(path):
    import torch
    from relion_torch.io.star import read_star
    supplied = Path(path).expanduser().resolve()
    if supplied.name.endswith("_optimiser.star") and supplied.is_file():
        blocks = read_star(supplied)
        for frame in blocks.values():
            if "rlnTorchCheckpoint" in frame:
                supplied = Path(str(frame["rlnTorchCheckpoint"].iloc[0]))
                break
    if supplied.name.endswith("_model.star"):
        supplied = Path(str(supplied).replace("_model.star", "_state.pt"))
    if not supplied.is_file() and not supplied.suffix:
        candidates = sorted(supplied.parent.glob(supplied.name + "_it*_state.pt"))
        if candidates:
            supplied = candidates[-1]
    if supplied.is_file() and supplied.name.endswith("_state.pt"):
        state = torch.load(supplied, map_location="cpu", weights_only=True)
        if not isinstance(state, dict) or state.get("format") != "relion-torch-class2d-v1":
            raise ValueError("Invalid Class2D checkpoint format")
        return state
    return None


def run_class2d(config: Class2DConfig) -> Class2DResult:
    from relion_torch.inference.permanent_workers import devices
    if config.worker_threads<1 or config.worker_chunk_size<1:raise ValueError("Worker threads and chunk size must be positive")
    if devices(config):config=replace(config,device="cpu")
    from contextlib import ExitStack
    with ExitStack() as resources:
        return _run_class2d(config, resources)


def _run_class2d(config: Class2DConfig, resources) -> Class2DResult:
    from relion_torch.alignment.core import AlignmentDataset
    dataset = None
    import torch
    import warnings
    from relion_torch.io.mrc import write_mrc
    from relion_torch.io.star import read_star
    output_root = Path(config.output_root).expanduser().resolve()
    output_root.parent.mkdir(parents=True, exist_ok=True)
    from .performance import StartupContext
    startup_device = config.device if config.device != 'cuda' or torch.cuda.is_available() else 'cpu'
    startup = StartupContext(config.timing, startup_device)
    def open_dataset(cfg, *, preserve_noise_groups=False):
        with startup.timer.section('dataset_open_and_preread'):
            return AlignmentDataset.from_config(cfg, preserve_noise_groups=preserve_noise_groups,
                                                shared_preread=bool(config.devices))
    continuation = None
    initial_references = None
    reference_collector = None
    with startup.timer.section('load_checkpoint'):
        saved = _load_saved_state(config.continue_from) if config.continue_from is not None else None
    if saved is not None:
        # Restore all scientific options; only execution settings and the number
        # of ADDITIONAL iterations come from the continuation invocation.
        previous = saved["options"]
        if "translation_prior_normalization" not in previous:
            warnings.warn("Continuing a pre-0.2.4 checkpoint with the corrected native RELION 3.1 "
                          "prior (GPU normalization by default). Its previous iterations used the "
                          "0.2.3 prior and cannot be reproduced by this continuation. For a clean "
                          "parity test start a new run from the supplied references.", RuntimeWarning)
        known = {f.name for f in fields(Class2DConfig)}
        values = {key: value for key, value in previous.items() if key in known}
        for key in ("devices", "worker_threads", "worker_chunk_size", "output_root", "device", "batch_size", "orientation_chunk_size",
                    "backprojector_chunk_size", "iterations", "write_debug", "continue_from",
                    "preread_images", "io_batch_size", "pool_size", "max_open_stacks",
                    "particle_io", "preread_max_gib", "performance_mode",
                    "performance_cache_mib", "timing", "candidate_chunk_size",
                    "candidate_work_mib", "fine_score_mode", "group_backprojection",
                    "batch_preprocess", "preprocess_work_mib", "preprocess_cache_mib",
                    "accumulation_mode", "group_cache_scope", "timing_detail_samples",
                    "candidate_schedule", "initialization_mode", "accumulation_statistics"):
            values[key] = getattr(config, key)
        for key in ("debug_dimensionally_consistent_prior", "translation_prior_normalization"):
            values.setdefault(key, getattr(config, key))
        values['fast_subsets'] = (previous.get('fast_subsets',False) if config.fast_subsets is None
                                  else bool(config.fast_subsets))
        config = Class2DConfig(**values)
        input_star = Path(saved["data_star"])
        start_iteration = int(saved["iteration"])
        from relion_torch.io.reference_output import write_reference_images
        initial_references = saved["references"]
        references = write_reference_images(initial_references, f"{output_root}_continue",
            reference_dim=2, pixel_size_angstrom=_input_pixel_size(input_star))
        mode, seeds, reconstructed = saved["initial_mode"], saved["generate_seeds"], False
    elif config.continue_from is not None:
        # Legacy/native STAR continuation: consume the optimiser file when it
        # exists, rather than silently resetting its observation-model state.
        from .state import read_native_optimiser_options
        config, model_path = read_native_optimiser_options(config)
        continuation = discover_continuation(model_path, output_root)
        input_star, references = continuation.data_star, continuation.references
        start_iteration = continuation.iteration
        mode, seeds, reconstructed = "model-star-continuation", False, False
        warnings.warn("STAR-only continuation cannot restore the exact RNG stream; use this version's _state.pt or _optimiser.star for exact continuation.", RuntimeWarning)
    else:
        input_star = Path(config.input_star).expanduser().resolve()
        start_iteration = 0
        config.input_star = input_star
        config.fast_subsets = bool(config.fast_subsets)
        if config.random_seed == -1:
            import time
            config.random_seed = int(time.time()) & 0x7fffffff
        if config.fast_subsets and config.random_seed < 0:
            raise ValueError('fast-subset seed must be -1, zero, or positive')
        _validate(config)
        dataset = open_dataset(config)
        resources.callback(dataset.close)
        from relion_torch.io.reference_output import InitialReferenceCollector
        reference_collector = InitialReferenceCollector(f"{output_root}_init", config.number_of_classes)
        references, mode, seeds, reconstructed = prepare_relion_references(
            config, output_root, dataset.pixel_size, dataset=dataset, startup=startup,
            reference_collector=reference_collector)
        with startup.timer.section('initial_stack_write'):
            references = reference_collector.finish(dataset.pixel_size)
        initial_references = reference_collector.images
    config.output_root = output_root
    config.fast_subsets = bool(config.fast_subsets)
    startup.mode = config.initialization_mode
    _validate(config)
    if config.fast_subsets and start_iteration + config.iterations < 20:
        raise ValueError('RELION --fast_subsets requires the absolute final iteration to be at least 20')
    if len(references) != config.number_of_classes:
        raise ValueError("number of references/checkpoint classes differs from --K")
    if config.gpu_psi_grid:
        import math
        count = int(math.ceil(360.0/config.psi_step_deg))
        config.psi_step_deg = 360.0/(32*int(math.ceil(count/32)))
    if reconstructed:
        config.ctf_corrected_ref = True
    if dataset is None:
        dataset = open_dataset(replace(config, input_star=input_star), preserve_noise_groups=True)
        resources.callback(dataset.close)
    optimiser = Class2DOptimiser(
        _alignment_config(config, input_star, references, start_iteration),
        class2d_config=config, initial_mode=mode, generate_seeds=seeds, checkpoint_state=saved, dataset=dataset, startup=startup,
        initial_references=initial_references)
    # Optimiser owns its device copies; do not retain diagnostic host seed arrays.
    initial_references = None
    if reference_collector is not None:
        reference_collector.images.clear()
    if saved is not None:
        optimiser.restore_checkpoint(saved)
    elif continuation is not None:
        install_state(optimiser, continuation)
        from .state import install_class2d_extra_state
        install_class2d_extra_state(optimiser, continuation)
    from relion_torch.inference.permanent_workers import PermanentPool,devices
    if devices(config):
        pool=PermanentPool(config);resources.callback(pool.close);pool.bind(optimiser)
    optimiser.run()
    final_iteration = start_iteration + config.iterations
    stacks = tuple(Path(f"{output_root}_it{i:03d}_classes.mrcs")
                   for i in range(0 if start_iteration == 0 else start_iteration+1, final_iteration+1))
    manifest = Path(f"{output_root}_class2d_manifest.json")
    from .optimiser import _jsonable
    manifest.write_text(json.dumps({
        "startup_timing": str(output_root)+"_startup_timing.json" if config.timing else None,
        "fast_subsets": bool(config.fast_subsets),
        "version": __version__, "implementation": "class2d-state-machine",
        "input_star": str(input_star), "output_root": str(output_root),
        "translation_prior": {"coordinates": "dimensionally-consistent-debug" if config.debug_dimensionally_consistent_prior else "relion31-native",
                              "normalization": config.translation_prior_normalization},
        "classes": config.number_of_classes, "start_iteration": start_iteration,
        "final_iteration": final_iteration, "initial_reference_mode": mode,
        "generate_seeds": seeds, "options": _jsonable(asdict(config)),
        "class_stacks": [str(x) for x in stacks],
        "numeric_precision": "complex64/float32 image kernels, float64 posterior/model reductions",
        "checkpoint": f"{output_root}_it{final_iteration:03d}_state.pt",
        "history": optimiser._iteration_history,
        "particle_io": {**asdict(dataset.io_options), "raw_bytes": dataset.images.raw_nbytes,
            "effective_pool_size": dataset.io_options.effective_pool(config.batch_size),
            "statistics": {**dataset.images.stats, "stack_opens": dataset.cache.opens,
                "peak_open_stacks": dataset.cache.peak_open, "stack_evictions": dataset.cache.evictions,
                "images_read": dataset.cache.images_read}},
        "limitations": ["Heterogeneous optics box sizes/pixel sizes are not supported.",
                        "RNG stream is platform-dependent; perturbation uses saved NumPy PCG64 state."]
    }, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    return Class2DResult(output_root,input_star,tuple(references),start_iteration,
                         final_iteration,stacks,manifest)
