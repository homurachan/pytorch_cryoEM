"""RELION 3.1-style multi-class two-dimensional classification.

The Class2D front end reuses the validated alignment, likelihood, masking,
projector, backprojector, SSNR and reconstruction core from relion-torch 0.1.12.
It adds reference-stack handling, a dedicated option surface, fixed-pose
class-only classification, continuation state restoration and permutation-aware
class-set comparison.
"""

from .matching import ClassMatch, correlation_matrix, match_class_maps
from .runner import Class2DConfig, Class2DResult, run_class2d

__all__ = [
    "Class2DConfig",
    "Class2DResult",
    "ClassMatch",
    "correlation_matrix",
    "match_class_maps",
    "run_class2d",
]
