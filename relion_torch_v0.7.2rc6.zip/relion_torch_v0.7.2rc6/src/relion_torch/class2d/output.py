"""Class2D output helpers."""
from __future__ import annotations

from pathlib import Path
from typing import Sequence

import mrcfile
import numpy as np

from relion_torch.io.mrc import write_mrc
from relion_torch.io.star import read_star, write_star


def write_class_stack(
    class_paths: Sequence[str | Path],
    stack_path: str | Path,
    *,
    pixel_size_angstrom: float | None = None,
) -> Path:
    arrays: list[np.ndarray] = []
    voxel: float | None = pixel_size_angstrom
    for source in class_paths:
        with mrcfile.open(source, mode="r", permissive=True) as handle:
            array = np.asarray(handle.data, dtype=np.float32).copy()
            local_voxel = float(handle.voxel_size.x)
        if array.ndim != 2:
            raise ValueError(f"Class map {source} has shape {array.shape}, expected 2-D")
        arrays.append(array)
        if voxel is None and local_voxel > 0:
            voxel = local_voxel
    if not arrays:
        raise ValueError("No class maps were supplied")
    shape = arrays[0].shape
    if any(array.shape != shape for array in arrays):
        raise ValueError("Class maps do not share one shape")
    return write_mrc(
        stack_path,
        np.stack(arrays, axis=0),
        pixel_size_angstrom=voxel,
    )


def class_paths_for_iteration(
    output_root: str | Path, iteration: int, number_of_classes: int
) -> list[Path]:
    root = str(output_root)
    return [
        Path(f"{root}_it{int(iteration):03d}_class{index:03d}.mrc")
        for index in range(1, int(number_of_classes) + 1)
    ]


def make_iteration_class_stack(
    output_root: str | Path,
    iteration: int,
    number_of_classes: int,
    *,
    rewrite_model_references: bool = True,
) -> Path:
    class_paths = class_paths_for_iteration(output_root, iteration, number_of_classes)
    missing = [str(path) for path in class_paths if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing class maps: " + ", ".join(missing))
    stack_path = Path(f"{output_root}_it{int(iteration):03d}_classes.mrcs")
    write_class_stack(class_paths, stack_path)
    if rewrite_model_references:
        model_path = Path(f"{output_root}_it{int(iteration):03d}_model.star")
        if model_path.is_file():
            blocks = read_star(model_path)
            class_block_name = next(
                (
                    name
                    for name in blocks
                    if "model_classes" in str(name).lower()
                ),
                None,
            )
            if class_block_name is not None:
                table = blocks[class_block_name].copy()
                label = (
                    "rlnReferenceImage"
                    if "rlnReferenceImage" in table.columns
                    else "_rlnReferenceImage"
                )
                table[label] = [
                    f"{index:06d}@{stack_path}"
                    for index in range(1, number_of_classes + 1)
                ]
                blocks[class_block_name] = table
                write_star(blocks, model_path, overwrite=True)
    return stack_path
