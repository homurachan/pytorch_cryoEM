"""Class2D priors layered on the shared dense/sparse likelihood engine."""
from __future__ import annotations
import torch
from relion_torch.inference.alignment import AlignmentExpectation
from .semantics import (class_translation_log_prior, coarse_translation_prior_coordinates,
                        gpu_prior_weight_selection_batch)


class Class2DExpectation(AlignmentExpectation):
    allowed_classes = None

    def __init__(self, *args,
                 debug_dimensionally_consistent_prior=False,
                 translation_prior_normalization="gpu", **kwargs):
        super().__init__(*args, **kwargs)
        self.prior_pixel_size = float(self.sizes.pixel_size)
        self.debug_dimensionally_consistent_prior = bool(debug_dimensionally_consistent_prior)
        self.translation_prior_normalization = translation_prior_normalization

    def _select_weights(self, log_prior, diff2, adaptive_fraction):
        if self.translation_prior_normalization == "gpu":
            return gpu_prior_weight_selection_batch(log_prior, diff2, adaptive_fraction)
        return super()._select_weights(log_prior, diff2, adaptive_fraction)

    def _dense_log_prior(self, bank, batch_size, *, offset_prior_angstrom,
                         orientation_prior_deg, dtype, device):
        centres = offset_prior_angstrom.to(device=device, dtype=torch.float64)
        if centres.ndim == 2:
            centres = centres[:, None].expand(-1, len(self.class_probabilities), -1)
        trans = torch.as_tensor(self.sampling.prior_translations, device=device,
                                dtype=torch.float64)
        trans = coarse_translation_prior_coordinates(trans, self.prior_pixel_size,
                    dimensionally_consistent=self.debug_dimensionally_consistent_prior)
        prior = class_translation_log_prior(trans, centres,
                    self.config.sigma_offset_angstrom, self.class_probabilities,
                    self.allowed_classes, normalization=self.translation_prior_normalization)
        return prior[:, :, None, :].expand(-1, -1, bank.number_of_orientations, -1)
