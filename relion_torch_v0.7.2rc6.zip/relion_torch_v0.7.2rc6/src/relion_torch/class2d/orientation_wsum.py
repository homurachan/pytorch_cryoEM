"""RELION-style orientation-major Class2D weighted sums.

This module is intentionally Class2D-only. It groups all retained fine
translations belonging to the same particle/class/fine-orientation before
computing noise, scale, offset and backprojection statistics. The phase basis and
workspace planner are shared with Class3D; this module retains Class2D-specific
class-offset and execution scheduling behavior.

v0.2.14 adds a dedicated orientation-major schedule/workspace. Parent-sized
Fourier tensors are never materialised before grouping, and consecutive groups
from the same class are combined into bounded supertiles. One real FP32 GEMM
per supertile evaluates the weighted complex phase, phase-power and translation
moments together.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import torch

from .candidate_execution import WeightGroupPlan


from relion_torch.alignment.orientation_statistics import (
    OrientationMajorWorkspace, OrientationMajorPhaseBasis,
    plan_orientation_major_workspace, build_orientation_major_phase_basis,
)


@dataclass(slots=True)
class OrientationMajorResult:
    rows: torch.Tensor
    angular_ids: torch.Tensor
    residual: torch.Tensor
    xa: torch.Tensor
    aa: torch.Tensor
    offset_sum: torch.Tensor
    offset_square: torch.Tensor
    numerator: torch.Tensor
    denominator: torch.Tensor
    orientation_rows: int
    parent_rows: int
    translation_slots: int


@dataclass(frozen=True, slots=True)
class OrientationMajorCost:
    parent_rows: int
    coarse_groups: int
    coarse_translations: int
    density: float
    translation_reuse: float
    parent_units: float
    orientation_units: float
    use_orientation: bool


def estimate_orientation_major_cost(
    parent_rows: int,
    coarse_groups: int,
    coarse_translations: int,
    *,
    translation_children: int,
    force: bool = False,
) -> OrientationMajorCost:
    """Estimate parent-major versus dense orientation-major execution cost.

    Units are normalized to one retained translation-parent statistics row.
    Orientation-major pays one base row per particle/class/coarse-orientation
    group plus a dense translation-rectangle/GEMM term.  The latter is 0.055
    parent-row units per fine-translation child and coarse translation.  For
    the common Class2D oversampling=1 case (21 coarse translations, four fine
    translations) this places the natural crossover at about 26.8% density,
    rather than v0.2.14's fixed 50% gate.  Other translation counts/orders
    move the crossover automatically.  Explicit orientation layout bypasses
    the comparison but never bypasses workspace bounds.
    """
    p=max(0,int(parent_rows)); g=max(0,int(coarse_groups)); t=max(1,int(coarse_translations))
    tc=max(1,int(translation_children))
    if p == 0 or g == 0:
        return OrientationMajorCost(p,g,t,0.0,0.0,float(p),float('inf'),False)
    reuse=p/g
    density=p/(g*t)
    parent_units=float(p)
    dense_slot_units=0.055*tc
    orientation_units=float(g)*(1.0 + t*dense_slot_units)
    return OrientationMajorCost(
        p,g,t,float(density),float(reuse),parent_units,orientation_units,
        bool(force or orientation_units <= parent_units),
    )


@dataclass(frozen=True, slots=True)
class OrientationMajorTile:
    parent_ids: torch.Tensor
    group_counts: torch.Tensor
    class_id: int
    host_angular_ids: tuple[int, ...]
    translations: int

    def build_plan(self, result, orientation_children: int) -> WeightGroupPlan:
        """Construct small GPU-local plan arrays; parent metadata never round-trips."""
        ids=self.parent_ids.to(torch.long)
        counts=self.group_counts.to(torch.long)
        ng=int(counts.numel())
        if ng < 1 or int(counts.sum().item()) != int(ids.numel()):
            raise ValueError("invalid orientation-major group counts")
        representatives=torch.cumsum(counts,0)-counts
        representative_ids=ids.index_select(0,representatives)
        rows=result.parent_particle_indices.index_select(0,representative_ids)
        coarse_orientation=result.parent_orientation_indices.index_select(0,representative_ids)
        child=torch.arange(int(orientation_children),device=ids.device,dtype=torch.long)
        angular_ids=coarse_orientation[:,None]*int(orientation_children)+child[None]
        group_index=torch.repeat_interleave(
            torch.arange(ng,device=ids.device,dtype=torch.long), counts)
        parent_translation=result.parent_translation_indices.index_select(0,ids)
        slots=group_index*int(self.translations)+parent_translation
        translation_ids=torch.arange(int(self.translations),device=ids.device,dtype=torch.long)
        return WeightGroupPlan(
            rows=rows,
            angular_ids=angular_ids,
            translation_ids=translation_ids,
            slots=slots,
            representatives=representatives,
            groups=ng,
            translations=int(self.translations),
        )


@dataclass(slots=True)
class OrientationMajorSchedule:
    flat: torch.Tensor
    descriptors: list
    parent_count: int
    nonzero_children: int
    d2h_bytes: int
    h2d_bytes: int
    regular_layout: int
    regular_grid_buffer_bytes: int
    cost: OrientationMajorCost

    def tiles(self):
        view = lambda ab: self.flat[ab[0]:ab[1]]
        for parent_span, counts_span, cls, host_ids, translations in self.descriptors:
            yield OrientationMajorTile(
                view(parent_span), view(counts_span), int(cls), host_ids, int(translations)
            )


@dataclass(frozen=True, slots=True)
class SparseParentSupertile:
    parent_ids: torch.Tensor
    class_groups: tuple


@dataclass(slots=True)
class SparseParentSupertileSchedule:
    """Cross-class sparse parent tiles reusing the orientation marker.

    Parent IDs retain the exact class/orientation/particle/translation ordering
    used by the pre-v0.2.16 compact schedule.  Only tile boundaries are allowed
    to cross class boundaries, so the hot weighted-phase/noise/scale kernels can
    process several tiny classes at once without changing candidate selection.
    """

    flat: torch.Tensor
    descriptors: list
    parent_count: int
    nonzero_children: int
    h2d_bytes: int
    tile_size: int
    class_groups: int
    row_peak: int

    def tiles(self):
        for start, stop, groups in self.descriptors:
            yield SparseParentSupertile(
                self.flat[start:stop],
                tuple((int(c), slice(int(a), int(b)), touched, None)
                      for c, a, b, touched in groups),
            )


def estimate_orientation_major_cost_dense_host(
    marker, shape, *, translation_children: int, force_orientation: bool = False
) -> OrientationMajorCost:
    """Cheap cost decision from the already-transferred dense marker.

    This deliberately stops before constructing parent-rank arrays.  The
    selected layout then builds exactly one schedule (orientation-major or
    sparse-parent supertile), avoiding duplicate late-iteration host work.
    """
    batch, classes, orientations, translations = map(int, shape)
    grid = np.asarray(marker).reshape(batch, classes, orientations, translations)
    active = grid > 1
    parent_count = int(active.sum())
    if parent_count == 0:
        return estimate_orientation_major_cost(
            0, 0, translations, translation_children=translation_children,
            force=force_orientation)
    coarse_groups = int(active.any(axis=-1).sum())
    return estimate_orientation_major_cost(
        parent_count, coarse_groups, translations,
        translation_children=translation_children, force=force_orientation)


def compact_sparse_parent_supertile_dense_host(
    marker, shape, *, children: int, tile_size: int, device
):
    """Build cross-class parent supertiles from the v0.2.15 dense marker.

    This is the *sparse* fallback, so it intentionally avoids a dense int32
    parent-rank grid.  Active coarse-grid codes are mapped back to parent-row
    IDs with one search in the ordered significant-code list, then only those
    active rows are stably sorted by class/orientation/particle/translation.
    The scientific parent order therefore matches the legacy compact parent
    scheduler while host work scales with retained sparse rows rather than the
    full [B,K,O,T] grid.
    """
    batch, classes, orientations, translations = map(int, shape)
    tile_size = max(1, int(tile_size))
    flat_marker = np.asarray(marker).reshape(-1)
    significant_codes = np.flatnonzero(flat_marker > 0)
    active_codes = np.flatnonzero(flat_marker > 1)
    parent_total = int(significant_codes.size)
    n = int(active_codes.size)
    if parent_total == 0 or n == 0:
        return SparseParentSupertileSchedule(
            torch.empty(0, device=device, dtype=torch.int32), [], 0, 0, 0,
            tile_size, 0, 0)

    # coarse.significant.nonzero() follows flattened [B,K,O,T] order. Since
    # active_codes is a subset of significant_codes, searchsorted gives the
    # exact row IDs into all SparseAdaptiveBatchExpectation parent arrays.
    parent_ids = np.searchsorted(significant_codes, active_codes).astype(
        np.int32 if parent_total <= np.iinfo(np.int32).max else np.int64, copy=False)

    tr = active_codes % translations
    co = active_codes // translations
    ori = co % orientations
    cp = co // orientations
    cls = cp % classes
    particle = cp // classes
    order = np.lexsort((tr, particle, ori, cls))
    parent_ids, cls, ori, particle, tr = (
        np.asarray(v)[order] for v in (parent_ids, cls, ori, particle, tr)
    )

    group_key = (cls.astype(np.int64) * orientations + ori.astype(np.int64)) * batch + particle
    group_starts = np.r_[0, np.flatnonzero(group_key[1:] != group_key[:-1]) + 1, n]
    class_starts = np.r_[0, np.flatnonzero(cls[1:] != cls[:-1]) + 1, n]

    descriptors = []
    total_groups = 0
    row_peak = 0
    start = 0
    while start < n:
        end = min(start + tile_size, n)
        # Avoid splitting one particle/orientation translation run when a
        # boundary exists inside the requested tile. Oversized single runs
        # remain safely splittable.
        if end < n:
            boundary_index = np.searchsorted(group_starts, end, side='right') - 1
            boundary = int(group_starts[boundary_index])
            if boundary > start:
                end = boundary
        if end <= start:
            end = min(start + tile_size, n)

        a = np.searchsorted(class_starts, start, side='right') - 1
        z = np.searchsorted(class_starts, end, side='left')
        boundaries = [start]
        boundaries.extend(int(x) for x in class_starts[a + 1:z])
        boundaries.append(end)
        groups = []
        for ga, gb in zip(boundaries[:-1], boundaries[1:]):
            if gb <= ga:
                continue
            c = int(cls[ga])
            touched_ori = ori[ga:gb]
            touched_ori = touched_ori[np.r_[True, touched_ori[1:] != touched_ori[:-1]]]
            touched = tuple(map(int, (
                touched_ori[:, None] * int(children)
                + np.arange(int(children), dtype=np.int64)[None]
            ).reshape(-1)))
            groups.append((c, ga - start, gb - start, touched))
        descriptors.append((start, end, tuple(groups)))
        total_groups += len(groups)
        row_peak = max(row_peak, end - start)
        start = end

    host_ids = np.asarray(parent_ids, dtype=parent_ids.dtype)
    flat = torch.as_tensor(host_ids, device=device)
    nonzero_children = int((flat_marker[active_codes].astype(np.int64) - 1).sum(dtype=np.int64))
    return SparseParentSupertileSchedule(
        flat=flat, descriptors=descriptors, parent_count=n,
        nonzero_children=nonzero_children, h2d_bytes=int(host_ids.nbytes),
        tile_size=tile_size, class_groups=total_groups, row_peak=row_peak)


def _decode_parent_grid(packed, nonzero_counts, shape):
    """Decode retained parents once; order by class/orientation/particle."""
    batch, classes, orientations, translations = map(int, shape)
    packed = np.asarray(packed)
    counts = np.asarray(nonzero_counts)
    keep = np.flatnonzero(counts).astype(np.int64, copy=False)
    if len(keep) == 0:
        return None
    code = packed[keep].astype(np.int64, copy=False)
    if code.min() < 0 or code.max() >= batch * classes * orientations * translations:
        raise ValueError("encoded parent outside coarse candidate shape")
    grid_elements = batch * classes * orientations * translations
    regular = (
        grid_elements <= np.iinfo(np.int32).max
        and 8 * grid_elements <= 64 * 1024**2
        and len(keep) * 2 >= grid_elements
        and (len(code) < 2 or bool(np.all(code[1:] > code[:-1])))
    )
    if regular:
        grid = np.full(grid_elements, -1, dtype=np.int32)
        grid[code] = keep
        arranged = (
            grid.reshape(batch, classes, orientations, translations)
            .transpose(1, 2, 0, 3)
            .reshape(-1)
        )
        position = np.flatnonzero(arranged >= 0)
        keep = arranged[position].astype(np.int64)
        key = position // translations
        tr = position % translations
        particle = key % batch
        co = key // batch
        ori = co % orientations
        cls = co // orientations
        del grid, arranged, code, position
    else:
        tr = code % translations
        co = code // translations
        ori = co % orientations
        cp = co // orientations
        cls, particle = cp % classes, cp // classes
        key = (cls * orientations + ori) * batch + particle
        order = np.argsort(key, kind="stable")
        keep, key, cls, ori, particle, tr = (
            v[order] for v in (keep, key, cls, ori, particle, tr)
        )
    return keep, key, cls, ori, particle, tr, regular, grid_elements


def compact_orientation_schedule_dense_host(
    marker,
    shape,
    *,
    orientation_children: int,
    translation_children: int,
    max_coarse_groups: int,
    device,
    force_orientation: bool = False,
    precomputed_cost: OrientationMajorCost | None = None,
):
    """Build supertiles from one dense uint marker copied from the GPU.

    ``marker`` is aligned to the full coarse [B,K,O,T] grid. Zero means the
    coarse parent was absent, one means it existed but all fine children became
    exact zero, and values >1 store ``1 + number_of_nonzero_fine_children``.
    This single byte/element transfer replaces v0.2.14's per-parent
    ``(count, encoded_code)`` D2H stream. Parent row IDs are reconstructed from
    the lexicographic ``torch.nonzero(coarse.significant)`` ordering. H2D then
    carries only int32 parent IDs plus one int32 count per compressed group;
    translation slots/rows/angular IDs are rebuilt on the GPU.
    """
    batch, classes, orientations, translations=map(int,shape)
    grid=np.asarray(marker).reshape(batch,classes,orientations,translations)
    significant=grid>0
    parent_total=int(significant.sum())
    if parent_total == 0:
        return None, estimate_orientation_major_cost(0,0,translations,
            translation_children=translation_children,force=force_orientation)
    active=grid>1
    parent_count=int(active.sum())
    # Parent row number equals rank among lexicographically ordered significant
    # coarse-grid entries, matching torch.nonzero on the contiguous coarse mask.
    rank=np.full(grid.size,-1,dtype=np.int32 if parent_total<=np.iinfo(np.int32).max else np.int64)
    sigflat=significant.reshape(-1)
    rank[sigflat]=np.arange(parent_total,dtype=rank.dtype)
    rank=rank.reshape(batch,classes,orientations,translations)

    trans_active=active.transpose(1,2,0,3)   # [K,O,B,T]
    trans_rank=rank.transpose(1,2,0,3)
    group_mask=trans_active.any(axis=-1)
    coarse_groups=int(group_mask.sum())
    cost = precomputed_cost or estimate_orientation_major_cost(
        parent_count,coarse_groups,translations,
        translation_children=int(translation_children),force=force_orientation)
    if not cost.use_orientation:
        return None,cost

    pieces=[]; descriptors=[]; offset=0
    def add(values):
        nonlocal offset
        arr=np.asarray(values,dtype=np.int32).reshape(-1)
        span=(offset,offset+len(arr)); pieces.append(arr); offset+=len(arr)
        return span
    max_groups=max(1,int(max_coarse_groups))
    for c in range(classes):
        coords=np.argwhere(group_mask[c])  # [coarse orientation, particle]
        if len(coords)==0: continue
        for g0 in range(0,len(coords),max_groups):
            sub=coords[g0:g0+max_groups]
            oidx=sub[:,0]; pidx=sub[:,1]
            mask=trans_active[c,oidx,pidx,:]
            ranks=trans_rank[c,oidx,pidx,:]
            group_counts=mask.sum(axis=1,dtype=np.int32)
            parent_ids=ranks[mask]
            if len(parent_ids)==0: continue
            parent_span=add(parent_ids)
            counts_span=add(group_counts)
            touched=np.unique(oidx)
            host_ids=tuple(map(int,(touched[:,None]*int(orientation_children)+
                                    np.arange(int(orientation_children),dtype=np.int64)[None]).reshape(-1)))
            descriptors.append((parent_span,counts_span,int(c),host_ids,translations))
    host=np.concatenate(pieces) if pieces else np.empty(0,dtype=np.int32)
    flat=torch.as_tensor(host,device=device,dtype=torch.int32)
    nonzero_children=int((grid.astype(np.int64)-1).clip(min=0).sum(dtype=np.int64))
    return OrientationMajorSchedule(
        flat=flat,descriptors=descriptors,parent_count=parent_count,
        nonzero_children=nonzero_children,d2h_bytes=int(np.asarray(marker).nbytes),
        h2d_bytes=int(host.nbytes),regular_layout=1,
        regular_grid_buffer_bytes=int(np.asarray(marker).nbytes+rank.nbytes),cost=cost,
    ),cost


def compact_orientation_schedule_host(
    packed,
    nonzero_counts,
    shape,
    *,
    orientation_children: int,
    max_coarse_groups: int,
    device,
    require_dense: bool = True,
):
    """Build Class2D orientation-major supertiles without parent Fourier data.

    Consecutive particle/coarse-orientation groups of one class are combined up
    to ``max_coarse_groups``. A dense translation rectangle is required in auto
    mode (same density criterion as v0.2.13 early merging). If any populated
    supertile is unsuitable, ``None`` is returned so the whole particle batch
    cleanly falls back to the mature parent-major iterator; no parent is lost or
    evaluated twice.
    """
    decoded = _decode_parent_grid(packed, nonzero_counts, shape)
    if decoded is None:
        return None
    keep, key, cls, ori, particle, tr, regular, grid_elements = decoded
    _, classes, _, translations = map(int, shape)
    n = len(keep)
    group_starts = np.r_[0, np.flatnonzero(key[1:] != key[:-1]) + 1, n]
    # group_starts[g]: first parent row of a (class, coarse orientation, particle) group
    group_cls = cls[group_starts[:-1]]
    pieces = []
    offset = 0

    def add(a):
        nonlocal offset
        arr = np.asarray(a, dtype=np.int64).reshape(-1)
        span = (offset, offset + len(arr))
        pieces.append(arr)
        offset += len(arr)
        return span

    translation_span = add(np.arange(translations, dtype=np.int64))
    descriptors = []
    max_groups = max(1, int(max_coarse_groups))
    for c in range(classes):
        cg = np.flatnonzero(group_cls == c)
        if len(cg) == 0:
            continue
        # Groups are already contiguous by class, so split only by compressed
        # group count, not retained-parent count.
        first_group = int(cg[0])
        stop_group = int(cg[-1]) + 1
        g0 = first_group
        while g0 < stop_group:
            g1 = min(stop_group, g0 + max_groups)
            beginnings = group_starts[g0:g1]
            endings = group_starts[g0 + 1 : g1 + 1]
            start = int(beginnings[0])
            end = int(endings[-1])
            ng = int(g1 - g0)
            count = int(end - start)
            # Parent-major remains the safer/faster fallback once translation
            # reuse becomes small. Explicit orientation mode still keeps this
            # bounded safety criterion; it never forces a sparse rectangle.
            dense = count >= max(128, 8 * ng) and ng * translations <= 2 * count
            if require_dense and not dense:
                return None
            if not dense:
                return None
            parent_span = add(keep[start:end])
            row_span = add(particle[beginnings])
            angular = ori[beginnings, None] * int(orientation_children) + np.arange(
                int(orientation_children), dtype=np.int64
            )[None]
            angular_span = add(angular)
            # Map each retained coarse-translation parent into its group's full
            # coarse-translation rectangle. Fine translation children remain in
            # the posterior tensor's final dimension and are not materialised.
            group_index = np.repeat(np.arange(ng, dtype=np.int64), endings - beginnings)
            slot_span = add(group_index * translations + tr[start:end])
            representative_span = add(beginnings - start)
            touched_ori = ori[beginnings]
            touched_ori = touched_ori[
                np.r_[True, touched_ori[1:] != touched_ori[:-1]]
            ]
            host_ids = tuple(
                map(
                    int,
                    (
                        touched_ori[:, None] * int(orientation_children)
                        + np.arange(int(orientation_children), dtype=np.int64)[None]
                    ).reshape(-1),
                )
            )
            descriptors.append(
                (
                    parent_span,
                    int(c),
                    host_ids,
                    (row_span, angular_span, translation_span, slot_span, representative_span),
                    ng,
                    translations,
                )
            )
            g0 = g1
    host = np.concatenate(pieces) if pieces else np.empty(0, dtype=np.int64)
    flat = torch.as_tensor(host, device=device, dtype=torch.long)
    return OrientationMajorSchedule(
        flat=flat,
        descriptors=descriptors,
        parent_count=n,
        nonzero_children=int(np.asarray(nonzero_counts).sum(dtype=np.int64)),
        d2h_bytes=int(np.asarray(packed).nbytes + np.asarray(nonzero_counts).nbytes),
        h2d_bytes=int(host.nbytes),
        regular_layout=int(regular),
        regular_grid_buffer_bytes=int(8 * grid_elements if regular else 0),
    )


@torch.no_grad()
def _coalesced_orientation_weight_matrix(weights: torch.Tensor, plan: WeightGroupPlan):
    """Return [fine orientation row, all fine translations] FP32 weights."""
    if weights.dtype != torch.float32:
        weights = weights.to(torch.float32)
    ng, nt = plan.groups, plan.translations
    _, oc, tc = weights.shape
    work = torch.zeros((ng * nt, oc, tc), device=weights.device, dtype=torch.float32)
    work.index_add_(0, plan.slots, weights)
    grouped = (
        work.reshape(ng, nt, oc, tc)
        .permute(0, 2, 1, 3)
        .reshape(ng * oc, nt * tc)
    )
    return grouped


@torch.no_grad()
def orientation_major_class_sums(
    *,
    weights: torch.Tensor,
    plan: WeightGroupPlan,
    phase_basis: OrientationMajorPhaseBasis,
    representative_refs: torch.Tensor,
    like_active: torch.Tensor,
    unmasked: torch.Tensor,
    pred_active_factor: torch.Tensor,
    num_factor: torch.Tensor,
    den_factor: torch.Tensor,
    inv: torch.Tensor,
    active_indices: torch.Tensor,
    integer_offsets: torch.Tensor,
    old_scales: torch.Tensor,
    class_offset: torch.Tensor,
    reliable_shell_mask: torch.Tensor | None,
    pixel_size: float,
    dimensionally_consistent_prior: bool,
    statistics_dtype: torch.dtype,
) -> OrientationMajorResult:
    """Evaluate one bounded class supertile after translation coalescing."""
    grouped = _coalesced_orientation_weight_matrix(weights, plan)
    ng = plan.groups
    oc = weights.shape[1]
    rows = plan.rows.repeat_interleave(oc)
    angular_ids = plan.angular_ids.reshape(-1)
    if representative_refs.shape[0] != ng:
        raise ValueError("representative reference count differs from orientation groups")
    if grouped.shape[1] != phase_basis.translation_slots:
        raise ValueError("grouped translation slots differ from phase basis")

    # One large GEMM for the entire supertile. The RHS is shared across all
    # classes/supertiles in the particle batch.
    reduced = grouped @ phase_basis.matrix
    f = phase_basis.full_pixels
    a = phase_basis.active_pixels
    phase_real = reduced[:, :f]
    phase_imag = reduced[:, f : 2 * f]
    weighted_phase_power = reduced[:, 2 * f : 2 * f + a]
    moments = reduced[:, 2 * f + a :]
    mass = moments[:, 0]
    weighted_t = moments[:, 1:3]
    weighted_t2 = moments[:, 3]
    phase_sum = torch.complex(phase_real, phase_imag).reshape(
        rows.numel(), phase_basis.height, phase_basis.width
    )

    ref_group = representative_refs.reshape(
        ng * oc, representative_refs.shape[-2], representative_refs.shape[-1]
    )
    prediction_active = (
        ref_group.flatten(-2).index_select(-1, active_indices)
        * pred_active_factor.index_select(0, rows)
    )
    image_active = like_active.index_select(0, rows)
    phase_sum_active = phase_sum.flatten(-2).index_select(-1, active_indices)
    xbar = image_active * phase_sum_active
    xpower = image_active.abs().square() * weighted_phase_power

    power = mass[:, None] * prediction_active.abs().square()
    cross = (prediction_active.conj() * xbar).real
    residual = (xpower + power - 2.0 * cross).clamp_min_(0.0).to(statistics_dtype)

    xa = torch.zeros(rows.numel(), device=weights.device, dtype=statistics_dtype)
    aa = torch.zeros_like(xa)
    if reliable_shell_mask is not None:
        rel = reliable_shell_mask.to(device=weights.device)
        scales = old_scales.index_select(0, rows).to(statistics_dtype)
        xa.copy_(cross[:, rel].sum(-1).to(statistics_dtype) / scales)
        aa.copy_(power[:, rel].sum(-1).to(statistics_dtype) / scales.square())

    integer = integer_offsets.index_select(0, rows).to(torch.float32) * float(pixel_size)
    offset_vec = weighted_t + mass[:, None] * integer
    centre = class_offset.to(torch.float32)
    if not dimensionally_consistent_prior:
        centre = centre * float(pixel_size)
    base = integer - centre[None]
    offset_square = (
        weighted_t2 + 2.0 * (weighted_t * base).sum(-1) + mass * base.square().sum(-1)
    ).sum().to(statistics_dtype)
    offset_sum = offset_vec.sum(0).to(statistics_dtype)

    numerator = (
        phase_sum
        * unmasked.index_select(0, rows)
        * (num_factor.index_select(0, rows) * inv.index_select(0, rows))
    )
    denominator = mass[:, None, None] * (
        den_factor.index_select(0, rows) * inv.index_select(0, rows)
    )
    return OrientationMajorResult(
        rows=rows,
        angular_ids=angular_ids,
        residual=residual,
        xa=xa,
        aa=aa,
        offset_sum=offset_sum,
        offset_square=offset_square,
        numerator=numerator,
        denominator=denominator,
        orientation_rows=int(rows.numel()),
        parent_rows=int(weights.shape[0]),
        translation_slots=int(grouped.numel()),
    )
