"""Bounded Class2D candidate execution, independent of posterior selection.

Only exactly-zero retained FP weights are skipped. Gridding contributions may
be regrouped after all per-parent noise/scale/offset statistics are evaluated.
No new package, custom CUDA kernel, or implicit full-data device cache is used.
"""
from __future__ import annotations
from collections import OrderedDict

import numpy as np
import torch


def candidate_schedule(class_values, orientation_values, tile_size, children, device):
    """One CPU schedule + one H2D index transfer, not GPU unique per tile.

    Inputs are one-dimensional NumPy arrays in retained parent order. Class
    selection indices are strictly increasing. The host orientation IDs let the
    gridding buffer track touched slots without a GPU nonzero at flush time.
    """
    parts = []
    metadata = []
    count = 0
    for start in range(0, len(class_values), tile_size):
        cls = class_values[start:start+tile_size]
        ori = orientation_values[start:start+tile_size]
        row = []
        for c in np.unique(cls):
            selected = np.flatnonzero(cls == c).astype(np.int64, copy=False)
            unique = np.unique(ori[selected])
            angular = (unique[:, None]*children + np.arange(children)[None]).reshape(-1)
            row.append((int(c), count, count+len(selected), tuple(map(int, angular))))
            parts.append(selected)
            count += len(selected)
        metadata.append(row)
    flat = np.concatenate(parts) if parts else np.empty(0, dtype=np.int64)
    indices = torch.as_tensor(flat, dtype=torch.long, device=device)
    return [[(c, indices[a:b], angular) for c, a, b, angular in row] for row in metadata]


class GroupedBackprojection2D:
    """LRU-bounded sums by class/fine orientation; optional iteration lifetime.

    Every input numerator already includes its own image/CTF/inverse-noise
    factors. Denominators are summed independently, never normalized here.
    If a complete orientation bank cannot fit, insert that class directly.
    That fallback changes performance only, never drops a contribution.
    """
    def __init__(self, backprojectors, angles, plan, *, max_bytes, orientation_chunk_size,
                 counters=None):
        self.backprojectors = backprojectors
        self.angles = angles
        self.plan = plan
        self.max_bytes = max(0, int(max_bytes))
        self.chunk = int(orientation_chunk_size)
        self.counters = counters
        self.buffers = OrderedDict()
        self.used_bytes = 0
        self.peak_bytes = 0

    def _count(self, key, value):
        if self.counters is not None:
            self.counters[key] = self.counters.get(key, 0) + int(value)

    def _insert(self, cls, numerator, denominator, angular_ids):
        self._count('backprojector_calls', 1)
        self._count('backprojected_orientation_rows', len(angular_ids))
        if self.plan is not None:
            self.plan.accumulate(self.backprojectors.objects[cls], numerator, denominator,
                                 angular_ids, orientation_chunk_size=self.chunk)
        else:
            from relion_torch.alignment.core import _euler_matrix
            rotations = _euler_matrix(self.angles.index_select(0, angular_ids))
            self.backprojectors.add(cls, numerator, rotations, torch.ones_like(denominator),
                                    denominator, orientation_chunk_size=self.chunk)

    def _flush(self, cls):
        numerator, denominator, touched, size = self.buffers.pop(cls)
        ids = torch.tensor(sorted(touched), device=numerator.device, dtype=torch.long)
        self._insert(cls, numerator.index_select(0, ids), denominator.index_select(0, ids), ids)
        self._count('grouped_flushes', 1)
        self.used_bytes -= size

    @torch.no_grad()
    def add(self, cls, numerator, denominator, angular_ids, host_ids):
        self._count('grouped_input_orientation_rows', len(angular_ids))
        shape = (len(self.angles), *numerator.shape[-2:])
        size = int(np.prod(shape)) * (numerator.element_size() + denominator.element_size())
        if size > self.max_bytes:
            self._count('grouped_fallback_orientation_rows', len(angular_ids))
            self._insert(cls, numerator, denominator, angular_ids)
            return
        if cls not in self.buffers:
            while self.buffers and self.used_bytes+size > self.max_bytes:
                self._flush(next(iter(self.buffers)))
            self.buffers[cls] = (torch.zeros(shape, device=numerator.device, dtype=numerator.dtype),
                                torch.zeros(shape, device=denominator.device, dtype=denominator.dtype),
                                set(), size)
            self.used_bytes += size
            self.peak_bytes = max(self.peak_bytes, self.used_bytes)
        self.buffers.move_to_end(cls)
        num, den, touched, _ = self.buffers[cls]
        num.index_add_(0, angular_ids, numerator)
        den.index_add_(0, angular_ids, denominator)
        touched.update(host_ids)

    def finish(self):
        while self.buffers:
            self._flush(next(iter(self.buffers)))
        if self.counters is not None:
            self.counters['grouped_peak_bytes'] = max(
                self.counters.get('grouped_peak_bytes', 0), self.peak_bytes)


from dataclasses import dataclass


@dataclass(frozen=True)
class CandidateWorkspace:
    total_bytes: int
    group_cache_bytes: int
    group_flush_reserve_bytes: int
    tile_bytes: int
    bytes_per_class: int
    cached_class_capacity: int


def plan_candidate_workspace(total_bytes, classes, orientations, size, *, grouping=True):
    """Bounded candidate/group-cache workspace with full-K residency priority.

    v0.2.14 capped the persistent class cache at one third of the workspace.
    That is pathological when the capacity becomes ``K-1``: particle batches
    visit classes cyclically and the LRU then flushes essentially every class
    on every batch.  Prefer keeping *all* K class/orientation banks resident
    whenever K banks, one flush copy and a small candidate reserve fit.  If a
    full-K cache cannot fit, retain the historical one-third policy rather than
    silently overcommitting memory.  Particle count never enters this budget.
    """
    total=max(1,int(total_bytes))
    classes=max(0,int(classes))
    per_class=int(orientations)*int(size)*(int(size)//2+1)*12  # c64 + f32
    capacity=0
    if grouping and per_class>0 and classes>0:
        # Preserve at least 8 MiB (or 1/16 of a smaller workspace) for candidate
        # execution.  The flush reserve is an additional complete class bank.
        minimum_tile=min(total//4, max(1, min(8*1024**2, total//16)))
        full_need=(classes+1)*per_class + minimum_tile
        if full_need <= total:
            capacity=classes
        else:
            capacity=min(classes,(total//3)//per_class)
    cache=capacity*per_class
    flush=per_class if capacity else 0
    return CandidateWorkspace(total,cache,flush,max(1,total-cache-flush),per_class,capacity)


@dataclass(frozen=True)
class WeightGroupPlan:
    rows: torch.Tensor
    angular_ids: torch.Tensor
    translation_ids: torch.Tensor
    slots: torch.Tensor
    representatives: torch.Tensor
    groups: int
    translations: int


def candidate_schedule_with_weights(class_values, orientation_values, particle_values,
                                    translation_values, tile_size, children, device):
    """Bounded CPU metadata plans; ALL integer indices use one device transfer.

    Unlike a full N*K*O*T posterior rectangle, each class/tile forms only a
    local (particle,orientation) x touched-translation block. Skip the plan
    when grouping saves few rows or creates an excessively empty rectangle.
    """
    pieces=[]; metadata=[]; offset=0
    def add(values):
        nonlocal offset
        a=np.asarray(values,dtype=np.int64).reshape(-1)
        span=(offset,offset+len(a));offset+=len(a);pieces.append(a)
        return span
    stride=int(np.max(orientation_values,initial=0))+1
    for start in range(0,len(class_values),tile_size):
        end=start+tile_size
        cls=class_values[start:end];ori=orientation_values[start:end]
        rows=particle_values[start:end];trans=translation_values[start:end]
        groups=[]
        for c in np.unique(cls):
            selected=np.flatnonzero(cls==c)
            select_span=add(selected)
            touched=np.unique(ori[selected])
            host=tuple(map(int,(touched[:,None]*children+np.arange(children)[None]).reshape(-1)))
            keys=rows[selected]*stride+ori[selected]
            _,first,gindex=np.unique(keys,return_index=True,return_inverse=True)
            tr,tindex=np.unique(trans[selected],return_inverse=True)
            ng=len(first);nt=len(tr)
            plan=None
            if len(selected)>=2*ng and ng*nt<=4*len(selected):
                row_span=add(rows[selected[first]])
                angular_span=add(ori[selected[first],None]*children+np.arange(children)[None])
                trans_span=add(tr)
                slot_span=add(gindex*nt+tindex)
                representative_span=add(first)
                plan=(row_span,angular_span,trans_span,slot_span,representative_span,ng,nt)
            groups.append((int(c),select_span,host,plan))
        metadata.append(groups)
    host=np.concatenate(pieces) if pieces else np.empty(0,dtype=np.int64)
    flat=torch.as_tensor(host,device=device,dtype=torch.long)
    def get(span):return flat[span[0]:span[1]]
    schedules=[]
    for groups in metadata:
        row=[]
        for cls,sel,host_ids,p in groups:
            plan=None
            if p is not None:
                rows,angular,tr,slots,reps,ng,nt=p
                plan=WeightGroupPlan(get(rows),get(angular),get(tr),get(slots),get(reps),ng,nt)
            row.append((cls,get(sel),host_ids,plan))
        schedules.append(row)
    return schedules


@dataclass(frozen=True)
class OrientationWeightSums:
    weights: torch.Tensor
    phase_sum: torch.Tensor
    mass: torch.Tensor
    rows: torch.Tensor
    angular_ids: torch.Tensor
    representatives: torch.Tensor


@torch.no_grad()
def coalesced_orientation_weights(weights, plan: WeightGroupPlan, phase_bank):
    """Collect translation children by particle/fine-orientation.

    ``weights`` is the retained parent tile ``[parent, orient_child, trans_child]``.
    The returned matrix is ``[particle-orientation, all fine translations]``.
    Missing coarse parents remain exactly zero.  No normalization or extra
    threshold is applied.  The complex weighted phase is evaluated once and
    can be shared by statistics and backprojection.
    """
    ng, nt = plan.groups, plan.translations
    _, oc, tc = weights.shape
    work = torch.zeros((ng * nt, oc, tc), device=weights.device, dtype=torch.float32)
    work.index_add_(0, plan.slots, weights.to(torch.float32))
    grouped = (work.reshape(ng, nt, oc, tc).permute(0, 2, 1, 3)
               .reshape(ng * oc, nt * tc))
    phase = phase_bank.index_select(0, plan.translation_ids).reshape(nt * tc, -1)
    phase_sum = torch.complex(grouped @ phase.real, grouped @ phase.imag)
    h, w = phase_bank.shape[-2:]
    return OrientationWeightSums(
        weights=grouped,
        phase_sum=phase_sum.reshape(ng * oc, h, w),
        mass=grouped.sum(-1),
        rows=plan.rows.repeat_interleave(oc),
        angular_ids=plan.angular_ids.reshape(-1),
        representatives=plan.representatives,
    )


@torch.no_grad()
def coalesced_weight_contributions(weights, plan: WeightGroupPlan, phase_bank,
                                   unmasked, num_factor, den_factor, inv):
    """Merge translation weights BEFORE creating full Fourier contributions.

    Each group retains one particle's factors. Only the already weighted
    numerator/denominator are later mixed across particles/classes. There is
    no normalization, extra significance threshold, or modification of noise
    residual clipping here.
    """
    state = coalesced_orientation_weights(weights, plan, phase_bank)
    numerator = (
        (state.phase_sum * unmasked.index_select(0, state.rows))
        * (num_factor.index_select(0, state.rows) * inv.index_select(0, state.rows))
    )
    denominator = (
        state.mass[..., None, None]
        * (den_factor.index_select(0, state.rows) * inv.index_select(0, state.rows))
    )
    return numerator,denominator,state.angular_ids


@dataclass
class CompactCandidateSchedule:
    """Contiguous index storage; tensor views are made lazily, one tile at a time."""
    flat: torch.Tensor
    parent_count: int
    descriptors: list
    host_bytes: int
    merged_tiles: int

    def tiles(self):
        for start, stop, cls, touched, spans in self.descriptors:
            plan = None
            if spans is not None:
                rs, aa, tr, sl, rp, ng, nt = spans
                view = lambda ab: self.flat[ab[0]:ab[1]]
                plan = WeightGroupPlan(view(rs), view(aa), view(tr), view(sl), view(rp), ng, nt)
            yield self.flat[start:stop], [(cls, slice(None), touched, plan)]


def compact_schedule_host(packed, nonzero_counts, shape, tile_size, children, *,
                          with_weights=True, diagnostics=None):
    """Group once by class/orientation/particle, preserving translation order.

    Input is ONE encoded integer per parent, not four int64 arrays. No unique
    or inverse-index sort is repeated for each tile. Group boundaries guide
    tiling; parent groups larger than the workspace are safely split.
    No posterior value or significance threshold is changed.
    """
    batch, classes, orientations, translations = map(int, shape)
    packed = np.asarray(packed)
    counts = np.asarray(nonzero_counts)
    if packed.ndim != 1 or counts.shape != packed.shape or tile_size < 1:
        raise ValueError('invalid compact candidate schedule inputs')
    keep = np.flatnonzero(counts).astype(np.int64, copy=False)
    if len(keep) == 0:
        return np.empty(0, dtype=np.int64), [], 0, 0
    code = packed[keep].astype(np.int64, copy=False)
    if code.min() < 0 or code.max() >= batch*classes*orientations*translations:
        raise ValueError('encoded parent outside coarse candidate shape')
    grid_elements=batch*classes*orientations*translations
    # Dense parent lists already follow coarse-grid order. A bounded integer
    # lookup/transpose avoids a multi-million-row sort; holes stay exactly -1.
    # Two int32 grid buffers together must fit 64 MiB. Never allocate by total N.
    regular = (grid_elements <= np.iinfo(np.int32).max and
               8*grid_elements <= 64*1024**2 and
               len(keep)*2 >= grid_elements and
               (len(code)<2 or bool(np.all(code[1:]>code[:-1]))))
    if regular:
        grid=np.full(grid_elements,-1,dtype=np.int32)
        grid[code]=keep
        arranged=grid.reshape(batch,classes,orientations,translations).transpose(1,2,0,3).reshape(-1)
        position=np.flatnonzero(arranged>=0)
        keep=arranged[position].astype(np.int64)
        del grid,arranged,code
        key=position//translations;tr=position%translations
        del position
        particle=key%batch; co=key//batch
        ori=co%orientations;cls=co//orientations
    else:
        tr = code % translations
        co = code // translations
        ori = co % orientations
        cp = co // orientations
        cls, particle = cp % classes, cp // classes
        key = (cls*orientations+ori)*batch+particle
        order = np.argsort(key, kind='stable')
        keep, key, cls, ori, particle, tr = (v[order] for v in (keep, key, cls, ori, particle, tr))
    if diagnostics is not None:
        diagnostics['regular_layout']=int(regular)
        diagnostics['regular_grid_buffer_bytes']=8*grid_elements if regular else 0
    n = len(keep)
    group_starts = np.r_[0, np.flatnonzero(key[1:] != key[:-1])+1, n]
    class_starts = np.r_[0, np.flatnonzero(cls[1:] != cls[:-1])+1, n]
    # Only integer metadata is retained, in one compact host/device buffer.
    pieces = [keep]; offset = n
    def add(a):
        nonlocal offset
        a = np.asarray(a, dtype=np.int64).reshape(-1)
        span = (offset, offset+len(a)); pieces.append(a); offset += len(a)
        return span
    trans_span = None  # lazy: sparse/large translation grids must not allocate unused tables
    descriptors = []; merged = 0
    for first, class_stop in zip(class_starts[:-1], class_starts[1:]):
        start = int(first); c = int(cls[start])
        while start < class_stop:
            end = min(start+int(tile_size), int(class_stop))
            if end < class_stop:
                boundary = int(group_starts[np.searchsorted(group_starts, end, side='right')-1])
                if boundary > start:
                    end = boundary
            a = np.searchsorted(group_starts, start, side='right')
            z = np.searchsorted(group_starts, end, side='left')
            beginnings = np.r_[start, group_starts[a:z]]
            endings = np.r_[beginnings[1:], end]
            ng = len(beginnings); count = end-start
            # Sorted orientation IDs: adjacent comparison, NOT np.unique/sort.
            touched_ori = ori[beginnings]
            touched_ori = touched_ori[np.r_[True, touched_ori[1:] != touched_ori[:-1]]]
            touched = tuple(map(int, (touched_ori[:,None]*children+np.arange(children)[None]).reshape(-1)))
            plan = None
            # Launch-aware policy: strong compression and reasonably dense
            # fixed translation rectangles, otherwise use shared-phase path.
            if with_weights and count >= max(128, 8*ng) and ng*translations <= 2*count:
                if trans_span is None:
                    trans_span=add(np.arange(translations))
                gindex = np.repeat(np.arange(ng), endings-beginnings)
                row_span = add(particle[beginnings])
                angular_span = add(ori[beginnings,None]*children+np.arange(children)[None])
                slots_span = add(gindex*translations+tr[start:end])
                representative_span = add(beginnings-start)
                plan = (row_span, angular_span, trans_span, slots_span, representative_span, ng, translations)
                merged += 1
            descriptors.append((start, end, c, touched, plan))
            start = end
    return np.concatenate(pieces), descriptors, n, merged
