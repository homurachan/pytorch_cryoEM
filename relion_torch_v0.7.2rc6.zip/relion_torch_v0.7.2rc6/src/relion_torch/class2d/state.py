"""Continuation discovery and state restoration for Class2D."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any

import mrcfile
import numpy as np
import torch

from relion_torch.io.mrc import write_mrc
from relion_torch.io.star import read_star
from relion_torch.relion_statistics import resolution_shell_from_data_vs_prior


@dataclass(slots=True)
class ContinuationState:
    data_star: Path
    model_star: Path
    references: list[str | Path]
    iteration: int
    sigma_offset_angstrom: float | None
    class_probabilities: np.ndarray | None
    group_scale_corrections: np.ndarray | None
    group_noise: list[np.ndarray]
    tau2: list[np.ndarray]
    sigma2_class: list[np.ndarray]
    data_vs_prior: list[np.ndarray]
    fourier_coverage: list[np.ndarray]
    average_norm_correction: float | None


def _find_block(blocks: dict[str, Any], fragment: str) -> Any | None:
    fragment = fragment.lower()
    for name, table in blocks.items():
        if fragment in str(name).lower():
            return table
    return None


def _column(table: Any, label: str) -> Any | None:
    if table is None:
        return None
    canonical = label.lstrip("_")
    for candidate in (canonical, "_" + canonical):
        if candidate in table:
            return table[candidate]
    return None


def _scalar(table: Any, label: str) -> float | None:
    values = _column(table, label)
    if values is None or len(values) == 0:
        return None
    value = float(values.iloc[0] if hasattr(values, "iloc") else values[0])
    return value if np.isfinite(value) else value


def _resolve_model_reference(
    value: str,
    model_path: Path,
    output_root: Path,
    class_index: int,
) -> str | Path:
    if "@" in value:
        index_text, stack_name = value.split("@", 1)
        index0 = int(index_text) - 1
        stack = Path(stack_name)
        probes = [stack, model_path.parent / stack, Path.cwd() / stack]
        source = next((probe.resolve() for probe in probes if probe.is_file()), None)
        if source is None:
            raise FileNotFoundError(f"Cannot resolve continuation stack {stack_name!r}")
        if index0 < 0:
            raise ValueError(f"Invalid continuation reference {value!r}")
        # Validate data shape/index while reading it once in the shared loader.
        return f"{index0 + 1:06d}@{source}"
    candidate = Path(value)
    for probe in (candidate, model_path.parent / candidate, Path.cwd() / candidate):
        if probe.is_file():
            return probe.resolve()
    raise FileNotFoundError(f"Cannot resolve continuation reference {value!r}")


def discover_continuation(
    prefix_or_model: str | Path,
    output_root: str | Path,
) -> ContinuationState:
    supplied = Path(prefix_or_model).expanduser()
    if supplied.name.endswith("_model.star"):
        model_path = supplied.resolve()
    else:
        parent = supplied.parent if str(supplied.parent) not in ("", ".") else Path.cwd()
        pattern = supplied.name + "_it*_model.star"
        candidates = sorted(parent.glob(pattern))
        if not candidates:
            raise FileNotFoundError(f"No continuation model matches {supplied}_itNNN_model.star")
        model_path = candidates[-1].resolve()
    match = re.search(r"_it(\d+)_model\.star$", model_path.name)
    if match is None:
        raise ValueError("Continuation model must end in _itNNN_model.star")
    iteration = int(match.group(1))
    data_path = Path(str(model_path)[: -len("_model.star")] + "_data.star")
    if not data_path.is_file():
        raise FileNotFoundError(data_path)
    blocks = read_star(model_path)
    general = _find_block(blocks, "model_general")
    classes = _find_block(blocks, "model_classes")
    if general is None or classes is None:
        raise ValueError(f"Incomplete model STAR: {model_path}")
    refs_column = _column(classes, "rlnReferenceImage")
    if refs_column is None:
        raise ValueError("Continuation model has no rlnReferenceImage")
    references = [
        _resolve_model_reference(str(value), model_path, Path(output_root), index)
        for index, value in enumerate(refs_column.astype(str).tolist(), start=1)
    ]
    class_probability = _column(classes, "rlnClassDistribution")
    group_table = _find_block(blocks, "model_groups")
    group_scale = _column(group_table, "rlnGroupScaleCorrection")

    group_noise: list[np.ndarray] = []
    class_tau2: list[np.ndarray] = []
    class_sigma2: list[np.ndarray] = []
    class_dvp: list[np.ndarray] = []
    class_coverage: list[np.ndarray] = []
    group_index = 1
    while True:
        table = _find_block(blocks, f"model_group_{group_index}")
        if table is None:
            break
        values = _column(table, "rlnSigma2Noise")
        if values is not None:
            group_noise.append(np.asarray(values, dtype=np.float64))
        group_index += 1
    class_index = 1
    while True:
        table = _find_block(blocks, f"model_class_{class_index}")
        if table is None:
            break
        for destination, label in (
            (class_dvp, "rlnSsnrMap"),
            (class_coverage, "rlnFourierCompleteness"),
            (class_sigma2, "rlnReferenceSigma2"),
            (class_tau2, "rlnReferenceTau2"),
        ):
            values = _column(table, label)
            destination.append(
                np.asarray(values, dtype=np.float64)
                if values is not None
                else np.asarray([], dtype=np.float64)
            )
        class_index += 1
    probabilities = (
        None
        if class_probability is None
        else np.asarray(class_probability, dtype=np.float64)
    )
    scales = None if group_scale is None else np.asarray(group_scale, dtype=np.float64)
    return ContinuationState(
        data_star=data_path.resolve(),
        model_star=model_path,
        references=references,
        iteration=iteration,
        sigma_offset_angstrom=_scalar(general, "rlnSigmaOffsetsAngst"),
        class_probabilities=probabilities,
        group_scale_corrections=scales,
        group_noise=group_noise,
        tau2=class_tau2,
        sigma2_class=class_sigma2,
        data_vs_prior=class_dvp,
        fourier_coverage=class_coverage,
        average_norm_correction=_scalar(general, "rlnNormCorrectionAverage"),
    )


def _copy_spectrum(source: np.ndarray, target: torch.Tensor) -> torch.Tensor:
    value = torch.as_tensor(source, device=target.device, dtype=target.dtype).reshape(-1)
    if value.numel() == 0:
        return target.clone()
    if value.numel() < target.numel():
        value = torch.nn.functional.pad(
            value,
            (0, target.numel() - value.numel()),
            value=float(value[-1].item()),
        )
    return value[: target.numel()].clone()


def install_state(optimiser: Any, state: ContinuationState) -> None:
    if state.sigma_offset_angstrom is not None:
        optimiser.sigma_offset_angstrom = float(state.sigma_offset_angstrom)
    if state.class_probabilities is not None:
        probabilities = torch.as_tensor(
            state.class_probabilities,
            device=optimiser.device,
            dtype=optimiser.class_prob.dtype,
        )
        if probabilities.numel() != optimiser.class_prob.numel():
            raise ValueError("Continuation class count does not match optimiser")
        total = probabilities.sum()
        if float(total.item()) > 0.0:
            optimiser.class_prob = probabilities / total
    if len(state.group_noise) == len(optimiser.sigma2):
        optimiser.sigma2 = [
            _copy_spectrum(source, target)
            for source, target in zip(state.group_noise, optimiser.sigma2)
        ]
    for attribute, values in (
        ("tau2", state.tau2),
        ("sigma2_class", state.sigma2_class),
        ("data_vs_prior", state.data_vs_prior),
        ("fourier_coverage", state.fourier_coverage),
    ):
        targets = getattr(optimiser, attribute, None)
        if targets is not None and len(values) == len(targets):
            setattr(
                optimiser,
                attribute,
                [_copy_spectrum(source, target) for source, target in zip(values, targets)],
            )
    if state.data_vs_prior and len(state.data_vs_prior) == len(optimiser.data_vs_prior):
        optimiser.psnr_shell = optimiser._safe_psnr_shell(optimiser.data_vs_prior)
        optimiser._refresh_fourier_sizes()
    if hasattr(optimiser, "group_scale_correction") and state.group_scale_corrections is not None:
        value = torch.as_tensor(
            state.group_scale_corrections,
            device=optimiser.device,
            dtype=optimiser.group_scale_correction.dtype,
        )
        if value.numel() == optimiser.group_scale_correction.numel():
            optimiser.group_scale_correction = value.clone()
    if hasattr(optimiser, "average_norm_correction") and state.average_norm_correction is not None:
        optimiser.average_norm_correction = float(state.average_norm_correction)


def read_native_optimiser_options(config):
    """Restore scientific flags from a native/legacy optimiser STAR where present."""
    from dataclasses import replace
    supplied=Path(config.continue_from).expanduser().resolve()
    opt_path=supplied if supplied.name.endswith('_optimiser.star') else Path(str(supplied).replace('_model.star','_optimiser.star'))
    model=supplied
    if opt_path.is_file() and opt_path.name.endswith('_optimiser.star'):
        blocks=read_star(opt_path); general=next(iter(blocks.values())).iloc[0]
        if 'rlnModelStarFile' in general:
            model=Path(str(general['rlnModelStarFile']))
            if not model.is_file():
                model=opt_path.parent/model
        aliases={
            'debug_dimensionally_consistent_prior':('rlnTorchDebugDimensionallyConsistentPrior',bool),
            'translation_prior_normalization':('rlnTorchTranslationPriorNormalization',str),
            'do_norm_correction':('rlnDoCorrectNorm',bool),
            'do_scale_correction':('rlnDoCorrectScale',bool),
            'use_ctf':('rlnDoCorrectCtf',bool),
            'ctf_corrected_ref':('rlnCtfCorrectedReference',bool),
            'flatten_solvent':('rlnDoSolventFlattening',bool),
            'firstiter_cc':('rlnDoFirstIterCC',bool),
            'oversampling':('rlnAdaptiveOversampleOrder',int),
            'adaptive_fraction':('rlnAdaptiveOversampleFraction',float),
            'particle_diameter_angstrom':('rlnParticleDiameter',float),
            'mask_edge_pixels':('rlnWidthMaskEdge',float),
            'random_seed':('rlnRandomSeed',int),
            'skip_align':('rlnDoSkipAlign',bool),
            'minres_map':('rlnMinResolutionMap',int),
            'zero_mask':('rlnDoZeroMask',bool),
            'ctf_phase_flipped':('rlnCtfDataArePhaseFlipped',bool),
            'only_flip_phases':('rlnDoOnlyFlipCtfPhases',bool),
            'intact_first_peak':('rlnDoIgnoreCtfUntilFirstPeak',bool),
            'auto_sampling':('rlnUseTooCoarseSampling',bool),
        }
        values={key:cast(general[label]) for key,(label,cast) in aliases.items() if label in general}
        # Native names used by ver3.1 differ for several historical labels.
        native={'rlnDoCorrectNorm':'do_norm_correction','rlnDoCorrectScale':'do_scale_correction',
                'rlnRefsAreCtfCorrected':'ctf_corrected_ref','rlnDoSolventFlatten':'flatten_solvent',
                'rlnDoFirstIterCC':'firstiter_cc'}
        values.update({dest:bool(general[src]) for src,dest in native.items() if src in general})
        for label,field in [('rlnSolventMaskName','solvent_mask'),('rlnSolventMask2Name','solvent_mask2')]:
            if label in general and str(general[label]) not in ('None','none','?','.'):
                path=Path(str(general[label]))
                if not path.is_file(): path=opt_path.parent/path
                values[field]=path
        if config.fast_subsets is None:
            for label in ('rlnDoFastSubsetOptimisation','rlnDoFastSubsets'):
                if label in general:
                    values['fast_subsets']=bool(int(general[label]))
                    break
        config=replace(config,**values)
    if model.is_file() and model.name.endswith('_model.star'):
        general=read_star(model)['model_general'].iloc[0]
        updates={}
        for label,field in [('rlnTau2FudgeFactor','tau2_fudge'),('rlnPaddingFactor','padding_factor')]:
            if label in general: updates[field]=float(general[label])
        config=replace(config,**updates)
    return config,model


def install_class2d_extra_state(optimiser,state):
    blocks=read_star(state.model_star)
    classes=blocks['model_classes']
    if 'rlnClassPriorOffsetX' in classes and 'rlnClassPriorOffsetY' in classes:
        optimiser.class_offsets=torch.tensor(classes[['rlnClassPriorOffsetX','rlnClassPriorOffsetY']].to_numpy(),
                                             device=optimiser.device,dtype=torch.float64)
    if state.group_scale_corrections is not None:
        optimiser.group_scales=torch.as_tensor(state.group_scale_corrections,device=optimiser.device,dtype=torch.float64)
    if state.average_norm_correction is not None:
        optimiser.avg_norm_correction=float(state.average_norm_correction)
    optimiser.last_completed_iteration=state.iteration
    sample=Path(str(state.model_star).replace('_model.star','_sampling.star'))
    if sample.is_file():
        general=next(iter(read_star(sample).values())).iloc[0]
        def val(names,default):
            return next((float(general[x]) for x in names if x in general),default)
        optimiser.original_psi_step=val(('rlnPsiStepOriginal','rlnPsiStepOri'),optimiser.original_psi_step)
        optimiser.original_offset_step=val(('rlnOffsetStepOriginal','rlnOffsetStepOri'),optimiser.original_offset_step)
        optimiser.original_offset_range=val(('rlnOffsetRangeOriginal','rlnOffsetRangeOri'),optimiser.original_offset_range)
        optimiser.options.perturbation_factor=val(('rlnSamplingPerturbFactor',),optimiser.options.perturbation_factor)
        optimiser._replace_sampling(val(('rlnPsiStep',),optimiser.sampling.actual_psi_step),
            val(('rlnOffsetStep',),optimiser.sampling.offset_step),
            q=val(('rlnSamplingPerturbInstance',),0.0))
    optimiser._refresh_fourier_sizes()
