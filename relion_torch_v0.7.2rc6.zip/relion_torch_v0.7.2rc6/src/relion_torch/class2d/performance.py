"""Execution-only Class2D utilities; no scientific state or sampling changes."""
from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
import json
from pathlib import Path
import time
from typing import Iterable

import torch


class StageTimer:
    """Optional synchronized wall timing, not unsynchronized CUDA launch timing.

    Synchronize only at coarse stage boundaries, never at each hypothesis or
    backprojection tile. With timing disabled, no new synchronization is made.
    """
    def __init__(self, enabled: bool, device):
        self.enabled = bool(enabled)
        self.device = torch.device(device)
        self.seconds: dict[str, float] = defaultdict(float)
        self.calls: dict[str, int] = defaultdict(int)

    def _sync(self):
        if self.enabled and self.device.type == 'cuda':
            torch.cuda.synchronize(self.device)

    @contextmanager
    def section(self, name: str):
        if not self.enabled:
            yield
            return
        self._sync()
        started = time.perf_counter()
        try:
            yield
        finally:
            self._sync()
            self.seconds[name] += time.perf_counter() - started
            self.calls[name] += 1

    def call(self, name, function, *args, **kwargs):
        with self.section(name):
            return function(*args, **kwargs)

    def batches(self, iterable: Iterable):
        iterator = iter(iterable)
        while True:
            with self.section('read_and_device_pool'):
                try:
                    value = next(iterator)
                except StopIteration:
                    return
            yield value

    def write(self, root, *, iteration, total_seconds, counters, mode, details=None, memory=None, subset=None):
        if not self.enabled:
            return
        path = Path(f'{root}_timing.jsonl')
        record = dict(iteration=int(iteration), performance_mode=mode,
                      total_seconds=float(total_seconds), seconds=dict(self.seconds),
                      calls=dict(self.calls), counters=counters)
        record['timing_schema_version'] = 4 if hasattr(self,'distributed') else 3
        if hasattr(self,'distributed'):record['distributed']=self.distributed
        record['details'] = details or {}
        record['subset'] = subset or {}
        record['memory'] = memory or {}
        record['detail_semantics'] = 'sampled_* fields are bounded first-call samples except all-batch schedules; total_* fields, when present, cover all calls; host/CUDA intervals overlap enclosing stages and each other, do not sum; stream intervals are not kernel busy time'
        record['other_seconds'] = max(0., total_seconds - sum(self.seconds.values()))
        with path.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + '\n')
        summary = ', '.join(f'{key}={value:.3f}s' for key, value in self.seconds.items())
        print(f'  [timing] total={total_seconds:.3f}s; {summary}; other={record["other_seconds"]:.3f}s')
        print(f'  [timing] {path}')


def class_selection_schedule(classes: list[int], tile_size: int, device):
    """One host grouping and one H2D transfer per particle batch, not per tile.

    Sorted class order and increasing within-class row order exactly reproduce
    torch.unique(classes), then boolean selection, in the 0.2.7 accumulator.
    The returned indices are local to each row tile (not global particle IDs).
    """
    locations: list[int] = []
    metadata: list[list[tuple[int, int, int]]] = []
    for start in range(0, len(classes), tile_size):
        by_class: dict[int, list[int]] = defaultdict(list)
        for local, cls in enumerate(classes[start:start + tile_size]):
            by_class[int(cls)].append(local)
        groups = []
        for cls in sorted(by_class):
            offset = len(locations)
            locations.extend(by_class[cls])
            groups.append((cls, offset, len(locations)))
        metadata.append(groups)
    indices = torch.tensor(locations, dtype=torch.long, device=device)
    return [[(cls, indices[a:b]) for cls, a, b in groups] for groups in metadata]


class DetailTimer:
    """Bounded samples, never a CUDA synchronization inside a candidate loop.

    Host submission and CUDA stream intervals are separate and are NOT added
    to coarse wall seconds. CUDA intervals may include launch/idle gaps and
    are not a kernel-only busy-time measurement. First max_samples calls of
    each tile category are sampled; schedule categories cover all batches.
    Extrapolation is deliberately not reported.
    """
    def __init__(self, enabled, device, max_samples=32):
        self.enabled=bool(enabled) and max_samples>0
        self.device=torch.device(device)
        self.max_samples=int(max_samples)
        self.observed=defaultdict(int)
        self.samples=defaultdict(list)
        self.totals=defaultdict(lambda: [0,0.,0.])
        self.pending=[]

    def start(self,name,*,full=False):
        if not self.enabled:
            return None
        self.observed[name]+=1
        sampled=self.observed[name]<=self.max_samples or name.startswith('accumulate.schedule')
        if not sampled and not full:
            return None
        event=None
        if self.device.type=='cuda':
            event=torch.cuda.Event(enable_timing=True)
            event.record(torch.cuda.current_stream(self.device))
        return name,time.perf_counter(),event,sampled,full

    def stop(self,token):
        if token is None:
            return
        name,start,event,sampled,full=token
        host=time.perf_counter()-start
        end=None
        if event is not None:
            end=torch.cuda.Event(enable_timing=True)
            end.record(torch.cuda.current_stream(self.device))
        if sampled:self.samples[name].append((host,event,end))
        if full:
            self.totals[name][0]+=1
            self.totals[name][1]+=host
            if event is not None:self.pending.append((name,event,end))

    @contextmanager
    def section(self,name,*,full=False):
        token=self.start(name,full=full)
        try:
            yield
        finally:
            self.stop(token)

    def flush_totals(self,*,synchronized=False):
        """Release per-batch events after existing coarse stage synchronization.

        Never introduce a CUDA wait inside a tile. Unready pairs remain owned.
        """
        pending=[]
        for name,start,end in self.pending:
            if synchronized or end.query():self.totals[name][2]+=start.elapsed_time(end)/1000.
            else:pending.append((name,start,end))
        self.pending=pending

    def report(self):
        if not self.enabled:
            return {}
        if self.device.type=='cuda':
            # One iteration-boundary wait, never one per hypothesis.
            torch.cuda.synchronize(self.device)
        self.flush_totals(synchronized=True)
        result={name:dict(observed_calls=self.observed[name],sampled_calls=len(samples),
                    sampling_policy=('all_batches' if name.startswith('accumulate.schedule') else 'bounded_first_calls'),
                    sampled_host_seconds=sum(v[0] for v in samples),
                    sampled_cuda_stream_seconds=(sum(v[1].elapsed_time(v[2]) for v in samples)/1000.
                        if self.device.type=='cuda' else None))
                for name,samples in self.samples.items()}
        for name,(count,host,cuda) in self.totals.items():
            result.setdefault(name,dict(observed_calls=self.observed[name],sampled_calls=0))
            result[name].update(total_timed_calls=count,total_host_seconds=host,
                                total_cuda_stream_seconds=cuda if self.device.type=='cuda' else None,
                                total_timing_policy='all_calls; overlaps enclosing stages; stream time is not kernel busy time')
        return result


class StartupContext:
    """Startup-only timings and one-shot spectra; never owns all particle FFTs."""
    def __init__(self, enabled, device):
        self.timer = StageTimer(enabled, device)
        self.timer._sync()
        self.started = time.perf_counter()
        self.counters = {}
        self.noise_spectra = None
        self.noise_group_ids = None
        self.written = False
        self.mode = 'batched'

    def finish(self, root, *, continued=False):
        if self.written:
            return
        self.written = True
        self.timer._sync()
        elapsed = time.perf_counter()-self.started
        if not self.timer.enabled:
            return
        data = dict(timing_schema_version=3, phase='startup', continued=bool(continued),
                    initialization_mode=self.mode, total_seconds=elapsed,
                    seconds=dict(self.timer.seconds),calls=dict(self.timer.calls),counters=self.counters,
                    other_seconds=max(0.,elapsed-sum(self.timer.seconds.values())),
                    timing_semantics='exclusive synchronized startup stages; excludes imports/CLI parse and all EM iterations')
        path = Path(f'{root}_startup_timing.json')
        tmp = path.with_suffix(path.suffix+'.tmp')
        tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        tmp.replace(path)
        print(f'[startup timing] total={elapsed:.3f}s; {path}',flush=True)
