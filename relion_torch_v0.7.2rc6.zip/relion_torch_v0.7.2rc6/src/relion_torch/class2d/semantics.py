"""RELION 3.1 Class2D model updates, independent of the execution backend.

Source: 3dem/relion ver3.1, ml_optimiser.cpp (maximizationOtherParameters,
storeWeightedSums, solventFlatten, updateAngularSampling). No damping or
posterior-temperature correction is introduced here.
"""
from __future__ import annotations

import math
from dataclasses import replace
import numpy as np
import torch

from relion_torch.sampling.relion_sampling import RelionSampling, FineSamplingTable


def translation_prior_centres(old_offset_pixels: torch.Tensor,
                              class_offset_values: torch.Tensor,
                              pixel_size: float, *,
                              dimensionally_consistent: bool = False) -> torch.Tensor:
    """Return [B,K,2] centres for the prior-distance calculation only.

    Native ver3.1 (CPU and CUDA) combines rounded old pixel offsets with
    Angstrom-valued sampling translations and the stored class-offset numbers,
    then multiplies the squared distance by pixel_size**2.  These deliberately
    historical units must NOT propagate into Fourier phases or output origins.

    In the debug mode, stored class offsets are interpreted in Angstroms:
    distance = old_pixels * pixel_size + translation_A - class_offset_A.
    """
    pixel = float(pixel_size)
    if not math.isfinite(pixel) or pixel <= 0:
        raise ValueError("pixel_size must be finite and positive")
    old = old_offset_pixels.to(dtype=torch.float64)
    means = class_offset_values.to(device=old.device, dtype=torch.float64)
    if old.ndim != 2 or old.shape[-1] != 2 or means.ndim != 2 or means.shape[-1] != 2:
        raise ValueError("expected old offsets [B,2] and class offsets [K,2]")
    class_centres = means if dimensionally_consistent else means * pixel
    return class_centres[None] - old[:, None] * pixel


def coarse_translation_prior_coordinates(translations_angstrom: torch.Tensor,
                                         pixel_size: float, *,
                                         dimensionally_consistent: bool = False) -> torch.Tensor:
    """Numeric sampling operand for a coarse prior; never a physical shift.

    Paired with translation_prior_centres this gives native
    pixel**2 * |old_pixels + sampling_translation_A - stored_class_offset|**2.
    The debug mode instead uses a distance with consistent Angstrom units.
    A --skip-align residual is not this sampling grid and must not pass here.
    """
    pixel = float(pixel_size)
    if not math.isfinite(pixel) or pixel <= 0:
        raise ValueError("pixel_size must be finite and positive")
    translations = translations_angstrom.to(dtype=torch.float64)
    return translations if dimensionally_consistent else translations * pixel


def class_translation_log_prior(translations, centres, sigma, probabilities,
                                allowed=None, *, normalization="gpu"):
    """Joint class/translation log-priors under an explicit backend convention.

    Inputs are already in the selected prior-distance coordinates, NOT
    necessarily physical Angstroms in native compatibility mode.

    GPU: log(pdf_class) - distance**2/(2*sigma_A**2), with no Gaussian
    prefactor or mean normalization, matching ver3.1 acc_ml_optimiser_impl.h.
    CPU: retain ver3.1's joint class/coarse-translation mean normalization.
    These conventions differ by a per-particle constant, so relative posterior
    weights agree but absolute evidence/DLL need not. Fine children inherit
    the coarse log-prior unchanged in both modes.
    """
    if normalization not in ("gpu", "cpu"):
        raise ValueError("translation-prior normalization must be 'gpu' or 'cpu'")
    if not math.isfinite(float(sigma)) or float(sigma) < 0:
        raise ValueError("sigma must be finite and non-negative")
    centres = centres.to(torch.float64)
    if centres.ndim != 3 or centres.shape[-1] != 2:
        raise ValueError("centres must have shape [B,K,2]")
    b, k, _ = centres.shape
    translations = translations.to(device=centres.device, dtype=torch.float64)
    if translations.ndim == 2:
        translations = translations[None].expand(b, -1, -1)
    if translations.ndim != 3 or translations.shape[0] != b or translations.shape[-1] != 2:
        raise ValueError("translations must have shape [T,2] or [B,T,2]")
    if translations.shape[1] == 0 or k == 0:
        raise ValueError("a prior needs at least one class and one translation")
    probabilities = probabilities.to(device=centres.device, dtype=torch.float64)
    if probabilities.shape != (k,):
        raise ValueError("class probabilities must have shape [K]")
    dist2 = (translations[:, None] - centres[:, :, None]).square().sum(-1)
    selected = torch.ones((b, k), device=centres.device, dtype=torch.bool)
    if allowed is not None:
        allowed = allowed.to(device=centres.device, dtype=torch.long)
        if allowed.shape != (b,) or bool(((allowed < 0) | (allowed >= k)).any()):
            raise ValueError("allowed_classes must contain one valid class index per particle")
        selected = torch.arange(k, device=centres.device)[None] == allowed[:, None]
    if float(sigma) ** 2 < 0.0001:
        raw_log = torch.where(dist2 == 0, 0.0, -torch.inf)
    else:
        raw_log = -dist2 / (2.0 * float(sigma) ** 2)
    class_log = torch.where(probabilities > 0, torch.log(probabilities), -torch.inf)
    if normalization == "gpu":
        return (raw_log + class_log[None, :, None]).masked_fill(~selected[..., None], -torch.inf)
    normalizer = torch.logsumexp(
        raw_log.masked_fill(~selected[..., None], -torch.inf).flatten(1), -1
    ) - torch.log(selected.sum(-1).to(torch.float64) * dist2.shape[-1])
    # Upstream CPU leaves the PDF unchanged if its mean is zero.
    normalizer = torch.where(torch.isfinite(normalizer), normalizer, 0.0)
    trans_log = raw_log - normalizer[:, None, None]
    mean_p = (probabilities[None] * selected).sum(-1) / selected.sum(-1)
    log_mean_p = torch.where(mean_p > 0, torch.log(mean_p), 0.0)
    result = trans_log + class_log[None, :, None] - log_mean_p[:, None, None]
    return result.masked_fill(~selected[..., None], -torch.inf)


def gpu_prior_weight_selection_batch(log_prior, diff2, adaptive_fraction):
    """GPU-style combined-log stabilization with float64 model reductions.

    ver3.1 CUDA adds orientation log-prior and offset log-prior to the
    relative likelihood, then exponentiates after making the maximum 50.
    In particular it does NOT first exponentiate an arbitrarily small prior,
    nor reject a hypothesis solely because its residual gap exceeds 700.
    Retain this project's float64 statistics rather than emulate GPU FP32
    underflow. The shared threshold/tie-selection implementation is unchanged.
    """
    from relion_torch.inference.alignment import (
        RelionWeightSelection, _relion_threshold_from_raw_weights,
    )
    if log_prior.shape != diff2.shape or diff2.ndim < 1 or diff2.shape[-1] == 0:
        raise ValueError("prior and residual arrays must have the same nonempty hypothesis shape")
    shape = diff2.shape
    prior = log_prior.reshape(-1, shape[-1]).to(torch.float64)
    residual = diff2.reshape_as(prior).to(torch.float64)
    valid = torch.isfinite(prior) & torch.isfinite(residual)
    if not bool(valid.any(-1).all()):
        raise RuntimeError("at least one particle has no finite hypothesis")
    minimum = residual.masked_fill(~valid, torch.inf).min(-1).values
    log_raw = (prior - (residual - minimum[:, None])).masked_fill(~valid, -torch.inf)
    maximum = log_raw.max(-1).values
    raw = torch.exp(log_raw - maximum[:, None] + 50.0)
    significant, count, threshold, total = _relion_threshold_from_raw_weights(raw, adaptive_fraction)
    total_flat = total.reshape(-1)
    if not bool((torch.isfinite(total_flat) & (total_flat > 0)).all()):
        raise RuntimeError("zero or non-finite sum of GPU-style RELION weights")
    posterior64 = raw / total_flat[:, None]
    best = raw.argmax(-1)
    pmax = posterior64.gather(1, best[:, None]).squeeze(1)
    evidence = torch.log(total_flat) - 50.0 + maximum - minimum
    lead = shape[:-1]
    return RelionWeightSelection(
        posterior=posterior64.to(diff2.dtype).reshape(shape),
        posterior64=posterior64.reshape(shape), significant=significant.reshape(shape),
        reported_significant_count=count.reshape(lead), significant_weight=threshold.reshape(lead),
        sumweight=total.reshape(lead), log_evidence=evidence.reshape(lead),
        best_index=best.reshape(lead), pmax=pmax.reshape(lead),
    )


def update_group_scales(xa, aa, particle_counts):
    """Upper-median 5x clipping followed by particle-count mean normalization."""
    xa, aa = xa.to(torch.float64), aa.to(torch.float64)
    scales = torch.where(aa > 0, xa / aa.clamp_min(torch.finfo(aa.dtype).tiny), 1.0)
    if not bool(torch.isfinite(scales).all()):
        raise FloatingPointError("non-finite group scale estimate")
    median = torch.sort(scales).values[scales.numel() // 2]
    if float(median) <= 0:
        raise FloatingPointError("non-positive median group scale; check reference contrast/CTF")
    scales = scales.clamp(min=median / 5.0, max=median * 5.0)
    counts = torch.as_tensor(particle_counts, device=scales.device, dtype=torch.float64)
    return scales / ((scales * counts).sum() / counts.sum())


def update_norm_corrections(old_norm, old_average, residual_power, total_mass):
    """RELION normcorr=(oldnorm/oldavg)*sqrt(2*full residual power)."""
    new = old_norm.to(torch.float64) / float(old_average) * torch.sqrt(
        2.0 * residual_power.to(torch.float64).clamp_min(0.0)
    )
    if not bool(torch.isfinite(new).all()) or bool((new <= 0).any()):
        raise FloatingPointError("non-positive/non-finite particle norm correction")
    average = new.sum() / float(total_mass)
    return new, float(average)


def solvent_mask(size, radius, edge, device, dtype=torch.float32):
    axis = torch.arange(size, device=device, dtype=dtype) - size // 2
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    rr = torch.sqrt(xx.square() + yy.square())
    if edge <= 0:
        return (rr <= radius).to(dtype)
    return torch.where(rr < radius, 1.0, torch.where(
        rr > radius + edge, 0.0,
        0.5 + 0.5 * torch.cos(math.pi * (rr - radius) / edge)))


def lowpass_reference(image, resolution_angstrom, pixel_size, edge=2.0):
    """RELION raised-cosine low-pass, centred at N*pixel/resolution."""
    if resolution_angstrom is None or resolution_angstrom <= 0:
        return image
    n = image.shape[-1]
    ky = torch.fft.fftfreq(n, device=image.device) * n
    kx = torch.arange(n // 2 + 1, device=image.device)
    rr = torch.sqrt(ky[:, None].square() + kx[None].square())
    inner = n * float(pixel_size) / float(resolution_angstrom) - edge / 2
    mask = torch.where(rr < inner, 1.0, torch.where(rr > inner + edge, 0.0,
        0.5 + 0.5 * torch.cos(math.pi * (rr - inner) / edge)))
    return torch.fft.irfft2(torch.fft.rfft2(image, norm="forward") * mask,
                            s=(n, n), norm="forward")


class Class2DSampling(RelionSampling):
    """Keep prior grid unperturbed; perturb transforms, including fine children.

    RELION stores q in [-factor,+factor], not q*factor. The same scalar
    displacement applies to x and y; translations are stored in Angstroms.
    """
    def __post_init__(self):
        q = float(self.random_perturbation)
        self.random_perturbation = 0.0
        super().__post_init__()
        self.random_perturbation = q

    @property
    def prior_translations(self):
        return self._translations.copy()

    @property
    def psi_angles(self):
        return (self._psi + self.random_perturbation * self.actual_psi_step + 180) % 360 - 180

    @property
    def translations(self):
        return self._translations + self.random_perturbation * self.offset_step

    def fine_sampling_table(self, order=None):
        table = super().fine_sampling_table(order)
        angles = table.orientation_angles.copy()
        angles[..., 2] = (angles[..., 2] + self.random_perturbation * self.actual_psi_step + 180) % 360 - 180
        return replace(table, orientation_angles=angles,
                       translations=table.translations + self.random_perturbation * self.offset_step)

    def advance(self, generator):
        f = float(self.perturbation_factor)
        if not 0 <= f <= 1:
            raise ValueError("--perturb must be in [0,1]")
        self.random_perturbation = 0.0 if f == 0 else (
            (self.random_perturbation + generator.uniform(0.5*f, f) + f) % (2*f) - f)


def coarser_sampling(acc_rotation, acc_translation, order, original_psi,
                     original_step, offset_range):
    psi = max(float(original_psi), .8 * float(acc_rotation) * (2**order))
    step = max(float(original_step), min(.8 * float(acc_translation) * (2**order),
                                        .95 * float(offset_range)))
    return 360.0 / max(1, math.ceil(360.0 / psi)), step
