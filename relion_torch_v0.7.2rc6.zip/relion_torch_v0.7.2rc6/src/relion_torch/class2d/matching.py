"""Permutation-aware comparison of Class2D class sets."""
from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations
from pathlib import Path
from typing import Sequence

import mrcfile
import numpy as np


@dataclass(slots=True, frozen=True)
class ClassMatch:
    reference_index: int
    candidate_index: int
    correlation: float


def _read_classes(paths: Sequence[str | Path] | str | Path) -> list[np.ndarray]:
    values = [Path(paths)] if isinstance(paths, (str, Path)) else [Path(value) for value in paths]
    arrays: list[np.ndarray] = []
    for path in values:
        with mrcfile.open(path, mode="r", permissive=True) as handle:
            data = np.asarray(handle.data, dtype=np.float64).copy()
        if data.ndim == 2:
            arrays.append(data)
        elif data.ndim == 3:
            arrays.extend(data[index] for index in range(data.shape[0]))
        else:
            raise ValueError(f"Unsupported class-map shape {data.shape} in {path}")
    if not arrays:
        raise ValueError("No class maps were loaded")
    shape = arrays[0].shape
    if any(array.shape != shape for array in arrays):
        raise ValueError("All class maps must have the same shape")
    return arrays


def _correlation(first: np.ndarray, second: np.ndarray) -> float:
    x = first.reshape(-1).astype(np.float64, copy=False)
    y = second.reshape(-1).astype(np.float64, copy=False)
    x = x - x.mean()
    y = y - y.mean()
    denominator = float(np.linalg.norm(x) * np.linalg.norm(y))
    return float(np.dot(x, y) / denominator) if denominator > 0.0 else 0.0


def correlation_matrix(
    reference_paths: Sequence[str | Path] | str | Path,
    candidate_paths: Sequence[str | Path] | str | Path,
) -> np.ndarray:
    references = _read_classes(reference_paths)
    candidates = _read_classes(candidate_paths)
    if len(references) != len(candidates):
        raise ValueError(
            f"Class sets have different sizes: {len(references)} and {len(candidates)}"
        )
    return np.asarray(
        [[_correlation(reference, candidate) for candidate in candidates] for reference in references],
        dtype=np.float64,
    )


def _assignment_dynamic_programming(score: np.ndarray) -> list[int]:
    """Exact maximum-weight assignment without requiring SciPy.

    Complexity is O(K 2^K), practical for the class counts normally used in the
    regression and parity tests.  Large sets use SciPy when available.
    """

    count = int(score.shape[0])
    if count > 18:
        raise RuntimeError("Install scipy to match more than 18 classes")
    states: dict[int, tuple[float, tuple[int, ...]]] = {0: (0.0, ())}
    for row in range(count):
        updated: dict[int, tuple[float, tuple[int, ...]]] = {}
        for mask, (value, assignment) in states.items():
            for column in range(count):
                bit = 1 << column
                if mask & bit:
                    continue
                new_mask = mask | bit
                candidate = (value + float(score[row, column]), assignment + (column,))
                old = updated.get(new_mask)
                if old is None or candidate[0] > old[0]:
                    updated[new_mask] = candidate
        states = updated
    return list(states[(1 << count) - 1][1])


def match_class_maps(
    reference_paths: Sequence[str | Path] | str | Path,
    candidate_paths: Sequence[str | Path] | str | Path,
) -> list[ClassMatch]:
    score = correlation_matrix(reference_paths, candidate_paths)
    count = int(score.shape[0])
    try:
        from scipy.optimize import linear_sum_assignment  # type: ignore

        rows, columns = linear_sum_assignment(-score)
        pairs = sorted(zip(rows.tolist(), columns.tolist()))
    except Exception:
        if count <= 9:
            permutation = max(
                permutations(range(count)),
                key=lambda order: sum(score[row, order[row]] for row in range(count)),
            )
            pairs = list(enumerate(permutation))
        else:
            assignment = _assignment_dynamic_programming(score)
            pairs = list(enumerate(assignment))
    return [
        ClassMatch(int(row), int(column), float(score[row, column]))
        for row, column in pairs
    ]
