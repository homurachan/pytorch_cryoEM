from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(slots=True)
class NumericsConfig:
    """Common numerical settings shared by reconstruction and fixed-pose EM."""

    device: str = "cpu"
    real_dtype: torch.dtype = torch.float32
    padding_factor: float = 2.0
    interpolation: str = "trilinear"
    eps: float = 1.0e-7
    deterministic: bool = False
    pixel_chunk_size: int = 262_144

    def torch_device(self) -> torch.device:
        dev = torch.device(self.device)
        if dev.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError(
                f"CUDA device {self.device!r} was requested, but torch.cuda.is_available() is false"
            )
        return dev

    @property
    def complex_dtype(self) -> torch.dtype:
        if self.real_dtype == torch.float64:
            return torch.complex128
        if self.real_dtype == torch.float32:
            return torch.complex64
        raise ValueError(f"Unsupported real dtype: {self.real_dtype}")

    def apply_determinism(self) -> None:
        if self.deterministic:
            torch.use_deterministic_algorithms(True)
