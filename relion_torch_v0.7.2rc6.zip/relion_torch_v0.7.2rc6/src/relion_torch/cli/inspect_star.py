from __future__ import annotations

import argparse
import json
import sys

from relion_torch.io.particles import ParticleDataset
from relion_torch.io.star import read_relion_star


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="relion_torch_inspect")
    parser.add_argument("star")
    args = parser.parse_args(argv)
    try:
        star = read_relion_star(args.star)
        dataset = ParticleDataset(star)
        try:
            summary = {
                "source": str(star.source_path),
                "particles": len(dataset),
                "optics_groups": len(star.optics),
                "box_size": dataset.box_size,
                "pixel_size_angstrom": dataset.pixel_size,
                "particle_columns": list(star.particles.columns),
                "optics_columns": list(star.optics.columns),
            }
        finally:
            dataset.close()
        print(json.dumps(summary, indent=2))
        return 0
    except Exception as exc:
        print(f"relion_torch_inspect: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
