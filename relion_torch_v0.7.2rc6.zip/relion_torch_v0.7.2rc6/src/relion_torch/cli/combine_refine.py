"""Command line for independent 3D auto combine refinement."""
from pathlib import Path
from relion_torch.cli.auto_refine import build_parser as auto_parser
from relion_torch.class3d.runner import EXECUTION_OVERRIDES
from relion_torch.combine_refine.config import JOINT_FIELDS
from relion_torch.combine_refine.runner import options_from_checkpoint, run_combine_refine
from relion_torch.version import __version__


def build_parser():
    p = auto_parser()
    p.description = (f'RELION-Torch {__version__} independent 3D auto combine refine: '
        'converged auto-refine -> broad 5D coarse -> joint pose/mean-defocus fine posterior. '
        'Default input resolution limit 6 A; explicit scoring cutoff required.')
    # Reuse execution controls, but do not advertise unrelated new-auto-refine
    # options that this task cannot honour. Original scientific settings load
    # from the seed; changing the point group or half identities is forbidden.
    allowed = (EXECUTION_OVERRIDES-{'fast_subsets', 'write_unfil_map'}) | {'output_root', 'continue_from', 'iterations', 'additional_iterations',
        'half_order', 'auto_execution', 'auto_cache_mib', 'verb', 'dtype', 'adaptive_fraction'}
    for action in list(p._actions):
        if action.dest in allowed or action.dest == 'help': continue
        for flag in action.option_strings: p._option_string_actions.pop(flag, None)
        p._remove_action(action)
        for group in p._action_groups:
            if action in group._group_actions: group._group_actions.remove(action)
    for action in p._actions:
        if action.dest == 'continue_from': action.help = 'Resume a combine checkpoint (.pt or optimiser STAR); preserves scientific settings'
        if action.dest == 'adaptive_fraction': action.help = 'Retained joint fine posterior mass target (seed default; coarse target is separate)'
    p.add_argument('--from-auto-refine', '--from_auto_refine', dest='seed_checkpoint', type=Path,
        help='Final converged RELION-Torch auto-refine *_state.pt; mutually exclusive with --continue')
    def arg(name, dest=None, **kw):
        p.add_argument('--'+name, '--'+name.replace('-', '_'), dest=dest or name.replace('-', '_'), default=None, **kw)
    arg('score-highres', 'score_highres_angstrom', type=float,
        help='Explicit finest scoring resolution in A; reconstruction still uses full input size')
    arg('combine-execution', choices=['optimized', 'reference'], help='Joint execution policy, default optimized; reference retains v0.6.0 loops')
    arg('combine-accumulation', choices=['auto', 'contracted', 'reference'],
        help='Auto contracts defocus/translation when skip-gridding is on; retains reference sums with iterative preweighting')
    arg('combine-defocus-chunk', type=int, help='Maximum defoci per bounded scoring/statistics tile, default 4')
    arg('maximum-start-resolution', type=float, help='Largest accepted reported input resolution, default 6 A')
    arg('defocus-range', type=float, help='Fixed half-range in A about input mean defocus, default 500; 0 is a fixed-defocus control')
    arg('defocus-step', type=float, help='Defocus grid spacing in A, default 50; range must be a multiple')
    arg('defocus-sigma', type=float, help='Gaussian prior SD in A, default 300; immutable input anchor')
    arg('coarse-fraction', type=float, help='5D coarse retained mass target, default .9999')
    arg('pose-sigma-factor', type=float, help='Broaden the converged local angular prior, default 1.5')
    arg('translation-range-factor', type=float, help='Broaden the final translation search range, default 1.5')
    for name, description in (
        ('minimum-iterations', 'Minimum combine iterations, default 2'),
        ('stable-iterations', 'Consecutive stable iterations before stopping, default 2')):
        arg(name, type=int, help=description)
    for name, description in (
        ('defocus-tolerance', 'RMS mean-defocus change in A, default 10'),
        ('angle-tolerance', 'Symmetry-aware mean angular change in degrees, default .1'),
        ('translation-tolerance', 'Per-axis RMS shift change in A, default .1'),
        ('map-tolerance', 'Largest half-map relative change, default .01'),
        ('boundary-tolerance', 'Defocus edge-mass / boundary-particle convergence threshold, default .05')):
        arg(name, type=float, help=description)
    return p


def main(argv=None):
    p = build_parser(); args = vars(p.parse_args(argv))
    if (args['seed_checkpoint'] is None) == (args['continue_from'] is None):
        p.error('Provide exactly one of --from-auto-refine and --continue')
    resume = args['continue_from'] is not None
    source = args['continue_from'] if resume else args['seed_checkpoint']
    options, state = options_from_checkpoint(source, args['output_root'], resume=resume)
    additional = args.pop('additional_iterations')
    verbosity = args.pop('verb', None); args.pop('dtype', None)
    if verbosity is not None: args['progress'] = verbosity > 0
    if args.get('half_order') is not None: args['half_order'] = tuple(map(int, args['half_order'].split(',')))
    for name, value in args.items():
        if value is None: continue
        if resume and name in JOINT_FIELDS | {'adaptive_fraction'} and value != getattr(options, name):
            p.error('Cannot change scientific setting on continue: '+name)
        setattr(options, name, value)
    if args.get('device') is not None and args.get('devices') is None: options.devices = ''
    if additional:
        if not resume: p.error('--additional-iterations requires --continue')
        options.iterations = state['iteration']+int(args.get('iterations') or 1)
    elif resume and args.get('iterations') is None:
        options.iterations = max(options.iterations, state['iteration']+1)
    result = run_combine_refine(options, checkpoint_state=state)
    print('Combine refinement converged.' if result['converged'] else
          'Iteration limit reached; results and resumable independent half states written.', flush=True)
    return result


def cli_main():
    main()


if __name__ == '__main__': cli_main()
