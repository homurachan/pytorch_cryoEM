"""Preserve the legacy align entry unless auto-refine is explicitly selected."""
import sys


def main(argv=None):
    args=list(sys.argv[1:] if argv is None else argv)
    if '--auto_refine' in args or '--auto-refine' in args:
        from .auto_refine import main as run
    else:
        from .align import main as run
    run(args)
