from __future__ import annotations

from pathlib import Path
import torch
from relion_torch.io.spectra import read_spectrum


def parse_dtype(name: str) -> torch.dtype:
    mapping = {
        "float32": torch.float32,
        "fp32": torch.float32,
        "float64": torch.float64,
        "fp64": torch.float64,
    }
    try:
        return mapping[name.lower()]
    except KeyError as exc:
        raise ValueError(f"Unsupported dtype {name!r}; use float32 or float64") from exc


def print_outputs(outputs: dict[str, Path]) -> None:
    for key, path in sorted(outputs.items()):
        print(f"{key}: {path}")
