from __future__ import annotations
import argparse
from pathlib import Path

from relion_torch.optimiser.alignment import AlignmentConfig, AlignmentOptimiser


def build_parser()->argparse.ArgumentParser:
    p=argparse.ArgumentParser(description='RELION 3.1-style PyTorch 2D/3D alignment and classification')
    p.add_argument('--i',required=True,dest='input_star')
    p.add_argument('--ref',action='append',required=True,dest='references')
    p.add_argument('--o',required=True,dest='output_root')
    p.add_argument('--iter',type=int,default=1,dest='iterations')
    p.add_argument('--K',type=int,default=None,help='number of classes; must match repeated --ref arguments')
    p.add_argument('--device',default='cuda')
    p.add_argument('--batch-size',type=int,default=8, help='particle batch size for dense or sparse global search')
    p.add_argument('--refdim',type=int,choices=(2,3),default=3,dest='reference_dim')
    p.add_argument('--healpix-order','--healpix_order',type=int,default=2)
    p.add_argument('--psi-step','--psi_step',type=float,default=None)
    p.add_argument('--offset-range','--offset_range',type=float,default=5.0,dest='offset_range_angstrom',
                   help='translation range in pixels, as in RELION')
    p.add_argument('--offset-step','--offset_step',type=float,default=1.0,dest='offset_step_angstrom',
                   help='translation step in pixels, as in RELION')
    p.add_argument('--offset-values-are-angstrom',action='store_true')
    p.add_argument('--oversampling','--adaptive-oversampling',type=int,default=0)
    p.add_argument('--adaptive-fraction','--adaptive_fraction',type=float,default=0.999)
    p.add_argument('--skip-align','--skip_align',action='store_true')
    p.add_argument('--skip-rotate','--skip_rotate',action='store_true')
    p.add_argument('--skip-maximize','--skip_maximize',action='store_true')
    p.add_argument('--firstiter-cc','--firstiter_cc',action='store_true')
    p.add_argument('--particle-diameter','--particle_diameter',type=float,default=None, help='particle diameter in Angstrom; default matches RELION: (box-maskedge)*pixel size')
    p.add_argument('--mask-edge','--maskedge',type=float,default=5.0,dest='mask_edge_pixels')
    p.add_argument('--zero-mask','--zero_mask',action='store_true')
    p.add_argument('--current-size','--current_size',type=int,default=None)
    p.add_argument('--coarse-size','--coarse_size',type=int,default=None)
    p.add_argument('--current-size-increment','--current_size_increment',type=int,default=10,
                   help=argparse.SUPPRESS)
    p.add_argument('--minres-map','--minres_map',type=int,default=5,
                   help=argparse.SUPPRESS)
    p.add_argument('--strict-highres-exp','--strict_highres_exp','--maxres',type=float,default=None,dest='strict_highres_angstrom')
    p.add_argument('--sigma-offset','--sigma_offset',type=float,default=10.0,dest='sigma_offset_angstrom')
    p.add_argument('--sigma-rot',type=float,default=0.0,dest='sigma_rot_deg')
    p.add_argument('--sigma-tilt',type=float,default=0.0,dest='sigma_tilt_deg')
    p.add_argument('--sigma-psi',type=float,default=0.0,dest='sigma_psi_deg')
    p.add_argument('--tau2-fudge','--tau2_fudge',type=float,default=1.0)
    p.add_argument('--pad',type=float,default=2.0,dest='padding_factor')
    p.add_argument('--preweight-iters',type=int,default=10,dest='preweight_iterations')
    p.add_argument('--seed','--random-seed','--random_seed',type=int,default=0,dest='random_seed')
    p.add_argument('--projector-backend',choices=('validated','fallback'),default='validated')
    p.add_argument('--orientation-chunk-size',type=int,default=256,
                   help='orientations per projection/likelihood chunk')
    p.add_argument('--backprojector-chunk-size',type=int,default=128,
                   help='orientations per vectorised backprojection chunk')
    p.add_argument('--write-debug','--write-posteriors',action='store_true')
    p.add_argument('--expected-accuracy-interface',action='store_true')
    p.add_argument(
        '--expected-accuracy-trials',
        type=int,
        default=100,
        help='number of particles used for RELION-style assignment-accuracy estimates',
    )
    p.add_argument(
        '--skip-expected-accuracy',
        action='store_true',
        help='skip the optional pre-expectation rotation/translation accuracy estimate',
    )
    # Reserved interfaces: parsed now so scripts remain forward-compatible.
    p.add_argument('--norm',action='store_true',help=argparse.SUPPRESS)
    p.add_argument('--scale',action='store_true',help=argparse.SUPPRESS)
    from relion_torch.io.particle_store import add_particle_io_arguments
    add_particle_io_arguments(p)
    return p


def main(argv=None)->int:
    a=build_parser().parse_args(argv)
    if a.K is not None and a.K != len(a.references):
        raise SystemExit(f'--K={a.K} but {len(a.references)} --ref arguments were supplied')
    cfg=AlignmentConfig(
        input_star=Path(a.input_star),references=[Path(x) for x in a.references],output_root=Path(a.output_root),
        iterations=a.iterations,device=a.device,batch_size=a.batch_size,reference_dim=a.reference_dim,
        preread_images=a.preread_images, io_batch_size=a.io_batch_size, pool_size=a.pool_size,
        max_open_stacks=a.max_open_stacks, particle_io=a.particle_io, preread_max_gib=a.preread_max_gib,
        healpix_order=a.healpix_order,psi_step=a.psi_step,offset_range_angstrom=a.offset_range_angstrom,
        offset_step_angstrom=a.offset_step_angstrom,offset_values_are_angstrom=a.offset_values_are_angstrom,
        oversampling=a.oversampling,
        adaptive_fraction=a.adaptive_fraction,skip_align=a.skip_align,skip_rotate=a.skip_rotate,
        skip_maximize=a.skip_maximize,firstiter_cc=a.firstiter_cc,particle_diameter=a.particle_diameter,
        mask_edge_pixels=a.mask_edge_pixels,zero_mask=a.zero_mask,current_size=a.current_size,
        coarse_size=a.coarse_size,strict_highres_angstrom=a.strict_highres_angstrom,
        current_size_increment=a.current_size_increment,minres_map=a.minres_map,
        sigma_offset_angstrom=a.sigma_offset_angstrom,sigma_rot_deg=a.sigma_rot_deg,
        sigma_tilt_deg=a.sigma_tilt_deg,sigma_psi_deg=a.sigma_psi_deg,tau2_fudge=a.tau2_fudge,
        padding_factor=a.padding_factor,preweight_iterations=a.preweight_iterations,
        random_seed=a.random_seed,projector_backend=a.projector_backend,
        orientation_chunk_size=a.orientation_chunk_size,
        backprojector_chunk_size=a.backprojector_chunk_size,
        write_debug=a.write_debug,expected_accuracy_interface=a.expected_accuracy_interface,
        expected_accuracy_trials=a.expected_accuracy_trials,
        skip_expected_accuracy=a.skip_expected_accuracy,
    )
    from relion_torch.alignment.core import AlignmentDataset
    with AlignmentDataset.from_config(cfg) as dataset:
        opt=AlignmentOptimiser(cfg, dataset=dataset)
        opt.run()
        if a.expected_accuracy_interface:
            print(opt.expected_accuracy_interface())
    return 0

if __name__=='__main__': raise SystemExit(main())
