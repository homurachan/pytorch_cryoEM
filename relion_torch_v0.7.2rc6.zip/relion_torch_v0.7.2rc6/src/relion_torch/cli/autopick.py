"""Command line entry point for PyTorch RELION 3.1 auto-picking."""
from __future__ import annotations
import argparse
import math
import sys
from relion_torch.version import __version__


def parser():
    p = argparse.ArgumentParser(description='RELION 3.1 auto-picking in PyTorch (LoG, templates, Gaussian blobs, helices).',allow_abbrev=False)
    p.add_argument('--version',action='version',version=__version__)
    p.add_argument('--i',required=True,help='Micrograph STAR or quoted MRC glob')
    p.add_argument('--ref',default='',help='2D MRC(S), reference STAR, 3D MRC, or gauss')
    p.add_argument('--ref_dim', '--ref-dim', type=int, choices=(2, 3), help='Override MRC reference dimensionality; use 2 for a cubic stack stored as .mrc')
    p.add_argument('--odir',default='AutoPick/')
    p.add_argument('--pickname',default='autopick')
    floats = {'angpix':1.,'particle_diameter':-1.,'outlier_removal_zscore':8.,
              'angpix_ref':-1.,'ang':10.,'lowpass':-1.,'highpass':-1.,'gauss_max':.1,
              'LoG_diam_min':-1.,'LoG_diam_max':-1.,'LoG_neighbour':100.,
              'LoG_adjust_threshold':0.,'LoG_upper_threshold':99999.,'Log_max_search':5.,
              'helical_tube_kappa_max':.25,'helical_tube_outer_diameter':-1.,
              'helical_tube_length_min':-1.,'threshold':.25,'min_distance':-1.,
              'max_stddev_noise':-1.,'min_avg_noise':-999.,'shrink':1.}
    for name,default in floats.items():
        p.add_argument('--'+name,type=float,default=default)
    integers = {'shrink_particle_mask':2,'healpix_order':1,'skip_side':0,'verb':1,'pad':2,'random_seed':1,'extra_pad':0,'j':1}
    for name,default in integers.items():
        p.add_argument('--'+name,type=int,default=default)
    for name in ('write_fom_maps','no_fom_limit','read_fom_maps','skip_optimise_scale','only_do_unfinished','invert','ctf','ctf_intact_first_peak','LoG','LoG_use_ctf','helix','amyloid'):
        p.add_argument('--'+name,action='store_true')
    p.add_argument('--Log_invert','--LoG_invert',dest='Log_invert',action='store_true')
    p.add_argument('----max_diam_local_avg','--max_diam_local_avg',dest='max_diam_local_avg',type=float,default=-1.)
    p.add_argument('--sym',default='C1')
    execution = p.add_mutually_exclusive_group()
    execution.add_argument('--gpu',nargs='?',const='0',help='CUDA id or comma-separated ids, e.g. --gpu 0,1')
    execution.add_argument('--device',default=None,help='Single-process cpu or cuda:N')
    execution.add_argument('--devices',default='',help='One persistent process per GPU, e.g. 0,1 or cuda:0,cuda:1; cpu,cpu for process validation')
    p.add_argument('--dtype',choices=('float32','float64'),default='float64',help='Default matches native double precision')
    p.add_argument('--pipeline_control',default=None,help='RELION pipeline directory for success/failure markers')
    return p


def validate(a):
    for name,value in vars(a).items():
        if isinstance(value,float) and not math.isfinite(value):
            raise ValueError(f'--{name} must be finite')
    if a.LoG == bool(a.ref):
        raise ValueError('Choose exactly one of --LoG or --ref')
    if getattr(a, 'ref_dim', None) == 3 and (a.ref == 'gauss' or a.ref.lower().endswith('.star')):
        raise ValueError('--ref_dim 3 requires a single MRC volume; Gaussian and STAR references are 2D templates')
    if a.LoG and (a.LoG_diam_min <= 0 or a.LoG_diam_max < a.LoG_diam_min or a.LoG_neighbour <= 0 or a.Log_max_search < 1):
        raise ValueError('LoG needs 0 < diam_min <= diam_max, neighbour > 0, Log_max_search >= 1')
    if a.ang <= 0 or a.ang > 360 or a.pad < 1 or a.j < 1 or a.shrink < 0 or a.extra_pad < 0 or a.skip_side < 0 or a.shrink_particle_mask < 0:
        raise ValueError('Invalid angle, padding, thread count, shrink factor, or mask/edge size')
    if a.LoG and (a.helix or a.amyloid):
        raise ValueError('Helical picking requires templates')
    if a.amyloid and not a.helix:
        raise ValueError('--amyloid requires --helix')
    if a.helix and (not .0001 <= a.helical_tube_kappa_max <= 1.0001 or a.min_distance <= 0 or a.helical_tube_outer_diameter <= 0):
        raise ValueError('Helix requires positive min_distance, tube_outer_diameter and kappa in (0,1]')
    if a.outlier_removal_zscore <= 0:
        raise ValueError('outlier_removal_zscore must be positive')
    if a.min_distance == 0 or a.particle_diameter == 0 or a.lowpass == 0 or a.highpass == 0:
        raise ValueError('Distances, diameter and filters cannot be zero (use -1 for defaults)')
    if not a.pickname or any(c in a.pickname for c in '/\\') or a.pickname in ('.','..'):
        raise ValueError('pickname must be a filename stem')
    if a.random_seed < -1:
        raise ValueError('random_seed must be -1 (time) or non-negative')
    if a.healpix_order < 0 or a.healpix_order > 6:
        raise ValueError('healpix_order must be between 0 and 6')


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    try:
        validate(args)
        from relion_torch.autopick.runner import run
        run(args)
    except (ValueError,FileNotFoundError,RuntimeError,OSError) as exc:
        if args.pipeline_control:
            from pathlib import Path
            path = Path(args.pipeline_control)
            path.mkdir(parents=True,exist_ok=True)
            (path/'RELION_JOB_EXIT_FAILURE').touch()
        p.exit(2,f'autopick: error: {exc}\n')
    except KeyboardInterrupt:
        p.exit(130,'autopick: interrupted\n')


if __name__ == '__main__':
    main()
