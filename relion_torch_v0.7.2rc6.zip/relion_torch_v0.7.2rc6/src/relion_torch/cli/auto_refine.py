"""Gold-standard point-group SPA auto-refine, sequential halves on one device."""
from dataclasses import fields
from pathlib import Path
from relion_torch.cli.class3d import build_parser as class3d_parser
from relion_torch.class3d.runner import PATH_FIELDS
from relion_torch.auto_refine.config import AutoRefineConfig
from relion_torch.auto_refine.runner import run_auto_refine,load_checkpoint,EXECUTION_FIELDS,CONTINUATION_FIELDS
from relion_torch.version import __version__
from relion_torch.reconstruction.sirm import SIRM_CONTINUATION_FIELDS


def build_parser():
    parser=class3d_parser()
    parser.description=f'RELION-Torch {__version__} gold-standard point-group 3D auto-refine; sequential halves, one CPU/CUDA device.'
    for action in parser._actions:
        if action.dest=='continue_from':action.help='Resume this package\'s unjoined auto-refine .pt or optimiser STAR; scientific settings are restored'
        if action.dest.startswith('sigma_') and action.dest.endswith('_deg'):action.help='Auto-refine manages angular priors; set auto-local-healpix-order instead'
    def arg(name,**kw):
        flags=['--'+name,'--'+name.replace('-','_')]
        parser.add_argument(*dict.fromkeys(flags),default=None,**kw)
    arg('auto-refine',action='store_true',help='Accepted for RELION-style commands; this entry always performs auto-refine')
    arg('auto-local-healpix-order',type=int)
    arg('auto-execution',choices=['optimized','reference'],help='Execution policy; reference retains v0.5.1 scoring/accumulation order')
    arg('auto-cache-mib',type=float,help='Projection cache: -1 uses the planned budget (new-run default), 0 disables, positive MiB sets an explicit ceiling; use -1 to remove a restored 0.5.2 ceiling')
    arg('solvent-correct-fsc',action='store_true')
    arg('low-resol-join-halves',type=float)
    arg('auto-ignore-angle-changes',action='store_true')
    arg('auto-resolution-based-angles',action='store_true')
    arg('minimum-angular-sampling',type=float)
    arg('maximum-angular-sampling',type=float)
    arg('max-healpix-order',type=int)
    arg('force-converge',action='store_true',help='Run the next iteration as final, including iteration 1 of a new run; write final map and independent unfiltered halves')
    arg('use-all-data',action='store_true',help='Use full-box Fourier support in every iteration without forcing convergence or joining halves')
    arg('no-use-all-data',dest='use_all_data',action='store_false')
    arg('do-mwtcf',action='store_true',help='SIRM-RELION FSC selection by half1 Fourier weight; use with --mwtcf')
    arg('no-do-mwtcf',dest='do_mwtcf',action='store_false')
    arg('mwtcf',type=float,help='Minimum weight / shell mean for MWTCF (native default -10); does not enable MWTCF by itself')
    arg('half-order',choices=['1,2','2,1'],help='Sequential execution order; half identities stay unchanged')
    arg('verb',type=int,help='0 disables particle progress')
    arg('dtype',choices=['float','float32'],help='Fourier kernels use float32; statistics precision has separate flags')
    return parser


def main(argv=None):
    parser=build_parser();args=vars(parser.parse_args(argv))
    additional=args.pop('additional_iterations');args.pop('auto_refine');args.pop('dtype')
    verbosity=args.pop('verb')
    if verbosity is not None:args['progress']=verbosity>0
    if args['half_order'] is not None:args['half_order']=tuple(int(x) for x in args['half_order'].split(','))
    state=load_checkpoint(args['continue_from']) if args['continue_from'] is not None else None
    options=AutoRefineConfig(args['input_star'],args['output_root'])
    if state is not None:
        for field in fields(options):
            if field.name in state['config']:
                value=state['config'][field.name]
                if field.name in PATH_FIELDS and value is not None:value=Path(value)
                if field.name in ('references','half_order'):value=tuple(value)
                setattr(options,field.name,value)
        # A previous forced-final intent must be explicitly requested again.
        options.force_converge=False
    for name,value in args.items():
        if value is None:continue
        if state is not None and name not in SIRM_CONTINUATION_FIELDS|EXECUTION_FIELDS|CONTINUATION_FIELDS|{'iterations','output_root','continue_from'}:
            if name=='input_star':parser.error('--i cannot replace checkpoint particle metadata')
            if value!=getattr(options,name):parser.error(f'Cannot change scientific setting {name} during continuation')
        setattr(options,name,value)
    if args.get('device') is not None and args.get('devices') is None:options.devices=''
    options.references=tuple(options.references)
    if (state is not None and state.get('package_version')=='0.5.2' and
            args.get('auto_cache_mib') is None and options.auto_cache_mib==2048 and options.auto_memory):
        print('Checkpoint restores a 2048 MiB projection-cache ceiling from 0.5.2. '
              'Use --auto_cache_mib -1 to let automatic planning use available GPU memory.',flush=True)
    if additional:
        if state is None:parser.error('--additional-iterations requires --continue')
        options.iterations=state['iteration']+int(args['iterations'] or 1)
    elif state is not None and args['iterations'] is None:
        options.iterations=max(options.iterations,state['iteration']+1)
    result=run_auto_refine(options,checkpoint_state=state)
    status='Converged; final map and independent unfiltered half maps written.' if result['converged'] else 'Iteration limit reached; independent halves and resumable checkpoint written.'
    print(status,flush=True)
    return result


def cli_main():
    main()


if __name__=='__main__':cli_main()
