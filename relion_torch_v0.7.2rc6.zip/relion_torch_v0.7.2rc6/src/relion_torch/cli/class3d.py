"""Point-group Class3D CLI with optional permanent device workers."""
from __future__ import annotations
import argparse
from dataclasses import fields
from pathlib import Path
from relion_torch.class3d.config import Class3DConfig, CONTINUATION_SAMPLING_OVERRIDES
from relion_torch.class3d.runner import run_class3d, load_checkpoint, EXECUTION_OVERRIDES, PATH_FIELDS
from relion_torch.version import __version__
from relion_torch.reconstruction.sirm import SIRM_CONTINUATION_FIELDS

def build_parser():
    p=argparse.ArgumentParser(description=f'RELION-Torch v{__version__} point-group SPA Class3D (2-D particles, 3-D references). Not auto-refine.')
    def arg(name,*aliases,**kw):
        flags=[name,*aliases]
        underscore='--'+name[2:].replace('-','_')
        if underscore!=name and underscore not in flags:flags.append(underscore)
        p.add_argument(*flags,default=None,**kw)
    arg('--i',dest='input_star',type=Path)
    arg('--o',dest='output_root',type=Path,required=True)
    arg('--ref',dest='references',action='append',help='One 3-D seed map, K separate maps (repeat --ref), or reference STAR')
    arg('--K',dest='number_of_classes',type=int)
    arg('--iter',dest='iterations',type=int,help='Final absolute iteration; with --additional-iterations, number to add')
    arg('--continue',dest='continue_from',type=Path,
        help='Resume own .pt / optimiser STAR; sampling and local angular sigma settings may change')
    p.add_argument('--additional-iterations',action='store_true')
    arg('--device',help='Single device when --devices is omitted')
    arg('--devices',help='Permanent workers: cuda:0,cuda:1 or 0,1; cpu,cpu for process validation')
    arg('--worker-threads',type=int,help='CPU threads per worker (default 1)')
    arg('--worker-chunk-size',type=int,help='Particles claimed per IO task (default 256; never below compute batch)')
    arg('--gpu-memory-percent',type=float,
        help='Maximum GPU memory percentage (0,100], default 100; automatically reserve 256 MiB to 1 GiB for the desktop and plan caches/workspaces each iteration')
    arg('--auto-memory',dest='auto_memory',action='store_true',
        help='Automatic CUDA memory planning (default); supersedes legacy cache/workspace byte flags')
    arg('--no-auto-memory',dest='auto_memory',action='store_false',
        help='Advanced compatibility: use legacy manual cache/workspace limits; percentage guard still applies on CUDA')
    arg('--skip-gridding',action='store_true',help='Skip iterative reconstruction preweighting; preserves 3D insertion')
    arg('--no-skip-gridding',dest='skip_gridding',action='store_false',help='Restore iterative preweighting on continue')
    for backend in ('symmetry-backend','reconstruction-backend','global-fusion'):
        arg('--'+backend,choices=['auto','off','required'],help='Optimized CUDA backend; auto falls back when unsupported')
    arg('--global-gridding', choices=['auto','off','required','ordered'], help='3D insertion backend; ordered uses fixed-order segmented sums for reproducibility')
    arg('--global-fine-mode', choices=['auto','cached','stream','hybrid'], help='Global fine execution: auto uses cached rows and fused miss generation for oversized fine banks; stream requests rc3 low-memory scoring; cached restores rc2')
    arg('--global-fine-statistics', choices=['auto','tensor','fused'], help='Independent statistics backend; auto uses tensor for hybrid/cached and fused for stream. Applies to eligible hybrid/stream execution.')
    arg('--global-fine-mib', type=float, help='Batch-scoped global fine projection buffer ceiling in MiB (default 512, within the existing projection budget)')
    arg('--global-window-mib', type=float, help='Additional bounded global coarse window; 0 disables cooperative tile reuse (default ceiling 2048 MiB, admitted only from unused planned headroom)')
    arg('--coarse-cache-policy', choices=['auto','fixed','clock'], help='Oversized global coarse bank: auto uses fixed GPU rows plus bounded host backing; fixed uses GPU only; clock restores legacy replacement')
    arg('--coarse-host-cache-mib', type=float, help='Separate pinned CPU RAM cap per expectation engine (default 1024 MiB); 0 disables host backing; only used when the global coarse bank cannot fit GPU cache')
    arg('--sym',dest='symmetry',help='Rotational point group: Cn, Dn, T, O, I1-I4 (I=I2)')
    for flag,dest,tp in [
        ('healpix-order','healpix_order',int),('psi-step','psi_step_deg',float),
        ('offset-range','offset_range_pixels',float),('offset-step','offset_step_pixels',float),
        ('oversampling','oversampling',int),('adaptive-fraction','adaptive_fraction',float),
        ('perturbation-factor','perturbation_factor',float),('random-seed','random_seed',int),
        ('ini-high','initial_high_resolution',float),('current-size','current_size',int),
        ('strict-highres','strict_highres_angstrom',float),('particle-diameter','particle_diameter_angstrom',float),
        ('mask-edge','mask_edge_pixels',float),('tau2-fudge','tau2_fudge',float),('pad','padding_factor',float),
        ('preweight-iterations','preweight_iterations',int),('minres-map','minres_map',int),('sigma-offset','sigma_offset_angstrom',float),
        ('batch-size','batch_size',int),('pool','pool_size',int),('io-batch-size','io_batch_size',int),
        ('max-open-stacks','max_open_stacks',int),('preread-max-gib','preread_max_gib',float),
        ('orientation-chunk-size','orientation_chunk_size',int),('backprojector-chunk-size','backprojector_chunk_size',int),
        ('candidate-chunk-size','candidate_chunk_size',int),('candidate-work-mib','candidate_work_mib',float),
        ('posterior-work-mib','posterior_work_mib',float),('sampling-work-mib','sampling_work_mib',float),('performance-cache-mib','performance_cache_mib',float),
        ('projector-cache-mib','projector_cache_mib',float),('backprojector-cache-mib','backprojector_cache_mib',float),
        ('backprojector-host-gib','backprojector_host_gib',float),('reference-max-gib','reference_max_gib',float),
        ('preprocess-work-mib','preprocess_work_mib',float),('preprocess-cache-mib','preprocess_cache_mib',float),
        ('expected-accuracy-trials','expected_accuracy_trials',int),('timing-detail-samples','timing_detail_samples',int),
    ]:arg('--'+flag,dest=dest,type=tp)
    for axis in ('ang','rot','tilt','psi'):
        arg('--sigma-'+axis, dest='sigma_'+axis+'_deg', type=float,
            help='Angular prior stddev in degrees (default -1: disabled); Class3D local range is +/- 3 sigma')
    arg('--coarse-score-chunk-size',dest='coarse_score_chunk_size',type=int,
        help='Global coarse score orientations per tile; 0 (default) chooses up to 2048 within candidate workspace')
    arg('--solvent-mask',dest='solvent_mask',type=Path)
    arg('--local-projection-mode', choices=['stream','cached'], help='Local projection execution: batch-scoped streaming (default) or legacy retained cache')
    arg('--local-batch-max',type=int,help='Automatic local batch ceiling (default 64); 0 keeps requested batch size')
    arg('--local-fusion',choices=['auto','off','required'],help='Fused CUDA projection/score/statistics; auto falls back when unavailable')
    arg('--local-coarse-mode',choices=['auto','direct','shared'],help='Local coarse execution: auto shares bounded projection tiles for broad windows; direct retains fused interpolation per particle')
    arg('--local-projection-reuse',choices=['auto','off'],help='Reuse local projection tiles; default off, including continuation; auto explicitly enables sharing')
    # Execution default intentionally overrides an older checkpoint's auto.
    p.set_defaults(local_projection_reuse='off')
    arg('--local-fine-inputs',choices=['auto','off'],help='Read local fine-score observations by GPU indices (default auto); off restores pre-score gathers for A/B timing')
    arg('--local-candidate-search',choices=['auto','off'],help='Exact indexed C1 local candidate search; off uses the full direction scan')
    arg('--local-fine-chunking',choices=['auto','off'],help='Budget indexed fine tiles by their actual workspace; off keeps the legacy tile size')
    arg('--local-statistics-inputs',choices=['auto','off'],help='Batch-owned statistics inputs and fused gridding input preparation')
    arg('--local-statistics-reduction',choices=['auto','off'],help='Fuse local FP32 residual/scale reductions (default auto)')
    arg('--local-gridding',choices=['auto','off','required','ordered'],help='Fused local 3D backprojection insertion; unrelated to RELION skip_gridding (default auto)')
    arg('--local-projection-mib', type=float, help='Upper bound in MiB for the reusable local projection buffer (default 1024; 0 disables retention)')
    arg('--fine-score-mode',dest='fine_score_mode',choices=['auto','dense','sparse'])
    arg('--dense-fine-execution',choices=['auto','reference'],help='Bounded dense projection reuse (default auto); reference selects the previous dense scorer for A/B tests')
    arg('--weight-precision',dest='weight_precision',choices=['float32','float64'])
    arg('--accumulation-precision',dest='accumulation_precision',choices=['float32','float64'])
    arg('--particle-io',dest='particle_io',choices=['read','mmap'])
    arg('--progress',dest='progress',action='store_true',
        help='Show particle progress and phase messages (default on); terminal refresh or periodic log lines')
    arg('--no-progress',dest='progress',action='store_false',help='Disable progress and phase messages')
    arg('--write-unfil-map',action='store_true',help='Write posterior-weighted unfiltered class maps every iteration, before MAP/SIRM/solvent processing')
    arg('--no-write-unfil-map',dest='write_unfil_map',action='store_false')
    for flag,dest in [('firstiter-cc','firstiter_cc'),('skip-align','skip_align'),('skip-rotate','skip_rotate'),
        ('ctf','use_ctf'),('ctf-corrected-ref','ctf_corrected_ref'),('ctf-premultiplied','ctf_premultiplied'),
        ('ctf-phase-flipped','ctf_phase_flipped'),('only-flip-phases','only_flip_phases'),('intact-first-peak','intact_first_peak'),
        ('norm','do_norm_correction'),('scale','do_scale_correction'),('zero-mask','zero_mask'),
        ('flatten-solvent','flatten_solvent'),('preread-images','preread_images'),('fast-subsets','fast_subsets'),
        ('skip-expected-accuracy','skip_expected_accuracy'),('timing','timing'),('write-debug','write_debug')]:
        arg('--'+flag,dest=dest,action='store_true')
        arg('--no-'+flag,dest=dest,action='store_false')
    arg('--sirm','--SIRM',dest='sirm',action='store_true',help='SIRM reference reconstruction (may be enabled on continuation)')
    arg('--no-sirm',dest='sirm',action='store_false')
    arg('--sirm-threshold','--thres_SIRM',dest='sirm_threshold',type=float,help='SIRM Fourier reliability threshold (default .3)')
    arg('--sirm-histogram','--thres_hist',dest='sirm_histogram',type=float,help='Native SIRM histogram value (default 0: positivity only)')
    arg('--sirm-iterations','--iter_SIRM',dest='sirm_iterations',type=int,help='Inner SIRM iterations per reconstruction (default 30)')
    arg('--sirm-mask','--RealSpace_mask','--Realspace_Restrain',dest='sirm_mask',type=Path,help='Real-space constraint inside SIRM')
    return p

def main(argv=None):
    parser=build_parser();ns=parser.parse_args(argv);values=vars(ns).copy();additional=values.pop('additional_iterations')
    state=None
    if ns.continue_from is not None:
        state=load_checkpoint(ns.continue_from)
        saved=state['config'];config=Class3DConfig(None,ns.output_root)
        for f in fields(config):
            if f.name in saved:setattr(config,f.name,Path(saved[f.name]) if f.name in PATH_FIELDS and saved[f.name] is not None else saved[f.name])
        # Native continuation applies common sigma first, then explicit axes.
        # Expand a saved common value when an individual axis is overridden.
        axis_fields=('sigma_rot_deg','sigma_tilt_deg','sigma_psi_deg')
        axis_changes=any(values.get(key) is not None for key in axis_fields)
        if axis_changes:
            effective=list(config.angular_sigmas)
            if ns.sigma_ang_deg is not None:
                effective=[max(0.,ns.sigma_ang_deg)]*3
            for j,key in enumerate(axis_fields):
                if values[key] is not None:effective[j]=values[key]
                values[key]=effective[j] if effective[j]>0 else -1.
            values['sigma_ang_deg']=-1.
        for key,value in values.items():
            if value is None:continue
            if key in SIRM_CONTINUATION_FIELDS or key in EXECUTION_OVERRIDES or key in CONTINUATION_SAMPLING_OVERRIDES or key in ('output_root','continue_from','iterations'):setattr(config,key,value)
            elif key=='input_star':parser.error('--i cannot replace checkpoint particle metadata; preserve its data STAR')
            elif value!=getattr(config,key):parser.error(f'Cannot change scientific setting {key} during Class3D continuation')
        # Native 3-D continuation derives the default psi grid from HEALPix.
        # A deliberate order change must not inherit an old custom psi step.
        # With no order change, preserve v0.3.1's exact-resume behaviour.
        if config.healpix_order!=saved['healpix_order'] and ns.psi_step_deg is None:
            config.psi_step_deg=None
        if ns.iterations is None:config.iterations=max(int(saved['iterations']),int(state['iteration'])+1)
        if additional:config.iterations=int(state['iteration'])+int(ns.iterations or 1)
    else:
        if additional:parser.error('--additional-iterations requires --continue')
        config=Class3DConfig(ns.input_star,ns.output_root)
        for key,value in values.items():
            if value is not None:setattr(config,key,value)
    if ns.device is not None and ns.devices is None:config.devices=''
    config.references=tuple(config.references)
    run_class3d(config,checkpoint_state=state)

if __name__=='__main__':main()
