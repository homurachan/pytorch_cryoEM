from __future__ import annotations

import argparse
import sys

import torch

from relion_torch.cli.common import parse_dtype, print_outputs
from relion_torch.em.fixed_pose import FixedPoseEMConfig, run_fixed_pose_from_files


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="relion_torch_fixedpose",
        description=(
            "Fixed-pose 2-D/3-D multi-class MAP/EM on RELION STAR/MRC particles"
        ),
    )
    parser.add_argument("--i", required=True, dest="input_star")
    parser.add_argument(
        "--ref",
        required=True,
        action="append",
        help=(
            "Initial reference; repeat for classes. One 2-D MRCS stack is also "
            "accepted with --refdim 2."
        ),
    )
    parser.add_argument("--o", required=True, dest="output_prefix")
    parser.add_argument("--refdim", type=int, choices=(2, 3))
    parser.add_argument("--iter", type=int, default=5, dest="iterations")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument(
        "--device", default="cuda:0" if torch.cuda.is_available() else "cpu"
    )
    parser.add_argument("--dtype", default="float32", choices=("float32", "float64"))
    parser.add_argument("--pad", type=float, default=2.0)
    parser.add_argument("--no-ctf", action="store_true")
    parser.add_argument("--tau2-fudge", type=float, default=1.0)
    parser.add_argument("--preweight-iters", type=int, default=10)
    parser.add_argument("--skip-gridding", action="store_true")
    parser.add_argument("--split-random-halves", action="store_true")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--subset", type=int, choices=(1, 2))
    parser.add_argument("--class-number", type=int)
    parser.add_argument(
        "--particle-diameter",
        "--particle_diameter",
        type=float,
        dest="particle_diameter_angstrom",
        help=(
            "Particle diameter in Angstrom (not radius). If omitted, use "
            "RELION's (box_size - mask_edge) * pixel_size default."
        ),
    )
    parser.add_argument(
        "--mask-edge",
        "--maskedge",
        "--width-mask-edge",
        "--width_mask_edge",
        type=float,
        default=5.0,
        dest="mask_edge_pixels",
        help="Width of the particle-mask cosine edge in pixels (RELION default: 5)",
    )
    parser.add_argument("--zero-mask", "--zero_mask", action="store_true")
    parser.add_argument("--flatten-solvent", action="store_true")
    parser.add_argument("--solvent-mask", dest="solvent_mask_path")
    parser.add_argument(
        "--strict-highres-exp",
        "--strict_highres_exp",
        "--maxres",
        type=float,
        dest="strict_highres_exp_angstrom",
        help=(
            "Strict Angstrom cutoff for probability calculations only; does not "
            "replace PSNR resolution or working current size"
        ),
    )
    parser.add_argument(
        "--current-size-increment",
        type=int,
        default=10,
        help="Shell increment used by RELION current_resolution -> current_size scheduling",
    )
    parser.add_argument(
        "--minres-map",
        "--minres_map",
        type=int,
        default=5,
        help="Minimum PSNR resolution shell used by RELION MAP estimation",
    )
    parser.add_argument(
        "--adaptive-fraction",
        "--adaptive_fraction",
        type=float,
        default=1.0,
        help="Posterior mass retained in maximization (1.0 is useful for parity tests)",
    )
    parser.add_argument(
        "--use-all-data",
        "--use_all_data",
        action="store_true",
        help="Disable adaptive working-size restriction and use all Fourier data",
    )
    parser.add_argument("--noise-smoothing-radius", type=int, default=0)
    parser.add_argument("--final-only", action="store_true")
    parser.add_argument("--write-posteriors", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        config = FixedPoseEMConfig(
            device=args.device,
            dtype=parse_dtype(args.dtype),
            iterations=args.iterations,
            batch_size=args.batch_size,
            padding_factor=args.pad,
            do_ctf=not args.no_ctf,
            tau2_fudge=args.tau2_fudge,
            preweight_iterations=args.preweight_iters,
            skip_gridding=args.skip_gridding,
            split_random_halves=args.split_random_halves,
            random_seed=args.seed,
            particle_diameter_angstrom=args.particle_diameter_angstrom,
            mask_edge_pixels=args.mask_edge_pixels,
            zero_mask=args.zero_mask,
            flatten_solvent=args.flatten_solvent,
            solvent_mask_path=args.solvent_mask_path,
            strict_highres_exp_angstrom=args.strict_highres_exp_angstrom,
            current_size_increment=args.current_size_increment,
            minres_map=args.minres_map,
            adaptive_fraction=args.adaptive_fraction,
            use_all_data=args.use_all_data,
            noise_smoothing_radius=args.noise_smoothing_radius,
            write_every_iteration=not args.final_only,
            write_posterior_table=args.write_posteriors,
        )
        refs: str | list[str]
        refs = args.ref[0] if len(args.ref) == 1 else args.ref
        result = run_fixed_pose_from_files(
            args.input_star,
            refs,
            args.output_prefix,
            config,
            reference_dim=args.refdim,
            subset=args.subset,
            class_number=args.class_number,
        )
        print_outputs(result.output_files)
        return 0
    except Exception as exc:
        print(
            f"relion_torch_fixedpose: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
