from __future__ import annotations

import argparse
from pathlib import Path
import sys

import torch

from relion_torch.cli.common import parse_dtype, print_outputs, read_spectrum
from relion_torch.reconstruction.reconstruct import ReconstructionOptions
from relion_torch.reconstruction.standalone import (
    StandaloneReconstructionConfig,
    run_standalone_reconstruction,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="relion_torch_reconstruct",
        description=(
            "Point-group RELION-3.1-style / SIRM reconstruction from particle STAR/MRC data using PyTorch"
        ),
    )
    parser.add_argument("--i", required=True, dest="input_star", help="Input particle STAR")
    parser.add_argument("--o", required=True, dest="output_root", help="Output root")
    parser.add_argument("--refdim", type=int, choices=(2, 3), default=3)
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--dtype", default="float32", choices=("float32", "float64"))
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--pad", type=float, default=2.0)
    parser.add_argument("--ctf", action="store_true", help="Apply CTF to numerator and CTF^2 to weight")
    parser.add_argument("--fom-weighting", action="store_true")
    parser.add_argument("--split-random-halves", action="store_true")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--subset", type=int, choices=(1, 2))
    parser.add_argument("--class-number", type=int)
    parser.add_argument("--maxres", type=float, dest="max_resolution_angstrom")
    parser.add_argument("--particle-diameter", type=float, dest="particle_diameter_angstrom")
    parser.add_argument("--zero-mask", action="store_true")
    parser.add_argument("--mask", dest="mask_path")
    parser.add_argument("--solvent-flatten", action="store_true")
    parser.add_argument("--preweight-iters", type=int, default=10)
    parser.add_argument("--skip-gridding", "--skip_gridding", action="store_true")
    parser.add_argument("--symmetry-backend",choices=["auto","off","required"],default="auto")
    parser.add_argument("--gridding-backend", choices=["auto","off","required","ordered"], default="auto", help="Insertion backend; ordered uses fixed-order segmented sums")
    parser.add_argument("--reconstruction-backend",choices=["auto","off","required"],default="auto")
    parser.add_argument("--tau2", help="Tau2 spectrum as STAR/NPY/TXT")
    parser.add_argument("--fsc", help="Gold-standard half-map FSC spectrum as STAR/NPY/TXT")
    parser.add_argument(
        "--fsc-already-full-map",
        action="store_true",
        help="Do not apply RELION's half-map-to-whole-map FSC conversion",
    )
    parser.add_argument("--tau2-fudge", type=float, default=1.0)
    parser.add_argument("--min-resol-shell", type=int, default=0)
    parser.add_argument("--blob-r", type=float, default=1.9)
    parser.add_argument("--blob-a", type=float, default=15.0)
    parser.add_argument("--write-debug", action="store_true")
    parser.add_argument('--sym',dest='symmetry',default='C1',help='Cn, Dn, T, O, I1-I4 (I=I2)')
    parser.add_argument('--sirm','--SIRM',action='store_true')
    parser.add_argument('--sirm-threshold','--thres_SIRM',type=float,default=.5)
    parser.add_argument('--sirm-histogram','--thres_hist',type=float,default=0.)
    parser.add_argument('--sirm-iterations','--iter_SIRM',type=int,default=5)
    parser.add_argument('--sirm-mask','--Realspace_Restrain','--RealSpace_mask')
    parser.add_argument('--sirm-fsc','--SIRM_weight_star',help='Native SIRM Weight.star; default Weight.star when no FSC/tau2/split source is specified')
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        dtype = parse_dtype(args.dtype)
        tau2 = read_spectrum(args.tau2, ("rlnTau2Ref", "rlnTau2")) if args.tau2 else None
        fsc = (
            read_spectrum(args.fsc, ("rlnFourierShellCorrelation", "rlnGoldStandardFsc"))
            if args.fsc
            else None
        )
        from relion_torch.reconstruction.sirm import SIRMOptions
        if args.sirm and not args.sirm_fsc and fsc is None and tau2 is None and not args.split_random_halves:
            args.sirm_fsc='Weight.star'
        sirm_fsc=read_spectrum(args.sirm_fsc,("rlnGoldStandardFsc","rlnFourierShellCorrelation")) if args.sirm_fsc else None
        options = ReconstructionOptions(
            sirm=SIRMOptions(args.sirm_threshold,args.sirm_iterations,args.sirm_histogram,args.sirm_mask,sirm_fsc) if args.sirm else None,
            preweight_iterations=args.preweight_iters,
            skip_gridding=args.skip_gridding,backend=args.reconstruction_backend,
            tau2=tau2,
            fsc=fsc,
            tau2_fudge=args.tau2_fudge,
            reconstruct_whole_map_from_fsc=not args.fsc_already_full_map,
            min_resol_shell=args.min_resol_shell,
            blob_radius=args.blob_r,
            blob_alpha=args.blob_a,
        )
        config = StandaloneReconstructionConfig(
            input_star=args.input_star,
            output_root=args.output_root,
            device=args.device,
            dtype=dtype,
            batch_size=args.batch_size, gridding_backend=args.gridding_backend,
            reference_dim=args.refdim,
            symmetry=args.symmetry,symmetry_backend=args.symmetry_backend,
            padding_factor=args.pad,
            use_ctf=args.ctf,
            fom_weighting=args.fom_weighting,
            split_random_halves=args.split_random_halves,
            random_seed=args.seed,
            subset=args.subset,
            class_number=args.class_number,
            max_resolution_angstrom=args.max_resolution_angstrom,
            particle_diameter_angstrom=args.particle_diameter_angstrom,
            zero_mask=args.zero_mask,
            mask_path=args.mask_path,
            solvent_flatten=args.solvent_flatten,
            write_debug=args.write_debug,
            reconstruction_options=options,
        )
        result = run_standalone_reconstruction(config)
        print_outputs(result.output_files)
        return 0
    except Exception as exc:
        print(f"relion_torch_reconstruct: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
