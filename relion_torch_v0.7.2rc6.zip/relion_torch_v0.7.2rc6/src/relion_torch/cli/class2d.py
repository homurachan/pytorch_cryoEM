"""Class2D CLI: explicit observation model, EM corrections, sampling and restart."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
from relion_torch.class2d.runner import Class2DConfig, run_class2d, _load_saved_state


def build_parser():
    p=argparse.ArgumentParser(prog="relion_torch_class2d",description="RELION 3.1 Class2D EM state machine")
    p.add_argument('--i',dest='input_star',help='input particle STAR; recovered on continuation')
    p.add_argument('--o',dest='output_root',required=True)
    p.add_argument('--K',dest='number_of_classes',type=int)
    p.add_argument('--ref',dest='references',action='append',default=[],
                   help='repeat for K references, use a reference STAR, or one common reference')
    p.add_argument('--ref-stack',dest='reference_stack',action='store_true',
                   help='interpret the single --ref as an explicit K-image stack (PyTorch extension)')
    p.add_argument('--continue',dest='continue_from')
    p.add_argument('--iter',dest='iterations',type=int,default=25,
                   help='final iteration number, including completed iterations on CLI continuation')
    p.add_argument('--additional-iterations',action='store_true',
                   help='interpret --iter as additional iterations on continuation (legacy PyTorch mode)')
    p.add_argument('--fast-subsets','--fast_subsets',dest='fast_subsets',action='store_true',default=None,
                   help='RELION 3.1 staged particle subsets (changes optimization); final absolute iteration >=20')
    p.add_argument('--no-fast-subsets','--no_fast_subsets',dest='fast_subsets',action='store_false')
    p.add_argument('--candidate-schedule',choices=('grouped','v0210'),default='grouped',
                   help='grouped: compact transfer and group-aligned candidate blocks; v0210: old CPU schedule')
    p.add_argument('--initialization-mode',choices=('batched','legacy'),default='batched',
                   help='batched: share full-data mask/FFT between noise and initial references; legacy: separate scalar passes')
    p.add_argument('--device',default='cuda')
    p.add_argument('--devices',default='',help='Permanent worker devices, e.g. 0,1; cpu,cpu for validation')
    p.add_argument('--worker-threads','--worker_threads',type=int,default=1)
    p.add_argument('--worker-chunk-size','--worker_chunk_size',type=int,default=256)
    p.add_argument('--batch-size','--batch_size',type=int,default=8)
    p.add_argument('--psi-step','--psi_step',type=float,default=12.)
    p.add_argument('--offset-range','--offset_range',type=float,default=5.)
    p.add_argument('--offset-step','--offset_step',type=float,default=1.)
    p.add_argument('--oversampling',type=int,default=1)
    p.add_argument('--adaptive-fraction','--adaptive_fraction',type=float,default=.999)
    p.add_argument('--skip-align','--skip_align',action='store_true')
    p.add_argument('--firstiter-cc','--firstiter_cc',action='store_true',default=True,
                   help='CC on absolute iteration 1 (default retained by project policy)')
    p.add_argument('--no-firstiter-cc','--no_firstiter_cc',dest='firstiter_cc',action='store_false')
    p.add_argument('--particle-diameter','--particle_diameter',type=float)
    p.add_argument('--mask-edge','--maskedge',type=float,default=5.)
    p.add_argument('--zero-mask','--zero_mask',action='store_true',default=True)
    p.add_argument('--no-zero-mask',dest='zero_mask',action='store_false')
    p.add_argument('--tau2-fudge','--tau2_fudge',type=float,default=2.)
    p.add_argument('--pad',dest='padding_factor',type=float,default=2.)
    p.add_argument('--minres-map','--minres_map',type=int,default=5)
    p.add_argument('--preweight-iterations',type=int,default=10)
    p.add_argument('--random-seed','--random_seed',type=int,default=0)
    p.add_argument('--perturb',dest='perturbation_factor',type=float,default=.5)
    p.add_argument('--gpu-psi-grid',action='store_true',help='round psi count to 32-multiple as native GPU mode')
    p.add_argument('--orientation-chunk-size',type=int,default=256)
    p.add_argument('--backprojector-chunk-size',type=int,default=128)
    p.add_argument('--skip-expected-accuracy',action='store_true')
    p.add_argument('--expected-accuracy-trials',type=int,default=10,
                   help='maximum trial particles for Class2D accuracy (RELION 3.1 default: 10; 0 disables)')
    p.add_argument('--init-mode',choices=('relion','random-subsets','random-particles'),default='relion',
                   help='relion: CTF-aware random class/psi Fourier initialization; other modes are custom')
    p.add_argument('--init-subset-size',type=int,default=64)
    p.add_argument('--use-input-alignment-for-init',action='store_true')
    p.add_argument('--ini-high','--ini_high',dest='initial_high_resolution',type=float,
                   help='Initial low-pass resolution (A); no-reference RELION mode defaults to N*pixel/ROUND(0.07*N)')
    p.add_argument('--flatten-solvent','--flatten_solvent',action='store_true')
    p.add_argument('--solvent-mask','--solvent_mask',type=Path)
    p.add_argument('--solvent-mask2','--solvent_mask2',type=Path)
    p.add_argument('--lowpass-mask','--lowpass_mask',type=Path)
    p.add_argument('--solvent-lowpass-resolution','--lowpass',type=float)
    p.add_argument('--norm',dest='do_norm_correction',action='store_true',default=False)
    p.add_argument('--no-norm','--no_norm',dest='do_norm_correction',action='store_false')
    p.add_argument('--scale',dest='do_scale_correction',action='store_true',default=False)
    p.add_argument('--no-scale','--no_scale',dest='do_scale_correction',action='store_false')
    p.add_argument('--auto-sampling','--allow-coarser-sampling','--allow_coarser_sampling',
                   dest='auto_sampling',action='store_true',default=False)
    p.add_argument('--fixed-sampling',dest='auto_sampling',action='store_false')
    p.add_argument('--debug-dimensionally-consistent-prior', '--debug_dimensionally_consistent_prior',
                   action='store_true', default=False,
                   help='DEBUG: use Angstrom-consistent translation priors and sigma-offset residuals; default is native RELION 3.1 numeric behavior')
    p.add_argument('--no-debug-dimensionally-consistent-prior',
                   dest='debug_dimensionally_consistent_prior', action='store_false')
    p.add_argument('--translation-prior-normalization', choices=('gpu', 'cpu'), default='gpu',
                   help='GPU log-prior convention (default); cpu adds native CPU mean normalization for absolute DLL comparisons')
    p.add_argument('--performance-mode', choices=('optimized', 'v029', 'v028', 'reference'), default='optimized',
                   help='optimized: current batch/weight execution; v029: 0.2.9 layout; v028: original 0.2.8 layout; reference: original uncached layout')
    p.add_argument('--performance-cache-mib', type=float, default=256.,
                   help='additional geometry/active-view cache budget in MiB (not total GPU memory); 0 disables these tables')
    p.add_argument('--candidate-chunk-size', type=int, default=4096,
                   help='maximum parent rows per optimized sparse tile; also bounded by candidate-work-mib')
    p.add_argument('--candidate-work-mib', type=float, default=256.,
                   help='workspace planning budget (MiB) for candidate tiles and grouped sums; not total GPU memory')
    p.add_argument('--fine-score-mode', choices=('auto', 'sparse', 'dense'), default='auto',
                   help='auto: deterministic dense-vs-sparse execution cost model using retained blocks, active Fourier support and workspace; bounded fallback in all modes')
    p.add_argument('--group-backprojection', dest='group_backprojection', action='store_true', default=True,
                   help='combine class/orientation contributions before gridding (default; changes FP summation order)')
    p.add_argument('--no-group-backprojection', dest='group_backprojection', action='store_false')
    p.add_argument('--batch-preprocess', dest='batch_preprocess', action='store_true', default=True,
                   help='shared batched observation preparation (default in optimized mode)')
    p.add_argument('--no-batch-preprocess', dest='batch_preprocess', action='store_false')
    p.add_argument('--preprocess-work-mib', type=float, default=256.,
                   help='transient preparation workspace planning budget, excluding returned batch tensors')
    p.add_argument('--preprocess-cache-mib', type=float, default=32.,
                   help='hard storage cap for shared mask/noise/CTF geometry; no particle images are cached')
    p.add_argument('--accumulation-statistics', choices=('optimized','v0211'), default='optimized',
                   help='optimized: reuse noise/scale terms and reduce residuals by particle; v0211: old statistic order')
    p.add_argument('--weighted-sum-layout', choices=('auto','orientation','parent'), default='auto',
                   help='Class2D only: auto/orientation groups translations by fine orientation; parent keeps v0.2.12 layout')
    p.add_argument('--weight-precision', choices=('float32','float64'), default='float32',
                   help='precision for posterior/raw-weight arithmetic; float32 matches RELION accelerator XFLOAT')
    p.add_argument('--accumulation-precision', choices=('float32','float64'), default='float32',
                   help='precision for Class2D noise/scale/offset weighted-sum statistics')
    p.add_argument('--accumulation-mode', choices=('auto','phase','v029'), default='auto',
                   help='auto: shared phase and bounded early weight coalescing; phase: shared phase only; v029: two weighted image sums')
    p.add_argument('--group-cache-scope', choices=('iteration','batch'), default='iteration',
                   help='lifetime of bounded grouped sums; never a full-particle cache')
    p.add_argument('--timing-detail-samples', type=int, default=32,
                   help='maximum sampled tile-detail intervals per iteration; schedule detail covers every batch; 0 disables details')
    p.add_argument('--timing', action='store_true',
                   help='synchronized stages: OUTPUT_timing.jsonl and OUTPUT_startup_timing.json')
    p.add_argument('--no-timing', dest='timing', action='store_false',
                   help='disable stage timings, including when continuing a timed checkpoint')
    p.add_argument('--write-debug',action='store_true')
    p.add_argument('--ctf',dest='use_ctf',action='store_true',default=False)
    p.add_argument('--no-ctf',dest='use_ctf',action='store_false')
    p.add_argument('--ctf-corrected-ref','--ctf_corrected_ref',dest='ctf_corrected_ref',action='store_true',default=False)
    p.add_argument('--no-ctf-corrected-ref',dest='ctf_corrected_ref',action='store_false')
    p.add_argument('--ctf-premultiplied',action='store_true')
    p.add_argument('--ctf-phase-flipped','--ctf_phase_flipped',action='store_true')
    p.add_argument('--only-flip-phases','--only_flip_phases',action='store_true')
    p.add_argument('--ctf-intact-first-peak','--ctf_intact_first_peak',dest='intact_first_peak',action='store_true')
    p.add_argument('--current-size',type=int,help='diagnostic explicit working size')
    p.add_argument('--strict-highres-exp','--strict_highres_exp',dest='strict_highres_angstrom',type=float)
    from relion_torch.io.particle_store import add_particle_io_arguments
    add_particle_io_arguments(p)
    return p


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    p=build_parser();a=p.parse_args(argv);completed=0
    if a.continue_from:
        state=_load_saved_state(a.continue_from)
        if state is not None:
            # Keep execution chunking as well unless explicitly overridden.
            # Changing reduction grouping can alter the last FP32 bits even
            # when scientific state and the random stream are identical.
            supplied = {token.split('=', 1)[0] for token in argv if token.startswith('--')}
            for key, names in {
                'preread_images': {'--preread-images', '--preread_images', '--no-preread-images', '--no_preread_images'},
                'io_batch_size': {'--io-batch-size', '--io_batch_size'},
                'pool_size': {'--pool', '--pool-size'},
                'max_open_stacks': {'--max-open-stacks', '--max_open_stacks'},
                'particle_io': {'--particle-io', '--particle_io'},
                'preread_max_gib': {'--preread-max-gib', '--preread_max_gib'},
                'device': {'--device'},
                'devices': {'--devices'},
                'worker_threads': {'--worker-threads','--worker_threads'},
                'worker_chunk_size': {'--worker-chunk-size','--worker_chunk_size'},
                'batch_size': {'--batch-size', '--batch_size'},
                'orientation_chunk_size': {'--orientation-chunk-size'},
                'backprojector_chunk_size': {'--backprojector-chunk-size'},
                'write_debug': {'--write-debug'},
                'performance_mode': {'--performance-mode'},
                'performance_cache_mib': {'--performance-cache-mib'},
                'timing': {'--timing', '--no-timing'},
                'candidate_chunk_size': {'--candidate-chunk-size'},
                'candidate_work_mib': {'--candidate-work-mib'},
                'fine_score_mode': {'--fine-score-mode'},
                'group_backprojection': {'--group-backprojection', '--no-group-backprojection'},
                'batch_preprocess': {'--batch-preprocess', '--no-batch-preprocess'},
                'preprocess_work_mib': {'--preprocess-work-mib'},
                'preprocess_cache_mib': {'--preprocess-cache-mib'},
                'accumulation_statistics': {'--accumulation-statistics'},
                'weighted_sum_layout': {'--weighted-sum-layout'},
                'weight_precision': {'--weight-precision'},
                'accumulation_precision': {'--accumulation-precision'},
                'accumulation_mode': {'--accumulation-mode'},
                'group_cache_scope': {'--group-cache-scope'},
                'timing_detail_samples': {'--timing-detail-samples'},
                'candidate_schedule': {'--candidate-schedule'},
                'initialization_mode': {'--initialization-mode'},
            }.items():
                if not (supplied & names) and key in state['options']:
                    setattr(a, key, state['options'][key])
            # Scientific prior modes are checkpoint state, not execution options.
            # Reject an explicitly conflicting flag instead of silently ignoring it.
            for key, names in {
                'debug_dimensionally_consistent_prior': {'--debug-dimensionally-consistent-prior', '--debug_dimensionally_consistent_prior', '--no-debug-dimensionally-consistent-prior'},
                'translation_prior_normalization': {'--translation-prior-normalization'},
            }.items():
                if key in state['options'] and supplied & names and getattr(a, key) != state['options'][key]:
                    p.error(f"{key} conflicts with the saved checkpoint; start a new run to compare prior modes")
            completed=int(state['iteration'])
            a.input_star=a.input_star or state['data_star']
            a.number_of_classes=a.number_of_classes or len(state['references'])
        else:
            from relion_torch.io.star import read_star
            import re
            path=Path(a.continue_from)
            if path.name.endswith('_optimiser.star'):
                general=next(iter(read_star(path).values())).iloc[0]
                path=Path(str(general['rlnModelStarFile']))
            if not path.name.endswith('_model.star'):
                candidates=sorted(path.parent.glob(path.name+'_it*_model.star'))
                if not candidates:p.error('cannot resolve continuation prefix')
                path=candidates[-1]
            completed=int(re.search(r'_it(\d+)_model.star$',path.name).group(1))
            a.input_star=a.input_star or str(path).replace('_model.star','_data.star')
            a.number_of_classes=a.number_of_classes or len(read_star(path)['model_classes'])
        if not a.additional_iterations:
            a.iterations-=completed
            if a.iterations<=0:p.error('--iter must exceed the completed iteration (or use --additional-iterations)')
    if a.input_star is None or a.number_of_classes is None:
        p.error('--i and --K are required for a new run')
    supplied={token.split('=',1)[0] for token in argv if token.startswith('--')}
    if '--device' in supplied and '--devices' not in supplied:a.devices=''
    config=Class2DConfig(
        input_star=Path(a.input_star),output_root=Path(a.output_root),number_of_classes=a.number_of_classes,
        references=tuple(Path(x) for x in a.references),iterations=a.iterations,device=a.device,batch_size=a.batch_size,
        devices=a.devices,worker_threads=a.worker_threads,worker_chunk_size=a.worker_chunk_size,
        preread_images=a.preread_images, io_batch_size=a.io_batch_size, pool_size=a.pool_size,
        max_open_stacks=a.max_open_stacks, particle_io=a.particle_io, preread_max_gib=a.preread_max_gib,
        psi_step_deg=a.psi_step,offset_range_pixels=a.offset_range,offset_step_pixels=a.offset_step,
        oversampling=a.oversampling,adaptive_fraction=a.adaptive_fraction,skip_align=a.skip_align,
        firstiter_cc=a.firstiter_cc,particle_diameter_angstrom=a.particle_diameter,mask_edge_pixels=a.mask_edge,
        zero_mask=a.zero_mask,tau2_fudge=a.tau2_fudge,padding_factor=a.padding_factor,
        preweight_iterations=a.preweight_iterations,random_seed=a.random_seed,
        orientation_chunk_size=a.orientation_chunk_size,backprojector_chunk_size=a.backprojector_chunk_size,
        skip_expected_accuracy=a.skip_expected_accuracy,expected_accuracy_trials=a.expected_accuracy_trials,
        init_mode=a.init_mode,init_subset_size=a.init_subset_size,use_input_alignment_for_init=a.use_input_alignment_for_init,
        continue_from=Path(a.continue_from) if a.continue_from else None,flatten_solvent=a.flatten_solvent,
        do_norm_correction=a.do_norm_correction,do_scale_correction=a.do_scale_correction,
        auto_sampling=a.auto_sampling,write_debug=a.write_debug,use_ctf=a.use_ctf,ctf_corrected_ref=a.ctf_corrected_ref,
        ctf_premultiplied=a.ctf_premultiplied,reference_stack=a.reference_stack,perturbation_factor=a.perturbation_factor,
        initial_high_resolution=a.initial_high_resolution,minres_map=a.minres_map,solvent_mask=a.solvent_mask,
        solvent_mask2=a.solvent_mask2,lowpass_mask=a.lowpass_mask,solvent_lowpass_resolution=a.solvent_lowpass_resolution,
        current_size=a.current_size,strict_highres_angstrom=a.strict_highres_angstrom,gpu_psi_grid=a.gpu_psi_grid,
        ctf_phase_flipped=a.ctf_phase_flipped,only_flip_phases=a.only_flip_phases,intact_first_peak=a.intact_first_peak,
        debug_dimensionally_consistent_prior=a.debug_dimensionally_consistent_prior,
        translation_prior_normalization=a.translation_prior_normalization,
        performance_mode=a.performance_mode, performance_cache_mib=a.performance_cache_mib, timing=a.timing,
        candidate_chunk_size=a.candidate_chunk_size, candidate_work_mib=a.candidate_work_mib,
        fine_score_mode=a.fine_score_mode, group_backprojection=a.group_backprojection,
        batch_preprocess=a.batch_preprocess, preprocess_work_mib=a.preprocess_work_mib,
        preprocess_cache_mib=a.preprocess_cache_mib, accumulation_mode=a.accumulation_mode,accumulation_statistics=a.accumulation_statistics,
        weighted_sum_layout=a.weighted_sum_layout, weight_precision=a.weight_precision,
        accumulation_precision=a.accumulation_precision,
        group_cache_scope=a.group_cache_scope, timing_detail_samples=a.timing_detail_samples,
        candidate_schedule=a.candidate_schedule, initialization_mode=a.initialization_mode, fast_subsets=a.fast_subsets)
    run_class2d(config)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
