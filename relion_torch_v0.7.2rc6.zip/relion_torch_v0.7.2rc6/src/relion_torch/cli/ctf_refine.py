"""Executable entry point: relion_pytorch_ctf_refine."""
from __future__ import annotations
import argparse
import math
import sys
from relion_torch.version import __version__


def parser():
    p = argparse.ArgumentParser(prog='relion_pytorch_ctf_refine',
        description='Fixed-pose RELION SPA CTF/optics refinement with PyTorch, CPU or CUDA.')
    p.add_argument('--version', action='version', version=f'relion-torch {__version__}')
    p.add_argument('--i', required=True, help='Input particle STAR with original poses and rlnRandomSubset')
    p.add_argument('--o', required=True, help='Output directory')
    p.add_argument('--f', help='PostProcess STAR (corrected FSC and optional reference paths)')
    p.add_argument('--m1', help='Unfiltered half-map 1')
    p.add_argument('--m2', help='Unfiltered half-map 2')
    p.add_argument('--mask', help='Reference mask')
    p.add_argument('--angpix_ref', '--angpix-ref', type=float, help='Reference pixel size; defaults to MRC header')
    p.add_argument('--pad', type=float, default=2., help='Reference Fourier padding (default: 2)')
    p.add_argument('--no_fsc_weight', '--no-fsc-weight', action='store_true', help='Explicitly use uniform reference weights')
    p.add_argument('--fit_defocus', '--fit-defocus', action='store_true', help='Run modular CTF fitting')
    p.add_argument('--fit_mode', '--fit-mode', help='Five f/p/m flags: phase, defocus, astigmatism, Cs, B/scale. Defaults: fpmfm with micrographs, fpfff without.')
    p.add_argument('--fit_bfacs', '--fit-bfacs', action='store_true', help='Separate B/scale L-BFGS fit after other particle parameters')
    p.add_argument('--bfac_per_mg', '--bfac-per-mg', action='store_true')
    p.add_argument('--fit_beamtilt', '--fit-beamtilt', action='store_true')
    p.add_argument('--trefoil', action='store_true', help='Fit beam tilt and odd Zernikes through degree 3')
    p.add_argument('--odd_aberr_max_n', '--odd-aberr-max-n', type=int, default=0)
    p.add_argument('--fit_aberr', '--fit-aberr', action='store_true', help='Fit even optical aberrations')
    p.add_argument('--even_aberr_max_n', '--even-aberr-max-n', type=int, default=4)
    p.add_argument('--fit_aniso', '--fit-aniso', action='store_true', help='Fit magnification per original optics group')
    p.add_argument('--keep_astig', '--keep-astig', action='store_true', help='Skip CTF coordinate adaptation after magnification (always enabled without micrograph names)')
    p.add_argument('--part_astig', '--part-astig', action='store_true', help='Use per-particle CTF coordinate adaptation with real micrographs')
    for name, default in [('defocus', 30.), ('bfac', 30.), ('tilt', 20.), ('aberr', 20.), ('mag', 20.)]:
        p.add_argument('--kmin_'+name, '--kmin-'+name, type=float, default=default, help='Exclude frequencies below this resolution in Angstrom (0 disables)')
    p.add_argument('--kmin', type=float, help='Set the inner resolution limit for all fits')
    for name in ('xr0_t', 'xr1_t', 'xr0_a', 'xr1_a'):
        p.add_argument('--'+name, type=float, default=-1., help='Optional exclusion-ring boundary in Angstrom')
    p.add_argument('--bf0', action='store_true', help='Brute-force initial per-particle defocus scan before L-BFGS')
    p.add_argument('--bf_only', '--bf-only', action='store_true', help='Only the explicit defocus grid scan')
    p.add_argument('--bf_range', '--bf-range', type=float, default=2000.)
    p.add_argument('--bf_step', '--bf-step', type=float, default=100.)
    p.add_argument('--max_defocus_iters', '--max-defocus-iters', type=int, default=100)
    p.add_argument('--max_aberration_iters', '--max-aberration-iters', type=int, default=150)
    p.add_argument('--tolerance', type=float, default=1.e-8)
    p.add_argument('--device', default='auto', help='auto, cpu, cuda, or cuda:N')
    p.add_argument('--dtype', choices=('float32', 'float64'), default='float32')
    p.add_argument('--batch_size', '--batch-size', type=int, default=256, help='Independent particle fitting unit size')
    p.add_argument('--projection_batch', '--projection-batch', type=int, default=8, help='Projection and objective work-tensor chunk size')
    p.add_argument('--fit_cache_mib', '--fit-cache-mib', type=float, default=512., help='CPU CTF statistics cache limit in MiB; excess spills to temporary files under output')
    p.add_argument('--reference_build_device', '--reference-build-device', choices=('auto', 'cpu', 'cuda'), default='auto', help='Reference FFT device; auto uses CUDA when estimated workspace fits, otherwise CPU')
    p.add_argument('--fit_gpu_cache_mib', '--fit-gpu-cache-mib', type=float, default=512., help='Maximum CUDA statistics cache per fitting unit; 0 disables (default 512 MiB)')
    p.add_argument('--resident_halves', '--resident-halves', type=int, choices=(1, 2), default=2)
    p.add_argument('--max_open_stacks', '--max-open-stacks', type=int, default=8)
    p.add_argument('--j', type=int, default=4, help='PyTorch CPU thread count')
    p.add_argument('--only_do_unfinished', '--only-do-unfinished', action='store_true', help='Resume verified completed stages')
    p.add_argument('--verb', type=int, choices=(0, 1), default=1)
    p.add_argument('--timing', action='store_true', help='Write per-unit wall timing, bounded CUDA event samples and transfer counters')
    p.add_argument('--timing_samples', '--timing-samples', type=int, default=32,
                   help='First N CUDA samples per section per reporting interval (default 32; 0: wall timing only)')
    p.add_argument('--debug', action='store_true')
    return p


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    if args.timing_samples < 0:
        p.error('timing_samples must be nonnegative')
    for name, value in vars(args).items():
        if isinstance(value, float) and not math.isfinite(value):
            p.error(name+' must be finite')
    if args.fit_cache_mib < 0 or args.fit_gpu_cache_mib < 0 or (args.angpix_ref is not None and args.angpix_ref <= 0):
        p.error('Cache size must be nonnegative; reference pixel size must be positive')
    for name in ('batch_size', 'projection_batch', 'max_open_stacks', 'j', 'max_defocus_iters', 'max_aberration_iters'):
        if getattr(args, name) < 1:
            p.error(name+' must be positive')
    if args.pad < 1 or args.bf_range < 0 or args.bf_step <= 0 or args.tolerance <= 0:
        p.error('invalid padding, defocus scan range/step, or tolerance')
    if args.odd_aberr_max_n not in (0, 3, 5, 7) or args.even_aberr_max_n not in (0, 2, 4, 6, 8):
        p.error('Supported odd maximum degrees: 0,3,5,7; even: 0,2,4,6,8')
    if args.kmin is not None:
        for name in ('defocus', 'bfac', 'tilt', 'aberr', 'mag'):
            setattr(args, 'kmin_'+name, args.kmin)
    if any(getattr(args, 'kmin_'+name) < 0 for name in ('defocus', 'bfac', 'tilt', 'aberr', 'mag')):
        p.error('Resolution limits must be nonnegative')
    if args.odd_aberr_max_n and not (args.fit_beamtilt or args.trefoil):
        p.error('--odd_aberr_max_n requires --fit_beamtilt or --trefoil')
    from relion_torch.ctf_refine.runner import run
    try:
        run(args)
    except Exception as exc:
        if args.debug:
            raise
        print(f'CTF refinement error: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
