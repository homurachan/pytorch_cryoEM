"""Numerical primitives for the RELION 3.1 autopicker.

Ported from RELION src/autopicker.cpp, fftw.cpp and funcs.cpp.
Original author: Sjors H.W. Scheres, MRC Laboratory of Molecular Biology.
This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version. This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
more details. This complete copyright notice must be included in any revised
version of the source code. Additional authorship citations may be added, but
existing author citations must be preserved.
"""
from __future__ import annotations
import math
import numpy as np
import torch
from relion_torch.relion_statistics import relion_round_positive as iround


def fourier_window(source: torch.Tensor, size: int) -> torch.Tensor:
    """RELION windowFourierTransform, unshifted half spectrum; no rescaling."""
    n = source.shape[-2]
    if size == n:
        return source
    out = source.new_zeros((*source.shape[:-2], size, size // 2 + 1))
    k = torch.arange(size, device=source.device)
    k = torch.where(k <= size // 2, k, k - size)
    x = torch.arange(min(size, n) // 2 + 1, device=source.device)
    valid = (k > -(n + 1) // 2) & (k <= n // 2)
    rows = torch.nonzero(valid).flatten()
    out[..., rows[:, None], x] = source[..., (k[rows] % n)[:, None], x]
    if size > n:
        out *= (k[:, None].square() + torch.arange(size // 2 + 1, device=source.device).square() <= (n // 2)**2)
    return out


def radius2(size, *, device, dtype):
    k = torch.arange(size, device=device, dtype=dtype)
    k = torch.where(k <= size // 2, k, k - size)
    return k[:, None].square() + torch.arange(size // 2 + 1, device=device, dtype=dtype).square()


def good_fourier_size(requested, limit, optimise=True):
    def largest_prime(v):
        i = 2
        while i * i <= v:
            if v % i:
                i += 1
            else:
                v //= i
        return v
    def score(v):
        return max(largest_prime(v), largest_prime(v // 2 + 1))
    requested = max(2, int(requested) // 2 * 2)
    if not optimise or score(requested) <= 43:
        return requested
    up = down = requested
    while score(up) >= 43 and up <= limit + 2:
        up += 2
    while score(down) >= 43 and down > 2:
        down -= 2
    return down if up - requested > requested - down or up > limit else up


class RelionRandom:
    """Portable glibc rand + RELION float polar Gaussian sequence.

    A private state avoids modifying Python, NumPy, PyTorch or libc global RNGs.
    Reseeding intentionally preserves the spare Gaussian, as RELION does.
    """
    def __init__(self, seed=1):
        self.spare = None
        self.seed(seed)

    def seed(self, seed):
        seed = int(seed) & 0xffffffff
        seed = seed or 1
        state = [seed]
        word = seed if seed < 0x80000000 else seed - 0x100000000
        for _ in range(30):
            word = (16807 * word) % 2147483647
            state.append(word)
        self.state = state
        self.front, self.rear = 3, 0
        for _ in range(310):
            self.rand()

    def rand(self):
        v = (self.state[self.front] + self.state[self.rear]) & 0xffffffff
        self.state[self.front] = v
        self.front = (self.front + 1) % 31
        self.rear = (self.rear + 1) % 31
        return v >> 1

    def normal(self, count):
        out = np.empty(count, dtype=np.float32)
        f = np.float32
        for i in range(count):
            if self.spare is not None:
                out[i], self.spare = self.spare, None
                continue
            while True:
                u = f(-1 + f(f(self.rand()) / f(2147483647)) * f(2))
                v = f(-1 + f(f(self.rand()) / f(2147483647)) * f(2))
                w = f(float(u)**2 + float(v)**2)
                if 0 < w < 1:
                    break
            mult = f(math.sqrt(-2 * math.log(float(w)) / float(w)))
            out[i], self.spare = f(u * mult), f(v * mult)
        return out


def prepare_micrograph(image, size, rng, outlier_zscore=8., invert=False):
    if image.ndim != 2 or not bool(torch.isfinite(image).all()):
        raise ValueError('Micrograph must be a finite 2D image')
    # In RELION 3.1 computeStats, N/(N-1) is integer division: population std.
    std, mean = torch.std_mean(image, correction=0)
    if not bool(std > 0):
        raise ValueError('Cannot pick from a constant micrograph')
    image = (image - mean) / std
    image = torch.where(image.abs() > outlier_zscore, 0., image)
    if invert:
        image = -image
    h, w = image.shape
    if (h, w) == (size, size):
        return image
    y, x = size // 2 - h // 2, size // 2 - w // 2
    result = image.new_empty((size, size))
    outside = torch.ones((size, size), dtype=torch.bool, device=image.device)
    outside[y:y+h, x:x+w] = False
    result[outside] = torch.from_numpy(rng.normal(size * size - h * w)).to(image)
    result[y:y+h, x:x+w] = image
    return result


def local_statistics(fmic, fmic2, mask, work_size):
    """Local solvent mean/stddev; forward-normalised Fourier conventions."""
    n = fmic.shape[-2]
    fmask = torch.fft.rfft2(torch.fft.ifftshift(mask), norm='forward')
    factor = n*n / float(mask.sum())
    mean = torch.fft.irfft2(fourier_window(fmic * fmask.conj(), work_size), s=(work_size,)*2, norm='forward') * factor
    second = torch.fft.irfft2(fourier_window(fmic2 * fmask.conj(), work_size), s=(work_size,)*2, norm='forward') * factor
    var = second - mean.square()
    return torch.where(var > 1.e-10, var.clamp_min(0).sqrt(), 1.), mean


def log_diameters(minimum, maximum, max_search=5.):
    return ([float(iround(minimum/i)) for i in range(int(max_search), 1, -1)]
            + [minimum, (maximum+minimum)/2, maximum]
            + [float(iround(maximum*i)) for i in range(2, int(max_search)+1)])


def log_filter(fmic, original_size, diameter, angpix):
    r2 = radius2(fmic.shape[-2], device=fmic.device, dtype=fmic.real.dtype)
    sigma2 = (0.5 * original_size * angpix / diameter)**2
    return torch.fft.irfft2(fmic * (r2 / sigma2) * torch.exp(-0.5*r2/sigma2), norm='forward')
