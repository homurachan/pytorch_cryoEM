"""Small vector PDF job summary, using only the Python standard library.

This replaces RELION's EPS/Ghostscript pipeline; it does not require a plotting
package or an external executable. Numerical results remain in summary.star.
"""
from pathlib import Path
import zlib


def write_pdf_summary(path,rows):
    def literal(value):
        return str(value).encode('ascii','replace').decode('ascii').replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
    def text(x,y,value,size=10):
        return f'BT /F1 {size} Tf {x} {y} Td ({literal(value)}) Tj ET\n'
    chunks=[rows[i:i+28] for i in range(0,len(rows),28)] or [[]]
    objects=[None,b'<< /Type /Catalog /Pages 2 0 R >>',None,b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
    pages=[]
    total=sum(row['rlnGroupNrParticles'] for row in rows)
    largest=max((row['rlnGroupNrParticles'] for row in rows),default=1) or 1
    for page_number,chunk in enumerate(chunks):
        content='0.1 0.15 0.2 rg\n'+text(40,800,'relion-torch auto-picking',18)
        content+=text(40,778,f'{len(rows)} micrographs | {total} particles | page {page_number+1}/{len(chunks)}')
        content+=text(40,750,'Micrograph (basename)',10)+text(390,750,'Particles',10)+text(490,750,'Mean FOM',10)
        for j,row in enumerate(chunk):
            y=727-j*23
            name=Path(row['rlnMicrographName']).name
            if len(name)>51:name='...'+name[-48:]
            count=row['rlnGroupNrParticles']
            content+='0.85 0.92 0.97 rg\n'+f'40 {y-5} {330*count/largest:.2f} 17 re f\n0.1 0.15 0.2 rg\n'
            content+=text(42,y,name,8)+text(400,y,str(count))+text(495,y,f'{row["rlnAutopickFigureOfMerit"]:.5g}')
        if not chunk:content+=text(40,720,'No completed micrographs.')
        content+=text(40,35,'Full names and precise values: summary.star / autopick_run.json',9)
        compressed=zlib.compress(content.encode('ascii'))
        stream_id=len(objects)
        objects.append(f'<< /Length {len(compressed)} /Filter /FlateDecode >>\nstream\n'.encode()+compressed+b'\nendstream')
        page_id=len(objects)
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents {stream_id} 0 R >>'.encode())
        pages.append(page_id)
    objects[2]=f'<< /Type /Pages /Kids [{" ".join(str(i)+" 0 R" for i in pages)}] /Count {len(pages)} >>'.encode()
    data=bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offsets=[0]
    for i,obj in enumerate(objects[1:],1):
        offsets.append(len(data));data.extend(f'{i} 0 obj\n'.encode()+obj+b'\nendobj\n')
    xref=len(data)
    data.extend(f'xref\n0 {len(objects)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:data.extend(f'{offset:010d} 00000 n \n'.encode())
    data.extend(f'trailer\n<< /Size {len(objects)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
