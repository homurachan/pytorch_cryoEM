"""Bounded, spawn-based micrograph scheduling: one image per device at a time.

Only metadata and, when needed, float32 Gaussian draws cross the boundary. Each
worker owns its CUDA context, reference/projector cache and micrograph arrays.
The coordinator alone publishes job summaries and pipeline status.
"""
from __future__ import annotations
from contextlib import redirect_stdout, redirect_stderr
from multiprocessing.connection import wait
from pathlib import Path
from types import SimpleNamespace
import multiprocessing as mp
import os
import time
import traceback
import torch
from relion_torch.inference.permanent_workers import devices as parse_devices
from relion_torch.autopick.numerics import RelionRandom


class AutopickAborted(Exception):
    pass


def check_abort(args):
    if args.pipeline_control and (Path(args.pipeline_control)/'RELION_JOB_ABORT_NOW').exists():
        raise AutopickAborted('RELION_JOB_ABORT_NOW was requested')


def execution_devices(args):
    """Reuse the refinement device parser without its model/reduction pool."""
    spec = getattr(args,'devices','')
    if spec:
        if args.device is not None or args.gpu is not None:
            raise ValueError('Choose only one of --devices, --device and --gpu')
        return parse_devices(SimpleNamespace(devices=spec)),True
    if args.gpu is not None and ',' in args.gpu:
        return parse_devices(SimpleNamespace(devices=args.gpu)),True
    device = args.device or ('cpu' if args.gpu is None else 'cuda:'+('0' if args.gpu == 'default' else args.gpu))
    return parse_devices(SimpleNamespace(devices=device)),False


class GaussianDraws:
    """Consume a single image's legacy random stream in its original order."""
    def __init__(self,values):
        # An even number of draws leaves no spare for the next image. Those
        # streams can be generated independently inside each worker without
        # serializing LoG/most multi-template jobs behind a coordinator CPU.
        self.generator = RelionRandom(values['seed']) if isinstance(values,dict) else None
        self.length = values['count'] if self.generator is not None else len(values)
        self.values = None if self.generator is not None else values
        self.position = 0

    def normal(self,count):
        end = self.position+count
        if count < 0 or end > self.length:
            raise RuntimeError('Autopick Gaussian draw count does not match the work plan')
        values = self.generator.normal(count) if self.generator is not None else self.values[self.position:end]
        self.position = end
        return values

    def finish(self):
        if self.position != self.length:
            raise RuntimeError('Autopick did not consume its planned Gaussian draws')


def planned_jobs(rows,paths,pending,seed,draw_count,args):
    """Bound memory to one pending image per worker and preserve native RNG.

    RELION's Gaussian generator carries a spare value across srand/reseed.
    Seeding workers independently would therefore change odd-reference runs.
    Odd draw counts use the same stream in input order, including skipped
    images during partial resume. Even counts are independent because there
    is no remaining spare; generate them on the worker. Neither path depends
    on which GPU finishes first.
    """
    rng = RelionRandom(seed)
    last = max(pending,default=-1)
    for index in range(last+1):
        check_abort(args)
        if draw_count%2 == 0:
            if index in pending:
                yield (index,rows[index],paths[index]),{'seed':seed+index,'count':draw_count}
            continue
        rng.seed(seed+index)
        noise = rng.normal(draw_count)
        if index in pending:
            check_abort(args)
            yield (index,rows[index],paths[index]),noise


def _worker_main(channel,device,args,angpix,shape,rank,log):
    # Spawn, never fork an initialized CUDA context (also works on Windows).
    with open(log,'w',encoding='utf-8',buffering=1) as stream:
        with redirect_stdout(stream),redirect_stderr(stream):
            active = 'worker initialization'
            try:
                from relion_torch.autopick.runner import MicrographPicker
                picker = MicrographPicker(args,angpix,shape,device,write_projections=rank==0)
                channel.send(('ready',{'pid':os.getpid(),'device':device,'descriptor':picker.descriptor()}))
                while True:
                    command = channel.recv()
                    if command[0] == 'close':
                        break
                    if command[0] != 'pick':
                        raise ValueError('Unknown autopick worker operation')
                    _,job,noise = command
                    active = f'micrograph {job[0]+1}: {job[1]["rlnMicrographName"]}'
                    channel.send(('result',picker.pick(job,GaussianDraws(noise))))
                    del noise,job,command
            except BaseException:
                error = active+'\n'+traceback.format_exc()
                print(error,flush=True)
                try:
                    channel.send(('error',error))
                except (OSError,EOFError,BrokenPipeError):
                    pass
            finally:
                channel.close()


class MicrographPool:
    def __init__(self,devices,args,angpix,shape):
        self.devices = list(devices)
        self.args = args
        self.processes,self.channels,self.info = [],[],[]
        self.closed = False
        logdir = Path(args.odir)/'autopick_workers'
        logdir.mkdir(parents=True,exist_ok=True)
        self.logs = [logdir/f'worker_{rank}.log' for rank in range(len(devices))]
        context = mp.get_context('spawn')
        try:
            for rank,device in enumerate(devices):
                check_abort(args)
                parent,child = context.Pipe()
                process = context.Process(target=_worker_main,
                    args=(child,device,args,angpix,shape,rank,str(self.logs[rank])),
                    name=f'autopick-{rank}')
                try:
                    process.start()
                except BaseException:
                    parent.close();child.close()
                    raise
                child.close()
                self.channels.append(parent);self.processes.append(process)
            remaining = set(range(len(devices)))
            ready = {}
            while remaining:
                for rank in self._ready(remaining):
                    tag,data = self._receive(rank)
                    if tag != 'ready':
                        raise RuntimeError(f'Unexpected autopick startup message: {tag}')
                    ready[rank] = {**data,'rank':rank,'log':str(self.logs[rank])}
                    remaining.remove(rank)
            self.info = [ready[rank] for rank in range(len(devices))]
            self.descriptor = self.info[0]['descriptor']
            if any(item['descriptor'] != self.descriptor for item in self.info):
                raise RuntimeError('Autopick reference geometry differs between devices')
        except BaseException:
            self.close(terminate=True)
            raise

    def _ready(self,ranks):
        check_abort(self.args)
        ordered = sorted(ranks)
        ready = wait([self.channels[r] for r in ordered],timeout=.2)
        result = [r for r in ordered if self.channels[r] in ready]
        for rank in ordered:
            if rank not in result and not self.processes[rank].is_alive():
                raise RuntimeError(f'Autopick worker {rank} ({self.devices[rank]}, PID {self.processes[rank].pid}) '
                    f'exited with code {self.processes[rank].exitcode}; see {self.logs[rank]}')
        return result

    def _receive(self,rank):
        try:
            tag,data = self.channels[rank].recv()
        except (EOFError,OSError) as exc:
            raise RuntimeError(f'Autopick worker {rank} ({self.devices[rank]}) disconnected; see {self.logs[rank]}') from exc
        if tag == 'error':
            raise RuntimeError(f'Autopick worker {rank} ({self.devices[rank]}) failed; see {self.logs[rank]}\n{data}')
        return tag,data

    def process(self,jobs,on_result):
        iterator = iter(jobs)
        active = {}
        def submit(rank):
            check_abort(self.args)
            item = next(iterator,None)
            if item is None:
                return
            job,noise = item
            try:
                self.channels[rank].send(('pick',job,noise))
            except (OSError,EOFError,BrokenPipeError) as exc:
                raise RuntimeError(f'Cannot send micrograph {job[0]+1} to autopick worker {rank} '
                    f'({self.devices[rank]}); see {self.logs[rank]}') from exc
            active[rank] = job[0]
        for rank in range(len(self.devices)):
            submit(rank)
        while active:
            ready = self._ready(active)
            # Read every completed result before dispatching further work so
            # a reported failure does not leave other results blocked on IPC.
            for rank in ready:
                tag,result = self._receive(rank)
                if tag != 'result' or result['input_index'] != active[rank]:
                    raise RuntimeError('Autopick worker returned an unexpected result')
                on_result(result)
                del active[rank]
            for rank in ready:
                submit(rank)

    def close(self,terminate=False):
        if self.closed:
            return
        self.closed = True
        for process,channel in zip(self.processes,self.channels):
            if terminate and process.is_alive():
                process.terminate()
            elif process.is_alive():
                try:
                    channel.send(('close',))
                except (OSError,EOFError,BrokenPipeError):
                    pass
        deadline = time.monotonic()+5
        for process in self.processes:
            process.join(max(0,deadline-time.monotonic()))
        for process in self.processes:
            if process.is_alive():
                process.terminate()
        for process in self.processes:
            process.join(2)
            if process.is_alive():
                process.kill();process.join(2)
        for channel in self.channels:
            channel.close()

    def __enter__(self):
        return self

    def __exit__(self,kind,value,tb):
        self.close(terminate=kind is not None)
