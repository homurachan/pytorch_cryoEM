# Author: "Sjors H.W. Scheres"
# MRC Laboratory of Molecular Biology
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# This complete copyright notice must be included in any revised version of the
# source code. Additional authorship citations may be added, but existing
# author citations must be preserved.

"""Micrograph/optics input and RELION-compatible coordinate output."""
from pathlib import Path
import glob
import re
import numpy as np
import pandas as pd
import mrcfile
import torch
from relion_torch.io.star import read_star, write_star
from relion_torch.io.mrc import read_mrc, mrc_pixel_size, MRCStackCache, write_mrc
from relion_torch.fourier.resampling import resize_centered_map
from relion_torch.fourier.projector import FourierProjector
from relion_torch.fourier.conventions import centered_irfft
from relion_torch.geometry.euler import relion_euler_matrix
from relion_torch.sampling.relion_sampling import RelionSampling
from relion_torch.relion_statistics import relion_round_positive as iround


def resolve_image(name, source=None):
    path = Path(name).expanduser()
    if path.exists():
        return path.resolve()
    if source is not None and not path.is_absolute():
        for parent in Path(source).resolve().parents:
            candidate = parent / path
            if candidate.exists():
                return candidate.resolve()
    raise FileNotFoundError(f'Image not found: {name} (input: {source})')


def micrographs(spec, angpix):
    if Path(spec).suffix.lower() == '.star':
        blocks = read_star(spec)
        frames = [v for v in blocks.values() if 'rlnMicrographName' in v]
        if len(frames) != 1:
            raise ValueError('Input STAR must contain one micrograph table')
        frame = frames[0]
        optics = blocks.get('optics')
        rows = []
        for _, r in frame.iterrows():
            row = r.to_dict()
            if optics is not None:
                group = optics[optics.rlnOpticsGroup == row.get('rlnOpticsGroup',1)]
                if len(group) != 1:
                    raise ValueError('Missing or duplicate optics group')
                row = {**group.iloc[0].to_dict(), **row}
            pixel = row.get('rlnMicrographPixelSize')
            if pixel is None and 'rlnDetectorPixelSize' in row and 'rlnMagnification' in row:
                pixel = row['rlnDetectorPixelSize'] / row['rlnMagnification'] * 10000
            if pixel is None:
                raise ValueError('STAR lacks rlnMicrographPixelSize or legacy magnification/pixel size')
            row['_angpix'] = float(pixel)
            row['_path'] = resolve_image(row['rlnMicrographName'],spec)
            rows.append(row)
        if rows and max(r['_angpix'] for r in rows)-min(r['_angpix'] for r in rows) > .01:
            raise ValueError('Run different micrograph pixel sizes separately')
    else:
        rows = [{'rlnMicrographName':p,'_path':Path(p).resolve(),'_angpix':angpix} for p in sorted(glob.glob(spec))]
    if not rows:
        raise ValueError('No input micrographs found')
    if not all(np.isfinite(r['_angpix']) and r['_angpix'] > 0 for r in rows):
        raise ValueError('Micrograph pixel size must be finite and positive')
    return rows


def output_root(name, odir):
    normalized = str(name).replace('\\','/')
    match = re.search(r'/job\d{3}[^/]*/(.*)',normalized)
    tail = match.group(1) if match else normalized
    # Absolute input filenames stay within odir and keep their directory names.
    tail = re.sub(r'^[A-Za-z]:','',tail).lstrip('/')
    if '..' in Path(tail).parts:
        raise ValueError('Parent traversal in micrograph names is not supported')
    return Path(odir) / Path(tail).with_suffix('')


COORD_COLUMNS = ['rlnCoordinateX','rlnCoordinateY','rlnClassNumber','rlnAutopickFigureOfMerit','rlnAnglePsi']
HELICAL_COLUMNS = ['rlnHelicalTubeID','rlnAngleTiltPrior','rlnAnglePsiPrior','rlnHelicalTrackLengthAngst','rlnAnglePsiFlipRatio','rlnAngleRotFlipRatio']


def write_coordinates(path, peaks, scale, extra=None):
    records = [dict(zip(COORD_COLUMNS,(p.x/scale,p.y/scale,p.ref+1,p.fom,p.psi))) for p in peaks]
    if extra is not None:
        for row, fields in zip(records,extra):
            row.update(fields)
    columns = COORD_COLUMNS if extra is None else COORD_COLUMNS[:-1]+HELICAL_COLUMNS
    frame = pd.DataFrame(records, columns=columns)
    path = Path(path)
    temporary = path.with_name(path.name+'.tmp')
    write_star({'':frame},temporary,deterministic=True)
    temporary.replace(path)
    return frame


def load_templates(args, angpix, device, dtype, *, write_projections=True):
    ref = args.ref
    ap = args.angpix_ref
    if ref == 'gauss':
        if args.particle_diameter <= 0:
            raise ValueError('--ref gauss requires --particle_diameter')
        n = int(1.5*iround(args.particle_diameter/angpix))
        n += n%2
        k = torch.arange(n,device=device,dtype=dtype)-n//2
        refs = [args.gauss_max*torch.exp(-(k[:,None].square()+k.square())/(2*(n/6)**2))]
        args.ang, args.ctf, ap = 360.,False,angpix
    elif Path(ref).suffix.lower() == '.star':
        blocks = read_star(ref)
        frames = [v for v in blocks.values() if 'rlnReferenceImage' in v or 'rlnImageName' in v]
        if len(frames) != 1:
            raise ValueError('Reference STAR must contain rlnReferenceImage or rlnImageName')
        frame = frames[0]
        column = 'rlnReferenceImage' if 'rlnReferenceImage' in frame else 'rlnImageName'
        refs = []
        with MRCStackCache() as cache:
            for value in frame[column]:
                value = str(value)
                index,name = value.split('@',1) if '@' in value else (None,value)
                path = resolve_image(name,ref)
                refs.append(cache.read_image(path,None if index is None else int(index),device=device,dtype=dtype))
                if len(refs) == 1 and ap < 0:
                    ap = mrc_pixel_size(path) or angpix
    else:
        path = resolve_image(ref)
        data = read_mrc(path,device=device,dtype=dtype)
        with mrcfile.open(path,header_only=True,permissive=True) as m:
            requested_dim = getattr(args, 'ref_dim', None)
            if requested_dim is not None:
                volume = requested_dim == 3
            else:
                # RELION 3.1 writes cubic maps with ISPG=0 but MZ=NZ.
                # .mrcs is always a stack unless explicitly overridden.
                cubic_grid = (data.ndim == 3 and len(set(data.shape)) == 1
                              and int(m.header.mz) == data.shape[0])
                volume = (data.ndim == 3 and path.suffix.lower() != '.mrcs'
                          and (int(m.header.ispg) != 0 or cubic_grid))
        if volume and (data.ndim != 3 or len(set(data.shape)) != 1 or data.shape[0] % 2):
            raise ValueError('3D reference must be an even-sized cubic volume; use --ref_dim 2 for an image stack')
        if args.verb:
            print(f'Reference {path}: {"3D volume" if volume else "2D image/stack"}'
                  ' (override with --ref_dim 2 or 3)')
        if volume:
            if args.helix:
                raise ValueError('--helix requires 2D templates')
            if ap < 0:
                ap = angpix
            n = data.shape[-1]
            current = n if args.lowpass < 0 else min(n,2*int(np.ceil(n*ap/args.lowpass)))
            projector = FourierProjector.from_real(data,padding_factor=args.pad,current_size=max(2,current))
            sampling = RelionSampling(3,healpix_order=args.healpix_order,symmetry=args.sym,perturbation_factor=0,offset_range=0)
            refs = []
            for rot,tilt in sampling.directions:
                matrix = relion_euler_matrix(float(rot),float(tilt),0.,device=device,dtype=dtype)
                refs.append(centered_irfft(projector.project(matrix), (n,n), ndim=2))
            if args.verb and write_projections:
                write_mrc(Path(args.odir)/'reference_projections.mrcs',torch.stack(refs),pixel_size_angstrom=ap)
        else:
            refs = [data] if data.ndim == 2 else list(data.unbind(0))
    if ap < 0:
        ap = angpix
    if not refs or any(r.ndim != 2 or r.shape[0] != r.shape[1] or r.shape != refs[0].shape or r.shape[0]%2 for r in refs):
        raise ValueError('Templates must have the same even square dimensions')
    if not all(bool(torch.isfinite(r).all()) for r in refs):
        raise ValueError('Non-finite reference template')
    if args.particle_diameter < 0:
        widths = []
        for r in refs:
            line = (r[r.shape[0]//2]-r[0,0]).abs() > 1.e-6
            hits = torch.nonzero(line).flatten()
            first = int(hits[0]) if hits.numel() else 0
            zeros = torch.nonzero(~line[first+1:]).flatten()
            last = first+int(zeros[0]) if zeros.numel() and hits.numel() else len(line)-1
            widths.append(last-first)
        args.particle_diameter = float(np.mean(widths))*ap
    if abs(ap-angpix) > 1.e-3:
        n = refs[0].shape[0]
        new = 2*iround((n//2)*ap/angpix)
        refs = [resize_centered_map(r,new)*min(1.,n/new) for r in refs]
    n = refs[0].shape[0]
    if not 0 < args.particle_diameter <= n*angpix:
        raise ValueError('Particle diameter must be positive and fit in the template box')
    radius = iround(args.particle_diameter/(2*angpix))-args.shrink_particle_mask
    if radius < 1:
        raise ValueError('Particle mask radius is empty; reduce --shrink_particle_mask')
    k = torch.arange(n,device=device)-n//2
    mask = k[:,None].square()+k.square() < radius*radius
    if bool(mask.all()):
        raise ValueError('No solvent pixels outside the particle mask')
    refs = [r*mask*(-1 if args.invert else 1) for r in refs]
    return refs, mask, radius*radius
