# Author: "Sjors H.W. Scheres"
# MRC Laboratory of Molecular Biology
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# This complete copyright notice must be included in any revised version of the
# source code. Additional authorship citations may be added, but existing
# author citations must be preserved.

"""Helical CCF peak growth, tube tracing, crossover rejection and amyloids.

Ported from RELION 3.1 src/autopicker.cpp. Original author: Sjors H.W.
Scheres, MRC Laboratory of Molecular Biology. GPL-2.0-or-later.
See numerics.py for the preserved copyright and warranty notice.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from functools import cmp_to_key
import math
import numpy as np
from relion_torch.sampling.relion_sampling import relion_round
from relion_torch.autopick.peaks import Peak


def rnd(v):
    return int(relion_round(v))


@dataclass
class HelicalPeak:
    x: float = 0.
    y: float = 0.
    r: float = -1.
    fom: float = -1.
    psi: float = 0.
    ref: int = -1
    pixels: list = field(default_factory=list)
    area: float = -1.
    count: int = 0


def _order(peaks):
    def less(a,b):
        va,vb = (a.fom,b.fom) if abs(a.r-b.r)<.01 else (a.r,b.r)
        return va<vb
    return native_sort(peaks,less)


def native_sort(values,less):
    """libstdc++ introsort tie ordering, used by the Linux reference picker.

    Equal CCF pixels are common along synthetic straight filaments. Stable
    sorting changes tube seeds and can change which end segments survive.
    """
    a = list(values)
    def median(result,x,y,z):
        if less(a[x],a[y]):
            chosen = y if less(a[y],a[z]) else (z if less(a[x],a[z]) else x)
        else:
            chosen = x if less(a[x],a[z]) else (z if less(a[y],a[z]) else y)
        a[result],a[chosen] = a[chosen],a[result]
    def loop(first,last,depth):
        while last-first>16:
            if depth==0:
                # Pathological partitions; keys in this application normally
                # have balanced pivots. Keep bounded worst-case complexity.
                cmp=lambda x,y: -1 if less(x,y) else (1 if less(y,x) else 0)
                a[first:last] = sorted(a[first:last],key=cmp_to_key(cmp))
                return
            depth-=1
            median(first,first+1,first+(last-first)//2,last-1)
            left,right=first+1,last
            while True:
                while less(a[left],a[first]):left+=1
                right-=1
                while less(a[first],a[right]):right-=1
                if left>=right:break
                a[left],a[right]=a[right],a[left]
                left+=1
            loop(left,last,depth)
            last=left
    if len(a)>1:
        loop(0,len(a),2*(len(a).bit_length()-1))
        for i in range(1,len(a)):
            value=a[i]
            j=i
            while j>0 and less(value,a[j-1]):
                a[j]=a[j-1];j-=1
            a[j]=value
    return a


def _bounds(shape,scale,side):
    h,w = [int(np.float32(v)*np.float32(scale)) for v in shape]
    return -(w//2)+side, w-w//2-1-side, -(h//2)+side, h-h//2-1-side


def ccf_peaks(ccf,std,mean,classes,shape,scale,box,ap,args):
    n = len(ccf)
    origin = n//2
    side = int(np.float32(args.skip_side+box//2)*np.float32(scale))
    xmin,xmax,ymin,ymax = _bounds(shape,scale,side)
    allowed = np.zeros_like(ccf,dtype=bool)
    allowed[ymin+origin:ymax+origin+1,xmin+origin:xmax+origin+1] = True
    if args.max_stddev_noise > 0:
        allowed &= std <= args.max_stddev_noise
    if args.min_avg_noise > -900:
        allowed &= mean >= args.min_avg_noise
    rec = allowed & (ccf > args.threshold)
    yy,xx = np.nonzero(rec)
    if allowed.sum() < 100 or len(xx) < 10 or len(xx) > allowed.sum()*.5:
        return [],np.zeros_like(ccf)
    values = ccf[yy,xx]
    order = reversed(native_sort(range(len(xx)),lambda a,b: values[a]<values[b]))
    pdiam = args.particle_diameter/ap*scale
    area_min = .2+2*(scale-.2) if .2<scale<.5 else (.2 if scale<.2 else .8)
    minccf = float(ccf.min())
    peaks = []
    disks = {}
    for rad in range(1,rnd(pdiam/2)):
        # Native enumerates dx first, then dy.
        disks[rad] = [(dx,dy) for dx in range(-rad,rad+1) for dy in range(-rad,rad+1) if dx*dx+dy*dy<=rad*rad]
    for idx in order:
        y,x = int(yy[idx]),int(xx[idx])
        if not rec[y,x]:
            continue
        oldx,oldy = x-origin,y-origin
        ref,fom = int(classes[y,x]),float(ccf[y,x])
        big = HelicalPeak()
        small = HelicalPeak()
        for rad, offsets in disks.items():
            small = big
            for _ in range(3):
                pixels = []
                for dx,dy in offsets:
                    px,py = oldx+dx,oldy+dy
                    if xmin+1<=px<=xmax-1 and ymin+1<=py<=ymax-1:
                        value = float(ccf[py+origin,px+origin]) if rec[py+origin,px+origin] else minccf
                        pixels.append((px,py,value))
                high = [p for p in pixels if p[2] > args.threshold]
                big = HelicalPeak(r=rad,pixels=pixels)
                if not high:
                    break
                big.x = sum(p[0] for p in high)/len(high)
                big.y = sum(p[1] for p in high)/len(high)
                big.fom = max(p[2] for p in high)
                big.count,big.area = len(high),len(high)/len(pixels)
                newx,newy = rnd(big.x),rnd(big.y)
                if not (xmin+1<=newx<=xmax-1 and ymin+1<=newy<=ymax-1) or (newx,newy)==(oldx,oldy):
                    break
                oldx,oldy = newx,newy
            if big.area < area_min:
                break
        if small.r >= 0 and small.area >= 0 and small.count:
            for px,py,_ in small.pixels:
                rec[py+origin,px+origin] = False
            small.ref,small.fom = ref,fom
            peaks.append(small)
    peaks = _order(peaks)
    owners = np.full_like(ccf,-1,dtype=np.int64)
    for i,peak in enumerate(peaks):
        radius = math.ceil(peak.r)
        if radius <= 1 or radius > pdiam/2:
            peak.r = -1
            continue
        for dx,dy in disks.get(radius,[]):
            x,y = rnd(peak.x)+dx,rnd(peak.y)+dy
            if not (xmin+1<=x<=xmax-1 and ymin+1<=y<=ymax-1):
                continue
            old = owners[y+origin,x+origin]
            if old >= 0:
                peaks[old].r = -1
            owners[y+origin,x+origin] = i
    peaks = [p for p in peaks if p.r >= 0 and p.area >= 0 and p.count]
    plot = np.zeros_like(ccf)
    for p in peaks:
        for x,y,fom in p.pixels:
            if fom >= args.threshold:
                plot[y+origin,x+origin] = 1
    return peaks,plot


def trace_tubes(peaks,scale,ap,args):
    diameter = args.particle_diameter/ap*scale
    step = args.min_distance/ap*scale
    width = args.helical_tube_outer_diameter/ap*scale
    if diameter < 5*scale or step < .9999 or step > diameter or width < 1 or width > diameter:
        raise ValueError('Helix scaled spacing/width must be >=1 pixel and <= particle diameter')
    if len(peaks) < 5:
        return []
    peaks = _order(peaks)
    xy = np.array([(p.x,p.y) for p in peaks])
    counts = np.array([max(1,p.count) for p in peaks])
    other = np.full(len(peaks),-1,dtype=int)
    curvature = args.helical_tube_kappa_max/(diameter/2)
    tubes = []
    tubeid = 0

    def gather(center,available):
        delta = xy-center
        dist2 = (delta*delta).sum(1)
        ids = np.nonzero(available & (dist2 < diameter*diameter/4))[0]
        dist = np.sqrt(dist2[ids])
        psi = np.rad2deg(np.arctan2(delta[ids,1],delta[ids,0]))
        psi[(np.abs(delta[ids])<.01).all(1)] = 0
        return ids,dist,psi

    for seed in range(len(peaks)-1,-1,-1):
        if other[seed] > 0:
            continue
        tubeid += 1
        other[seed] = tubeid
        this = np.zeros(len(peaks),bool)
        this[seed] = True
        ids,dist,psi = gather(xy[seed],other < 0)
        if len(ids) <= 2:
            continue
        candidates = np.arange(1800)*.1
        dev = np.abs(psi[:,None]-candidates)
        dev = np.where(dev>180,np.abs(dev-360),dev)
        dev = np.where(dev>90,np.abs(dev-180),dev)
        best = candidates[np.argmin((dev*counts[ids,None]).sum(0)/counts[ids].sum())]
        dev0 = np.abs(psi-best)
        dev1 = np.where(dev0>180,np.abs(dev0-360),dev0)
        dev1 = np.where(dev1>90,np.abs(dev1-180),dev1)
        allowed = np.deg2rad(dev1)/np.maximum(dist,1.e-30) <= curvature
        direction2 = np.abs(dev1-dev0) < .1
        tracks,lengths = [],[]
        for mask in (allowed & ~direction2,allowed & direction2):
            track,length = [],0.
            if mask.any():
                direction = float(psi[mask].mean())
                distance = float(dist[mask].max())
                center = xy[seed].copy()
                while True:
                    unit = np.array([math.cos(math.radians(direction)),math.sin(math.radians(direction))])
                    end = center+unit*distance
                    track.append(HelicalPeak(x=float(end[0]),y=float(end[1]),psi=direction))
                    length += distance
                    delta = xy-(center+end)/2
                    along = np.abs(delta@unit)
                    across = np.abs(delta@np.array([-unit[1],unit[0]]))
                    near = ((delta*delta).sum(1) <= ((distance+width)/2)**2) & (along<(distance+width)/2) & (across<width/2)
                    new = near & ~this
                    fresh = new & (other<0)
                    this[new] = True
                    other[fresh] = tubeid
                    if not fresh.any():
                        break
                    center = end
                    next_ids,next_dist,next_psi = gather(center,~this)
                    keep = np.deg2rad(np.abs(next_psi-direction))/np.maximum(next_dist,1.e-30) < curvature
                    if not keep.any():
                        break
                    weights = counts[next_ids[keep]]
                    direction = float(np.sum(next_psi[keep]*weights)/weights.sum())
                    distance = float(next_dist[keep].max())
            tracks.append(track)
            lengths.append(length)
        track = list(reversed(tracks[1]))+[peaks[seed]]+tracks[0]
        length = sum(lengths)
        if len(track)<3 or length<diameter or length<step:
            continue
        segments = [HelicalPeak(x=track[0].x,y=track[0].y,psi=math.degrees(math.atan2(track[1].y-track[0].y,track[1].x-track[0].x)))]
        left = 0.
        for a,b in zip(track,track[1:]):
            dx,dy = b.x-a.x,b.y-a.y
            distance = math.hypot(dx,dy)
            angle = math.degrees(math.atan2(dy,dx))
            number = math.floor((left+distance)/step)
            for j in range(1,number+1):
                frac = (j*step-left)/distance
                segments.append(HelicalPeak(x=a.x+frac*dx,y=a.y+frac*dy,psi=angle))
            left = left+distance-number*step
        segments.append(HelicalPeak(x=track[-1].x,y=track[-1].y,psi=1.e30))
        tubes.append((segments,track,length))
    return tubes


def _extra(tube,psi,length):
    return {'rlnHelicalTubeID':tube,'rlnAngleTiltPrior':90.,'rlnAnglePsiPrior':psi,
        'rlnHelicalTrackLengthAngst':length,'rlnAnglePsiFlipRatio':.5,'rlnAngleRotFlipRatio':.5}


def export_tubes(tubes,ccf,classes,plot,shape,scale,ap,box,args):
    n = len(ccf)
    diameter = args.particle_diameter/ap*scale
    if diameter < 5:
        raise ValueError('Helical export requires particle diameter >=5 pixels after shrinking')
    for _,track,_ in tubes:
        for a,b in zip(track,track[1:]):
            dx,dy = b.x-a.x,b.y-a.y
            distance = math.hypot(dx,dy)
            for d in np.arange(1,distance):
                x,y = rnd(a.x+dx*d/distance)+n//2,rnd(a.y+dy*d/distance)+n//2
                if 0<=x<n and 0<=y<n:
                    plot[y,x] = 1
    for i,(segments,_,_) in enumerate(tubes):
        for other,_,_ in tubes[i+1:]:
            xy = np.array([(p.x,p.y) for p in other])
            for p in segments:
                close = np.nonzero(((xy-(p.x,p.y))**2).sum(1) < diameter*diameter/4)[0]
                if len(close):
                    p.psi = 1.e30
                    for j in close:
                        other[j].psi = 1.e30
    peaks,extras = [],[]
    tubeid = 0
    side = int(np.float32(args.skip_side+box//2)*np.float32(scale))
    h,w = shape
    for segments,_,length in tubes:
        if args.helical_tube_length_min > args.particle_diameter and length < args.helical_tube_length_min/ap*scale:
            continue
        tubeid += 1
        track_length = 0.
        for j,p in enumerate(segments):
            if j:
                track_length += math.hypot(p.x-segments[j-1].x,p.y-segments[j-1].y)
            x,y = rnd(p.x),rnd(p.y)
            # Native export uses the original image extent here; protect array bounds too.
            if abs(p.psi)>360 or not (-w//2+side+1<=x<=w-w//2-side-2 and -h//2+side+1<=y<=h-h//2-side-2):
                continue
            ix,iy = x+n//2,y+n//2
            if not (0<=ix<n and 0<=iy<n):
                continue
            peaks.append(Peak(p.x+(w//2)*scale,p.y+(h//2)*scale,int(classes[iy,ix]),float(ccf[iy,ix]),0.))
            # Preserve native 3.1 track-length field (scaled-grid length * angpix).
            extras.append(_extra(tubeid,-p.psi,ap*track_length))
    return peaks,extras


def amyloid(ccf,psi,std,mean,shape,scale,ap,args):
    ccf = ccf.copy()
    n = len(ccf)
    radius = max(1,rnd(.5*args.helical_tube_outer_diameter/ap*scale))
    maxdiff = math.degrees(2*args.helical_tube_kappa_max)
    circle = []
    for y in range(-radius-1,radius+2):
        for x in range(-radius-1,radius+2):
            if radius*radius < x*x+y*y <= (radius+1)**2:
                angle = math.degrees(math.atan2(y,x))
                if angle>90: angle-=180
                if angle<-90: angle+=180
                if abs(angle)<maxdiff:
                    circle.append((x,y))
    circle = np.asarray(circle,dtype=float).reshape(-1,2)
    xmin,xmax,ymin,ymax = _bounds(shape,scale,rnd(args.skip_side*scale))

    def candidates(p):
        angle = math.radians(-p.psi)
        c,s = math.cos(angle),math.sin(angle)
        xy = circle@np.array([[c,s],[-s,c]]) + (p.x,p.y)
        result = []
        for x,y in xy:
            ix,iy = rnd(x),rnd(y)
            if not (xmin+1<=ix<xmax-1 and ymin+1<=iy<ymax-1):
                continue
            value,angle = float(ccf[iy+n//2,ix+n//2]),float(psi[iy+n//2,ix+n//2])
            diff = abs(p.psi-angle)%360
            if diff>180:diff-=180
            if diff>90:diff-=180
            if abs(diff)<maxdiff and value>args.threshold:
                result.append(HelicalPeak(x=x,y=y,psi=angle,fom=value))
        return result

    def next_coord(p):
        ix,iy = rnd(p.x)+n//2,rnd(p.y)+n//2
        if ccf[iy,ix] < args.threshold:
            return None
        y0,y1,x0,x1 = max(0,iy-radius),min(n,iy+radius+1),max(0,ix-radius),min(n,ix+radius+1)
        yy,xx = np.ogrid[y0:y1,x0:x1]
        view = ccf[y0:y1,x0:x1]
        view[(xx-ix)**2+(yy-iy)**2<radius*radius] = -999.
        first = candidates(p)
        best,best_score = None,-9999.
        # Four-level look-ahead, preserving the native depth-first tie order.
        def visit(q,depth,total,root):
            nonlocal best,best_score
            total += q.fom
            if total>best_score:
                best,best_score = root,total
            if depth<4:
                for child in candidates(q):
                    visit(child,depth+1,total,root)
        for q in first:
            visit(q,1,0.,q)
        return best

    helices = []
    while True:
        iy,ix = np.unravel_index(np.argmax(ccf),ccf.shape)
        value = float(ccf[iy,ix])
        if value < args.threshold:
            break
        helix = [HelicalPeak(x=ix-n//2,y=iy-n//2,fom=value,psi=float(psi[iy,ix]))]
        done = [False,False]
        while not all(done):
            for end in range(2):
                if done[end]:continue
                q = next_coord(helix[0] if end==0 else helix[-1])
                valid = q is not None and q.fom>args.threshold
                if valid:
                    x,y = rnd(q.x)+n//2,rnd(q.y)+n//2
                    valid = not (args.max_stddev_noise>0 and std[y,x]>args.max_stddev_noise) and not (args.min_avg_noise>-900 and mean[y,x]<args.min_avg_noise)
                if valid:
                    if end==0:helix.insert(0,q)
                    else:helix.append(q)
                else:done[end]=True
        ccf[iy,ix] = -999.
        if args.helical_tube_outer_diameter*.5*len(helix)>args.helical_tube_length_min:
            helices.append(helix)
    peaks,extras = [],[]
    h,w = shape
    step = np.float32(args.min_distance/ap)
    for tube,helix in enumerate(helices,1):
        left,length = 0.,0.
        for a,b in zip(helix,helix[1:]):
            dx,dy = np.float32(b.x-a.x)/np.float32(scale),np.float32(b.y-a.y)/np.float32(scale)
            distance = np.float32(math.sqrt(float(dx*dx+dy*dy)))
            angle = -math.degrees(math.atan2(float(dy),float(dx)))
            position = np.float32(left)
            while position < distance:
                frac = float(position/distance)
                peaks.append(Peak(a.x+((w//2)+frac*dx)*scale,a.y+((h//2)+frac*dy)*scale,-1,a.fom))
                extras.append(_extra(tube,angle,ap*length))
                # Match native 3.1's leftover-distance update, including its sign.
                left = float(step+(distance-position))
                length += float(step)
                position = np.float32(position+step)
    return peaks,extras


def pick_helices(ccf,psi,classes,std,mean,shape,scale,ap,box,args):
    if args.amyloid:
        peaks,extras = amyloid(ccf,psi,std,mean,shape,scale,ap,args)
        return peaks,extras,None
    peaks,plot = ccf_peaks(ccf,std,mean,classes,shape,scale,box,ap,args)
    tubes = trace_tubes(peaks,scale,ap,args)
    peaks,extras = export_tubes(tubes,ccf,classes,plot,shape,scale,ap,box,args)
    return peaks,extras,plot
