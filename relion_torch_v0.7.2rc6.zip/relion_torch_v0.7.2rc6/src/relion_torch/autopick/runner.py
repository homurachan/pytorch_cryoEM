# Author: "Sjors H.W. Scheres"
# MRC Laboratory of Molecular Biology
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# This complete copyright notice must be included in any revised version of the
# source code. Additional authorship citations may be added, but existing
# author citations must be preserved.

"""RELION 3.1 autopicker workflow using existing relion_torch primitives.

Ported from src/autopicker.cpp. Original author: Sjors H.W. Scheres,
MRC Laboratory of Molecular Biology. GPL-2.0-or-later; see numerics.py
for the original copyright and warranty notice.
"""
from __future__ import annotations
from pathlib import Path
import copy
import json
import math
import os
import time
import mrcfile
import numpy as np
import pandas as pd
import torch
from relion_torch.io.mrc import read_mrc
from relion_torch.io.star import read_star,write_star
from relion_torch.io.spider import read_spider,write_spider
from relion_torch.fourier.resampling import window_centered_map
from relion_torch.fourier.projector import FourierProjector
from relion_torch.fourier.conventions import centered_irfft
from relion_torch.geometry.euler import relion_euler_matrix
from relion_torch.optics.ctf import CTFParameters,compute_ctf
from relion_torch.optics.ctf import CTFFrequencyGrid2D
from relion_torch.optics.zernike import parse_coefficients,evaluate
from relion_torch.relion_statistics import relion_round_positive as iround
from relion_torch.autopick.data import micrographs,output_root,load_templates,write_coordinates
from relion_torch.autopick.numerics import (fourier_window,radius2,good_fourier_size,
    prepare_micrograph,local_statistics,log_diameters,log_filter)
from relion_torch.autopick.peaks import search_peaks,prune_clusters,remove_close,pick_log
from relion_torch.version import __version__


def ctf_for_micrograph(row,n,original,angpix,args,device,dtype,log=False):
    fields = ['rlnDefocusU','rlnDefocusV','rlnDefocusAngle','rlnVoltage','rlnSphericalAberration','rlnAmplitudeContrast']
    missing = [key for key in fields if key not in row or not np.isfinite(float(row[key]))]
    if missing:
        raise ValueError('Missing CTF metadata: '+', '.join(missing))
    parameters = CTFParameters(*(float(row[k]) for k in fields),
        phase_shift_deg=float(row.get('rlnPhaseShift',0)),bfactor=0. if log else float(row.get('rlnCtfBfactor',0)),
        scale=float(row.get('rlnCtfScalefactor',1)))
    kw = dict(device=device,dtype=dtype,intact_first_peak=args.ctf_intact_first_peak and not log)
    mag_labels = ('rlnMagMat00','rlnMagMat01','rlnMagMat10','rlnMagMat11')
    if all(label in row for label in mag_labels):
        kw['frequency_matrix'] = torch.tensor([row[k] for k in mag_labels],device=device,dtype=dtype).reshape(2,2)
    even = parse_coefficients(row.get('rlnEvenZernike'))
    if len(even):
        grid = CTFFrequencyGrid2D.create(n,angpix*original/n,device=device,dtype=dtype)
        kw['frequency_grid'] = grid
        kw['gamma_offset'] = evaluate(even,grid.x,grid.y,'even')
    # Preserve original field of view on a cropped Fourier grid.
    ctf = compute_ctf(n,angpix*original/n,parameters,**kw)
    if log:
        gamma = compute_ctf(n,angpix*original/n,parameters,**kw,return_gamma=True)
        ctf = torch.where(gamma.abs() > math.pi/2,float(parameters.scale),ctf)
    return torch.where(ctf.abs() < 1.e-8, torch.where(ctf < 0,-1.e-8,1.e-8),ctf)


def cache_read(prefix,suffix,shape,device,dtype):
    data,_ = read_spider(str(prefix)+suffix+'.spi')
    if data.shape != (shape,shape):
        raise ValueError(f'FOM map shape mismatch: {prefix}{suffix}; expected {shape}')
    return torch.as_tensor(data,device=device,dtype=dtype)


def cache_write(prefix,suffix,data,header_max=None):
    write_spider(str(prefix)+suffix+'.spi',data,header_max=header_max)


def make_projector(ref,n,down,args):
    projector = FourierProjector.from_real(window_centered_map(ref,n),padding_factor=args.pad,
        gridding_pre_correction=False,current_size=down)
    # RELION also stores only the low-frequency projector. Crop the periodic
    # representation after construction; keep the original frequency scale.
    compact = min(projector.padded_size,down*args.pad+4)
    if compact < projector.padded_size:
        projector.data = fourier_window(projector.data,compact).clone()
        projector.padded_size = compact
    return projector


def run_log(image,row,prefix,n,work,scale,rng,args,device,dtype):
    diameters = log_diameters(args.LoG_diam_min,args.LoG_diam_max,args.Log_max_search)
    if min(diameters) <= 0:
        raise ValueError('LoG search contains zero diameter; increase LoG_diam_min or reduce Log_max_search')
    if not args.read_fom_maps:
        prepared = prepare_micrograph(image,n,rng,args.outlier_removal_zscore,not args.Log_invert)
        fmic = fourier_window(torch.fft.rfft2(prepared,norm='forward'),work)
        if args.LoG_use_ctf:
            fmic = fmic/ctf_for_micrograph(row,work,n,row['_angpix'],args,device,dtype,log=True)
    best = torch.full((work,work),-999.,device=device,dtype=torch.float32)
    sizes = torch.full_like(best,-999.)
    for diameter in diameters:
        suffix = '_LoG'+str(iround(diameter))
        values = cache_read(prefix,suffix,work,device,dtype) if args.read_fom_maps else log_filter(fmic,n,diameter,row['_angpix'])
        if args.write_fom_maps:
            cache_write(prefix,suffix,values)
        better = values > best
        best[better] = values[better].float()
        sizes[better] = diameter
    if args.write_fom_maps:
        cache_write(prefix,'_bestLoG',best)
        cache_write(prefix,'_bestSize',sizes)
    skip = max(args.skip_side,int(.5*args.LoG_diam_min/row['_angpix']))
    return pick_log(best.cpu().numpy(),sizes.cpu().numpy(),image.shape,scale,row['_angpix'],
        args.LoG_diam_min,args.LoG_diam_max,skip,args.LoG_adjust_threshold,args.LoG_upper_threshold,args.LoG_neighbour/100,
        on_stage=(lambda suffix,data: cache_write(prefix,suffix,data)) if args.write_fom_maps else None)


def run_templates(image,row,prefix,n,down,work,scale,rng,args,refs,mask,radius_sq,projectors,projector_down=None):
    device,dtype = image.device,image.dtype
    ap = row['_angpix']
    box = refs[0].shape[0]
    count = int(mask.sum())
    ctf = ctf_for_micrograph(row,down,n,ap,args,device,dtype) if args.ctf else None
    if args.read_fom_maps:
        std = cache_read(prefix,'_stddevNoise',work,device,dtype)
        mean = cache_read(prefix,'_avgNoise',work,device,dtype)
        helical_std,helical_mean = std,mean
    else:
        prepared = prepare_micrograph(image,n,rng,args.outlier_removal_zscore)
        fmic = torch.fft.rfft2(prepared,norm='forward')
        if args.highpass > 0:
            r = radius2(n,device=device,dtype=dtype).sqrt()
            edge = iround(n*ap/args.highpass)
            lower,upper = max(0,edge-1),edge+1
            hp = .5-.5*torch.cos(math.pi*((r-lower)/(upper-lower)).clamp(0,1))
            fmic *= hp
            prepared = torch.fft.irfft2(fmic,s=(n,n),norm='forward')
        fmic2 = torch.fft.rfft2(prepared.square(),norm='forward')
        inverse_mask = window_centered_map((~mask).to(dtype),n)
        std,mean = local_statistics(fmic,fmic2,inverse_mask,work)
        helical_std,helical_mean = std,mean
        if args.helix:
            axis = torch.arange(box,device=device)-box//2
            r2 = axis[:,None].square()+axis.square()
            hmask = r2 >= iround(args.helical_tube_outer_diameter/(2*ap))**2
            outer = args.max_diam_local_avg
            if args.amyloid and outer < 0:
                outer = 3*args.helical_tube_outer_diameter
            if outer > 0:
                hmask &= r2 <= iround(outer/(2*ap))**2
            if not bool(hmask.any()):
                raise ValueError('Helical noise mask has no pixels')
            helical_std,helical_mean = local_statistics(fmic,fmic2,window_centered_map(hmask.to(dtype),n),work)
        if args.write_fom_maps:
            cache_write(prefix,'_stddevNoise',helical_std)
            cache_write(prefix,'_avgNoise',helical_mean)
        fmic = fourier_window(fmic,down)
    angles = [j*360/iround(360/args.ang) for j in range(iround(360/args.ang))]
    peaks = []
    minimum = iround(args.min_distance/ap)
    expected_ratios = []
    if args.helix:
        combined = torch.full((work,work),-1.e30,device=device,dtype=dtype)
        combined_psi = torch.zeros_like(combined)
        combined_class = torch.full_like(combined,-1.)
    for index,ref in enumerate(refs):
        if args.read_fom_maps:
            if args.helix:
                break
            best = cache_read(prefix,f'_ref{index:06d}._bestCCF',work,device,dtype)
            psi_map = cache_read(prefix,f'_ref{index:06d}._bestPSI',work,device,dtype)
        else:
            if args.verb > 1:
                print(f'  template {index+1}/{len(refs)}',flush=True)
            projector = projectors.get(index)
            if projector is None:
                projector = make_projector(ref,n,down if projector_down is None else projector_down,args)
                projectors[index] = projector
            best = torch.full((work,work),-1.e30,device=device,dtype=dtype)
            psi_map = torch.zeros_like(best)
            for j,psi in enumerate(angles):
                matrix = relion_euler_matrix(0.,0.,psi,device=device,dtype=dtype)
                fref = projector.project(matrix,output_size=down)
                if ctf is not None:
                    fref *= ctf
                if j == 0:
                    real_ref = centered_irfft(fourier_window(fref,n),(n,n),ndim=2)
                    crop = window_centered_map(real_ref,box)[mask]
                    # Native CPU adds one to sumn, but not to the correlation divisor.
                    sumn = count+1
                    sum_ref = crop.sum()/sumn
                    sum_ref2 = crop.square().sum()/sumn
                    noise = torch.from_numpy(rng.normal(count)).to(image)
                    exponent = float((crop.square()+2*crop*noise).sum()/(2*sumn))
                    denominator = math.expm1(exponent)
                    if abs(denominator) < 1.e-14:
                        raise ValueError('Degenerate reference expected probability ratio; check template contrast')
                    expected_ratios.append(math.exp(exponent))
                    del real_ref,crop,noise
                correlation = torch.fft.irfft2(fourier_window(fmic*fref.conj(),work),s=(work,work),norm='forward')*(n*n/count)
                exponent_map = (correlation-mean*sum_ref)/std-.5*sum_ref2
                score = torch.expm1(exponent_map)/denominator
                if not bool(torch.isfinite(score).all()):
                    raise ValueError('Non-finite template scores; check reference contrast or use float64')
                better = score > best
                best[better] = score[better]
                psi_map[better] = psi
            if args.write_fom_maps and not args.helix:
                cache_write(prefix,f'_ref{index:06d}._bestCCF',best,expected_ratios[-1])
                cache_write(prefix,f'_ref{index:06d}._bestPSI',psi_map,expected_ratios[-1])
        if args.helix:
            better = best > combined
            combined[better],combined_psi[better],combined_class[better] = best[better],psi_map[better],float(index)
        else:
            selected = search_peaks(best.cpu().numpy(),psi_map.cpu().numpy(),std.cpu().numpy(),mean.cpu().numpy(),index,
                image.shape,scale,args.skip_side+box//2,args.threshold,args.max_stddev_noise,args.min_avg_noise)
            peaks.extend(prune_clusters(selected,radius_sq,minimum,scale))
    if args.helix:
        if args.read_fom_maps:
            combined = cache_read(prefix,'_combinedCCF',work,device,dtype)
            if args.amyloid:
                combined_psi = cache_read(prefix,'_combinedPSI',work,device,dtype)
            else:
                combined_class = cache_read(prefix,'_combinedCLASS',work,device,dtype)
        if args.write_fom_maps:
            cache_write(prefix,'_combinedCCF',combined)
            cache_write(prefix,'_combinedPSI' if args.amyloid else '_combinedCLASS',combined_psi if args.amyloid else combined_class)
        from relion_torch.autopick.helical import pick_helices
        peaks,extras,plot = pick_helices(combined.cpu().numpy(),combined_psi.cpu().numpy(),combined_class.cpu().numpy(),
            helical_std.cpu().numpy(),helical_mean.cpu().numpy(),image.shape,scale,ap,box,args)
        if plot is not None and (args.write_fom_maps or args.read_fom_maps):
            cache_write(prefix,'_combinedPLOT',plot)
        return peaks,{'expected_probability_ratios':expected_ratios},extras
    peaks = remove_close(prune_clusters(peaks,radius_sq,minimum,scale),minimum,scale)
    return peaks,{'expected_probability_ratios':expected_ratios},None


def input_shape(rows,args):
    """Validate all image headers before any worker can overwrite output."""
    shape = None
    for row in rows:
        with mrcfile.open(row['_path'],header_only=True,permissive=True) as handle:
            current = (int(handle.header.ny),int(handle.header.nx))
            if int(handle.header.nz) != 1 or min(current) < 1:
                raise ValueError('Input micrographs must be 2D images')
        if shape is None:
            shape = current
        if current != shape:
            raise ValueError('All micrographs must have identical 2D dimensions')
    if (max(shape)+2*args.extra_pad)%2:
        raise ValueError('The padded square micrograph size must be even; crop/pad odd-sized inputs first')
    return shape


class MicrographPicker:
    """One device's persistent references and Fourier projectors."""
    @torch.inference_mode()
    def __init__(self,args,angpix,shape,device,*,write_projections=True):
        self.args = args = copy.deepcopy(args)
        self.shape = tuple(shape)
        self.device = torch.device(device)
        self.dtype = getattr(torch,args.dtype)
        torch.set_num_threads(args.j)
        if self.device.type == 'cuda':
            torch.cuda.set_device(self.device)
        self.refs = self.mask = self.radius_sq = None
        self.projectors = {}
        if not args.LoG:
            self.refs,self.mask,self.radius_sq = load_templates(args,angpix,self.device,self.dtype,
                write_projections=write_projections)
            if args.min_distance < 0:
                args.min_distance = self.refs[0].shape[0]*angpix/2
            if args.helix and args.helical_tube_outer_diameter > args.particle_diameter:
                raise ValueError('Helical tube diameter must fit inside particle diameter')
        self.n = n = max(shape)+2*args.extra_pad
        self.down,self.work,self.scale = self.sampling_sizes(angpix)
        if self.refs is not None and self.refs[0].shape[0] > n:
            raise ValueError('Reference box exceeds the micrograph size')
        self.draw_count = 0 if args.read_fom_maps else n*n-shape[0]*shape[1]
        if not args.read_fom_maps and self.refs is not None:
            self.draw_count += len(self.refs)*int(self.mask.sum())

    def sampling_sizes(self,angpix):
        args,n = self.args,self.n
        down = n if args.lowpass < 0 else max(2,min(n,2*iround(n*angpix/args.lowpass)))
        if args.shrink > 1:
            requested = iround(args.shrink)//2*2
            if requested >= n:
                raise ValueError('--shrink in pixels must be smaller than the micrograph')
        else:
            requested = iround(args.shrink*n)//2*2 if args.shrink else down
        work = good_fourier_size(requested,n,not args.skip_optimise_scale)
        scale = float(np.float32(work)/np.float32(n))
        return down,work,scale

    def descriptor(self):
        return {'draw_count':self.draw_count,'work_size':self.work,'original_size':self.n,
            'effective_parameters':{key:getattr(self.args,key) for key in ('ang','ctf','particle_diameter','min_distance')}}

    @torch.inference_mode()
    def pick(self,job,rng):
        index,row,prefix = job
        args = self.args
        started = time.time()
        image = read_mrc(row['_path'],device=self.device,dtype=self.dtype)
        if tuple(image.shape) != self.shape:
            raise ValueError(f'Micrograph shape changed after header validation: {row["_path"]}')
        prefix = Path(prefix)
        prefix.parent.mkdir(parents=True,exist_ok=True)
        down,work,scale = self.sampling_sizes(row['_angpix'])
        if args.LoG:
            peaks,details = run_log(image,row,prefix,self.n,work,scale,rng,args,self.device,self.dtype)
            extras = None
        else:
            peaks,details,extras = run_templates(image,row,prefix,self.n,down,work,scale,rng,args,
                self.refs,self.mask,self.radius_sq,self.projectors,projector_down=self.down)
        rng.finish()
        write_coordinates(str(prefix)+'.star',peaks,scale,extras)
        finished = time.time()
        return {'input_index':index,'micrograph':row['rlnMicrographName'],'count':len(peaks),
            'device':str(self.device),'worker_pid':os.getpid(),'started_at_epoch':started,
            'finished_at_epoch':finished,'seconds':finished-started,'work_size':work,
            'original_size':self.n,'scale':scale,**details}


def _atomic_text(path,text):
    temporary = path.with_name(path.name+'.tmp')
    temporary.write_text(text,encoding='utf-8')
    temporary.replace(path)


def publish(args,rows,paths,reports,skipped,started,devices,workers,status,error=None):
    """The coordinator is the only writer of combined output and status."""
    finished = set(skipped) | {item['input_index'] for item in reports}
    summary,coordinates = [],[]
    for index,(row,prefix) in enumerate(zip(rows,paths)):
        if index not in finished:
            continue
        path = Path(str(prefix)+'.star')
        if path.exists():
            blocks = read_star(path)
            frames = [f for f in blocks.values() if 'rlnCoordinateX' in f]
            frame = frames[0] if frames else pd.DataFrame()
            summary.append({'rlnMicrographName':row['rlnMicrographName'],'rlnAutopickFigureOfMerit':float(frame.rlnAutopickFigureOfMerit.mean()) if len(frame) else 0.,'rlnGroupNrParticles':len(frame)})
            coordinates.append({'rlnMicrographName':row['rlnMicrographName'],'rlnMicrographCoordinates':str(path)})
    out = Path(args.odir)
    out.mkdir(parents=True,exist_ok=True)
    for name,records,columns in (
        ('summary.star',summary,['rlnMicrographName','rlnAutopickFigureOfMerit','rlnGroupNrParticles']),
        ('coords.star',coordinates,['rlnMicrographName','rlnMicrographCoordinates'])):
        temporary = out/(name+'.tmp')
        write_star({'':pd.DataFrame(records,columns=columns)},temporary,deterministic=True)
        temporary.replace(out/name)
    _atomic_text(out/('coords_suffix_'+args.pickname+'.star'),str(args.i)+'\n')
    report = {'version':__version__,'status':status,'device':devices[0] if len(devices)==1 else 'multiple',
        'devices':devices,'workers':workers,'dtype':args.dtype,'parameters':vars(args),
        'micrographs':sorted(reports,key=lambda r:r['input_index']),'skipped_input_indices':sorted(skipped),
        'input_micrographs':len(rows),'completed_micrographs':len(finished),
        'random_stream':'RELION Gaussian stream in input order, including skipped images',
        'total_particles':sum(r['rlnGroupNrParticles'] for r in summary),'seconds':time.time()-started}
    if error is not None:
        report['error'] = str(error)
    _atomic_text(out/'autopick_run.json',json.dumps(report,indent=2,ensure_ascii=False))
    from relion_torch.autopick.report import write_pdf_summary
    write_pdf_summary(out/'logfile.pdf',summary)
    if args.pipeline_control:
        Path(args.pipeline_control).mkdir(parents=True,exist_ok=True)
        marker = {'completed':'SUCCESS','failed':'FAILURE','aborted':'ABORTED'}[status]
        (Path(args.pipeline_control)/('RELION_JOB_EXIT_'+marker)).touch()
    if args.verb:
        print(f'{status}: {report["total_particles"]} particles in {len(finished)}/{len(rows)} micrographs; {report["seconds"]:.2f} s',flush=True)
    return report


def run(args):
    from relion_torch.autopick.parallel import (execution_devices,MicrographPool,GaussianDraws,
        planned_jobs,check_abort,AutopickAborted)
    started = time.time()
    if args.pipeline_control:
        control = Path(args.pipeline_control)
        control.mkdir(parents=True,exist_ok=True)
        for suffix in ('SUCCESS','FAILURE','ABORTED'):
            (control/('RELION_JOB_EXIT_'+suffix)).unlink(missing_ok=True)
    devices,use_workers = execution_devices(args)
    rows = micrographs(args.i,args.angpix)
    paths = [Path(str(output_root(r['rlnMicrographName'],args.odir))+'_'+args.pickname) for r in rows]
    if len({str(p.resolve()) for p in paths}) != len(paths):
        raise ValueError('Input micrographs would overwrite the same output file')
    skipped = {i for i,p in enumerate(paths) if args.only_do_unfinished and Path(str(p)+'.star').exists()}
    pending = set(range(len(rows)))-skipped
    if args.write_fom_maps and len(pending) > 30 and not args.no_fom_limit:
        raise ValueError('Writing more than 30 FOM maps requires --no_fom_limit')
    if args.random_seed == -1:
        args.random_seed = int(time.time())
    reports,workers = [],[]
    def completed(result):
        reports.append(result)
        if args.verb:
            print(f'[{len(reports)}/{len(pending)}] {result["micrograph"]}: {result["count"]} particles '
                f'({result["device"]}, PID {result["worker_pid"]}); {result["seconds"]:.2f} s',flush=True)
    def finish(status,error=None):
        return publish(args,rows,paths,reports,skipped,started,devices,workers,status,error)
    try:
        check_abort(args)
        if pending:
            shape = input_shape(rows,args)
            angpix = rows[0]['_angpix']
            if use_workers:
                with MicrographPool(devices[:len(pending)],args,angpix,shape) as pool:
                    workers.extend(pool.info)
                    for key,value in pool.descriptor['effective_parameters'].items():
                        setattr(args,key,value)
                    jobs = planned_jobs(rows,paths,pending,args.random_seed,pool.descriptor['draw_count'],args)
                    pool.process(jobs,completed)
            else:
                picker = MicrographPicker(args,angpix,shape,devices[0])
                for key,value in picker.descriptor()['effective_parameters'].items():
                    setattr(args,key,value)
                workers.append({'device':devices[0],'pid':os.getpid(),'rank':0})
                for job,noise in planned_jobs(rows,paths,pending,args.random_seed,picker.draw_count,args):
                    completed(picker.pick(job,GaussianDraws(noise)))
        check_abort(args)
        return finish('completed')
    except AutopickAborted as exc:
        return finish('aborted',exc)
    except KeyboardInterrupt:
        finish('aborted','Keyboard interrupt')
        raise
    except Exception as exc:
        # Preserve the primary worker/error traceback if a failed disk also
        # prevents writing the diagnostic summary.
        try:
            finish('failed',exc)
        except (OSError,ValueError):
            pass
        raise
