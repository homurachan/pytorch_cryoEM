# Author: "Sjors H.W. Scheres"
# MRC Laboratory of Molecular Biology
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# This complete copyright notice must be included in any revised version of the
# source code. Additional authorship citations may be added, but existing
# author citations must be preserved.

"""Peak selection ported from RELION 3.1 autopicker.cpp (GPL-2.0-or-later).

Original author: Sjors H.W. Scheres, MRC Laboratory of Molecular Biology.
See numerics.py for the preserved copyright and warranty notice.
"""
from dataclasses import dataclass
import numpy as np
from relion_torch.relion_statistics import relion_round_positive as iround


@dataclass
class Peak:
    x: int
    y: int
    ref: int
    fom: float
    psi: float = 0.


def search_peaks(fom, psi, stddev, mean, ref, shape, scale, skip, threshold, max_std=-1., min_mean=-999.):
    n = fom.shape[0]
    h, w = (int(np.float32(v) * np.float32(scale)) for v in shape)
    skip = max(1, int(np.float32(skip)*np.float32(scale)))
    y0, x0 = n//2 - h//2 + skip, n//2 - w//2 + skip
    y1, x1 = n//2 - h//2 + h - skip, n//2 - w//2 + w - skip
    valid = np.zeros(fom.shape, bool)
    valid[y0:y1, x0:x1] = True
    valid &= fom >= threshold
    if max_std > 0:
        valid &= stddev <= max_std
    if min_mean > -900:
        valid &= mean >= min_mean
    for axis, delta in ((0,1),(0,-1),(1,1),(1,-1)):
        neighbor = np.roll(fom, delta, axis=axis)
        valid &= neighbor <= fom
        if scale >= 1:
            valid &= neighbor >= threshold
    ys, xs = np.nonzero(valid)
    return [Peak(int(x - n//2 + w//2), int(y - n//2 + h//2), ref, float(fom[y,x]), float(psi[y,x])) for y,x in zip(ys,xs)]


def prune_clusters(peaks, particle_radius2, min_distance, scale):
    """Connected components followed by greedy pruning *within* each component.

    This is intentionally not global NMS: RELION also removes both remaining
    close neighbours in a separate final pass.
    """
    if not peaks:
        return []
    xy = np.array([(p.x,p.y) for p in peaks], dtype=np.int64)
    left = np.ones(len(peaks), bool)
    out = []
    cluster_r2 = float(np.float32(particle_radius2)*np.float32(scale)*np.float32(scale))
    mind2 = float(np.float32(min_distance*min_distance)*np.float32(scale)*np.float32(scale))
    for seed in range(len(peaks)):
        if not left[seed]:
            continue
        cluster = [seed]
        left[seed] = False
        for i in cluster:
            near = np.nonzero(left & (((xy-xy[i])**2).sum(1) < cluster_r2))[0]
            cluster.extend(near.tolist())
            left[near] = False
        while cluster:
            best = max(cluster, key=lambda i: peaks[i].fom)
            out.append(peaks[best])
            cluster = [i for i in cluster if i != best and ((xy[i]-xy[best])**2).sum() >= mind2]
    return out


def remove_close(peaks, min_distance, scale):
    xy = np.array([(p.x,p.y) for p in peaks], dtype=np.int64)
    mind2 = float(np.float32(min_distance*min_distance)*np.float32(scale)*np.float32(scale))
    return [p for i,p in enumerate(peaks) if len(peaks) < 2 or np.all(np.delete(((xy-xy[i])**2).sum(1),i) > mind2)]


def pick_log(best, sizes, shape, scale, angpix, minimum, maximum, skip, adjustment, upper, neighbour, on_stage=None):
    best = np.array(best, dtype=np.float32, copy=True)
    n = best.shape[0]
    h, w = (int(np.float32(v)*np.float32(scale)) for v in shape)
    side = int(np.float32(skip)*np.float32(scale))
    y0, x0 = n//2-h//2, n//2-w//2
    if side > 0:
        valid = np.zeros_like(best, dtype=bool)
        valid[y0+side:y0+h-side,x0+side:x0+w-side] = True
        best[~valid] = 0
    valid_size = (sizes >= minimum) & (sizes <= maximum)
    if not valid_size.any():
        return [], {'threshold': None, 'upper_limit': None}
    samples = best[valid_size].astype(np.float64)
    avg, std = float(samples.mean()), float(samples.std())
    threshold, upper_limit = np.float32(avg + adjustment*std), np.float32(avg+upper*std)
    best[~valid_size] = 0
    if on_stage is not None:
        on_stage('_bestLoGb',best)
    best[best < threshold] = 0
    if on_stage is not None:
        on_stage('_bestLoGc',best)
    # Sorting once is equivalent to repeated global maxIndex; stable raster ties.
    candidates = np.flatnonzero(best.ravel() > 0)
    order = candidates[np.argsort(-best.ravel()[candidates], kind='stable')]
    peaks = []
    for index in order:
        y,x = divmod(int(index), n)
        value = best[y,x]
        if value <= 0:
            continue
        if value < upper_limit:
            peaks.append(Peak(x-x0,y-y0,-1,float(value)))
        radius = max(1, iround(scale*(float(sizes[y,x])+minimum)*neighbour/2/angpix))
        a,b,c,d = max(0,y-radius),min(n,y+radius+1),max(0,x-radius),min(n,x+radius+1)
        yy,xx = np.ogrid[a:b,c:d]
        view = best[a:b,c:d]
        view[(yy-y)**2+(xx-x)**2 < radius*radius] = 0
        best[y,x] = 0
    return peaks, {'threshold':float(threshold), 'upper_limit':float(upper_limit)}
