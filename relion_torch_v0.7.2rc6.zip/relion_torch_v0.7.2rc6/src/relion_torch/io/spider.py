"""Dependency-free 2D SPIDER image I/O for RELION autopicker FOM caches.

The maximum header field may hold expected_Pratio instead of the image max.
SPIDER stacks, Fourier images and volumes are deliberately rejected.
"""
from pathlib import Path
import numpy as np
import torch


def read_spider(path):
    path = Path(path)
    with path.open('rb') as stream:
        raw = stream.read(1024)
        if len(raw) < 1024:
            raise ValueError(f'Truncated SPIDER header: {path}')
        header = None
        for endian in ('<','>'):
            trial = np.frombuffer(raw, dtype=endian+'f4')
            if trial[4] == 1 and trial[0] == 1 and trial[23] == 0:
                header = trial
                break
        if header is None:
            raise ValueError(f'Expected a real 2D SPIDER image: {path}')
        h,w,offset = int(header[1]),int(header[11]),int(header[21])
        if min(h,w) < 1 or offset < 1024 or offset != int(header[12])*int(header[22]) or int(header[22]) != 4*w:
            raise ValueError(f'Invalid SPIDER dimensions/header length: {path}')
        if path.stat().st_size != offset+4*h*w:
            raise ValueError(f'Truncated or unexpected SPIDER payload: {path}')
        stream.seek(offset)
        array = np.fromfile(stream,dtype=endian+'f4',count=h*w).astype(np.float32).reshape(h,w)
    if not np.isfinite(array).all():
        raise ValueError(f'Non-finite SPIDER image: {path}')
    return array, float(header[6])


def write_spider(path, data, *, header_max=None):
    if isinstance(data, torch.Tensor):
        data = data.detach().cpu().numpy()
    array = np.asarray(data,dtype='<f4')
    if array.ndim != 2 or not np.isfinite(array).all():
        raise ValueError('SPIDER writer expects a finite 2D image')
    h,w = array.shape
    records = (1024+4*w-1)//(4*w)
    header = np.zeros(records*w,dtype='<f4')
    header[0:3] = (1,h,records+h)
    header[4:10] = (1,1,float(array.max()) if header_max is None else header_max,float(array.min()),float(array.mean()),float(array.std()))
    header[11:13] = (w,records)
    header[20:23] = (1,records*4*w,4*w)
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary = path.with_name(path.name+'.tmp')
    with temporary.open('wb') as stream:
        header.tofile(stream)
        array.tofile(stream)
    temporary.replace(path)

