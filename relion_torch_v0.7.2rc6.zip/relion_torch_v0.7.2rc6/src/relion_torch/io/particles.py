from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
from typing import Any, Iterator, Sequence

import numpy as np
import pandas as pd
import torch

from relion_torch.geometry.euler import relion_euler_matrix
from relion_torch.io.mrc import MRCStackCache
from relion_torch.io.star import RelionStar
from relion_torch.optics.ctf import CTFParameters


def parse_image_reference(value: str, base_dir: Path) -> tuple[int | None, Path]:
    text = str(value).strip()
    if "@" in text:
        index_text, filename = text.split("@", 1)
        try:
            index = int(index_text)
        except ValueError as exc:
            raise ValueError(f"Invalid RELION stack image reference: {text!r}") from exc
        if index < 1:
            raise ValueError(f"RELION image index is one-based and must be >=1: {text!r}")
    else:
        index = None
        filename = text
    path = Path(filename).expanduser()
    if path.is_absolute():
        return index, path.resolve()

    # RELION commonly stores paths relative to the project root, while STAR
    # files produced by jobs live several directories below that root.  First
    # try the STAR directory, then each ancestor (nearest first), and finally
    # the process working directory.  This also keeps simple STAR+MRCS folders
    # working without requiring the caller to chdir into the project.
    base = Path(base_dir).expanduser().resolve()
    candidates = [base / path]
    candidates.extend(parent / path for parent in base.parents)
    cwd_candidate = Path.cwd().resolve() / path
    if cwd_candidate not in candidates:
        candidates.append(cwd_candidate)
    for candidate in candidates:
        if candidate.exists():
            return index, candidate.resolve()
    # Preserve a deterministic, informative missing-file path.
    return index, (base / path).resolve()



def rebase_image_references(
    table: pd.DataFrame,
    *,
    source_dir: str | Path,
    output_dir: str | Path,
) -> pd.DataFrame:
    """Rewrite rlnImageName paths so a copied STAR remains self-consistent.

    RELION image paths are normally interpreted relative to the project working
    directory.  A STAR copied into another job directory can therefore break if
    it originally used paths relative to its own directory.  This helper resolves
    every source reference and writes an equivalent path relative to the output
    STAR directory while preserving one-based stack indices.
    """

    if "rlnImageName" not in table.columns:
        raise KeyError("Particle table is missing rlnImageName")
    source = Path(source_dir).expanduser().resolve()
    output = Path(output_dir).expanduser().resolve()
    result = table.copy()
    rebased: list[str] = []
    for value in result["rlnImageName"]:
        index, path = parse_image_reference(str(value), source)
        relative = Path(os.path.relpath(path, output)).as_posix()
        rebased.append(relative if index is None else f"{index:06d}@{relative}")
    result["rlnImageName"] = rebased
    return result

def owned_array(array: np.ndarray, dtype: np.dtype[Any] = np.dtype(np.float64)) -> np.ndarray:
    """Return writable, owned, C-contiguous metadata storage."""

    return np.array(array, dtype=dtype, order="C", copy=True)


# Retain the private name used by earlier internal callers.
_owned_array = owned_array


def _series_numeric(table: pd.DataFrame, label: str, default: float) -> np.ndarray:
    if label not in table.columns:
        return np.full(len(table), default, dtype=np.float64)
    # pandas may return a read-only view (in particular with copy-on-write
    # enabled).  ``torch.as_tensor`` warns for such arrays because a tensor
    # sharing that storage could subsequently be written.  Metadata batches
    # are tiny compared with particle images, so make an explicit writable,
    # C-contiguous copy here rather than relying on backend-specific pandas
    # ownership semantics.
    return _owned_array(
        pd.to_numeric(table[label], errors="coerce")
        .fillna(default)
        .to_numpy(dtype=np.float64),
        np.dtype(np.float64),
    )


@dataclass(slots=True)
class ParticleBatch:
    row_indices: np.ndarray
    images: torch.Tensor
    rotations: torch.Tensor
    origins_pixels: torch.Tensor
    euler_degrees: torch.Tensor
    ctf_parameters: CTFParameters
    random_subset: torch.Tensor
    class_number: torch.Tensor
    group_index: torch.Tensor
    group_number: torch.Tensor
    fom: torch.Tensor


class ParticleDataset:
    """RELION particle table plus lazy MRCS image access.

    This milestone enforces a single optics group. Metadata tensors are prepared
    once, while images are copied from memory-mapped stacks on demand.
    """

    def __init__(
        self,
        star: RelionStar,
        *,
        subset: int | None = None,
        class_number: int | None = None,
        max_open_stacks: int = 8,
        require_single_optics: bool = True,
    ) -> None:
        if require_single_optics:
            star.validate_single_optics_group()
        else:
            for label in ('rlnImagePixelSize', 'rlnImageSize'):
                if label in star.optics and pd.to_numeric(star.optics[label], errors='raise').nunique() != 1:
                    raise NotImplementedError('Standalone reconstruction currently requires a common pixel/box grid across optics groups; CTF refinement supports separate grids')
        table = star.particles.copy().reset_index(drop=False).rename(columns={"index": "_source_row"})
        if subset is not None:
            if subset not in (1, 2):
                raise ValueError("subset must be 1 or 2")
            if "rlnRandomSubset" not in table.columns:
                raise KeyError("--subset requires rlnRandomSubset in the particle STAR")
            table = table[pd.to_numeric(table["rlnRandomSubset"], errors="coerce") == subset]
        if class_number is not None:
            if class_number < 1:
                raise ValueError("class_number must be >=1")
            if "rlnClassNumber" not in table.columns:
                raise KeyError("--class-number requires rlnClassNumber in the particle STAR")
            table = table[pd.to_numeric(table["rlnClassNumber"], errors="coerce") == class_number]
        table = table.reset_index(drop=True)
        if table.empty:
            raise ValueError("No particles remain after filtering")
        if "rlnImageName" not in table.columns:
            raise KeyError("Particle table is missing rlnImageName")

        self.star = star
        self.table = table
        self.pixel_size = star.pixel_size_angstrom()

        if "rlnGroupNumber" in table.columns:
            group_values = _owned_array(
                (
                pd.to_numeric(table["rlnGroupNumber"], errors="coerce")
                .fillna(1)
                .astype(np.int64)
                .to_numpy()
                ),
                np.dtype(np.int64),
            )
        else:
            group_values = np.ones(len(table), dtype=np.int64)
            self.table["rlnGroupNumber"] = group_values
        self.group_numbers = sorted(int(value) for value in np.unique(group_values))
        group_to_index = {value: index for index, value in enumerate(self.group_numbers)}
        self._group_indices = np.asarray(
            [group_to_index[int(value)] for value in group_values], dtype=np.int64
        )
        self._group_numbers_per_particle = group_values.copy()
        self.group_particle_counts = [
            int(np.count_nonzero(group_values == value)) for value in self.group_numbers
        ]
        self.group_names: list[str] = []
        for value in self.group_numbers:
            rows = self.table[group_values == value]
            if "rlnGroupName" in rows.columns:
                name = str(rows.iloc[0]["rlnGroupName"])
            elif "rlnMicrographName" in rows.columns:
                name = str(rows.iloc[0]["rlnMicrographName"])
            else:
                name = f"group_{value}"
            self.group_names.append(name)
        self.cache = MRCStackCache(max_open=max_open_stacks)
        self._refs = [parse_image_reference(v, star.source_dir) for v in table["rlnImageName"]]
        first_index, first_path = self._refs[0]
        shape = self.cache.shape(first_path)
        if len(shape) == 2:
            self.box_size = int(shape[-1])
        elif len(shape) == 3:
            self.box_size = int(shape[-1])
        else:
            raise ValueError(f"Unsupported particle MRC shape: {shape}")
        if int(shape[-2]) != self.box_size:
            raise ValueError(f"Particle images must be square, got shape {shape[-2:]}")

        optics = star.optics.iloc[0]
        self.voltage_kv = float(optics.get("rlnVoltage", table.iloc[0].get("rlnVoltage", 300.0)))
        self.cs_mm = float(
            optics.get("rlnSphericalAberration", table.iloc[0].get("rlnSphericalAberration", 2.7))
        )
        self.amplitude_contrast = float(
            optics.get("rlnAmplitudeContrast", table.iloc[0].get("rlnAmplitudeContrast", 0.1))
        )

    def __len__(self) -> int:
        return len(self.table)

    @property
    def number_of_groups(self) -> int:
        return len(self.group_numbers)

    def close(self) -> None:
        self.cache.close()

    def _metadata_arrays(self, indices: np.ndarray) -> dict[str, np.ndarray]:
        rows = self.table.iloc[indices]
        rot = _series_numeric(rows, "rlnAngleRot", 0.0)
        tilt = _series_numeric(rows, "rlnAngleTilt", 0.0)
        psi = _series_numeric(rows, "rlnAnglePsi", 0.0)
        ox_a = _series_numeric(rows, "rlnOriginXAngst", np.nan)
        oy_a = _series_numeric(rows, "rlnOriginYAngst", np.nan)
        if np.isnan(ox_a).any():
            ox_px = _series_numeric(rows, "rlnOriginX", 0.0)
            ox_a = np.where(np.isnan(ox_a), ox_px * self.pixel_size, ox_a)
        if np.isnan(oy_a).any():
            oy_px = _series_numeric(rows, "rlnOriginY", 0.0)
            oy_a = np.where(np.isnan(oy_a), oy_px * self.pixel_size, oy_a)
        return {
            "rot": rot,
            "tilt": tilt,
            "psi": psi,
            "ox": ox_a / self.pixel_size,
            "oy": oy_a / self.pixel_size,
            "du": _series_numeric(rows, "rlnDefocusU", 0.0),
            "dv": _series_numeric(rows, "rlnDefocusV", 0.0),
            "da": _series_numeric(rows, "rlnDefocusAngle", 0.0),
            "phase": _series_numeric(rows, "rlnPhaseShift", 0.0),
            "subset": _series_numeric(rows, "rlnRandomSubset", 1.0),
            "class": _series_numeric(rows, "rlnClassNumber", 1.0),
            "group_index": _owned_array(
                self._group_indices[indices], np.dtype(np.int64)
            ),
            "group_number": _owned_array(
                self._group_numbers_per_particle[indices], np.dtype(np.int64)
            ),
            "fom": self._fom_array(rows),
        }

    @staticmethod
    def _fom_array(rows: pd.DataFrame) -> np.ndarray:
        for label in ("rlnMaxValueProbDistribution", "rlnParticleFigureOfMerit"):
            if label in rows.columns:
                values = pd.to_numeric(rows[label], errors="coerce").fillna(1.0)
                return _owned_array(
                    values.to_numpy(dtype=np.float64), np.dtype(np.float64)
                )
        return np.ones(len(rows), dtype=np.float64)

    def get_batch(
        self,
        indices: Sequence[int] | np.ndarray,
        *,
        device: torch.device | str,
        dtype: torch.dtype = torch.float32,
        pin_memory: bool = True,
    ) -> ParticleBatch:
        idx = _owned_array(np.asarray(indices), np.dtype(np.int64))
        dev = torch.device(device)
        images = [
            self.cache.read_image(
                self._refs[int(i)][1],
                self._refs[int(i)][0],
                dtype=dtype,
                device="cpu",
                pin_memory=pin_memory and dev.type == "cuda",
            )
            for i in idx
        ]
        host = torch.stack(images, dim=0)
        images_tensor = host.to(dev, non_blocking=host.is_pinned())
        meta = self._metadata_arrays(idx)
        rot = torch.as_tensor(meta["rot"], device=dev, dtype=dtype)
        tilt = torch.as_tensor(meta["tilt"], device=dev, dtype=dtype)
        psi = torch.as_tensor(meta["psi"], device=dev, dtype=dtype)
        rotations = relion_euler_matrix(rot, tilt, psi, device=dev, dtype=dtype)
        origins = torch.as_tensor(
            np.stack((meta["ox"], meta["oy"]), axis=-1), device=dev, dtype=dtype
        )
        ctf = CTFParameters(
            defocus_u=torch.as_tensor(meta["du"], device=dev, dtype=dtype),
            defocus_v=torch.as_tensor(meta["dv"], device=dev, dtype=dtype),
            defocus_angle_deg=torch.as_tensor(meta["da"], device=dev, dtype=dtype),
            voltage_kv=torch.full((len(idx),), self.voltage_kv, device=dev, dtype=dtype),
            cs_mm=torch.full((len(idx),), self.cs_mm, device=dev, dtype=dtype),
            amplitude_contrast=torch.full(
                (len(idx),), self.amplitude_contrast, device=dev, dtype=dtype
            ),
            phase_shift_deg=torch.as_tensor(meta["phase"], device=dev, dtype=dtype),
        )
        return ParticleBatch(
            row_indices=idx,
            images=images_tensor,
            rotations=rotations,
            origins_pixels=origins,
            euler_degrees=torch.stack((rot, tilt, psi), dim=-1),
            ctf_parameters=ctf,
            random_subset=torch.as_tensor(meta["subset"], device=dev, dtype=torch.int64),
            class_number=torch.as_tensor(meta["class"], device=dev, dtype=torch.int64),
            group_index=torch.as_tensor(meta["group_index"], device=dev, dtype=torch.int64),
            group_number=torch.as_tensor(meta["group_number"], device=dev, dtype=torch.int64),
            fom=torch.as_tensor(meta["fom"], device=dev, dtype=dtype),
        )

    def iter_batches(
        self,
        batch_size: int,
        *,
        device: torch.device | str,
        dtype: torch.dtype = torch.float32,
        shuffle: bool = False,
        seed: int = 0,
    ) -> Iterator[ParticleBatch]:
        if batch_size < 1:
            raise ValueError("batch_size must be >=1")
        indices = np.arange(len(self), dtype=np.int64)
        if shuffle:
            rng = np.random.default_rng(seed)
            rng.shuffle(indices)
        for start in range(0, len(indices), batch_size):
            yield self.get_batch(indices[start : start + batch_size], device=device, dtype=dtype)

    def source_row_indices(self) -> np.ndarray:
        return _owned_array(
            self.table["_source_row"].to_numpy(dtype=np.int64),
            np.dtype(np.int64),
        )
