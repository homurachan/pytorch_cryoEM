"""Shared CPU pre-read / disk batches / device-pool staging for 2-D particles.

Only raw float32 images are cached. No CTF, masks, origins, noise or Fourier
transforms are cached, so updated iteration state is always applied afresh.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from multiprocessing import shared_memory
from pathlib import Path
import shutil
import sys
from typing import Iterator, Sequence

import numpy as np
import torch

from .mrc_stack import MRCStackCache, ParticleReadError


@dataclass(frozen=True)
class ParticleIOOptions:
    preread_images: bool = False
    io_batch_size: int = 256
    pool_size: int | None = None  # None follows compute batch_size
    max_open_stacks: int = 8
    particle_io: str = 'read'
    preread_max_gib: float | None = None

    def validate(self, batch_size: int = 1) -> None:
        if batch_size < 1 or self.io_batch_size < 1 or self.max_open_stacks < 1:
            raise ValueError("batch_size, io_batch_size and max_open_stacks must be positive")
        if self.pool_size is not None and self.pool_size < batch_size:
            raise ValueError("--pool must be >= --batch-size (or omit --pool to follow --batch-size)")
        if self.particle_io not in ('read', 'mmap'):
            raise ValueError("--particle-io must be read or mmap")
        if self.preread_max_gib is not None and (
                not math.isfinite(self.preread_max_gib) or self.preread_max_gib <= 0):
            raise ValueError("--preread-max-gib must be finite and positive")

    @classmethod
    def from_config(cls, config) -> 'ParticleIOOptions':
        return cls(**{key: getattr(config, key, field.default)
                      for key, field in cls.__dataclass_fields__.items()})

    def effective_pool(self, batch_size: int) -> int:
        self.validate(batch_size)
        requested = self.pool_size if self.pool_size is not None else batch_size
        # Preserve E-step batch boundaries exactly. Never enlarge the requested
        # pool; its unused tail is at most batch_size-1 images.
        return (int(requested) // batch_size) * batch_size


def add_particle_io_arguments(parser) -> None:
    group = parser.add_argument_group('particle I/O and memory')
    choice = group.add_mutually_exclusive_group()
    choice.add_argument('--preread-images', '--preread_images', dest='preread_images',
                        action='store_true', default=False,
                        help='read ALL selected raw float32 images into CPU RAM, never all into GPU RAM')
    choice.add_argument('--no-preread-images', '--no_preread_images', dest='preread_images',
                        action='store_false', help='stream bounded image batches from disk (default)')
    group.add_argument('--io-batch-size', '--io_batch_size', type=int, default=256,
                       help='max raw images in a CPU disk-read batch (default: 256)')
    group.add_argument('--pool', '--pool-size', dest='pool_size', type=int, default=None,
                       help='raw images staged on device per pool; default follows --batch-size; '
                            'must be >= batch-size and is rounded DOWN to its multiple')
    group.add_argument('--max-open-stacks', '--max_open_stacks', type=int, default=8,
                       help='LRU limit on simultaneously open particle stacks (default: 8)')
    group.add_argument('--particle-io', '--particle_io', choices=('read', 'mmap'), default='read',
                       help='read: bounded seek/read (default); mmap: opt-in bounded-handle mappings')
    group.add_argument('--preread-max-gib', '--preread_max_gib', type=float,
                       help='optional hard budget for the raw all-particle RAM array only, not total process RAM')


class ParticleImageStore:
    """Reusable raw image store, independent of optimiser or metadata format.

    ``refs`` contain (resolved stack path, one-based image index) in STAR order.
    ``iter_batches`` defaults to all rows; explicit indices preserve the caller's
    order/subset and original STAR row identities. On CUDA the
    host staging chunk is independent of pool size. Device pools are allocated
    once per iterator and reused after all their compute batches finish.
    """
    def __init__(self, refs: Sequence[tuple[Path, int]], *, box_size: int,
                 options: ParticleIOOptions | None = None,
                 cache: MRCStackCache | None = None,
                 image_names: Sequence[str] | None = None) -> None:
        self.options = options or ParticleIOOptions()
        self.options.validate()
        self.refs = list(refs)
        if not self.refs:
            raise ValueError("particle STAR contains no images")
        self.image_names = list(image_names) if image_names is not None else None
        self.cache = cache or MRCStackCache(self.options.max_open_stacks, backend=self.options.particle_io)
        self.box_size = int(box_size)
        self._ram: np.ndarray | None = None
        self._shared_memory = None
        self._shared_owner = False
        self._chunk: np.ndarray | None = None
        self._chunk_first = -1
        self._closed = False
        self.stats = {'disk_read_batches': 0, 'preread_passes': 0, 'peak_host_chunk_images': 0,
                      'device_pools': 0, 'peak_device_pool_images': 0}
        if self.box_size <= 0:
            shape = self.cache.shape(self.refs[0][0])
            self.box_size = int(shape[-1])
        if self.box_size < 1:
            raise ValueError("particle box size must be positive")

    def __len__(self) -> int:
        return len(self.refs)

    @property
    def raw_nbytes(self) -> int:
        return len(self) * self.box_size * self.box_size * 4

    @property
    def is_preread(self) -> bool:
        return self._ram is not None

    def _refs_digest(self) -> str:
        digest = hashlib.sha256()
        for path, index in self.refs:
            value = str(path).encode('utf-8')
            digest.update(len(value).to_bytes(8, 'little'))
            digest.update(value)
            digest.update(int(index).to_bytes(8, 'little'))
        return digest.hexdigest()

    def shared_descriptor(self):
        """Only metadata crosses spawn/IPC; never pickle the raw image array."""
        if self._shared_memory is None:
            return None
        return dict(name=self._shared_memory.name, shape=list(self._ram.shape),
                    dtype='float32', nbytes=self.raw_nbytes, refs_sha256=self._refs_digest())

    def attach_shared(self, descriptor) -> None:
        """Map the coordinator's completed raw cache without reading any stack."""
        self._check_open()
        if self._ram is not None:
            raise RuntimeError('Cannot attach a shared cache over existing raw storage')
        shape = (len(self), self.box_size, self.box_size)
        if (tuple(descriptor['shape']) != shape or descriptor['dtype'] != 'float32'
                or descriptor['nbytes'] != self.raw_nbytes
                or descriptor['refs_sha256'] != self._refs_digest()):
            raise ValueError('Shared raw cache particle identities/order or dimensions differ')
        segment = shared_memory.SharedMemory(name=descriptor['name'], create=False)
        if segment.size < self.raw_nbytes:
            segment.close()
            raise ValueError('Shared raw cache allocation is smaller than its descriptor')
        try:
            ram = np.ndarray(shape, dtype=np.float32, buffer=segment.buf)
            ram.flags.writeable = False
        except BaseException:
            segment.close()
            raise
        self._chunk = None
        self._chunk_first = -1
        self.cache.close()
        self._shared_memory = segment
        self._shared_owner = False
        self._ram = ram

    def cache_report(self) -> dict:
        shared = self._shared_memory is not None
        return dict(preread_requested=self.options.preread_images,
                    is_preread=self.is_preread, shared=shared,
                    cache_id=self._shared_memory.name if shared else None,
                    raw_cache_bytes=self.raw_nbytes if self.is_preread else 0,
                    private_raw_cache_bytes=self.raw_nbytes if self.is_preread and not shared else 0,
                    shared_owner=self._shared_owner, preread_passes=self.stats['preread_passes'],
                    disk_read_batches=self.stats['disk_read_batches'])

    def _release_shared(self) -> None:
        segment, self._shared_memory = self._shared_memory, None
        owner, self._shared_owner = self._shared_owner, False
        if segment is not None:
            try:
                segment.close()
            finally:
                if owner:
                    try:segment.unlink()
                    except FileNotFoundError:pass

    def _check_open(self) -> None:
        if self._closed:
            raise RuntimeError("particle image store has been closed")

    def _read_range(self, first: int, out: np.ndarray) -> None:
        """Fill a <=io_batch_size buffer, grouping only contiguous stack indices."""
        self._check_open()
        if len(out) > self.options.io_batch_size:
            raise ValueError("internal disk batch exceeds io_batch_size")
        self.stats['disk_read_batches'] += 1
        self.stats['peak_host_chunk_images'] = max(self.stats['peak_host_chunk_images'], len(out))
        local = 0
        while local < len(out):
            row = first + local
            path, index = self.refs[row]
            count = 1
            while local + count < len(out) and self.refs[row+count] == (path, index+count):
                count += 1
            try:
                images = self.cache.read_images(path, index, count)
                if images.shape[1:] != (self.box_size, self.box_size):
                    raise ValueError(f"image shape {images.shape[1:]} differs from required "
                                     f"({self.box_size}, {self.box_size})")
                out[local:local+count] = images
                del images
            except Exception as exc:
                name = self.image_names[row] if self.image_names is not None else f'{index}@{path}'
                raise ParticleReadError(f"Particle STAR row {row+1}, rlnImageName={name!r}, "
                                        f"batch rows {first+1}..{first+len(out)}: {exc}") from exc
            local += count

    def preread(self, *, shared: bool = False) -> None:
        self._check_open()
        if self._ram is not None:
            if shared and self._shared_memory is None:
                raise RuntimeError('Shared preread must be selected before allocating a private raw cache')
            return
        gib = self.raw_nbytes / 2**30
        if self.options.preread_max_gib is not None and gib > self.options.preread_max_gib:
            raise MemoryError(f"Raw particle pre-read needs {gib:.3f} GiB, exceeding "
                              f"--preread-max-gib {self.options.preread_max_gib:g}; "
                              "use --no-preread-images or increase the budget")
        self._chunk = None
        self._chunk_first = -1
        mode = 'one shared CPU RAM cache' if shared else 'CPU RAM'
        print(f"Pre-reading {len(self)} raw float32 particles into {mode}: {gib:.3f} GiB "
              "(additional process/model memory is not included)", flush=True)
        ram = None
        try:
            shape = (len(self), self.box_size, self.box_size)
            if shared:
                # POSIX shm is commonly a size-limited tmpfs. Detect insufficient
                # space before touching its pages (which can otherwise SIGBUS).
                if sys.platform.startswith('linux') and Path('/dev/shm').is_dir():
                    free = shutil.disk_usage('/dev/shm').free
                    if self.raw_nbytes > free:
                        raise MemoryError(f'Shared preread needs {gib:.3f} GiB, but /dev/shm has '
                                          f'{free/2**30:.3f} GiB free; enlarge shared memory or use --no-preread-images')
                self._shared_memory = shared_memory.SharedMemory(create=True, size=self.raw_nbytes)
                self._shared_owner = True
                ram = np.ndarray(shape, dtype=np.float32, buffer=self._shared_memory.buf)
            else:
                ram = np.empty(shape, dtype=np.float32)
            next_report = 10
            for first in range(0, len(self), self.options.io_batch_size):
                stop = min(len(self), first+self.options.io_batch_size)
                self._read_range(first, ram[first:stop])
                percentage = 100 * stop // len(self)
                if percentage >= next_report or stop == len(self):
                    print(f"Pre-read: {stop}/{len(self)} particles ({percentage}%)", flush=True)
                    next_report = (percentage // 10 + 1) * 10
        except BaseException:
            ram = None
            self._release_shared()
            self.cache.close()
            raise
        if shared:
            ram.flags.writeable = False
            print(f'Shared raw cache ready: {self._shared_memory.name}; {gib:.3f} GiB total across permanent workers', flush=True)
        self._ram = ram
        self.stats['preread_passes'] += 1
        self.cache.close()

    def _host_slice(self, first: int, stop: int) -> np.ndarray:
        self._check_open()
        if self._ram is not None:
            return self._ram[first:stop]
        if not (self._chunk is not None and self._chunk_first <= first < self._chunk_first+len(self._chunk)):
            chunk_first = (first // self.options.io_batch_size) * self.options.io_batch_size
            count = min(self.options.io_batch_size, len(self)-chunk_first)
            # Release old storage before allocating the next chunk.
            self._chunk = None
            self._chunk_first = -1
            chunk = np.empty((count, self.box_size, self.box_size), dtype=np.float32)
            self._read_range(chunk_first, chunk)
            self._chunk, self._chunk_first = chunk, chunk_first
        end = min(stop, self._chunk_first + len(self._chunk))
        return self._chunk[first-self._chunk_first:end-self._chunk_first]

    def image(self, index: int) -> np.ndarray:
        if index < 0 or index >= len(self):
            raise IndexError(f"particle index {index} outside 0..{len(self)-1}")
        # A raw cache must never be changed by norm/mask/offset processing.
        return self._host_slice(index, index+1)[0].copy()

    def iter_batches(self, *, device: torch.device | str,
                     batch_size: int, pool_size: int | None = None,
                     indices=None) -> Iterator[tuple[list[int], torch.Tensor]]:
        """Yield compute-sized views into a bounded raw device pool.

        A yielded view is borrowed and valid only until the next pool is filled;
        callers must not retain or modify it. prepare_particle() clones it.
        No particle compute/reduction grouping depends on disk or pool sizes.
        """
        self._check_open()
        if indices is not None:
            yield from self._iter_selected_batches(indices, device=device, batch_size=batch_size, pool_size=pool_size)
            return
        requested = pool_size if pool_size is not None else self.options.pool_size
        requested = batch_size if requested is None else requested
        if batch_size < 1 or requested < batch_size:
            raise ValueError("pool_size must be >= positive batch_size")
        capacity = min(len(self), (int(requested)//batch_size)*batch_size)
        device = torch.device(device)
        pool = torch.empty((capacity, self.box_size, self.box_size), dtype=torch.float32, device=device)
        self.stats['peak_device_pool_images'] = max(self.stats['peak_device_pool_images'], capacity)
        try:
            for first in range(0, len(self), capacity):
                stop = min(len(self), first+capacity)
                cursor = first
                while cursor < stop:
                    # Cap the transfer host window even for a fully pre-read dataset.
                    host = self._host_slice(cursor, min(stop, cursor+self.options.io_batch_size))
                    if not host.flags.writeable:
                        # A bounded staging copy keeps Torch away from readonly
                        # shared pages; never copy the full raw cache.
                        host = host.copy()
                    used = len(host)
                    # Synchronous copies keep a reused CPU buffer safe without
                    # pinned-memory/event lifetime pitfalls; no worker imports.
                    pool[cursor-first:cursor-first+used].copy_(torch.from_numpy(host), non_blocking=False)
                    cursor += used
                    del host
                self.stats['device_pools'] += 1
                for local in range(0, stop-first, batch_size):
                    end = min(stop-first, local+batch_size)
                    yield list(range(first+local, first+end)), pool[local:end]
        finally:
            del pool

    def _read_selected(self, rows, out):
        """Read only requested rows, coalescing adjacent slices within each stack.

        Sorting is local to the bounded I/O chunk; output order remains the
        caller's selected-particle order. No full-stack or full-subset copy.
        """
        if len(rows) > self.options.io_batch_size or len(rows) != len(out):
            raise ValueError("selected I/O chunk exceeds io_batch_size")
        self.stats['peak_host_chunk_images'] = max(self.stats['peak_host_chunk_images'], len(rows))
        if self._ram is not None:
            np.take(self._ram, rows, axis=0, out=out)
            return
        self.stats['disk_read_batches'] += 1
        locations = sorted(range(len(rows)), key=lambda j: (str(self.refs[int(rows[j])][0]), self.refs[int(rows[j])][1]))
        first = 0
        while first < len(locations):
            j = locations[first]
            path, index = self.refs[int(rows[j])]
            stop = first + 1
            while stop < len(locations) and self.refs[int(rows[locations[stop]])] == (path, index+stop-first):
                stop += 1
            try:
                data = self.cache.read_images(path, index, stop-first)
                if data.shape[1:] != (self.box_size, self.box_size):
                    raise ValueError("selected image box differs from dataset")
                out[locations[first:stop]] = data
                del data
            except Exception as exc:
                row = int(rows[j])
                name = self.image_names[row] if self.image_names is not None else f'{index}@{path}'
                raise ParticleReadError(f"Particle STAR row {row+1}, rlnImageName={name!r}: {exc}") from exc
            first = stop

    def _iter_selected_batches(self, indices, *, device, batch_size, pool_size):
        rows = np.asarray(indices)
        if rows.ndim != 1:
            raise ValueError("selected particle indices must be a 1-D integer array")
        if len(rows) == 0:
            return
        if rows.dtype.kind not in 'iu':
            raise ValueError("selected particle indices must be a 1-D integer array")
        if rows.min() < 0 or rows.max() >= len(self):
            raise IndexError("selected particle index outside dataset")
        requested = self.options.pool_size if pool_size is None else pool_size
        requested = batch_size if requested is None else requested
        if batch_size < 1 or requested < batch_size:
            raise ValueError("pool_size must be >= positive batch_size")
        capacity = min(len(rows), (int(requested)//batch_size)*batch_size)
        # Release the sequential host cache before allocating selected I/O chunks.
        self._chunk, self._chunk_first = None, -1
        pool = torch.empty((capacity, self.box_size, self.box_size), dtype=torch.float32, device=device)
        self.stats['peak_device_pool_images'] = max(self.stats['peak_device_pool_images'], capacity)
        try:
            for first in range(0, len(rows), capacity):
                chosen = rows[first:first+capacity]
                for local in range(0, len(chosen), self.options.io_batch_size):
                    selected = chosen[local:local+self.options.io_batch_size]
                    host = np.empty((len(selected), self.box_size, self.box_size), dtype=np.float32)
                    self._read_selected(selected, host)
                    pool[local:local+len(selected)].copy_(torch.from_numpy(host), non_blocking=False)
                    del host
                self.stats['device_pools'] += 1
                for local in range(0, len(chosen), batch_size):
                    end = min(len(chosen), local+batch_size)
                    yield chosen[local:end].tolist(), pool[local:end]
        finally:
            del pool

    def report(self, *, batch_size: int, device: str) -> None:
        effective = self.options.effective_pool(batch_size)
        each = self.box_size*self.box_size*4
        mode = 'all images in CPU RAM' if self.options.preread_images else 'streaming from disk'
        print(f"Particle I/O: {mode}; backend={self.options.particle_io}; particles={len(self)}; "
              f"box={self.box_size}; full raw RAM={self.raw_nbytes/2**30:.3f} GiB", flush=True)
        print(f"Particle batches: disk/CPU <= {self.options.io_batch_size} "
              f"({self.options.io_batch_size*each/2**20:.1f} MiB raw); "
              f"device pool <= {effective} ({effective*each/2**20:.1f} MiB raw on {device}); "
              f"compute batch={batch_size}; open stacks <= {self.options.max_open_stacks}", flush=True)
        print("Memory figures exclude transient read copies, FFT/CTF, projections, posteriors, "
              "backprojectors and allocator caches.", flush=True)

    def close(self) -> None:
        self.cache.close()
        self._ram = self._chunk = None
        self._release_shared()
        self._chunk_first = -1
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
