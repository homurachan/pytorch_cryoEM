"""Dimension-aware reference output, written once from in-memory maps.

2-D references are an image stack with indexed STAR locators. 3-D references
remain independent volumes. No output is read back to assemble other output.
"""
from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np
import torch

from .mrc import write_mrc


def reference_image_names(prefix: str | Path, number_of_classes: int,
                          reference_dim: int) -> list[str]:
    if number_of_classes < 1 or reference_dim not in (2, 3):
        raise ValueError("reference output requires at least one 2-D or 3-D class")
    if reference_dim == 2:
        stack = Path(f"{prefix}_classes.mrcs").expanduser().resolve()
        return [f"{i:06d}@{stack}" for i in range(1, number_of_classes+1)]
    return [str(Path(f"{prefix}_class{i:03d}.mrc").expanduser().resolve())
            for i in range(1, number_of_classes+1)]


def _host_array(image: torch.Tensor | np.ndarray) -> np.ndarray:
    if isinstance(image, torch.Tensor):
        return image.detach().to(device="cpu", dtype=torch.float32).contiguous().numpy()
    return np.asarray(image, dtype=np.float32)


def write_reference_images(maps: Sequence[torch.Tensor | np.ndarray], prefix: str | Path,
                           *, reference_dim: int, pixel_size_angstrom: float,
                           counters: dict | None = None) -> list[str]:
    """Write K maps, without stacking on GPU or reading an intermediate file.

    For 2-D, host workspace is one float32 K-image stack plus one transfer
    image. For 3-D, write each volume independently, not a K-volume tensor.
    Finite-value validation and all MRC headers are handled by write_mrc.
    """
    names = reference_image_names(prefix, len(maps), reference_dim)
    shapes = [tuple(image.shape) for image in maps]
    if any(len(shape) != reference_dim for shape in shapes) or len(set(shapes)) != 1:
        raise ValueError(f"inconsistent {reference_dim}-D reference shapes: {shapes}")
    total_bytes = 0
    if reference_dim == 2:
        stack = np.empty((len(maps), *shapes[0]), dtype=np.float32)
        for i, image in enumerate(maps):
            stack[i] = _host_array(image)
        path = names[0].split("@", 1)[1]
        write_mrc(path, stack, pixel_size_angstrom=pixel_size_angstrom)
        total_bytes = stack.nbytes
        files = 1
    else:
        for name, image in zip(names, maps):
            array = _host_array(image)
            write_mrc(name, array, pixel_size_angstrom=pixel_size_angstrom)
            total_bytes += array.nbytes
        files = len(maps)
    if counters is not None:
        counters['reference_output_files'] = counters.get('reference_output_files', 0) + files
        counters['reference_output_data_bytes'] = counters.get('reference_output_data_bytes', 0) + total_bytes
        counters.setdefault('reference_output_readbacks', 0)
    return names


class InitialReferenceCollector:
    """Collect the same generated seed images, avoiding per-class temp files.

    The initialization algorithms call emit instead of writing each seed. The
    runner writes a single diagnostic seed stack and gives these in-memory
    images directly to the optimiser, without reading that stack back.
    """
    def __init__(self, prefix: str | Path, number_of_classes: int):
        self.prefix = prefix
        self.names = reference_image_names(prefix, number_of_classes, 2)
        self.images: list[torch.Tensor] = []

    def emit(self, class_index: int, image: torch.Tensor | np.ndarray) -> str:
        if class_index != len(self.images) + 1:
            raise ValueError("seed images must be emitted once in class order")
        array = np.array(_host_array(image), dtype=np.float32, order='C', copy=True)
        if array.ndim != 2 or not np.isfinite(array).all():
            raise ValueError("seed reference must be finite and two-dimensional")
        self.images.append(torch.from_numpy(array))
        return self.names[class_index - 1]

    def finish(self, pixel_size_angstrom: float) -> list[str]:
        if len(self.images) != len(self.names):
            raise ValueError("incomplete seed reference output")
        return write_reference_images(self.images, self.prefix, reference_dim=2,
                                      pixel_size_angstrom=pixel_size_angstrom)
