"""Public STAR / NPY / text spectrum reader with shell-index validation."""
from pathlib import Path
import numpy as np
import torch
from relion_torch.io.star import read_star

def read_spectrum(path: str | Path, preferred_labels: tuple[str, ...]) -> torch.Tensor:
    source = Path(path).expanduser().resolve()
    suffix = source.suffix.lower()
    if suffix == ".npy":
        values = np.load(source)
    elif suffix in {".txt", ".dat", ".csv"}:
        values = np.loadtxt(source)
        if values.ndim > 1:
            values = values[:, -1]
    elif suffix == ".star":
        blocks = read_star(source)
        values = None
        for frame in blocks.values():
            for label in preferred_labels:
                if label in frame.columns:
                    selected = frame
                    if 'rlnSpectralIndex' in frame:
                        indices = frame['rlnSpectralIndex'].to_numpy(dtype=np.float64)
                        if (not np.isfinite(indices).all() or not np.equal(indices,np.floor(indices)).all()
                            or sorted(indices.tolist()) != list(range(len(indices)))):
                            raise ValueError('Spectrum shell indices must be unique and contiguous from zero')
                        selected = frame.sort_values('rlnSpectralIndex')
                    values = selected[label].to_numpy(dtype=np.float64)
                    break
            if values is not None:
                break
        if values is None:
            raise KeyError(
                f"None of {preferred_labels} was found in spectrum STAR {source}"
            )
    else:
        raise ValueError(f"Unsupported spectrum file type: {source.suffix}")
    # STAR columns can be read-only pandas/Arrow views. Own writable storage
    # before torch.from_numpy(), just as the particle metadata loader does.
    array = np.array(values, dtype=np.float64, order="C", copy=True).reshape(-1)
    if array.size < 2:
        raise ValueError(f"Spectrum {source} contains too few values")
    if not np.isfinite(array).all():
        raise ValueError(f"Spectrum {source} contains non-finite values")
    return torch.from_numpy(array)

