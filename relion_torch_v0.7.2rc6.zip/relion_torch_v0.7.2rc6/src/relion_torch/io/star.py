from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
import shlex
from typing import Any, Mapping

import numpy as np

try:
    import pandas as pd
except ImportError as exc:  # starfile itself depends on pandas.
    raise ImportError("relion-torch requires pandas through the starfile dependency") from exc


def canonical_label(label: str) -> str:
    return label.strip().lstrip("_")


def canonical_block(block: str) -> str:
    block = block.strip()
    return block[5:] if block.startswith("data_") else block


def _convert_token(token: str) -> Any:
    low = token.lower()
    if low in {"nan", "+nan", "-nan", "<na>", "?", "."}:
        return float("nan")
    if low in {"inf", "+inf"}:
        return float("inf")
    if low == "-inf":
        return float("-inf")
    try:
        if token and all(ch not in token for ch in ".eE"):
            return int(token)
        return float(token)
    except ValueError:
        return token


def _star_tokens(text: str) -> list[str]:
    lexer = shlex.shlex(text, posix=True)
    lexer.whitespace_split = True
    lexer.commenters = '#'
    # STAR filenames use literal backslashes; they are not shell escapes.
    lexer.escape = ''
    return list(lexer)


def _normalise_frames(blocks: Mapping[str, Any]) -> OrderedDict[str, pd.DataFrame]:
    result: OrderedDict[str, pd.DataFrame] = OrderedDict()
    for name, value in blocks.items():
        key = canonical_block(str(name))
        if isinstance(value, pd.DataFrame):
            frame = value.copy()
        elif isinstance(value, pd.Series):
            frame = value.to_frame().T
        elif isinstance(value, Mapping):
            frame = pd.DataFrame([dict(value)])
        else:
            raise TypeError(f"Unsupported STAR block type for {name}: {type(value)}")
        # Private runtime bookkeeping columns are never part of RELION STAR
        # schemas.  AlignmentDataset uses one to preserve immutable source-row
        # identity across internal scheduling/replacement.
        private = [column for column in frame.columns
                   if str(column).startswith("__relion_torch_")]
        if private:
            frame = frame.drop(columns=private)
        frame.columns = [canonical_label(str(column)) for column in frame.columns]
        result[key] = frame
    return result


def _read_with_starfile(path: Path) -> OrderedDict[str, pd.DataFrame]:
    import starfile

    parsed = starfile.read(path, always_dict=True)
    frames = _normalise_frames(parsed)
    # Old relion-torch/starfile outputs could contain bare <NA> in numeric
    # columns. Treat exact missing tokens as NaN; never replace substrings in
    # filenames or other labels (e.g. a stack called sample_<NA>.mrcs).
    for frame in frames.values():
        for column in frame.columns:
            series = frame[column]
            if pd.api.types.is_numeric_dtype(series.dtype):
                if pd.api.types.is_extension_array_dtype(series.dtype) and series.isna().any():
                    frame[column] = series.to_numpy(dtype=np.float64, na_value=np.nan)
                continue
            missing = series.isin(["<NA>", "<na>", "?", "."])
            if missing.any():
                repaired = series.astype(object).mask(missing, np.nan)
                try:
                    repaired = pd.to_numeric(repaired, errors="raise")
                except (ValueError, TypeError):
                    pass
                frame[column] = repaired
    return frames


def _read_fallback(path: Path) -> OrderedDict[str, pd.DataFrame]:
    """Read the loop-based subset used by RELION 3.1 STAR files."""

    raw_lines = path.read_text(encoding="utf-8").splitlines()
    blocks: OrderedDict[str, pd.DataFrame] = OrderedDict()
    current_name: str | None = None
    scalar_data: OrderedDict[str, Any] = OrderedDict()
    i = 0

    def flush_scalars() -> None:
        nonlocal scalar_data
        if current_name is not None and scalar_data:
            blocks[current_name] = pd.DataFrame([scalar_data])
            scalar_data = OrderedDict()

    while i < len(raw_lines):
        stripped = raw_lines[i].strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue
        if stripped.startswith("data_"):
            flush_scalars()
            current_name = canonical_block(stripped)
            i += 1
            continue
        if current_name is None:
            raise ValueError(f"STAR content before data_ block at line {i + 1}")
        if stripped == "loop_":
            flush_scalars()
            i += 1
            labels: list[str] = []
            while i < len(raw_lines):
                candidate = raw_lines[i].strip()
                if not candidate or candidate.startswith("#"):
                    i += 1
                    continue
                if not candidate.startswith("_"):
                    break
                labels.append(canonical_label(candidate.split()[0]))
                i += 1
            if not labels:
                raise ValueError(f"loop_ without labels in data_{current_name}")
            rows: list[list[Any]] = []
            pending: list[str] = []
            while i < len(raw_lines):
                candidate = raw_lines[i].strip()
                if not candidate or candidate.startswith("#"):
                    i += 1
                    if rows and not pending:
                        # A blank line conventionally terminates a loop, but
                        # tolerate blanks inside before looking ahead.
                        look = i
                        while look < len(raw_lines) and (
                            not raw_lines[look].strip() or raw_lines[look].lstrip().startswith("#")
                        ):
                            look += 1
                        if look >= len(raw_lines) or raw_lines[look].strip().startswith(("data_", "loop_", "_")):
                            i = look
                            break
                    continue
                if candidate.startswith(("data_", "loop_", "_")) and not pending:
                    break
                pending.extend(_star_tokens(candidate))
                while len(pending) >= len(labels):
                    row_tokens = pending[: len(labels)]
                    pending = pending[len(labels) :]
                    rows.append([_convert_token(token) for token in row_tokens])
                i += 1
            if pending:
                raise ValueError(
                    f"Incomplete STAR row in data_{current_name}: expected {len(labels)} columns, "
                    f"found {len(pending)} trailing values"
                )
            blocks[current_name] = pd.DataFrame(rows, columns=labels)
            continue
        if stripped.startswith("_"):
            tokens = _star_tokens(stripped)
            if len(tokens) < 2:
                raise ValueError(f"Unsupported multiline scalar at line {i + 1}")
            scalar_data[canonical_label(tokens[0])] = _convert_token(tokens[1])
            i += 1
            continue
        raise ValueError(f"Unsupported STAR syntax at line {i + 1}: {stripped}")

    flush_scalars()
    return blocks


def read_star(path: str | Path, *, exact_floats: bool = False) -> OrderedDict[str, pd.DataFrame]:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    if exact_floats:
        return _read_fallback(path)
    try:
        return _read_with_starfile(path)
    except ImportError:
        return _read_fallback(path)


def _format_value(value: Any, precision: int = 15) -> str:
    if value is None:
        return "?"
    if value is pd.NA or value is pd.NaT:
        return "nan"
    if isinstance(value, (np.bool_, bool)):
        return "1" if value else "0"
    if isinstance(value, (np.floating, float)):
        if np.isnan(value):
            return "nan"
        if np.isinf(value):
            return "inf" if value > 0 else "-inf"
        return format(float(value), f'.{precision}g')
    if isinstance(value, (np.integer, int)):
        return str(int(value))
    text = str(value)
    if not text:
        return "''"
    if any(char.isspace() for char in text) or text.startswith("#"):
        return shlex.quote(text)
    return text


def _write_fallback(blocks: Mapping[str, Any], path: Path, precision: int = 15) -> None:
    normalised = _normalise_frames(blocks)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for block_name, frame in normalised.items():
            handle.write(f"\ndata_{block_name}\n\nloop_\n")
            for index, column in enumerate(frame.columns, start=1):
                handle.write(f"_{canonical_label(str(column))} #{index}\n")
            for row in frame.itertuples(index=False, name=None):
                handle.write(" ".join(_format_value(value, precision) for value in row) + "\n")
            handle.write("\n")


def write_star(
    blocks: Mapping[str, Any],
    path: str | Path,
    *,
    overwrite: bool = True,
    precision: int = 15,
    deterministic: bool = False,
) -> None:
    if not 1 <= precision <= 17:
        raise ValueError('STAR floating-point precision must be between 1 and 17')
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise FileExistsError(path)
    normalised = _normalise_frames(blocks)
    if deterministic:
        _write_fallback(normalised, path, precision)
        return
    try:
        import inspect
        import starfile
    except ImportError:
        _write_fallback(normalised, path, precision)
        return

    # Require BOTH precision and missing-value controls. In starfile 0.5.13
    # na_rep defaults to '<NA>', which is not RELION's numeric NaN spelling.
    # For older APIs use the deterministic local writer; do not silently fall
    # back to rounded spectra or pandas-specific missing-value tokens.
    parameters = inspect.signature(starfile.write).parameters
    if {"float_format", "na_rep"}.issubset(parameters):
        starfile.write(
            normalised,
            path,
            overwrite=overwrite,
            float_format=f"%.{precision}g",
            na_rep="nan",
        )
    else:
        _write_fallback(normalised, path, precision)


@dataclass(slots=True)
class RelionStar:
    optics: pd.DataFrame
    particles: pd.DataFrame
    source_path: Path
    extra_blocks: dict[str, pd.DataFrame]

    @property
    def source_dir(self) -> Path:
        return self.source_path.parent

    def validate_single_optics_group(self) -> None:
        if len(self.optics) != 1:
            raise NotImplementedError(
                "Phase 1/2/3/5 supports exactly one optics-group row; "
                f"found {len(self.optics)}"
            )
        if "rlnOpticsGroup" in self.particles.columns:
            values = pd.to_numeric(self.particles["rlnOpticsGroup"], errors="coerce")
            unique = sorted(int(v) for v in values.dropna().unique())
            if len(unique) > 1:
                raise NotImplementedError(
                    "Multiple particle optics groups are outside this milestone: "
                    f"{unique}"
                )

    def optics_value(self, label: str, default: Any = None) -> Any:
        label = canonical_label(label)
        if label not in self.optics.columns:
            if default is not None:
                return default
            raise KeyError(f"Missing optics label {label}")
        return self.optics.iloc[0][label]

    def pixel_size_angstrom(self) -> float:
        for label in ("rlnImagePixelSize", "rlnMicrographPixelSize"):
            if label in self.optics.columns:
                value = float(self.optics.iloc[0][label])
                if value > 0:
                    return value
        if (
            "rlnDetectorPixelSize" in self.particles.columns
            and "rlnMagnification" in self.particles.columns
        ):
            detector = float(self.particles.iloc[0]["rlnDetectorPixelSize"])
            magnification = float(self.particles.iloc[0]["rlnMagnification"])
            return 10_000.0 * detector / magnification
        raise KeyError("Could not determine rlnImagePixelSize from STAR metadata")

    def copy_with_particles(self, particles: pd.DataFrame) -> "RelionStar":
        return RelionStar(
            optics=self.optics.copy(),
            particles=particles.copy(),
            source_path=self.source_path,
            extra_blocks={key: frame.copy() for key, frame in self.extra_blocks.items()},
        )


def read_relion_star(path: str | Path, *, require_single_optics: bool = True) -> RelionStar:
    source = Path(path).expanduser().resolve()
    blocks = read_star(source)
    lower = {name.lower(): name for name in blocks}
    particle_key = lower.get("particles") or lower.get("images")
    if particle_key is None:
        candidates = [name for name, frame in blocks.items() if "rlnImageName" in frame.columns]
        if len(candidates) != 1:
            raise KeyError("Could not identify data_particles/data_images in STAR file")
        particle_key = candidates[0]
    particles = blocks[particle_key].copy()
    optics_key = lower.get("optics")
    if optics_key is not None:
        optics = blocks[optics_key].copy()
    else:
        row: dict[str, Any] = {
            "rlnOpticsGroup": 1,
            "rlnOpticsGroupName": "opticsGroup1",
        }
        for label in (
            "rlnVoltage",
            "rlnSphericalAberration",
            "rlnAmplitudeContrast",
            "rlnImagePixelSize",
            "rlnImageSize",
            "rlnImageDimensionality",
        ):
            if label in particles.columns:
                row[label] = particles.iloc[0][label]
        optics = pd.DataFrame([row])
        if "rlnOpticsGroup" not in particles.columns:
            particles["rlnOpticsGroup"] = 1
    used = {particle_key}
    if optics_key is not None:
        used.add(optics_key)
    result = RelionStar(
        optics=optics,
        particles=particles,
        source_path=source,
        extra_blocks={name: frame.copy() for name, frame in blocks.items() if name not in used},
    )
    if require_single_optics:
        result.validate_single_optics_group()
    return result


def write_relion_star(
    star: RelionStar,
    path: str | Path,
    *,
    extra_blocks: Mapping[str, Any] | None = None,
) -> Path:
    out = Path(path).expanduser().resolve()
    blocks: OrderedDict[str, Any] = OrderedDict()
    blocks["optics"] = star.optics
    blocks["particles"] = star.particles
    for name, frame in star.extra_blocks.items():
        if name not in blocks:
            blocks[name] = frame
    if extra_blocks:
        for name, value in extra_blocks.items():
            blocks[name] = value
    write_star(blocks, out, overwrite=True)
    return out


def write_spectrum_star(
    path: str | Path,
    labels: Mapping[str, Any],
    *,
    block_name: str = "spectral",
) -> Path:
    out = Path(path).expanduser().resolve()
    write_star({block_name: pd.DataFrame(dict(labels))}, out, overwrite=True)
    return out
