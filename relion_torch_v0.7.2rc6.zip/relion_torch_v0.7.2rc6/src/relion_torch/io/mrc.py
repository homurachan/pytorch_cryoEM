from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Sequence

import mrcfile
import numpy as np
import torch


def read_mrc(
    path: str | Path,
    *,
    device: torch.device | str = "cpu",
    dtype: torch.dtype = torch.float32,
    copy: bool = True,
) -> torch.Tensor:
    path = Path(path).expanduser().resolve()
    with mrcfile.open(path, permissive=True) as handle:
        array = np.asarray(handle.data)
        if copy:
            array = np.array(array, copy=True)
    return torch.as_tensor(array, dtype=dtype, device=device)


# Backward-compatible alias used internally by some modules.
load_mrc = read_mrc


def mrc_pixel_size(path: str | Path) -> float | None:
    with mrcfile.open(path, mode="r", permissive=True, header_only=True) as handle:
        value = float(handle.voxel_size.x)
    return value if value > 0 else None


def write_mrc(
    path: str | Path,
    data: torch.Tensor | np.ndarray,
    *,
    pixel_size_angstrom: float | None = None,
    overwrite: bool = True,
) -> Path:
    path = Path(path).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, torch.Tensor):
        array = data.detach().to(device="cpu", dtype=torch.float32).contiguous().numpy()
    else:
        array = np.asarray(data, dtype=np.float32)
    finite = np.isfinite(array)
    if not bool(finite.all()):
        nan_count = int(np.count_nonzero(np.isnan(array)))
        posinf_count = int(np.count_nonzero(np.isposinf(array)))
        neginf_count = int(np.count_nonzero(np.isneginf(array)))
        raise FloatingPointError(
            f"Refusing to write non-finite MRC data to {path}: "
            f"NaN={nan_count}, +Inf={posinf_count}, -Inf={neginf_count}"
        )
    with mrcfile.new(path, overwrite=overwrite) as handle:
        handle.set_data(np.ascontiguousarray(array))
        if path.suffix.lower() == ".mrcs" and array.ndim == 3:
            handle.set_image_stack()
        if pixel_size_angstrom is not None:
            handle.voxel_size = float(pixel_size_angstrom)
        handle.update_header_stats()
    return path


# Shared bounded reader; re-export preserves the existing public import.
from relion_torch.io.mrc_stack import MRCStackCache


def load_references(
    specification: str | Sequence[str | Path],
    *,
    reference_dim: int | None = None,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> tuple[list[torch.Tensor], list[Path]]:
    """Load individual class maps or a 2-D class-average stack."""

    if isinstance(specification, str):
        paths = [Path(item.strip()) for item in specification.split(",") if item.strip()]
    else:
        paths = [Path(item) for item in specification]
    if not paths:
        raise ValueError("No reference files were provided")
    references: list[torch.Tensor] = []
    source_paths: list[Path] = []
    if len(paths) == 1:
        tensor = read_mrc(paths[0], device=device or "cpu", dtype=dtype)
        if tensor.ndim == 2:
            references = [tensor]
            source_paths = [paths[0]]
        elif tensor.ndim == 3 and reference_dim == 2:
            references = [tensor[index] for index in range(tensor.shape[0])]
            source_paths = [paths[0]] * tensor.shape[0]
        elif tensor.ndim == 3:
            references = [tensor]
            source_paths = [paths[0]]
        else:
            raise ValueError(f"Unsupported reference shape {tuple(tensor.shape)}")
    else:
        for path in paths:
            tensor = read_mrc(path, device=device or "cpu", dtype=dtype)
            if tensor.ndim not in (2, 3):
                raise ValueError(f"Reference {path} has unsupported shape {tuple(tensor.shape)}")
            references.append(tensor)
            source_paths.append(path)
    dims = {ref.ndim for ref in references}
    shapes = {tuple(ref.shape) for ref in references}
    if len(dims) != 1 or len(shapes) != 1:
        raise ValueError("All class references must have identical dimensionality and shape")
    if reference_dim is not None and next(iter(dims)) != reference_dim:
        raise ValueError(
            f"Requested reference_dim={reference_dim}, but references are {next(iter(dims))}D"
        )
    return references, source_paths
