"""Read individual volumes or indexed class images, without unpacking to disk."""
from __future__ import annotations
from pathlib import Path
from typing import Sequence
import numpy as np
import torch
from .mrc_stack import MRCStackCache


def read_reference_images(paths: Sequence[str | Path], device: torch.device | str) -> list[torch.Tensor]:
    from relion_torch.alignment.core import read_reference
    images = []
    with MRCStackCache(max_open=8, backend='read') as cache:
        for value in paths:
            text = str(value)
            index, separator, name = text.partition('@')
            if separator and index.isdecimal():
                if not index.isdecimal() or int(index) < 1 or not name:
                    raise ValueError(f"invalid 1-based reference locator: {text!r}")
                array = cache.image(name, int(index))
                images.append(torch.as_tensor(np.array(array, dtype=np.float32, copy=True), device=device))
            else:
                images.append(read_reference(value, torch.device(device)))
    return images
