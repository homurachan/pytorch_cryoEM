"""Bounded, slice-only particle MRC access (no scientific image operations).

The default backend uses seek/fromfile, never ``mrcfile.open(...).data`` and
never a whole-stack mapping.  An opt-in mmap backend uses the same validation.
Returned arrays own their storage; eviction cannot invalidate caller data.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import math
import os
from pathlib import Path
from typing import BinaryIO
import warnings

import mrcfile
from mrcfile.dtypes import HEADER_DTYPE
from mrcfile import utils
import numpy as np
import torch


class ParticleReadError(RuntimeError):
    """A particle stack cannot be opened, validated, or read safely."""


@dataclass
class _Stack:
    path: Path
    stream: BinaryIO
    shape: tuple[int, ...]
    dtype: np.dtype
    offset: int
    mode: int
    size: int
    mapping: np.memmap | None = None

    @property
    def count(self) -> int:
        return 1 if len(self.shape) == 2 else self.shape[0]

    @property
    def image_shape(self) -> tuple[int, int]:
        return self.shape[-2:]

    def describe(self) -> str:
        expected = self.offset + math.prod(self.shape) * self.dtype.itemsize
        return (f"path={str(self.path)!r}, shape={self.shape}, mode={self.mode}, "
                f"dtype={self.dtype}, data_offset={self.offset}, "
                f"expected_bytes={expected}, actual_bytes={self.size}")

    def close(self) -> None:
        try:
            if self.mapping is not None:
                mapping, self.mapping = self.mapping, None
                mapping._mmap.close()
        finally:
            self.stream.close()


def _read_header(stream: BinaryIO, path: Path) -> _Stack:
    """Read just 1024 bytes, using mrcfile's dtype/byte-order definitions.

    Extended headers are skipped by byte offset, not allocated.  Preserve
    mrcfile's permissive handling of legacy MAP/machine stamps but never its
    permissive ``data=None`` failure behavior.
    """
    raw = stream.read(HEADER_DTYPE.itemsize)
    if raw[:2] in (b'\x1f\x8b', b'BZ'):
        raise ValueError("compressed particle stacks are not seekable; decompress the MRC/MRCS first")
    if len(raw) != HEADER_DTYPE.itemsize:
        raise ValueError(f"incomplete MRC header: expected 1024 bytes, got {len(raw)}")
    header = np.frombuffer(raw, dtype=HEADER_DTYPE).copy().reshape(()).view(np.recarray)
    if bytes(header.map)[:3] != b'MAP':
        warnings.warn(f"{path}: missing MRC MAP identifier; checking dimensions, mode and file length", RuntimeWarning)
    try:
        byte_order = utils.byte_order_from_machine_stamp(header.machst)
    except ValueError as exc:
        warnings.warn(f"{path}: {exc}; trying little-endian, as mrcfile permissive mode does", RuntimeWarning)
        byte_order = '<'
    header.dtype = header.dtype.newbyteorder(byte_order)
    try:
        dtype = utils.data_dtype_from_header(header)
    except ValueError:
        # Compatibility with files whose machine stamp has the wrong byte order.
        opposite = header.copy()
        opposite.dtype = opposite.dtype.newbyteorder()
        dtype = utils.data_dtype_from_header(opposite)
        header = opposite
        warnings.warn(f"{path}: machine stamp disagrees with the apparent data byte order", RuntimeWarning)
    mode = int(header.mode)
    if mode not in (0, 1, 2, 6, 12):
        raise ValueError(f"unsupported real-space particle mode {mode}; expected 0, 1, 2, 6 or 12 (complex data are not particle images)")
    nx, ny, nz, mz = (int(header[x]) for x in ('nx', 'ny', 'nz', 'mz'))
    if min(nx, ny, nz) < 1:
        raise ValueError(f"nonpositive MRC dimensions nx={nx}, ny={ny}, nz={nz}")
    if utils.spacegroup_is_volume_stack(header.ispg):
        raise ValueError(f"4-D volume stacks are not supported as 2-D particles (ispg={int(header.ispg)}, mz={mz})")
    shape = tuple(int(x) for x in utils.data_shape_from_header(header))
    extended = int(header.nsymbt)
    if extended < 0:
        raise ValueError(f"negative extended-header size nsymbt={extended}")
    size = os.fstat(stream.fileno()).st_size
    stack = _Stack(path, stream, shape, np.dtype(dtype), HEADER_DTYPE.itemsize + extended, mode, size)
    expected = stack.offset + math.prod(shape) * stack.dtype.itemsize
    if size < expected:
        raise ValueError(f"truncated MRC/MRCS or inconsistent header: {stack.describe()}")
    # Trailing bytes are allowed, as in the historical permissive reader.
    return stack


class MRCStackCache:
    """LRU of at most ``max_open`` files; default reads only requested slices.

    Not thread-safe: each worker must own its own cache. No mapping or raw view
    escapes this object. Both close() and exception cleanup are deterministic.
    """
    def __init__(self, max_open: int = 8, max_open_files: int | None = None,
                 *, backend: str = 'read') -> None:
        if max_open_files is not None:
            max_open = max_open_files
        if max_open < 1:
            raise ValueError("max_open must be at least one")
        if backend not in ('read', 'mmap'):
            raise ValueError("particle I/O backend must be read or mmap")
        self.max_open = int(max_open)
        self.backend = backend
        self._handles: OrderedDict[Path, _Stack] = OrderedDict()
        self.opens = 0
        self.evictions = 0
        self.peak_open = 0
        self.images_read = 0

    def _open(self, path: Path) -> _Stack:
        path = path.expanduser().resolve()
        if path in self._handles:
            self._handles.move_to_end(path)
            return self._handles[path]
        # Evict BEFORE opening, including the temporary open/mmap operation.
        if len(self._handles) >= self.max_open:
            _, old = self._handles.popitem(last=False)
            old.close()
            self.evictions += 1
        stream = None
        try:
            stream = open(path, 'rb', buffering=0)
            stack = _read_header(stream, path)
            if self.backend == 'mmap':
                # No permissive wrapper: preserve mmap's original errno/cause.
                stack.mapping = np.memmap(stream, dtype=stack.dtype, mode='r',
                                          offset=stack.offset, shape=stack.shape)
            self._handles[path] = stack
            self.opens += 1
            self.peak_open = max(self.peak_open, len(self._handles))
            return stack
        except Exception as exc:
            if stream is not None:
                stream.close()
            hint = " Try --particle-io read for a mmap resource failure." if self.backend == 'mmap' else ""
            raise ParticleReadError(f"Cannot open particle stack {str(path)!r} (backend={self.backend}): "
                                    f"{type(exc).__name__}: {exc}.{hint}") from exc

    def shape(self, path: str | Path) -> tuple[int, ...]:
        return self._open(Path(path)).shape

    def read_images(self, path: str | Path, one_based_index: int, count: int = 1) -> np.ndarray:
        """Owned float32 [count,ny,nx]; one contiguous disk read where possible."""
        path = Path(path)
        try:
            stack = self._open(path)
            first = int(one_based_index) - 1
            if count < 1 or first < 0 or first + count > stack.count:
                raise IndexError(f"image range {one_based_index}..{one_based_index+count-1} "
                                 f"is outside 1..{stack.count}; {stack.describe()}")
            if stack.mapping is not None:
                arr = stack.mapping[None] if len(stack.shape) == 2 else stack.mapping
                result = np.array(arr[first:first+count], dtype=np.float32, copy=True, order='C')
            else:
                pixels = math.prod(stack.image_shape)
                stack.stream.seek(stack.offset + first * pixels * stack.dtype.itemsize)
                data = np.fromfile(stack.stream, dtype=stack.dtype, count=count * pixels)
                if data.size != count * pixels:
                    raise OSError(f"short read: expected {count*pixels*stack.dtype.itemsize} bytes, "
                                  f"read {data.nbytes}; file may have changed or NFS read failed; {stack.describe()}")
                result = np.asarray(data, dtype=np.float32).reshape((count,) + stack.image_shape)
            self.images_read += count
            return result
        except Exception as exc:
            if isinstance(exc, ParticleReadError):
                raise ParticleReadError(f"Reading images {one_based_index}..{one_based_index+count-1} "
                                        f"from {str(path)!r}: {exc}") from exc
            raise ParticleReadError(f"Cannot read images {one_based_index}..{one_based_index+count-1} "
                                    f"from {str(path)!r}: {type(exc).__name__}: {exc}") from exc

    def image(self, path: str | Path, one_based_index: int | None) -> np.ndarray:
        if one_based_index is None:
            shape = self.shape(path)
            if len(shape) != 2:
                raise ParticleReadError(f"Stack index is required for {path}, shape={shape}")
            one_based_index = 1
        return self.read_images(path, one_based_index, 1)[0]

    def read_image(self, path: str | Path, one_based_index: int | None, *,
                   dtype: torch.dtype = torch.float32, device: torch.device | str = 'cpu',
                   pin_memory: bool = False) -> torch.Tensor:
        host = torch.from_numpy(self.image(path, one_based_index))
        if pin_memory and torch.cuda.is_available():
            host = host.pin_memory()
        return host.to(device=device, dtype=dtype, non_blocking=pin_memory)

    def close(self) -> None:
        while self._handles:
            _, handle = self._handles.popitem(last=False)
            handle.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
