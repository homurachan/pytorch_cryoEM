from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

import torch

from relion_torch.geometry.grids import rfft_frequency_coordinates_2d


@dataclass(slots=True)
class CTFParameters:
    """Standard RELION CTF parameters.

    STAR units are used: defocus in Angstrom, astigmatism angle and phase shift
    in degrees, voltage in kV, spherical aberration in mm. Values may be scalar
    or tensors with arbitrary broadcastable leading dimensions.
    """

    defocus_u: Any
    defocus_v: Any
    defocus_angle_deg: Any
    voltage_kv: Any
    cs_mm: Any
    amplitude_contrast: Any
    phase_shift_deg: Any = 0.0
    bfactor: Any = 0.0
    scale: Any = 1.0


def electron_wavelength_angstrom(voltage_kv: torch.Tensor | float) -> torch.Tensor:
    """RELION 3.1 relativistic electron wavelength, in Angstrom."""

    kv = torch.as_tensor(voltage_kv)
    volts = kv * 1000.0
    return 12.2643247 / torch.sqrt(volts * (1.0 + volts * 0.978466e-6))


def _tensor(value: Any, *, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    return torch.as_tensor(value, device=device, dtype=dtype)


@dataclass(frozen=True)
class CTFFrequencyGrid2D:
    """Geometry-only CTF grid; contains no per-particle or per-iteration state."""
    box_size: int
    pixel_size_angstrom: float
    x: torch.Tensor
    y: torch.Tensor
    u2: torch.Tensor

    @classmethod
    def create(cls, box_size, pixel_size_angstrom, *, device, dtype):
        if box_size <= 0 or not math.isfinite(pixel_size_angstrom) or pixel_size_angstrom <= 0:
            raise ValueError("CTF grid requires a positive box and finite positive pixel size")
        coords = rfft_frequency_coordinates_2d(box_size, device=device, dtype=dtype)
        x = (coords[..., 0] / (box_size * float(pixel_size_angstrom))).contiguous()
        y = (coords[..., 1] / (box_size * float(pixel_size_angstrom))).contiguous()
        return cls(int(box_size), float(pixel_size_angstrom), x, y, x.square()+y.square())

    @property
    def byte_size(self):
        return sum(t.numel()*t.element_size() for t in (self.x, self.y, self.u2))


def compute_ctf(
    box_size: int,
    pixel_size_angstrom: float,
    parameters: CTFParameters,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
    batch_shape: tuple[int, ...] | None = None,
    intact_first_peak: bool = False,
    phase_flipped_input: bool = False,
    only_flip_phases: bool = False,
    ctf_abs: bool = False,
    frequency_grid: CTFFrequencyGrid2D | None = None,
    validate_parameters: bool = True,
    frequency_matrix: torch.Tensor | None = None,
    gamma_offset: torch.Tensor | None = None,
    return_gamma: bool = False,
) -> torch.Tensor:
    """Calculate the RELION 3.1 CTF on an unshifted RFFT grid.

    This follows ``CTF::initialise`` and ``CTF::getCTF`` rather than using a
    rearranged microscope-textbook expression. In particular, RELION stores the
    quadratic defocus matrix with negative eigenvalues and evaluates::

        gamma = K1*(Axx*X^2 + 2*Axy*X*Y + Ayy*Y^2)
                + K2*(X^2+Y^2)^2 - phase_shift - K3
        CTF = -sin(gamma) * exp(-B*(X^2+Y^2)/4) * scale

    where ``K3 = atan(Q0/sqrt(1-Q0^2))`` incorporates amplitude contrast.
    """

    if box_size <= 0:
        raise ValueError("box_size must be positive")
    if pixel_size_angstrom <= 0:
        raise ValueError("pixel_size_angstrom must be positive")
    dev = torch.device("cpu" if device is None else device)

    values = [
        _tensor(parameters.defocus_u, device=dev, dtype=dtype),
        _tensor(parameters.defocus_v, device=dev, dtype=dtype),
        _tensor(parameters.defocus_angle_deg, device=dev, dtype=dtype),
        _tensor(parameters.voltage_kv, device=dev, dtype=dtype),
        _tensor(parameters.cs_mm, device=dev, dtype=dtype),
        _tensor(parameters.amplitude_contrast, device=dev, dtype=dtype),
        _tensor(parameters.phase_shift_deg, device=dev, dtype=dtype),
        _tensor(parameters.bfactor, device=dev, dtype=dtype),
        _tensor(parameters.scale, device=dev, dtype=dtype),
    ]
    du, dv, angle, kv, cs_mm, q0, phase, bfac, scale = torch.broadcast_tensors(*values)
    if batch_shape is not None:
        target = torch.Size(batch_shape)
        du, dv, angle, kv, cs_mm, q0, phase, bfac, scale = [
            value.expand(target)
            for value in (du, dv, angle, kv, cs_mm, q0, phase, bfac, scale)
        ]
    if validate_parameters and torch.any((q0 < 0) | (q0 >= 1)):
        raise ValueError("Amplitude contrast must satisfy 0 <= Q0 < 1")

    # Rotation Q=[cos -sin; sin cos], D=diag(-defocus_u,-defocus_v), A=Q D Q^T.
    a = angle * (math.pi / 180.0)
    ca, sa = torch.cos(a), torch.sin(a)
    axx = -(du * ca.square() + dv * sa.square())
    ayy = -(du * sa.square() + dv * ca.square())
    axy = (dv - du) * sa * ca

    wavelength = electron_wavelength_angstrom(kv).to(device=dev, dtype=dtype)
    cs_angstrom = cs_mm * 1.0e7
    k1 = math.pi * wavelength
    k2 = 0.5 * math.pi * cs_angstrom * wavelength.pow(3)
    k3 = torch.atan(q0 / torch.sqrt(torch.clamp(1.0 - q0.square(), min=1.0e-30)))
    k4 = -bfac / 4.0
    k5 = phase * (math.pi / 180.0)

    if frequency_grid is None:
        grid = CTFFrequencyGrid2D.create(box_size, pixel_size_angstrom, device=dev, dtype=dtype)
    else:
        grid = frequency_grid
        if (grid.box_size != box_size or grid.pixel_size_angstrom != float(pixel_size_angstrom)
                or grid.x.device != du.device or grid.x.dtype != dtype):
            raise ValueError("CTF frequency grid does not match box/pixel/device/dtype")
    x, y, u2 = grid.x, grid.y, grid.u2
    if frequency_matrix is not None:
        matrix = torch.as_tensor(frequency_matrix, device=dev, dtype=dtype)
        if matrix.shape != (2, 2):
            raise ValueError("frequency_matrix must be a 2x2 optics-group matrix")
        x, y = matrix[0, 0]*x + matrix[0, 1]*y, matrix[1, 0]*x + matrix[1, 1]*y
        u2 = x.square() + y.square()

    lead = du.ndim
    tail = (None, None)
    axx = axx[(...,) + tail]
    axy = axy[(...,) + tail]
    ayy = ayy[(...,) + tail]
    k1 = k1[(...,) + tail]
    k2 = k2[(...,) + tail]
    k3 = k3[(...,) + tail]
    k4 = k4[(...,) + tail]
    k5 = k5[(...,) + tail]
    scale = scale[(...,) + tail]
    x = x.reshape((1,) * lead + x.shape)
    y = y.reshape((1,) * lead + y.shape)
    u2 = u2.reshape((1,) * lead + u2.shape)

    gamma = k1 * (axx * x.square() + 2.0 * axy * x * y + ayy * y.square())
    gamma = gamma + k2 * u2.square() - k5 - k3
    if gamma_offset is not None:
        gamma = gamma + torch.as_tensor(gamma_offset, device=dev, dtype=dtype)
    if return_gamma:
        return gamma
    ctf = -torch.sin(gamma)
    if intact_first_peak:
        ctf = torch.where(gamma.abs() < (0.5 * math.pi), torch.ones_like(ctf), ctf)
    ctf = ctf * torch.exp(k4 * u2) * scale

    if phase_flipped_input:
        ctf = ctf.abs()
    if only_flip_phases:
        ctf = torch.where(ctf < 0, -torch.ones_like(ctf), torch.ones_like(ctf))
    if ctf_abs:
        ctf = ctf.abs()

    return ctf
