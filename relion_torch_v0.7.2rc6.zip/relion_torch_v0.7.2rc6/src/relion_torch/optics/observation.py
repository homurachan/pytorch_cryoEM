"""Shared RELION optical observation model for prediction and reconstruction."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import math
import numpy as np
import pandas as pd
import torch

from relion_torch.io.star import read_star
from relion_torch.io.particles import parse_image_reference, owned_array
from relion_torch.optics.ctf import CTFParameters, CTFFrequencyGrid2D, compute_ctf
from relion_torch.optics.aberrations import AberrationCoefficients, phase_factor


def metadata_values(particles, optics, label, default=None):
    """Particle values take precedence over the associated optics row."""
    fallback = optics.get(label, default)
    if label in particles:
        values = pd.to_numeric(particles[label], errors='coerce').to_numpy(dtype=float)
        if fallback is not None and not pd.isna(fallback):
            values = np.where(np.isnan(values), float(fallback), values)
    elif fallback is not None and not pd.isna(fallback):
        values = np.full(len(particles), float(fallback))
    else:
        raise ValueError(f'Missing required metadata: {label}')
    if not np.isfinite(values).all():
        raise ValueError(f'Non-finite or missing metadata: {label}')
    # pandas Copy-on-Write can expose a read-only view. Never share that
    # storage with torch, including on the CPU path used to encode CTF fits.
    return owned_array(values)


@dataclass
class OpticsGroup:
    identifier: int
    row: pd.Series
    box_size: int
    pixel_size: float
    matrix: torch.Tensor
    odd: np.ndarray
    even: np.ndarray
    grid: CTFFrequencyGrid2D
    x: torch.Tensor
    y: torch.Tensor
    odd_phase: torch.Tensor
    even_phase: torch.Tensor
    mtf: torch.Tensor


class ObservationModel:
    def __init__(self, optics, *, source_dir='.', device='cpu', dtype=torch.float32):
        self.optics = optics.copy()
        self.device, self.dtype = torch.device(device), dtype
        self.source_dir = Path(source_dir)
        self.groups = {}
        for _, row in self.optics.iterrows():
            raw_id = float(row['rlnOpticsGroup'])
            if not math.isfinite(raw_id) or int(raw_id) != raw_id or raw_id < 1:
                raise ValueError('rlnOpticsGroup must contain positive integers')
            identifier = int(raw_id)
            if identifier in self.groups:
                raise ValueError(f'Duplicate optics group {identifier}')
            size, pixel = float(row['rlnImageSize']), float(row['rlnImagePixelSize'])
            if not math.isfinite(size) or size != int(size):
                raise ValueError('Optics image size must be an integer')
            n = int(size)
            if n < 2 or n % 2 or pixel <= 0 or not math.isfinite(pixel):
                raise ValueError('Optics groups need an even box and positive pixel size')
            if int(row.get('rlnImageDimensionality', 2)) != 2:
                raise ValueError('The SPA observation model requires 2D particles')
            matrix = torch.tensor([[row.get(f'rlnMagMat{i}{j}', float(i == j))
                                    for j in range(2)] for i in range(2)], device=self.device, dtype=dtype)
            if not torch.isfinite(matrix).all() or float(torch.linalg.det(matrix)) < 1.e-8:
                raise ValueError(f'Invalid magnification matrix in optics group {identifier}')
            grid = CTFFrequencyGrid2D.create(n, pixel, device=self.device, dtype=dtype)
            x = matrix[0, 0]*grid.x+matrix[0, 1]*grid.y
            y = matrix[1, 0]*grid.x+matrix[1, 1]*grid.y
            aberrations = AberrationCoefficients.from_optics(row)
            odd, even = np.asarray(aberrations.odd), np.asarray(aberrations.even)
            group = OpticsGroup(identifier, row.copy(), n, pixel, matrix, odd, even, grid, x, y,
                aberrations.phase(grid, 'odd'), aberrations.phase(grid, 'even'), self._mtf(row, grid))
            self.groups[identifier] = group

    def _mtf(self, row, grid):
        value = row.get('rlnMtfFileName')
        if value is None or str(value) in ('None', 'none', 'nan', '?', '.', ''):
            return torch.ones_like(grid.x)
        if 'rlnMicrographOriginalPixelSize' not in row:
            raise ValueError('MTF requires rlnMicrographOriginalPixelSize in optics')
        _, path = parse_image_reference(str(value), self.source_dir)
        blocks = read_star(path)
        curve = next((v for v in blocks.values() if 'rlnMtfValue' in v), None)
        if curve is None:
            raise ValueError(f'No rlnMtfValue in {path}')
        frequency = np.asarray(curve['rlnResolutionInversePixel'], dtype=float)/float(row['rlnMicrographOriginalPixelSize'])
        values = np.asarray(curve['rlnMtfValue'], dtype=float)
        if len(values) < 2 or not np.isfinite(frequency).all() or not np.isfinite(values).all() or np.any(values <= 0) or np.any(np.diff(frequency) <= 0):
            raise ValueError(f'Invalid MTF curve: {path}')
        radius = (grid.x.square()+grid.y.square()).sqrt().cpu().numpy()
        # Match ObservationModel::getMtfImage's legacy interval selection.
        index = np.floor(radius/((frequency[-1]-frequency[0])/len(values))).astype(int)
        safe = np.clip(index, 0, len(values)-2)
        result = values[safe]+(values[safe+1]-values[safe])*(radius-frequency[safe])/(frequency[safe+1]-frequency[safe])
        result = np.where(index <= 0, values[0], np.where(index >= len(values)-1, values[-1], result))
        if np.any(result <= 0):
            raise ValueError('Interpolated MTF is not positive')
        return torch.as_tensor(result, device=self.device, dtype=self.dtype)

    def parameters(self, rows, group_id):
        row = self.groups[int(group_id)].row
        labels = [('rlnDefocusU', None), ('rlnDefocusV', None), ('rlnDefocusAngle', 0.),
                  ('rlnVoltage', 300.), ('rlnSphericalAberration', 2.7), ('rlnAmplitudeContrast', .1),
                  ('rlnPhaseShift', 0.), ('rlnCtfBfactor', 0.), ('rlnCtfScalefactor', 1.)]
        values = [torch.as_tensor(metadata_values(rows, row, name, default),
            device=self.device, dtype=self.dtype) for name, default in labels]
        if bool((values[3] <= 0).any()) or bool(((values[5] < 0) | (values[5] >= 1)).any()):
            raise ValueError('CTF voltage must be positive and amplitude contrast must be in [0, 1)')
        return CTFParameters(*values)

    def ctf(self, rows, group_id, *, include_even=True, return_gamma=False):
        g = self.groups[int(group_id)]
        return compute_ctf(g.box_size, g.pixel_size, self.parameters(rows, group_id),
            device=self.device, dtype=self.dtype, frequency_grid=g.grid,
            frequency_matrix=g.matrix, gamma_offset=g.even_phase if include_even else None,
            return_gamma=return_gamma)

    def predict(self, projector, rotations, group_id, reference_pixel, *, apply_odd=True, gradients=False):
        g = self.groups[int(group_id)]
        prediction = projector.project_optics(rotations, output_size=g.box_size,
            frequency_matrix=g.matrix,
            scale_ratio=projector.original_size*reference_pixel/(g.box_size*g.pixel_size),
            gradients=gradients)
        factor = g.mtf*phase_factor(g.odd_phase) if apply_odd else g.mtf
        if gradients:
            values, gradient = prediction
            return values*factor, gradient*factor[..., None]
        return prediction*factor

    def reconstruction_terms(self, fourier, rows, group_id):
        """Return conjugate-model numerator and normal-equation denominator."""
        g = self.groups[int(group_id)]
        transfer = self.ctf(rows, group_id)*g.mtf*phase_factor(g.odd_phase)
        return fourier*transfer.conj(), transfer.abs().square()

    def reconstruction_rotations(self, rotations, group_id, reference_box, reference_pixel):
        g = self.groups[int(group_id)]
        mag = torch.eye(3, device=self.device, dtype=self.dtype)
        mag[:2, :2] = g.matrix
        return (torch.linalg.inv(mag)@rotations)*(g.box_size*g.pixel_size/(reference_box*reference_pixel))
