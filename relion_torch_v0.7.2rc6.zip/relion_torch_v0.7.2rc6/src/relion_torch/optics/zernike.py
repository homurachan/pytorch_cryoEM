"""RELION 3.1 Zernike conventions (physical reciprocal-Angstrom coordinates).

Based on RELION src/jaz/math/Zernike.cpp and ctf/tilt_helper.cpp,
Jasenko Zivanov and contributors, GPL-2.0-or-later; see NOTICE.
"""
from __future__ import annotations

import math
import re
import numpy as np
import torch


def parse_coefficients(value) -> np.ndarray:
    if value is None or (isinstance(value, (float, np.floating)) and np.isnan(value)):
        return np.empty(0, dtype=np.float64)
    if isinstance(value, (list, tuple, np.ndarray)):
        result = np.asarray(value, dtype=np.float64)
    else:
        text = str(value).strip()
        if text in ('', '?', '.', 'None', 'nan'):
            return np.empty(0, dtype=np.float64)
        text = text.strip('[]')
        result = np.asarray([float(s) for s in re.split(r'[,\s]+', text) if s], dtype=np.float64)
    if result.ndim != 1 or not np.isfinite(result).all():
        raise ValueError('Zernike coefficients must be a finite one-dimensional vector')
    return result


def format_coefficients(value) -> str:
    return '[' + ','.join(format(float(x), '.17g') for x in value) + ']'


def indices(parity: str, max_degree: int) -> list[tuple[int, int]]:
    if parity not in ('even', 'odd') or max_degree < 0:
        raise ValueError('invalid Zernike parity/degree')
    return [(m, n) for n in range(0 if parity == 'even' else 1, max_degree+1, 2)
            for m in range(-n, n+1, 2)]


def polynomial(m: int, n: int, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Cartesian polynomial: no atan2/sqrt singular derivative at the origin."""
    order = abs(m)
    if order > n or (n-order) % 2:
        raise ValueError('invalid Zernike indices')
    real, imag = torch.ones_like(x), torch.zeros_like(x)
    for _ in range(order):
        real, imag = real*x-imag*y, real*y+imag*x
    angular = real if m >= 0 else imag
    r2 = x*x+y*y
    radial = torch.zeros_like(x)
    for k in range((n-order)//2+1):
        coefficient = ((-1)**k * math.factorial(n-k)
                       / (math.factorial(k)*math.factorial((n+order)//2-k)
                          * math.factorial((n-order)//2-k)))
        radial = radial + coefficient*r2.pow((n-order)//2-k)
    return angular*radial


def basis(x, y, parity: str, max_degree: int) -> torch.Tensor:
    return torch.stack([polynomial(m, n, x, y) for m, n in indices(parity, max_degree)])


def evaluate(coefficients, x, y, parity: str) -> torch.Tensor:
    coefficients = torch.as_tensor(coefficients, device=x.device, dtype=x.dtype)
    out = torch.zeros_like(x)
    n = 0 if parity == 'even' else 1
    cursor = 0
    while cursor < coefficients.numel():
        for m in range(-n, n+1, 2):
            if cursor == coefficients.numel():
                break
            out = out + coefficients[cursor]*polynomial(m, n, x, y)
            cursor += 1
        n += 2
    return out


def insert_tilt(coefficients, tx: float, ty: float, cs_mm: float, wavelength: float):
    out = np.zeros(max(6, len(coefficients)), dtype=np.float64)
    out[:len(coefficients)] = coefficients
    scale = cs_mm*20000*wavelength*wavelength*math.pi
    zx, zy = -scale*tx/3, -scale*ty/3
    out[1] += 2*zx
    out[0] += 2*zy
    out[4], out[3] = zx, zy
    return out


def extract_tilt(coefficients, cs_mm: float, wavelength: float):
    out = np.asarray(coefficients, dtype=np.float64).copy()
    if out.size < 6:
        out = np.pad(out, (0, 6-out.size))
    scale = cs_mm*20000*wavelength*wavelength*math.pi
    if abs(scale) < 1.e-15:
        # A coma phase can still be represented as Zernikes on a Cs-corrected scope.
        return out, 0., 0.
    zx, zy = out[4], out[3]
    out[4] = out[3] = 0.
    out[1] -= 2*zx
    out[0] -= 2*zy
    return out, -3*zx/scale, -3*zy/scale
