"""Shared RELION odd/even phase conventions for all observation paths.

Beam tilt is in mrad; Zernikes use physical reciprocal-Angstrom coordinates.
Odd phase multiplies a prediction by exp(+i phase), and an observation by
exp(-i phase). Even phase is added to CTF gamma, not to the complex image.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np
import torch

from .ctf import CTFFrequencyGrid2D, electron_wavelength_angstrom
from .zernike import parse_coefficients, insert_tilt, evaluate


@dataclass(frozen=True)
class AberrationCoefficients:
    """Immutable, host-only optics state, shared by records of one group."""
    odd: tuple[float, ...] = ()
    even: tuple[float, ...] = ()
    matrix: tuple[float, ...] = (1., 0., 0., 1.)

    @classmethod
    def from_optics(cls, row):
        odd = parse_coefficients(row.get('rlnOddZernike'))
        even = parse_coefficients(row.get('rlnEvenZernike'))
        # Match ObservationModel/TiltHelper: explicit beam-tilt columns replace
        # the coma coefficients (3,4), while retaining trefoil/higher orders.
        if 'rlnBeamTiltX' in row or 'rlnBeamTiltY' in row:
            tx, ty = float(row.get('rlnBeamTiltX', 0)), float(row.get('rlnBeamTiltY', 0))
            voltage = float(row.get('rlnVoltage', 300.))
            cs = float(row.get('rlnSphericalAberration', 2.7))
            if not all(math.isfinite(x) for x in (tx, ty, voltage, cs)) or voltage <= 0:
                raise ValueError('Beam tilt/Cs must be finite and voltage must be positive')
            wavelength = float(electron_wavelength_angstrom(torch.tensor(voltage, dtype=torch.float64)))
            odd = insert_tilt(odd, tx, ty, cs, wavelength)
        matrix = tuple(float(row.get(f'rlnMagMat{i}{j}', float(i == j)))
                       for i in range(2) for j in range(2))
        if not all(math.isfinite(x) for x in matrix) or matrix[0]*matrix[3]-matrix[1]*matrix[2] < 1.e-8:
            raise ValueError('Invalid optics magnification matrix')
        # Empty vectors make neutral optics an exact no-op, without device work.
        return cls(tuple(odd) if np.any(odd) else (),
                   tuple(even) if np.any(even) else (), matrix)

    def phase(self, grid: CTFFrequencyGrid2D, parity: str):
        if parity not in ('odd', 'even'):
            raise ValueError('Expected odd or even aberration phase')
        coefficients = self.odd if parity == 'odd' else self.even
        if not coefficients:
            return torch.zeros_like(grid.x)
        # ObservationModel uses negative y Nyquist, unlike the ordinary CTF
        # grid. Preserve that distinction, also for the even offset.
        yp = grid.y.clone()
        if grid.box_size % 2 == 0:
            yp[grid.box_size//2] = -yp[grid.box_size//2]
        a, b, c, d = self.matrix
        return evaluate(coefficients, a*grid.x+b*yp, c*grid.x+d*yp, parity)


def phase_factor(phase, *, inverse=False):
    return torch.polar(torch.ones_like(phase), -phase if inverse else phase)


def correction_for(coefficients, grid, kind, cache=None):
    """Use the caller's byte-bounded cache; no module-global device tensors."""
    if cache is not None:
        return cache.get_aberration(coefficients, grid, kind)
    phase = coefficients.phase(grid, 'odd' if kind == 'demodulation' else 'even')
    return phase_factor(phase, inverse=True) if kind == 'demodulation' else phase


def record_groups(records, parity):
    groups = {}
    for i, record in enumerate(records):
        coefficients = getattr(record, 'aberrations', None)
        if coefficients is not None and getattr(coefficients, parity):
            groups.setdefault(coefficients, []).append(i)
    return groups


def demodulate_records_(records, grid, *fourier, cache=None):
    """Correct owned Fourier batches in place, after masking and FFT.

    All arrays are [B,N,N//2+1]. Mixed optics groups need no separate FFTs or
    projection banks: each group receives its own unit-modulus correction.
    """
    for coefficients, rows in record_groups(records, 'odd').items():
        factor = correction_for(coefficients, grid, 'demodulation', cache)
        contiguous = rows[-1]-rows[0]+1 == len(rows)
        selected = slice(rows[0], rows[-1]+1) if contiguous else torch.tensor(rows, device=grid.x.device)
        for image in fourier:
            if contiguous:
                image[selected].mul_(factor)
            else:
                image.index_copy_(0, selected, image.index_select(0, selected)*factor)


def even_offset_for_records(records, grid, cache=None):
    groups = record_groups(records, 'even')
    if not groups:
        return None
    if len(groups) == 1:
        coefficients, rows = next(iter(groups.items()))
        if len(rows) == len(records):
            return correction_for(coefficients, grid, 'even', cache)
    result = torch.zeros((len(records), *grid.x.shape), device=grid.x.device, dtype=grid.x.dtype)
    for coefficients, rows in groups.items():
        result[rows] = correction_for(coefficients, grid, 'even', cache)
    return result
