"""Exact selected direction/psi pairs, without a Cartesian union or global table."""
import copy
import math
import numpy as np
import torch
from relion_torch.class3d.sampling import Class3DSampling
from relion_torch.sampling.relion_sampling import (FineSamplingTable, nested_children,
    pix2ang_nest, oversampled_psi, oversampled_translation)
from relion_torch.sampling.local import LocalAngularSupport, select_local_angular_support
from relion_torch.geometry.euler import relion_euler_matrix, matrix_to_relion_euler


def selected_table(root, ids, over):
    ids=np.asarray(ids,dtype=np.int64)
    npsi=len(root._psi);di=ids//npsi;pi=ids%npsi
    oc=8**over;pc=2**over
    angles=np.empty((len(ids),oc,3),dtype=np.float64)
    directions=np.empty((len(ids),oc),dtype=np.int64)
    orientation_ids=np.empty_like(directions)
    if over==0:
        angles[:,0,:2]=root._directions[di];angles[:,0,2]=root._psi[pi]
        directions[:,0]=di;orientation_ids[:,0]=ids
        translations=root._translations[:,None,:].copy()
    else:
        # Evaluate each HEALPix child once, even when many psi values share it.
        unique_di, inverse_di=np.unique(di,return_inverse=True)
        coordinate_rows=[];direction_rows=[]
        for d in unique_di:
            children=nested_children(int(root._coarse_direction_ids[d]) if hasattr(root,"_coarse_direction_ids") else int(d),over)
            coords=[]
            for child in children:
                theta,phi=pix2ang_nest(1<<(root.healpix_order+over),int(child))
                rot=math.degrees(phi)
                coords.append((rot-360 if rot>180 else rot,math.degrees(theta)))
            coordinate_rows.append(np.repeat(np.asarray(coords),pc,axis=0))
            direction_rows.append(np.repeat(children,pc))
        angles[:,:,:2]=np.asarray(coordinate_rows)[inverse_di]
        directions[:]=np.asarray(direction_rows)[inverse_di]
        unique_pi,inverse_pi=np.unique(pi,return_inverse=True)
        # Psi children depend only on psi, not on the HEALPix direction.
        psis=np.stack([oversampled_psi(root._psi[p],root.actual_psi_step,over) for p in unique_pi])[inverse_pi]
        angles[:,:,2]=np.tile(psis,(1,4**over))
        orientation_ids[:]=directions*(npsi*pc)+pi[:,None]*pc+np.tile(np.arange(pc),4**over)[None]
        translations=np.stack([oversampled_translation(x,root.offset_step,over) for x in root._translations])
    if root.random_perturbation:
        flat=torch.from_numpy(angles.reshape(-1,3))
        a=relion_euler_matrix(flat[:,0],flat[:,1],flat[:,2])
        dq=root.random_perturbation*root.angular_sampling()
        r=relion_euler_matrix(dq,dq,dq,dtype=torch.float64)
        angles=matrix_to_relion_euler(a@r).numpy().reshape(angles.shape)
    return FineSamplingTable(angles,directions,orientation_ids,
        translations+root.random_perturbation*root.offset_step,oc,4**over)


class SelectedSampling(Class3DSampling):
    def selected_fine_sampling_table(self,indices,order):
        return selected_table(self.root,self.global_orientation_ids[np.asarray(indices,dtype=np.int64)],int(order))

    @property
    def number_of_orientations(self):return len(self.global_orientation_ids)
    def fine_sampling_table(self,order=None):
        over=self.adaptive_oversampling if order is None else int(order)
        if over not in self._tables:
            root=self.root
            if over==0 and root.number_of_orientations*40<=getattr(self,'_shared_coarse_budget',0):
                key=(float(root.random_perturbation),root._directions.tobytes(),root._psi.tobytes(),
                     root._translations.tobytes(),float(root.offset_step))
                cached=getattr(root,'_selected_coarse_cache',None)
                if cached is None or cached[0]!=key:
                    table=selected_table(root,np.arange(root.number_of_orientations),0)
                    root._selected_coarse_cache=(key,table)
                else:table=cached[1]
                ids=self.global_orientation_ids
                self._tables[0]=FineSamplingTable(table.orientation_angles[ids],table.direction_indices[ids],
                    table.orientation_ids[ids],table.translations,1,1)
            else:self._tables[over]=selected_table(root,self.global_orientation_ids,over)
        return self._tables[over]
    def coarse_direction_indices(self,ids):
        mapping=torch.as_tensor(self.global_orientation_ids//len(self._psi),device=ids.device)
        return mapping[ids]


def subset_selected_sampling(parent,support,positions):
    """Reuse an uncommitted batch's support without repeating angular queries.

    The child has its own compact IDs/tables; probabilities and root IDs remain
    exactly those of its parent. A subset cannot exceed the admitted parent
    sampling-table bound. All ownership ends at the outer batch boundary.
    """
    rows=tuple(support.orientation_indices[int(p)] for p in positions)
    ids=np.unique(np.concatenate(rows))
    child=SelectedSampling.__new__(SelectedSampling)
    child.__dict__=copy.copy(parent.__dict__)
    child.global_orientation_ids=parent.global_orientation_ids[ids]
    child._tables={}
    local=LocalAngularSupport(tuple(np.searchsorted(ids,row) for row in rows),
        tuple(support.probabilities[int(p)] for p in positions))
    return child,local


def select_sampling(root,centres,sigmas,max_bytes,*,mode='auto',counters=None):
    from .direction_index import DirectionIndex
    index=None
    if (mode!='off' and root.symmetry.upper()=='C1' and sigmas[0]>0 and sigmas[1]>0
            and len(root._directions)>=512
            and len(root._directions)*DirectionIndex.bytes_per_direction <= max_bytes//4):
        index=getattr(root,'_local_direction_index',None)
        if index is None or not index.matches(root._directions):
            index=DirectionIndex(root._directions)
            root._local_direction_index=index
            if counters is not None:counters['local_candidate_index_builds']=counters.get('local_candidate_index_builds',0)+1
        if counters is not None:counters['local_candidate_index_bytes']=max(counters.get('local_candidate_index_bytes',0),index.nbytes)
    else:
        root.__dict__.pop('_local_direction_index',None)
    support=select_local_angular_support(root._directions,root._psi,centres,sigmas,symmetry=root.symmetry,
                                         direction_index=index,counters=counters)
    ids=np.unique(np.concatenate(support.orientation_indices))
    # Includes host tables, device copies and metadata; reject before building.
    if len(ids)*(1+8**root.adaptive_oversampling)*96+(index.nbytes if index else 0)>max_bytes:
        raise MemoryError('Selected angular pairs exceed --sampling-work-mib')
    out=SelectedSampling.__new__(SelectedSampling)
    out.__dict__=copy.copy(root.__dict__)
    out.root=root;out.global_orientation_ids=ids;out._tables={}
    out._shared_coarse_budget=min(16*2**20,max_bytes//8)
    local=LocalAngularSupport(tuple(np.searchsorted(ids,x) for x in support.orientation_indices),support.probabilities)
    return out,local
