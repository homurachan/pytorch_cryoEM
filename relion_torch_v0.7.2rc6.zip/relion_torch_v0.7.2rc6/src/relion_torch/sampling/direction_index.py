"""Conservative C1 spherical-cap lookup; exact legacy distances decide support.

Sorted Cartesian axes give a bounding box without a SciPy dependency. The
index owns only sampling geometry, never particle priors or selected support.
"""
import numpy as np


class DirectionIndex:
    bytes_per_direction = 88

    def __init__(self, directions):
        self.directions = np.array(directions, dtype=np.float64, copy=True)
        rot, tilt = np.deg2rad(self.directions).T
        self.xyz = np.stack((np.sin(tilt)*np.cos(rot), np.sin(tilt)*np.sin(rot), np.cos(tilt)), axis=1)
        self.order = np.argsort(self.xyz, axis=0, kind='stable')
        self.sorted_xyz = np.take_along_axis(self.xyz, self.order, axis=0)
        self.nbytes = sum(a.nbytes for a in (self.directions, self.xyz, self.order, self.sorted_xyz))

    def matches(self, directions):
        # Catch in-place grid changes too; identity alone is not a valid key.
        return np.array_equal(self.directions, directions)

    def candidates(self, centre, degrees):
        if degrees >= 180.:
            return np.arange(len(self.xyz), dtype=np.int64)
        # Include roundoff in norms/dot products, even at an almost zero cap.
        radius = 2*np.sin(np.deg2rad(degrees)*.5) + np.sqrt(128*np.finfo(np.float64).eps)
        bounds = [(np.searchsorted(self.sorted_xyz[:, a], centre[a]-radius, side='left'),
                   np.searchsorted(self.sorted_xyz[:, a], centre[a]+radius, side='right')) for a in range(3)]
        axis = min(range(3), key=lambda a: bounds[a][1]-bounds[a][0])
        lo, hi = bounds[axis]
        ids = self.order[lo:hi, axis]
        inside = np.all(np.abs(self.xyz[ids]-centre) <= radius, axis=1)
        # Native global direction order, including deterministic nearest ties.
        return np.sort(ids[inside])

    def select(self, centre, sigma, cutoff, counters=None):
        ids = self.candidates(centre, cutoff*sigma)
        distance = np.rad2deg(np.arccos(np.clip(self.xyz[ids] @ centre, -1., 1.)))
        if np.any(np.abs(distance-cutoff*sigma)<2e-5):
            # A differently sized BLAS call may round the final dot product
            # differently. Resolve near-boundary decisions with the EXACT old
            # full-table operation, including tiny caps next to acos(1).
            ids=np.arange(len(self.xyz),dtype=np.int64)
            distance=np.rad2deg(np.arccos(np.clip(self.xyz @ centre,-1.,1.)))
            if counters is not None:
                counters['local_candidate_boundary_fallbacks']=counters.get('local_candidate_boundary_fallbacks',0)+1
        keep = distance < cutoff*sigma
        if counters is not None:
            for key, value in [('local_candidate_queries', 1),
                               ('local_candidate_full_directions', len(self.xyz)),
                               ('local_candidate_tested_directions', len(ids))]:
                counters[key] = counters.get(key, 0)+value
        ids, distance = ids[keep], distance[keep]
        if not len(ids):
            # Use the original full arccos/argmin, not a different nearest metric.
            distance = np.rad2deg(np.arccos(np.clip(self.xyz @ centre, -1., 1.)))
            if counters is not None:
                counters['local_candidate_nearest_fallbacks'] = counters.get('local_candidate_nearest_fallbacks', 0)+1
            return np.array([int(np.argmin(distance))], dtype=np.int64), np.ones(1)
        probability = np.exp(-.5*(distance/sigma)**2)
        return ids, probability/probability.sum()
