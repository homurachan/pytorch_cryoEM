"""RELION 3.1 compatible angular and translational sampling.

The implementation is dependency-free and uses nested HEALPix indexing.  It is
kept separate from the likelihood engine so sampling tables can be compared
against RELION ``*_sampling.star`` before any image processing is involved.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
from pathlib import Path
from typing import Iterable, Iterator, Sequence

import numpy as np

_JRLL = np.asarray([2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4], dtype=np.int64)
_JPLL = np.asarray([1, 3, 5, 7, 0, 2, 4, 6, 1, 3, 5, 7], dtype=np.int64)


def relion_round(value: float | np.ndarray) -> int | np.ndarray:
    """C/C++ style nearest integer used by RELION (halves away from zero)."""
    x = np.asarray(value)
    result = np.where(x >= 0.0, np.floor(x + 0.5), np.ceil(x - 0.5)).astype(np.int64)
    return int(result) if result.ndim == 0 else result


def _compact_bits(v: int) -> int:
    """De-interleave the even-position bits of a HEALPix NEST index."""
    out = 0
    bit = 0
    while v:
        out |= (v & 1) << bit
        v >>= 2
        bit += 1
    return out


def _spread_bits(v: int) -> int:
    """Interleave integer bits into the even positions of a NEST child code."""
    out = 0
    bit = 0
    value = int(v)
    while value:
        out |= (value & 1) << (2 * bit)
        value >>= 1
        bit += 1
    return out


def pix2ang_nest(nside: int, ipix: int) -> tuple[float, float]:
    """Return ``(theta, phi)`` in radians for a nested HEALPix pixel centre.

    This follows the integer face-coordinate equations used by the original
    HEALPix C implementation and by RELION's ``Healpix_Base(..., NEST)``.
    """
    if nside < 1 or nside & (nside - 1):
        raise ValueError("nside must be a positive power of two")
    npface = nside * nside
    npix = 12 * npface
    if not 0 <= ipix < npix:
        raise IndexError(f"HEALPix index {ipix} outside [0, {npix})")
    face = ipix // npface
    ipf = ipix - face * npface
    ix = _compact_bits(ipf)
    iy = _compact_bits(ipf >> 1)

    jr = int(_JRLL[face] * nside - ix - iy - 1)
    if jr < nside:
        nr = jr
        z = 1.0 - (nr * nr) / (3.0 * nside * nside)
        kshift = 0
    elif jr > 3 * nside:
        nr = 4 * nside - jr
        z = -1.0 + (nr * nr) / (3.0 * nside * nside)
        kshift = 0
    else:
        nr = nside
        z = (2 * nside - jr) * (2.0 / (3.0 * nside))
        kshift = (jr - nside) & 1
    if nr <= 0:
        phi = 0.0
    else:
        jp = (int(_JPLL[face]) * nr + ix - iy + 1 + kshift) // 2
        nl4 = 4 * nr
        while jp > nl4:
            jp -= nl4
        while jp < 1:
            jp += nl4
        phi = (jp - 0.5 * (kshift + 1)) * (math.pi / (2.0 * nr))
        phi %= 2.0 * math.pi
    theta = math.acos(max(-1.0, min(1.0, z)))
    return theta, phi


def nest_directions(order: int) -> np.ndarray:
    """Return C1 directions in RELION NEST pixel order as rot/tilt degrees."""
    if order < 0:
        raise ValueError("HEALPix order must be non-negative")
    nside = 1 << order
    out = np.empty((12 * nside * nside, 2), dtype=np.float64)
    for ipix in range(out.shape[0]):
        theta, phi = pix2ang_nest(nside, ipix)
        rot = math.degrees(phi)
        if rot > 180.0:
            rot -= 360.0
        out[ipix] = (rot, math.degrees(theta))
    return out


def nested_children(ipix: int, oversampling_order: int) -> np.ndarray:
    """Return NEST children in RELION's ``iy``-outer, ``ix``-inner order.

    For one oversampling level the Morton child codes happen to be contiguous.
    At order two and above, however, numerical NEST index order differs from
    RELION's face-coordinate traversal and is observable in fine-hypothesis tie
    ordering.
    """

    if oversampling_order < 0:
        raise ValueError("oversampling_order must be non-negative")
    n = 1 << int(oversampling_order)
    parent = int(ipix) << (2 * int(oversampling_order))
    codes = [
        _spread_bits(ix) | (_spread_bits(iy) << 1)
        for iy in range(n)
        for ix in range(n)
    ]
    return parent + np.asarray(codes, dtype=np.int64)


def psi_grid(requested_step_deg: float, perturbation: float = 0.0) -> tuple[np.ndarray, float]:
    if requested_step_deg <= 0.0:
        raise ValueError("psi step must be positive")
    n = max(1, int(math.ceil(360.0 / requested_step_deg)))
    step = 360.0 / n
    values = (np.arange(n, dtype=np.float64) + float(perturbation)) * step
    values = ((values + 180.0) % 360.0) - 180.0
    return values, step


def translation_grid(range_angstrom: float, step_angstrom: float) -> np.ndarray:
    """RELION circular x/y translation grid, in Angstrom."""
    if range_angstrom < 0.0:
        raise ValueError("translation range must be non-negative")
    if step_angstrom <= 0.0:
        raise ValueError("translation step must be positive")
    imax = int(math.ceil(range_angstrom / step_angstrom))
    rows: list[tuple[float, float]] = []
    limit = range_angstrom * range_angstrom + 0.001
    # RELION setTranslations() traverses x first and y second.  Preserve the
    # order because equal likelihoods are resolved by flattened table position.
    for ix in range(-imax, imax + 1):
        x = ix * step_angstrom
        for iy in range(-imax, imax + 1):
            y = iy * step_angstrom
            if x * x + y * y < limit:
                rows.append((x, y))
    if not rows:
        rows.append((0.0, 0.0))
    return np.asarray(rows, dtype=np.float64)


def oversampled_psi(psi_deg: float, coarse_step_deg: float, order: int) -> np.ndarray:
    n = 1 << order
    substep = coarse_step_deg / n
    offsets = (np.arange(n, dtype=np.float64) + 0.5 - 0.5 * n) * substep
    values = psi_deg + offsets
    return ((values + 180.0) % 360.0) - 180.0


def oversampled_translation(
    xy_angstrom: Sequence[float], coarse_step_angstrom: float, order: int
) -> np.ndarray:
    n = 1 << order
    substep = coarse_step_angstrom / n
    offsets = (np.arange(n, dtype=np.float64) + 0.5 - 0.5 * n) * substep
    x0, y0 = float(xy_angstrom[0]), float(xy_angstrom[1])
    # RELION's getTranslationsInPixel() traverses x first, then y.  The
    # order is observable in adaptive-oversampling tie handling and in the
    # flattened fine-hypothesis index, so keep the same x-major convention.
    return np.asarray(
        [(x0 + dx, y0 + dy) for dx in offsets for dy in offsets],
        dtype=np.float64,
    )


@dataclass(frozen=True)
class FineSamplingTable:
    """Vectorised adaptive-oversampling children for every coarse grid point.

    ``orientation_angles`` and ``direction_indices`` are indexed as
    ``[coarse_orientation, orientation_child]``. ``translations`` is indexed as
    ``[coarse_translation, translation_child]``. Child traversal order matches
    RELION: oversampled direction, oversampled psi, oversampled x, oversampled y.
    """

    orientation_angles: np.ndarray
    direction_indices: np.ndarray
    orientation_ids: np.ndarray
    translations: np.ndarray
    orientation_children: int
    translation_children: int



@dataclass(frozen=True)
class SamplingPoint:
    class_index: int
    direction_index: int
    psi_index: int
    translation_index: int
    rot: float
    tilt: float
    psi: float
    x: float
    y: float
    parent_index: int = -1


@dataclass
class RelionSampling:
    reference_dim: int
    healpix_order: int = 2
    psi_step: float | None = None
    offset_range: float = 5.0
    offset_step: float = 1.0
    adaptive_oversampling: int = 0
    perturbation_factor: float = 0.5
    random_perturbation: float = 0.0
    symmetry: str = "C1"
    _directions: np.ndarray = field(init=False, repr=False)
    _psi: np.ndarray = field(init=False, repr=False)
    _translations: np.ndarray = field(init=False, repr=False)
    actual_psi_step: float = field(init=False)

    def __post_init__(self) -> None:
        if self.reference_dim not in (2, 3):
            raise ValueError("reference_dim must be 2 or 3")
        if self.reference_dim == 3:
            from relion_torch.geometry.symmetry import normalize_symmetry, asymmetric_grid
            self.symmetry = normalize_symmetry(self.symmetry)
            self._directions, self._coarse_direction_ids = asymmetric_grid(self.healpix_order,self.symmetry)
            default_psi = 360.0 / (6.0 * (1 << self.healpix_order))
        else:
            self._directions = np.asarray([[0.0, 0.0]], dtype=np.float64)
            default_psi = 10.0
        self._psi, self.actual_psi_step = psi_grid(
            float(default_psi if self.psi_step is None else self.psi_step),
            self.random_perturbation * self.perturbation_factor,
        )
        self._translations = translation_grid(self.offset_range, self.offset_step)

    @property
    def directions(self) -> np.ndarray:
        return self._directions.copy()

    @property
    def psi_angles(self) -> np.ndarray:
        return self._psi.copy()

    @property
    def translations(self) -> np.ndarray:
        return self._translations.copy()

    @property
    def number_of_orientations(self) -> int:
        return int(len(self._directions) * len(self._psi))

    @property
    def number_of_translations(self) -> int:
        return int(len(self._translations))

    def coarse_points(
        self,
        number_of_classes: int,
        *,
        fixed_angles: np.ndarray | None = None,
        fixed_translation: Sequence[float] | None = None,
        skip_rotate: bool = False,
        skip_align: bool = False,
    ) -> Iterator[SamplingPoint]:
        if number_of_classes < 1:
            return
        if fixed_angles is not None:
            rot0, tilt0, psi0 = map(float, fixed_angles)
        else:
            rot0 = tilt0 = psi0 = 0.0

        # RELION's HealpixSampling::addOneOrientation() always stores a pure
        # in-plane orientation for a 2-D reference: input rot/tilt metadata are
        # deliberately discarded internally and only psi is retained.  The
        # original rot/tilt columns remain untouched in the output STAR.
        if self.reference_dim == 2:
            rot0 = 0.0
            tilt0 = 0.0

        if fixed_translation is not None:
            fixed_xy = np.asarray(fixed_translation, dtype=np.float64)
        else:
            fixed_xy = np.zeros(2, dtype=np.float64)

        if skip_align:
            dirs = [(0, rot0, tilt0)]
            psis = [(0, psi0)]
            trans = [(0, fixed_xy[0], fixed_xy[1])]
        else:
            if skip_rotate:
                dirs = [(0, rot0, tilt0)]
                psis = [(0, psi0)]
            elif self.reference_dim == 2:
                dirs = [(0, 0.0, 0.0)]
                psis = [(i, float(v)) for i, v in enumerate(self._psi)]
            else:
                dirs = [(i, float(v[0]), float(v[1])) for i, v in enumerate(self._directions)]
                psis = [(i, float(v)) for i, v in enumerate(self._psi)]
            trans = [(i, float(v[0]), float(v[1])) for i, v in enumerate(self._translations)]
        parent = 0
        for c in range(number_of_classes):
            for idir, rot, tilt in dirs:
                for ipsi, psi in psis:
                    for itrans, x, y in trans:
                        yield SamplingPoint(c, idir, ipsi, itrans, rot, tilt, psi, x, y, parent)
                        parent += 1


    def fine_sampling_table(self, order: int | None = None) -> FineSamplingTable:
        """Return all adaptive children without constructing ``SamplingPoint`` objects.

        The table is deliberately independent of class and particle.  It is
        therefore built once per optimiser iteration and gathered by the sparse
        significant-parent indices on the GPU.
        """

        over = self.adaptive_oversampling if order is None else int(order)
        if over <= 0:
            angles = np.empty((self.number_of_orientations, 1, 3), dtype=np.float64)
            directions = np.empty((self.number_of_orientations, 1), dtype=np.int64)
            cursor = 0
            for idir, (rot, tilt) in enumerate(self._directions):
                for psi in self._psi:
                    angles[cursor, 0] = (float(rot), float(tilt), float(psi))
                    directions[cursor, 0] = idir
                    cursor += 1
            orientation_ids = np.arange(
                self.number_of_orientations, dtype=np.int64
            ).reshape(self.number_of_orientations, 1)
            translations = self._translations[:, None, :].copy()
            return FineSamplingTable(
                angles, directions, orientation_ids, translations, 1, 1
            )

        npsi_child = 1 << over
        if self.reference_dim == 3:
            ndir_child = 1 << (2 * over)
        else:
            ndir_child = 1
        norient_child = ndir_child * npsi_child
        ntrans_child = 1 << (2 * over)
        angles = np.empty(
            (self.number_of_orientations, norient_child, 3), dtype=np.float64
        )
        directions = np.empty(
            (self.number_of_orientations, norient_child), dtype=np.int64
        )
        orientation_ids = np.empty_like(directions)

        cursor = 0
        fine_nside = 1 << (self.healpix_order + over)
        for coarse_direction, (coarse_rot, coarse_tilt) in enumerate(self._directions):
            if self.reference_dim == 3:
                child_direction_rows: list[tuple[int, float, float]] = []
                for child in nested_children(int(self._coarse_direction_ids[coarse_direction]) if hasattr(self, "_coarse_direction_ids") else coarse_direction, over):
                    theta, phi = pix2ang_nest(fine_nside, int(child))
                    rot = math.degrees(phi)
                    if rot > 180.0:
                        rot -= 360.0
                    child_direction_rows.append(
                        (int(child), float(rot), float(math.degrees(theta)))
                    )
            else:
                child_direction_rows = [(0, float(coarse_rot), float(coarse_tilt))]

            fine_psi_count = len(self._psi) * npsi_child
            for coarse_psi_index, coarse_psi in enumerate(self._psi):
                child_psis = oversampled_psi(
                    float(coarse_psi), self.actual_psi_step, over
                )
                child_cursor = 0
                for child_direction, rot, tilt in child_direction_rows:
                    for psi_child_index, psi in enumerate(child_psis):
                        angles[cursor, child_cursor] = (rot, tilt, float(psi))
                        directions[cursor, child_cursor] = child_direction if over else coarse_direction
                        fine_psi_index = (
                            coarse_psi_index * npsi_child + psi_child_index
                        )
                        orientation_ids[cursor, child_cursor] = (
                            child_direction * fine_psi_count + fine_psi_index if over else cursor
                        )
                        child_cursor += 1
                cursor += 1

        translations = np.stack(
            [
                oversampled_translation(xy, self.offset_step, over)
                for xy in self._translations
            ],
            axis=0,
        )
        if translations.shape[1] != ntrans_child:
            raise RuntimeError("unexpected adaptive translation child count")
        return FineSamplingTable(
            orientation_angles=angles,
            direction_indices=directions,
            orientation_ids=orientation_ids,
            translations=translations,
            orientation_children=norient_child,
            translation_children=ntrans_child,
        )

    def fine_children(self, point: SamplingPoint, order: int | None = None) -> list[SamplingPoint]:
        over = self.adaptive_oversampling if order is None else int(order)
        if over <= 0:
            return [point]
        if self.reference_dim == 3:
            nside = 1 << (self.healpix_order + over)
            child_dirs = []
            for child in nested_children(int(self._coarse_direction_ids[point.direction_index]) if hasattr(self, "_coarse_direction_ids") else point.direction_index, over):
                theta, phi = pix2ang_nest(nside, int(child))
                rot = math.degrees(phi)
                if rot > 180.0:
                    rot -= 360.0
                child_dirs.append((int(child), rot, math.degrees(theta)))
        else:
            child_dirs = [(0, point.rot, point.tilt)]
        psis = oversampled_psi(point.psi, self.actual_psi_step, over)
        trans = oversampled_translation((point.x, point.y), self.offset_step, over)
        out: list[SamplingPoint] = []
        for idir, rot, tilt in child_dirs:
            for jpsi, psi in enumerate(psis):
                for jtrans, xy in enumerate(trans):
                    out.append(SamplingPoint(
                        point.class_index, idir, jpsi, jtrans,
                        float(rot), float(tilt), float(psi),
                        float(xy[0]), float(xy[1]), point.parent_index,
                    ))
        return out

    def to_star_blocks(self) -> dict[str, object]:
        try:
            import pandas as pd
        except ImportError as exc:  # starfile depends on pandas, but report clearly.
            raise RuntimeError("pandas is required by starfile") from exc
        general = pd.DataFrame({
            "rlnSymmetryGroup": [self.symmetry],
            "rlnHealpixOrder": [self.healpix_order],
            "rlnPsiStep": [self.actual_psi_step],
            "rlnOffsetRange": [self.offset_range],
            "rlnOffsetStep": [self.offset_step],
            "rlnRandomPerturbation": [self.random_perturbation],
        })
        dirs = pd.DataFrame({
            "rlnAngleRot": self._directions[:, 0],
            "rlnAngleTilt": self._directions[:, 1],
        })
        psi = pd.DataFrame({"rlnAnglePsi": self._psi})
        translations = pd.DataFrame({
            "rlnOriginXAngst": self._translations[:, 0],
            "rlnOriginYAngst": self._translations[:, 1],
        })
        return {
            "sampling_general": general,
            "sampling_directions": dirs,
            "sampling_psi": psi,
            "sampling_translations": translations,
        }

    def write_star(self, path: str | Path) -> None:
        from relion_torch.io.star import write_star

        write_star(self.to_star_blocks(), path, overwrite=True)
