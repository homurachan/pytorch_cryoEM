"""Small dependency-free HEALPix RING utilities.

The user-supplied cisTEM simulation project uses a validated pure-Python
HEALPix implementation instead of ``healpy``. This module follows the same
requirement and implements the standard RING pixel-centre equations with NumPy.
It is included for the next pose-search phase; Phase 1/2/3/5 does not invoke it.
"""

from __future__ import annotations

import numpy as np


def nside_from_order(order: int) -> int:
    if order < 0:
        raise ValueError("HEALPix order must be non-negative")
    return 1 << int(order)


def npix_from_nside(nside: int) -> int:
    if nside <= 0 or (nside & (nside - 1)) != 0:
        raise ValueError("nside must be a positive power of two")
    return 12 * nside * nside


def pix2ang_ring(nside: int, ipix: np.ndarray | int) -> tuple[np.ndarray, np.ndarray]:
    """Convert zero-based RING pixel indices to ``(theta, phi)`` in radians."""

    npix = npix_from_nside(nside)
    ip = np.asarray(ipix, dtype=np.int64)
    if np.any(ip < 0) or np.any(ip >= npix):
        raise ValueError(f"Pixel index must be in [0, {npix})")

    ip1 = ip + 1  # HEALPix formulae are one-based.
    ncap = 2 * nside * (nside - 1)
    nl2 = 2 * nside
    nl4 = 4 * nside
    fact1 = 1.5 * nside
    fact2 = 3.0 * nside * nside

    theta = np.empty(ip.shape, dtype=np.float64)
    phi = np.empty(ip.shape, dtype=np.float64)

    north = ip1 <= ncap
    equatorial = (ip1 > ncap) & (ip1 <= npix - ncap)
    south = ip1 > npix - ncap

    if np.any(north):
        hip = ip1[north] / 2.0
        fihip = np.floor(hip)
        iring = np.floor(np.sqrt(hip - np.sqrt(fihip))).astype(np.int64) + 1
        iphi = ip1[north] - 2 * iring * (iring - 1)
        z = 1.0 - (iring.astype(np.float64) ** 2) / fact2
        theta[north] = np.arccos(np.clip(z, -1.0, 1.0))
        phi[north] = (iphi - 0.5) * np.pi / (2.0 * iring)

    if np.any(equatorial):
        ip_eq = ip1[equatorial] - ncap - 1
        iring = ip_eq // nl4 + nside
        iphi = ip_eq % nl4 + 1
        fodd = 0.5 * (1 + ((iring + nside) & 1))
        z = (nl2 - iring).astype(np.float64) / fact1
        theta[equatorial] = np.arccos(np.clip(z, -1.0, 1.0))
        phi[equatorial] = (iphi - fodd) * np.pi / (2.0 * nside)

    if np.any(south):
        ip_s = npix - ip1[south] + 1
        hip = ip_s / 2.0
        fihip = np.floor(hip)
        iring = np.floor(np.sqrt(hip - np.sqrt(fihip))).astype(np.int64) + 1
        iphi = 4 * iring + 1 - (ip_s - 2 * iring * (iring - 1))
        z = -1.0 + (iring.astype(np.float64) ** 2) / fact2
        theta[south] = np.arccos(np.clip(z, -1.0, 1.0))
        phi[south] = (iphi - 0.5) * np.pi / (2.0 * iring)

    phi %= 2.0 * np.pi
    return theta, phi


def healpix_ring_directions(order: int, *, degrees: bool = True) -> tuple[np.ndarray, np.ndarray]:
    """Return all HEALPix RING directions as RELION-like ``(rot, tilt)`` arrays."""

    nside = nside_from_order(order)
    theta, phi = pix2ang_ring(nside, np.arange(npix_from_nside(nside), dtype=np.int64))
    if degrees:
        return np.rad2deg(phi), np.rad2deg(theta)
    return phi, theta
