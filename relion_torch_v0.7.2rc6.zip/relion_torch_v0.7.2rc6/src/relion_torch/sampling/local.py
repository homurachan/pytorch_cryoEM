"""Point-group SPA local angular support, independent of classification/refinement policy.

RELION 3.1.4 healpix_sampling.cpp selectOrientationsWithNonZeroPriorProbability.
Select on the UNPERTURBED coarse grid; children inherit their parent's prior.
This module does not choose auto-refine thresholds or update angular sigmas.
"""
from dataclasses import dataclass
import math
import numpy as np


def resolve_angular_sigmas(sigma_ang=-1., sigma_rot=-1., sigma_tilt=-1., sigma_psi=-1.):
    """RELION new-run precedence: a positive common sigma sets all three axes."""
    values = tuple(float(x) for x in (sigma_ang, sigma_rot, sigma_tilt, sigma_psi))
    if not all(math.isfinite(x) for x in values):
        raise ValueError('Angular standard deviations must be finite')
    return (values[0],) * 3 if values[0] > 0 else tuple(max(0., x) for x in values[1:])


def resolve_prior_centres(current, prior):
    """Resolve each angle independently; absent/nonfinite/999 priors use current."""
    current = np.asarray(current, dtype=np.float64)
    prior = np.asarray(prior, dtype=np.float64)
    if current.shape != prior.shape or current.ndim != 2 or current.shape[1] != 3:
        raise ValueError('Current angles and angular priors must have shape [particles,3]')
    missing = ~np.isfinite(prior) | ((prior > 998.99) & (prior < 999.01))
    result = np.where(missing, current, prior)
    if not np.isfinite(result).all():
        raise ValueError('Local angular search needs finite current angles where priors are missing')
    return result


def wrapped_difference(a, b):
    return (np.asarray(a) - np.asarray(b) + 180.) % 360. - 180.


def _selected(distance, sigma, cutoff):
    if sigma <= 0:
        ids = np.arange(distance.size, dtype=np.int64)
        return ids, np.full(distance.size, 1. / distance.size)
    ids = np.flatnonzero(distance < cutoff * sigma)
    if not len(ids):
        return np.array([int(np.argmin(distance))], dtype=np.int64), np.ones(1)
    prob = np.exp(-.5 * (distance[ids] / sigma) ** 2)
    return ids, prob / prob.sum()


@dataclass(frozen=True)
class LocalAngularSupport:
    """Rows retain native direction-major/psi-minor GLOBAL orientation indices."""
    orientation_indices: tuple
    probabilities: tuple

    @property
    def counts(self):
        return np.asarray([len(x) for x in self.orientation_indices], dtype=np.int64)

    def padded(self):
        counts = self.counts
        ids = np.full((len(counts), int(counts.max())), -1, dtype=np.int64)
        log_prior = np.full(ids.shape, -np.inf, dtype=np.float64)
        for row, (index, probability) in enumerate(zip(self.orientation_indices, self.probabilities)):
            ids[row, :len(index)] = index
            # Native convertAllSquaredDifferencesToWeights divides by the mean
            # on the LOCAL grid. Class factors are absent in this prior mode.
            log_prior[row, :len(index)] = np.log(probability * len(index))
        return ids, log_prior


def select_local_angular_support(directions, psi_angles, centres, sigmas, *, sigma_cutoff=3., symmetry='C1', direction_index=None, counters=None):
    """Truncated Gaussian support with stable nearest-point fallback and native symmetry mates.

    Both rot/tilt positive: spherical cap using max(sigma_rot,sigma_tilt), as
    native 3.1.4. Rot-only: distance to the prior meridian plane; tilt-only:
    latitude difference. Nonpositive sigma leaves that coordinate unrestricted.
    """
    directions = np.asarray(directions, dtype=np.float64)
    psi = np.asarray(psi_angles, dtype=np.float64)
    centres = np.asarray(centres, dtype=np.float64).reshape(-1, 3)
    sr, st, sp = (float(x) for x in sigmas)
    if not all(math.isfinite(x) for x in (sr, st, sp, sigma_cutoff)) or sigma_cutoff <= 0:
        raise ValueError('Finite sigmas and a positive cutoff are required')
    if not len(directions) or not len(psi) or not len(centres) or not np.isfinite(centres).all():
        raise ValueError('Nonempty sampling and finite angular centres are required')
    indexed = direction_index is not None and symmetry.upper() == 'C1' and sr > 0 and st > 0
    if indexed:
        if not direction_index.matches(directions):
            raise ValueError('Direction index does not match the sampling grid')
        xyz = direction_index.xyz
    else:
        rot, tilt = np.deg2rad(directions).T
        xyz = np.stack((np.sin(tilt)*np.cos(rot), np.sin(tilt)*np.sin(rot), np.cos(tilt)), axis=1)
    indices, probabilities = [], []
    for cr, ct, cp in centres:
        if sr > 0 and st > 0:
            r, t = np.deg2rad([cr, ct])
            centre = np.array([np.sin(t)*np.cos(r), np.sin(t)*np.sin(r), np.cos(t)])
            if indexed:
                di, dp = direction_index.select(centre, max(sr, st), sigma_cutoff, counters)
                pi, pp = _selected(np.abs(wrapped_difference(psi, cp)), sp, sigma_cutoff)
                indices.append((di[:, None]*len(psi)+pi[None]).reshape(-1))
                probabilities.append((dp[:, None]*pp[None]).reshape(-1))
                continue
            distance = np.rad2deg(np.arccos(np.clip(xyz @ centre, -1., 1.)))
            sigma = max(sr, st)
        elif sr > 0:
            distance = np.abs(np.rad2deg(np.arcsin(np.clip(np.sin(tilt)*np.sin(rot-np.deg2rad(cr)), -1., 1.))))
            sigma = sr
        elif st > 0:
            distance = np.abs(wrapped_difference(directions[:, 1], ct))
            sigma = st
        else:
            distance = np.zeros(len(directions)); sigma = 0.
        if symmetry.upper() != "C1" and (sr > 0 or st > 0):
            from relion_torch.geometry.symmetry import operators
            for op in operators(symmetry)[1:]:
                mate=xyz@op
                if sr>0 and st>0:
                    candidate=np.rad2deg(np.arccos(np.clip(mate@centre,-1.,1.)))
                elif sr>0:
                    meridian=np.array([-np.sin(np.deg2rad(cr)),np.cos(np.deg2rad(cr)),0.])
                    candidate=np.abs(np.rad2deg(np.arcsin(np.clip(mate@meridian,-1.,1.))))
                else:
                    candidate=np.abs(wrapped_difference(np.rad2deg(np.arccos(np.clip(mate[:,2],-1.,1.))),ct))
                distance=np.minimum(distance,candidate)
        di, dp = _selected(distance, sigma, sigma_cutoff)
        pi, pp = _selected(np.abs(wrapped_difference(psi, cp)), sp, sigma_cutoff)
        indices.append((di[:, None]*len(psi)+pi[None]).reshape(-1))
        probabilities.append((dp[:, None]*pp[None]).reshape(-1))
    return LocalAngularSupport(tuple(indices), tuple(probabilities))
