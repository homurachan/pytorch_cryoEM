from __future__ import annotations

from dataclasses import dataclass
import math

import torch

from relion_torch.geometry.grids import (
    rfft_frequency_coordinates_2d,
    rfft_multiplicity,
)


def relion_round_positive(value: float | torch.Tensor) -> int | torch.Tensor:
    """RELION/Xmipp ROUND for non-negative Fourier radii.

    ``torch.round`` uses ties-to-even, whereas RELION uses ``floor(x + 0.5)``
    for the non-negative radii used by Mresol and updateSSNRarrays.
    """

    if isinstance(value, torch.Tensor):
        return torch.floor(value + 0.5).to(torch.int64)
    return int(math.floor(float(value) + 0.5))


@dataclass(frozen=True, slots=True)
class Mresol2D:
    """RELION-style shell lookup and masks for one RFFT particle image."""

    shells: torch.Tensor
    unique_mask: torch.Tensor
    full_disk_mask: torch.Tensor
    valid_mask: torch.Tensor
    likelihood_mask: torch.Tensor
    npix_per_shell: torch.Tensor
    max_shell: int
    current_size: int


def relion_mresol_2d(
    box_size: int,
    current_size: int,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> Mresol2D:
    """Build the 2-D Mresol table used by RELION's expectation step.

    The shell index is ``ROUND(sqrt(x**2+y**2))``.  The redundant Friedel
    coefficients on ``x == 0, y < 0`` are excluded.  DC remains in
    ``valid_mask`` for noise statistics but is excluded from
    ``likelihood_mask`` because RELION sets Minvsigma2 to zero for shell 0.
    """

    n = int(box_size)
    if n < 2:
        raise ValueError("box_size must be >= 2")
    current = max(2, min(int(current_size), n))
    if current % 2:
        current -= 1
    current = max(2, current)

    coords = rfft_frequency_coordinates_2d(n, device=device, dtype=dtype)
    radius = torch.linalg.vector_norm(coords, dim=-1)
    shells = relion_round_positive(radius)
    assert isinstance(shells, torch.Tensor)

    unique = ~((coords[..., 0] == 0) & (coords[..., 1] < 0))
    full_disk = unique & (shells <= n // 2)
    max_shell = current // 2
    valid = full_disk & (shells <= max_shell)
    likelihood = valid & (shells > 0)

    shell_values = shells[full_disk].reshape(-1)
    counts = torch.bincount(shell_values, minlength=n // 2 + 1)
    counts = counts[: n // 2 + 1]
    return Mresol2D(
        shells=shells,
        unique_mask=unique,
        full_disk_mask=full_disk,
        valid_mask=valid,
        likelihood_mask=likelihood,
        npix_per_shell=counts,
        max_shell=max_shell,
        current_size=current,
    )


def radial_sum_unique_2d(
    values: torch.Tensor,
    mresol: Mresol2D,
    *,
    mask: torch.Tensor | None = None,
    max_shell: int | None = None,
    accumulate_dtype: torch.dtype = torch.float64,
) -> torch.Tensor:
    """Sum one or more RFFT images over RELION's unique rounded shells."""

    if values.shape[-2:] != mresol.shells.shape:
        raise ValueError(
            f"Expected trailing Fourier shape {tuple(mresol.shells.shape)}, got {tuple(values.shape)}"
        )
    if max_shell is None:
        max_shell = int(mresol.npix_per_shell.numel() - 1)
    use = mresol.full_disk_mask if mask is None else (mresol.full_disk_mask & mask)
    use = use & (mresol.shells <= int(max_shell))
    indices = mresol.shells[use].reshape(-1)
    flat = values[..., use]
    lead_shape = flat.shape[:-1]
    flat2 = flat.reshape(-1, flat.shape[-1]).to(accumulate_dtype)
    out = torch.zeros(
        (flat2.shape[0], int(max_shell) + 1),
        device=values.device,
        dtype=accumulate_dtype,
    )
    index = indices.unsqueeze(0).expand(flat2.shape[0], -1)
    out.scatter_add_(1, index, flat2)
    return out.reshape(*lead_shape, int(max_shell) + 1)


def radial_average_rfft_power_2d(
    power: torch.Tensor,
    box_size: int,
    *,
    accumulate_dtype: torch.dtype = torch.float64,
) -> torch.Tensor:
    """Average RFFT power over the corresponding full Fourier shells.

    This is used for RELION's initial image power spectra.  Interior RFFT x
    columns receive multiplicity two, matching a full complex Fourier plane.
    """

    n = int(box_size)
    if power.shape[-2:] != (n, n // 2 + 1):
        raise ValueError("power has an incompatible RFFT shape")
    coords = rfft_frequency_coordinates_2d(n, device=power.device, dtype=power.dtype)
    shells = relion_round_positive(torch.linalg.vector_norm(coords, dim=-1))
    assert isinstance(shells, torch.Tensor)
    valid = shells <= n // 2
    mult = rfft_multiplicity(n, 2, device=power.device, dtype=power.dtype)
    idx = shells[valid].reshape(-1)
    weights = mult[valid].reshape(-1).to(accumulate_dtype)
    flat = power[..., valid].reshape(-1, idx.numel()).to(accumulate_dtype)
    sums = torch.zeros(
        (flat.shape[0], n // 2 + 1), device=power.device, dtype=accumulate_dtype
    )
    counts = torch.zeros_like(sums)
    expanded_idx = idx.unsqueeze(0).expand(flat.shape[0], -1)
    sums.scatter_add_(1, expanded_idx, flat * weights.unsqueeze(0))
    counts.scatter_add_(1, expanded_idx, weights.unsqueeze(0).expand_as(flat))
    average = sums / counts.clamp_min(1.0)
    return average.reshape(*power.shape[:-2], n // 2 + 1)



def repair_negative_spectrum_relion(
    spectrum: torch.Tensor,
    *,
    minimum: float = 1.0e-20,
) -> torch.Tensor:
    """Repair negative initial-noise shells like RELION 3.1.

    During initial sigma-noise estimation RELION changes only values ``< 0``.
    It first copies the immediately preceding positive shell; when that is not
    available it scans forward for the first positive shell.  Exact zeros are
    intentionally left unchanged.
    """

    if spectrum.ndim not in (1, 2):
        raise ValueError("spectrum must be one- or two-dimensional")
    if spectrum.numel() == 0:
        return spectrum.clone()
    n = spectrum.shape[-1]
    values = spectrum.reshape(-1, n)
    indices = torch.arange(n, device=values.device).expand_as(values)
    valid = torch.isfinite(values) & (values >= 0)
    positive = torch.isfinite(values) & (values > 0)
    # A zero is a barrier to propagation from the left. For an invalid run
    # after a zero (or at the beginning), use the next original positive shell.
    previous = torch.where(valid, indices, -1).cummax(-1).values
    following = torch.where(positive, indices, n).flip([-1]).cummin(-1).values.flip([-1])
    left = values.gather(-1, previous.clamp_min(0))
    right = values.gather(-1, following.clamp_max(n-1))
    fallback = torch.where(following < n, right, torch.full_like(values, minimum))
    repaired = torch.where((previous >= 0) & (left > 0), left, fallback)
    return torch.where(valid, values, repaired).reshape(spectrum.shape)


def repair_nonpositive_spectrum(
    spectrum: torch.Tensor,
    *,
    minimum: float = 1.0e-20,
) -> torch.Tensor:
    """Replace non-positive/non-finite spectrum entries as RELION does.

    RELION propagates the nearest preceding positive value; when the first
    entry is invalid it searches forward for the first valid value.
    """

    original_shape = spectrum.shape
    if spectrum.ndim == 1:
        work = spectrum.unsqueeze(0).clone()
    elif spectrum.ndim == 2:
        work = spectrum.clone()
    else:
        raise ValueError("spectrum must be one- or two-dimensional")
    for row in range(work.shape[0]):
        values = work[row]
        valid = torch.isfinite(values) & (values > 0)
        if not bool(torch.any(valid)):
            values.fill_(float(minimum))
            continue
        first = int(torch.nonzero(valid, as_tuple=False)[0, 0].item())
        values[:first] = values[first]
        last = values[first]
        for index in range(first + 1, values.numel()):
            if bool(torch.isfinite(values[index]) & (values[index] > 0)):
                last = values[index]
            else:
                values[index] = last
        values.clamp_min_(float(minimum))
    return work[0] if len(original_shape) == 1 else work


def resolution_shell_from_data_vs_prior(
    data_vs_prior: torch.Tensor,
    *,
    min_shell: int = 0,
    include_nyquist: bool = False,
) -> int:
    """Return RELION's safe resolution shell from class data-vs-prior curves.

    RELION scans each class until ``data_vs_prior < 1``, subtracts one shell,
    takes the highest shell across classes, and finally enforces ``minres_map``.

    Two closely related RELION code paths differ at Nyquist.  The optimiser's
    *working current-resolution* scan stops at ``ori_size/2 - 1``; model-class
    ``rlnEstimatedResolution``/coverage accounting scans the full spectrum and
    may therefore report the Nyquist shell.  This helper retains the non-DC
    working scan even with ``include_nyquist=True``. For exact per-class
    reporting (which starts at DC), use class_resolution_shell_from_data_vs_prior.
    """

    if data_vs_prior.ndim == 1:
        curves = data_vs_prior.unsqueeze(0)
    elif data_vs_prior.ndim == 2:
        curves = data_vs_prior
    else:
        raise ValueError("data_vs_prior must be [shell] or [class,shell]")
    if curves.shape[-1] < 3:
        return 0
    best = 0
    last_shell = curves.shape[-1] - 1
    scan_stop = last_shell + 1 if include_nyquist else last_shell
    for curve in curves:
        safe = last_shell if include_nyquist else max(0, last_shell - 1)
        for shell in range(1, scan_stop):
            value = float(curve[shell].item())
            if not math.isfinite(value) or value < 1.0:
                safe = max(0, shell - 1)
                break
        best = max(best, safe)
    return max(int(min_shell), int(best))


def class_resolution_shell_from_data_vs_prior(data_vs_prior: torch.Tensor) -> int:
    """RELION MlModel::calculateTotalFourierCoverage reporting scan.

    Start at DC, include Nyquist, and stop at the first value < 1.  In
    particular DVP[0] < 1 returns zero even if higher shells are strong.  Do
    not use this to schedule working Fourier sizes: those deliberately use
    resolution_shell_from_data_vs_prior with a non-DC scan and minres floor.

    As in the native C++ comparison, NaN < 1 is false. Preserved spectrum
    state is not silently rewritten during reporting.
    """
    if data_vs_prior.ndim != 1:
        raise ValueError("class reporting expects one one-dimensional DVP curve")
    safe = 0
    for shell, value in enumerate(data_vs_prior.detach().to(device="cpu", dtype=torch.float64).tolist()):
        if value < 1.0:
            break
        safe = shell
    return safe


def current_size_from_resolution_shell(
    box_size: int,
    resolution_shell: int,
    *,
    increment: int = 10,
) -> int:
    """RELION classification current-size schedule: 2*(ires+increment)."""

    n = int(box_size)
    shell = max(0, int(resolution_shell))
    current = min(n, 2 * (shell + max(0, int(increment))))
    current = max(2, current)
    if current % 2:
        current -= 1
    return max(2, current)


def current_size_from_max_resolution(
    box_size: int,
    pixel_size_angstrom: float,
    max_resolution_angstrom: float,
) -> int:
    """Convert a user max-resolution cutoff to an even Mresol image size."""

    n = int(box_size)
    if max_resolution_angstrom <= 0:
        return n
    radius = n * float(pixel_size_angstrom) / float(max_resolution_angstrom)
    max_shell = max(1, min(n // 2, int(relion_round_positive(radius))))
    return min(n, 2 * max_shell)


@dataclass(frozen=True, slots=True)
class ResolutionSchedule:
    """Separate RELION's PSNR, working-size, and strict-cutoff states."""

    psnr_shell: int
    psnr_angstrom: float
    working_current_size: int
    working_max_shell: int
    likelihood_current_size: int
    likelihood_max_shell: int
    strict_highres_angstrom: float | None


def resolution_schedule(
    data_vs_prior: torch.Tensor,
    *,
    box_size: int,
    pixel_size_angstrom: float,
    increment: int = 10,
    min_shell: int = 5,
    strict_highres_angstrom: float | None = None,
    use_all_data: bool = False,
) -> ResolutionSchedule:
    """Build the sizes used by a RELION classification iteration.

    The PSNR-derived shell controls the reported current resolution. The
    working image size is that shell plus ``increment``. A strict user cutoff
    caps only probability calculations; weighted sums still use the working
    image size.
    """

    n = int(box_size)
    psnr_shell = resolution_shell_from_data_vs_prior(
        data_vs_prior, min_shell=min_shell
    )
    working_size = (
        n
        if use_all_data
        else current_size_from_resolution_shell(
            n, psnr_shell, increment=increment
        )
    )
    likelihood_size = working_size
    strict_value: float | None = None
    if strict_highres_angstrom is not None and strict_highres_angstrom > 0:
        strict_value = float(strict_highres_angstrom)
        likelihood_size = min(
            working_size,
            current_size_from_max_resolution(
                n, pixel_size_angstrom, strict_value
            ),
        )
    return ResolutionSchedule(
        psnr_shell=psnr_shell,
        psnr_angstrom=shell_to_angstrom(n, pixel_size_angstrom, psnr_shell),
        working_current_size=working_size,
        working_max_shell=working_size // 2,
        likelihood_current_size=likelihood_size,
        likelihood_max_shell=likelihood_size // 2,
        strict_highres_angstrom=strict_value,
    )


def shell_to_angstrom(box_size: int, pixel_size_angstrom: float, shell: int) -> float:
    if shell <= 0:
        return float("inf")
    return float(box_size) * float(pixel_size_angstrom) / float(shell)
