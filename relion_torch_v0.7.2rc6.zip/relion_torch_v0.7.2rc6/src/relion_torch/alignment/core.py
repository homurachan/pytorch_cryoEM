"""Runtime adapters connecting alignment to the validated 0.1.6 core."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import importlib
import inspect
import math
import os
from collections import OrderedDict
from typing import Any, Iterable, Mapping, Sequence

import mrcfile
import numpy as np
import pandas as pd
import torch

from relion_torch.fourier.conventions import relion_soft_mask_outside_map
from relion_torch.geometry.offsets import dont_wrap_shift_2d, split_old_offset
from relion_torch.alignment.noise_groups import assign_noise_groups
from relion_torch.optics.aberrations import AberrationCoefficients, demodulate_records_


def _column(df: Any, name: str, default: Any = None) -> np.ndarray:
    for key in (name, '_' + name):
        if key in df.columns:
            return np.array(df[key].to_numpy(), copy=True)
    if default is None:
        raise KeyError(name)
    value = default(len(df)) if callable(default) else default
    if np.isscalar(value):
        return np.full(len(df), value)
    return np.array(value, copy=True)


def _get_block(blocks: Any, names: Sequence[str]) -> Any:
    if not isinstance(blocks, Mapping):
        return blocks
    for name in names:
        for key in (name, 'data_' + name):
            if key in blocks:
                return blocks[key]
    for key, value in blocks.items():
        lk = str(key).lower()
        if any(name in lk for name in names):
            return value
    raise KeyError(f"none of blocks {names!r} found")


def read_relion_star(path: str | Path) -> tuple[Any, Any]:
    from relion_torch.io.star import read_star

    blocks = read_star(path)
    return _get_block(blocks, ('optics',)), _get_block(blocks, ('particles',))


def _resolve_stack_path(star_path: Path, image_path: str) -> Path:
    p = Path(image_path).expanduser()
    candidates = [p, star_path.parent / p, Path.cwd() / p]
    # Output STAR files are often written into a job subdirectory while keeping
    # particle paths relative to the project root.  Search the input STAR's
    # parent chain so continuation remains valid without rewriting metadata.
    candidates.extend(parent / p for parent in star_path.parents)
    if str(p).startswith('../'):
        candidates.append(star_path.parent / str(p)[3:])
    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        if resolved in seen:
            continue
        seen.add(resolved)
        if resolved.exists():
            return resolved
    raise FileNotFoundError(
        f"cannot resolve particle stack {image_path!r} relative to {star_path}"
    )


# Historical name retained for external imports; no second reader/cache.
from relion_torch.io.mrc_stack import MRCStackCache as MrcStackCache
from relion_torch.io.particle_store import ParticleIOOptions, ParticleImageStore


@dataclass
class ParticleRecord:
    row: int
    image_name: str
    stack_path: Path
    stack_index: int
    group_number: int
    class_number: int
    rot: float
    tilt: float
    psi: float
    origin_x_angstrom: float
    origin_y_angstrom: float
    origin_prior_x_angstrom: float
    origin_prior_y_angstrom: float
    rot_prior: float
    tilt_prior: float
    psi_prior: float
    defocus_u: float
    defocus_v: float
    defocus_angle: float
    phase_shift: float
    voltage_kv: float
    cs_mm: float
    amplitude_contrast: float
    pixel_size: float
    ctf_premultiplied: bool = False
    ctf_bfactor: float = 0.0
    ctf_scale: float = 1.0
    aberrations: AberrationCoefficients | None = None


class AlignmentDataset:
    def __init__(self, star_path: str | Path, *, io_options: ParticleIOOptions | None = None,
                 preserve_noise_groups: bool = False, metadata_tables=None) -> None:
        self.star_path = Path(star_path).resolve()
        self.optics, self.particles = (read_relion_star(self.star_path) if metadata_tables is None
                                      else tuple(table.copy() for table in metadata_tables))
        # Immutable logical row identity.  Internal batching/subset scheduling
        # may use arbitrary particle indices, but Class2D data STAR output can
        # always be restored to the exact input-row order without sorting by
        # rlnImageName text.  Keep this private column out of written STAR files.
        self._source_row_column = "__relion_torch_source_row"
        if self._source_row_column in self.particles.columns:
            raise ValueError(f"reserved particle column present: {self._source_row_column}")
        self.particles = assign_noise_groups(self.particles, preserve_numbers=preserve_noise_groups)
        self.particles[self._source_row_column] = np.arange(len(self.particles), dtype=np.int64)
        if len(self.optics) == 0:
            raise ValueError("the optics table is empty")
        self._optics_by_id = {}
        for _, optics_row in self.optics.iterrows():
            group_id = int(optics_row.get('rlnOpticsGroup', optics_row.get('_rlnOpticsGroup', 1)))
            if group_id in self._optics_by_id:
                raise ValueError(f"duplicate optics group {group_id}")
            self._optics_by_id[group_id] = optics_row
        opt = self.optics.iloc[0]
        def oval(name: str, default: float) -> float:
            for k in (name, '_' + name):
                if k in opt.index: return float(opt[k])
            return default
        self.pixel_size = oval('rlnImagePixelSize', 1.0)
        self.box_size = int(oval('rlnImageSize', 0))
        self.voltage = oval('rlnVoltage', 300.0)
        self.cs = oval('rlnSphericalAberration', 2.7)
        self.amplitude_contrast = oval('rlnAmplitudeContrast', 0.1)
        for group_id, row in self._optics_by_id.items():
            pixel = float(row.get('rlnImagePixelSize', row.get('_rlnImagePixelSize', self.pixel_size)))
            size = int(row.get('rlnImageSize', row.get('_rlnImageSize', self.box_size)))
            if abs(pixel-self.pixel_size) > 1.e-5 or size != self.box_size:
                raise NotImplementedError(
                    "Different pixel/box sizes across optics groups require native observation-model "
                    "resampling, which is not supported yet. Resample particles to a common grid first.")
            if int(row.get('rlnImageDimensionality',2)) != 2:
                raise ValueError("alignment expects 2-D particle images")
        self.io_options = io_options or ParticleIOOptions()
        self.io_options.validate()
        self._resolved_paths: dict[str, Path] = {}
        self.cache = MrcStackCache(self.io_options.max_open_stacks, backend=self.io_options.particle_io)
        self._records = self._make_records()
        self.images = ParticleImageStore(
            [(r.stack_path, r.stack_index) for r in self._records], box_size=self.box_size,
            options=self.io_options, cache=self.cache,
            image_names=[r.image_name for r in self._records])
        self.box_size = self.images.box_size

    def _make_records(self) -> list[ParticleRecord]:
        p = self.particles
        aberrations_by_id = {group: AberrationCoefficients.from_optics(row)
                            for group, row in self._optics_by_id.items()}
        image_names = _column(p, 'rlnImageName').astype(str)
        groups = _column(p, 'rlnGroupNumber', 1).astype(np.int64)
        optics_ids = _column(p, 'rlnOpticsGroup', next(iter(self._optics_by_id))).astype(np.int64)
        classes = _column(p, 'rlnClassNumber', 1).astype(np.int64)
        rot = _column(p, 'rlnAngleRot', 0.0).astype(float)
        tilt = _column(p, 'rlnAngleTilt', 0.0).astype(float)
        psi = _column(p, 'rlnAnglePsi', 0.0).astype(float)
        ox = _column(p, 'rlnOriginXAngst', 0.0).astype(float)
        oy = _column(p, 'rlnOriginYAngst', 0.0).astype(float)
        opx = _column(p, 'rlnOriginXPriorAngst', 0.0).astype(float)
        opy = _column(p, 'rlnOriginYPriorAngst', 0.0).astype(float)
        def angular_prior(label, fallback):
            raw=_column(p,label,fallback)
            return np.asarray([np.nan if v is None or str(v).strip() in ('.','?','') else float(v) for v in raw],dtype=float)
        rpr = angular_prior('rlnAngleRotPrior', rot)
        tpr = angular_prior('rlnAngleTiltPrior', tilt)
        ppr = angular_prior('rlnAnglePsiPrior', psi)
        du = _column(p, 'rlnDefocusU', 0.0).astype(float)
        dv = _column(p, 'rlnDefocusV', du).astype(float)
        da = _column(p, 'rlnDefocusAngle', 0.0).astype(float)
        ph = _column(p, 'rlnPhaseShift', 0.0).astype(float)
        bf = _column(p, 'rlnCtfBfactor', 0.0).astype(float)
        sc = _column(p, 'rlnCtfScalefactor', 1.0).astype(float)
        out=[]
        for i,name in enumerate(image_names):
            try:
                idx,path=name.split('@',1)
                if int(idx) < 1:
                    raise ValueError("stack indices must be positive and one-based")
            except ValueError as exc:
                raise ValueError(f"Invalid rlnImageName at STAR row {i+1}: {name!r}") from exc
            if path not in self._resolved_paths:
                self._resolved_paths[path] = _resolve_stack_path(self.star_path, path)
            if int(optics_ids[i]) not in self._optics_by_id:
                raise ValueError(f"particle {i+1} references unknown optics group {optics_ids[i]}")
            optics = self._optics_by_id[int(optics_ids[i])]
            def value(label, default):
                return float(optics.get(label, optics.get('_'+label, default)))
            out.append(ParticleRecord(
                i,name,self._resolved_paths[path],int(idx),int(groups[i]),int(classes[i]),
                float(rot[i]),float(tilt[i]),float(psi[i]),float(ox[i]),float(oy[i]),
                float(opx[i]),float(opy[i]),float(rpr[i]),float(tpr[i]),float(ppr[i]),
                float(du[i]),float(dv[i]),float(da[i]),float(ph[i]),
                value('rlnVoltage',self.voltage),value('rlnSphericalAberration',self.cs),
                value('rlnAmplitudeContrast',self.amplitude_contrast),self.pixel_size,
                bool(value('rlnCtfDataAreCtfPremultiplied',0)),float(bf[i]),float(sc[i]),
                aberrations_by_id[int(optics_ids[i])],
            ))
        return out

    def __len__(self) -> int: return len(self._records)
    def record(self, index: int) -> ParticleRecord: return self._records[index]
    def load_image(self, index: int) -> np.ndarray:
        return self.images.image(index)

    @classmethod
    def from_config(cls, config, *, preserve_noise_groups: bool = False, shared_preread: bool = False):
        options = ParticleIOOptions.from_config(config)
        options.validate(config.batch_size)
        dataset = cls(config.input_star, io_options=options, preserve_noise_groups=preserve_noise_groups)
        try:
            dataset.images.report(batch_size=config.batch_size, device=config.device)
            if options.preread_images:
                dataset.images.preread(shared=shared_preread)
        except BaseException:
            dataset.close()
            raise
        return dataset

    def iter_image_batches(self, *, device, batch_size, pool_size=None, indices=None):
        return self.images.iter_batches(device=device, batch_size=batch_size, pool_size=pool_size, indices=indices)

    def close(self):
        if hasattr(self, "images"):
            self.images.close()
        elif hasattr(self, "cache"):
            self.cache.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def particles_in_source_order(self, particles: Any | None = None):
        """Return a write-only particle table in immutable input-row order.

        The private source-row column travels with the in-memory table but is
        never written to RELION STAR output.  This is an O(N) gather when the
        mapping is already monotonic and an O(N log N) stable argsort only if a
        future execution path has actually reordered rows.
        """
        frame = self.particles if particles is None else particles
        if len(frame) != len(self.particles):
            raise ValueError("particle table length changed while restoring source order")
        key = self._source_row_column
        if key not in frame.columns:
            raise ValueError("particle table lost immutable source-row mapping")
        source = pd.to_numeric(frame[key], errors="raise").to_numpy(dtype=np.int64)
        if not np.array_equal(np.sort(source), np.arange(len(source), dtype=np.int64)):
            raise ValueError("source-row mapping is not a particle permutation")
        if np.array_equal(source, np.arange(len(source), dtype=np.int64)):
            ordered = frame
        else:
            order = np.argsort(source, kind="stable")
            ordered = frame.iloc[order]
        return ordered.drop(columns=[key]).reset_index(drop=True)

    def source_row_indices(self) -> np.ndarray:
        return pd.to_numeric(
            self.particles[self._source_row_column], errors="raise"
        ).to_numpy(dtype=np.int64, copy=True)

    def replace_particles(self, particles: Any) -> None:
        """Install updated metadata and rebuild per-particle records.

        Alignment iterations must consume the origins and angles written by the
        preceding iteration.  Replacing only the public DataFrame leaves the
        cached ``ParticleRecord`` objects stale.
        """

        if len(particles) != len(self.particles):
            raise ValueError(
                "updated particle table has a different number of rows: "
                f"{len(particles)} != {len(self.particles)}"
            )
        particles = particles.copy()
        key = self._source_row_column
        if key not in particles.columns:
            # Normal callers update a copy of self.particles, so this is a
            # compatibility fallback for older helpers rather than a reorder.
            particles[key] = self.particles[key].to_numpy(copy=True)
        old_source = pd.to_numeric(self.particles[key], errors="raise").to_numpy(dtype=np.int64)
        new_source = pd.to_numeric(particles[key], errors="raise").to_numpy(dtype=np.int64)
        if not np.array_equal(np.sort(new_source), np.sort(old_source)):
            raise ValueError("updated particle table changed immutable source-row identities")
        self.particles = particles
        self._records = self._make_records()
        new_refs = [(r.stack_path, r.stack_index) for r in self._records]
        if new_refs != self.images.refs:
            # Normal iterations only change poses/norms and keep raw RAM intact.
            # A real image reorder/replacement must invalidate the raw row cache.
            shared = self.images.shared_descriptor() is not None
            if shared and not self.images.cache_report()['shared_owner']:
                raise ValueError('A worker cannot change particle identities/order in a shared raw cache')
            self.images.close()
            self.cache = MrcStackCache(self.io_options.max_open_stacks, backend=self.io_options.particle_io)
            self.images = ParticleImageStore(new_refs, box_size=self.box_size,
                options=self.io_options, cache=self.cache,
                image_names=[r.image_name for r in self._records])
            if self.io_options.preread_images:
                self.images.preread(shared=shared)


def electron_wavelength_angstrom(voltage_kv: float) -> float:
    volts = voltage_kv * 1000.0
    return 12.2643247 / math.sqrt(volts * (1.0 + volts * 0.978466e-6))


def ctf_rfft(record: ParticleRecord, size: int, device: torch.device, dtype: torch.dtype,
             *, phase_flipped_input: bool = False, only_flip_phases: bool = False,
             intact_first_peak: bool = False) -> torch.Tensor:
    """Return the shared RELION-3.1 CTF used by fixed-pose EM.

    The first alignment implementation used an algebraically rearranged CTF
    expression with an extra leading minus sign.  Relative to
    :func:`relion_torch.optics.ctf.compute_ctf`, and therefore to RELION's
    ``CTF::getFftwImage`` convention, that function returned exactly ``-CTF``
    at every Fourier pixel.  A one-class alignment can still finish, but its
    M-step numerator is multiplied by the wrong-sign CTF and the reconstructed
    density is globally contrast-inverted.

    Reuse the already validated fixed-pose implementation instead of keeping a
    second CTF formula in the alignment path.
    """
    from relion_torch.optics.ctf import CTFParameters, CTFFrequencyGrid2D, compute_ctf
    from relion_torch.optics.aberrations import even_offset_for_records

    grid = CTFFrequencyGrid2D.create(size, record.pixel_size, device=device, dtype=dtype)

    return compute_ctf(
        int(size),
        float(record.pixel_size),
        CTFParameters(
            defocus_u=float(record.defocus_u),
            defocus_v=float(record.defocus_v),
            defocus_angle_deg=float(record.defocus_angle),
            voltage_kv=float(record.voltage_kv),
            cs_mm=float(record.cs_mm),
            amplitude_contrast=float(record.amplitude_contrast),
            phase_shift_deg=float(record.phase_shift),
            bfactor=float(record.ctf_bfactor),scale=float(record.ctf_scale),
        ),
        device=device,
        dtype=dtype,
        phase_flipped_input=phase_flipped_input,only_flip_phases=only_flip_phases,
        intact_first_peak=intact_first_peak,
        frequency_grid=grid, gamma_offset=even_offset_for_records([record], grid),
    )


def _find_fft_function(name_candidates: Sequence[str]):
    modules=('relion_torch.fourier.fft','relion_torch.fourier.fft_utils','relion_torch.fourier.conventions',
             'relion_torch.fourier.transforms','relion_torch.fourier')
    for mn in modules:
        try: mod=importlib.import_module(mn)
        except Exception: continue
        for name in name_candidates:
            fn=getattr(mod,name,None)
            if callable(fn): return fn
    return None


def centered_rfft2(image: torch.Tensor) -> torch.Tensor:
    fn=_find_fft_function(('centered_rfft2','centered_rfft','rfft2_centered'))
    if fn is not None:
        for kwargs in ({'norm':'forward'},{},):
            try:
                out=fn(image,**kwargs)
                if torch.is_tensor(out): return out
            except TypeError: continue
    h,w=image.shape[-2:]
    yy=torch.arange(h,device=image.device)[:,None]
    xx=torch.arange(w,device=image.device)[None,:]
    sign=torch.where(((yy+xx)&1)==0,1.0,-1.0).to(image.dtype)
    return torch.fft.rfft2(image*sign,norm='forward')


def soft_circular_mask(size: int, radius: float, edge: float, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
    # RELION image masks use pixel-centred coordinates around N/2.
    y=torch.arange(size,device=device,dtype=dtype)-size//2
    x=torch.arange(size,device=device,dtype=dtype)-size//2
    yy,xx=torch.meshgrid(y,x,indexing='ij')
    r=torch.sqrt(xx.square()+yy.square())
    if edge <= 0:
        return (r <= radius).to(dtype)
    inner=radius
    outer=radius+edge
    mask=torch.ones_like(r)
    mask=torch.where(r>=outer,torch.zeros_like(mask),mask)
    trans=(r>inner)&(r<outer)
    mask=torch.where(trans,0.5+0.5*torch.cos(math.pi*(r-inner)/edge),mask)
    return mask


def prepare_particle(
    image_np: np.ndarray | torch.Tensor, record: ParticleRecord, *, particle_diameter: float,
    mask_edge_pixels: float, zero_mask: bool, sigma2_by_shell: torch.Tensor,
    device: torch.device, seed: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    if isinstance(image_np, torch.Tensor):
        # Device-pool views are borrowed and raw; never modify cached pixels.
        image = image_np.detach().to(device=device, dtype=torch.float32).clone()
    else:
        image=torch.tensor(np.array(image_np,copy=True),device=device,dtype=torch.float32)
    old=torch.tensor([record.origin_x_angstrom/record.pixel_size,record.origin_y_angstrom/record.pixel_size],
                     device=device,dtype=torch.float32)
    dec=split_old_offset(old)
    # RELION shifts the observation toward the reference by the integer old offset.
    shifted=dont_wrap_shift_2d(image,dec.integer_xy)
    unmasked_ft=centered_rfft2(shifted)
    mask_radius = particle_diameter / (2.0 * record.pixel_size)
    if zero_mask:
        # RELION's --zero_mask is named historically: it calls
        # softMaskOutsideMap without an explicit noise image, which replaces
        # the solvent by its weighted average background rather than literal
        # zeros.
        likelihood_image = relion_soft_mask_outside_map(
            shifted,
            radius_pixels=mask_radius,
            cosine_width_pixels=mask_edge_pixels,
            ndim=2,
        )
    else:
        gen=torch.Generator(device=device)
        gen.manual_seed(int(seed)+record.row)
        n=image.shape[-1]
        shells=_rounded_shells_full(n,device)
        sigma_lookup=sigma2_by_shell.to(device=device)
        sig=torch.sqrt(torch.clamp(sigma_lookup[shells.clamp_max(len(sigma_lookup)-1)],min=0.0))
        sig=torch.where(shells < len(sigma_lookup),sig,torch.zeros_like(sig))
        real=torch.randn((n,n//2+1),generator=gen,device=device)*sig
        imag=torch.randn((n,n//2+1),generator=gen,device=device)*sig
        noise_ft=torch.complex(real,imag)
        noise=torch.fft.irfft2(noise_ft,s=(n,n),norm='forward')
        yy=torch.arange(n,device=device)[:,None]; xx=torch.arange(n,device=device)[None,:]
        noise=noise*torch.where(((yy+xx)&1)==0,1.0,-1.0)
        likelihood_image = relion_soft_mask_outside_map(
            shifted,
            radius_pixels=mask_radius,
            cosine_width_pixels=mask_edge_pixels,
            noise=noise,
            ndim=2,
        )
    like = centered_rfft2(likelihood_image)
    if getattr(record, 'aberrations', None) is not None and record.aberrations.odd:
        from relion_torch.optics.ctf import CTFFrequencyGrid2D
        grid = CTFFrequencyGrid2D.create(image.shape[-1], record.pixel_size,
                                        device=device, dtype=like.real.dtype)
        demodulate_records_([record], grid, like[None], unmasked_ft[None])
    return like,unmasked_ft,dec.integer_xy,dec.residual_xy


def _rounded_shells_full(size: int, device: torch.device) -> torch.Tensor:
    ky=torch.fft.fftfreq(size,device=device)*size
    kx=torch.arange(size//2+1,device=device,dtype=ky.dtype)
    yy,xx=torch.meshgrid(ky,kx,indexing='ij')
    return torch.floor(torch.sqrt(xx.square()+yy.square())+0.5).long()


def read_reference(path: str | Path, device: torch.device) -> torch.Tensor:
    if '@' in str(path) and str(path).partition('@')[0].isdecimal():
        from relion_torch.io.reference_input import read_reference_images
        return read_reference_images([path], device)[0]
    with mrcfile.open(path,permissive=True) as m:
        arr=np.array(m.data,dtype=np.float32,copy=True)
    return torch.tensor(arr,device=device)


def _supported_kwargs(callable_obj: Any, candidates: Mapping[str, Any]) -> dict[str, Any]:
    try: sig=inspect.signature(callable_obj)
    except Exception: return dict(candidates)
    if any(p.kind==inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
        return dict(candidates)
    return {k:v for k,v in candidates.items() if k in sig.parameters}


def _euler_matrix(angles: torch.Tensor) -> torch.Tensor:
    modules=('relion_torch.geometry.euler','relion_torch.geometry.relion_euler','relion_torch.geometry','relion_torch.conventions')
    names=('relion_euler_matrix','euler_matrix','angles_to_matrix','rotation_matrix')
    for mn in modules:
        try: mod=importlib.import_module(mn)
        except Exception: continue
        for name in names:
            fn=getattr(mod,name,None)
            if not callable(fn): continue
            try:
                out=fn(angles)
                if torch.is_tensor(out) and out.shape[-2:]==(3,3): return out
            except Exception: pass
            try:
                out=fn(angles[...,0],angles[...,1],angles[...,2])
                if torch.is_tensor(out) and out.shape[-2:]==(3,3): return out
            except Exception: pass
    a=torch.deg2rad(angles)
    rot,tilt,psi=a.unbind(-1)
    def rz(v):
        z=torch.zeros_like(v); o=torch.ones_like(v); c=torch.cos(v); s=torch.sin(v)
        return torch.stack((c,-s,z,s,c,z,z,z,o),-1).reshape(v.shape+(3,3))
    def ry(v):
        z=torch.zeros_like(v); o=torch.ones_like(v); c=torch.cos(v); s=torch.sin(v)
        return torch.stack((c,z,s,z,o,z,-s,z,c),-1).reshape(v.shape+(3,3))
    return rz(psi)@ry(tilt)@rz(rot)


class ReferenceProjector:
    """Adapter to the validated projector with a current-size batch API.

    Single-angle calls retain a small compatibility cache for translation-only
    refinement.  Global rotation search bypasses that cache and projects
    orientation chunks directly, avoiding GPU->CPU cache-key synchronisation and
    the old 512-entry cache thrashing pattern.
    """

    def __init__(
        self,
        reference: torch.Tensor,
        padding_factor: float = 2.0,
        backend: str = "validated",
        *,
        current_size: int | None = None,
    ) -> None:
        self.reference = reference
        self.padding_factor = float(padding_factor)
        self.backend = backend
        self.source_current_size = int(reference.shape[-1] if current_size is None else current_size)
        self._support_generation = 0
        self._obj = None
        if backend != "fallback":
            self._obj = self._construct_validated()
        self._fallback_fft = None
        self._cache: OrderedDict[tuple[int, tuple[float, ...]], torch.Tensor] = OrderedDict()
        self._cache_limit = 512

    def _construct_validated(self):
        # The installed package has one concrete production API. Import,
        # allocation and numerical failures are not backend-discovery signals.
        from relion_torch.fourier.projector import FourierProjector
        return FourierProjector.from_real(self.reference,padding_factor=self.padding_factor,
                                          current_size=self.source_current_size)

    @property
    def source_cache_token(self) -> tuple:
        return (id(self), self._support_generation, self.source_current_size,
                id(self._obj), getattr(self.reference, "_version", 0))

    def set_source_support(self, current_size: int) -> None:
        """Set iteration support, never infer it from a coarse output size.

        Rebuild from real-space data when growing as well as shrinking: a
        previously zeroed Fourier buffer cannot recover the lost frequencies.
        """
        size = int(current_size)
        n = int(self.reference.shape[-1])
        if size < 2 or size > n or size % 2:
            raise ValueError("source current_size must be even and in [2, original_size]")
        if size == self.source_current_size:
            return
        old = self.source_current_size
        self.source_current_size = size
        try:
            obj = self._construct_validated() if self.backend != "fallback" else None
        except Exception:
            self.source_current_size = old
            raise
        self._obj = obj
        self._support_generation += 1
        self._cache.clear()
        self._fallback_fft = None

    @staticmethod
    def _normalise_angles(angles_deg: torch.Tensor) -> torch.Tensor:
        angles = torch.as_tensor(angles_deg)
        if angles.ndim == 1:
            angles = angles.unsqueeze(0)
        if angles.ndim != 2 or angles.shape[-1] != 3:
            raise ValueError(f"angles must have shape [batch,3], got {tuple(angles.shape)}")
        return angles

    def _project_validated(self, angles_deg: torch.Tensor, output_size: int) -> torch.Tensor | None:
        if self._obj is None:
            if self.backend != "fallback":
                raise RuntimeError("validated projector is unavailable")
            return None
        from relion_torch.fourier.projector import FourierProjector
        if not isinstance(self._obj, FourierProjector):
            raise TypeError("unexpected projector backend; select fallback explicitly")
        out = self._obj.project(_euler_matrix(angles_deg), output_size=int(output_size))
        return out.unsqueeze(0) if out.ndim == 2 else out

    def project_batch(
        self,
        angles_deg: torch.Tensor,
        output_size: int,
        *,
        chunk_size: int = 256,
    ) -> torch.Tensor:
        """Project a batch without constructing scalar CPU cache keys."""

        angles = self._normalise_angles(angles_deg)
        chunk = max(1, int(chunk_size))
        outputs: list[torch.Tensor] = []
        for start in range(0, int(angles.shape[0]), chunk):
            part = angles[start : start + chunk]
            out = self._project_validated(part, int(output_size))
            if out is None:
                out = self._fallback(part, int(output_size))
            outputs.append(out)
        if not outputs:
            return torch.empty(
                (0, int(output_size), int(output_size) // 2 + 1),
                device=self.reference.device,
                dtype=torch.complex64
                if self.reference.dtype == torch.float32
                else torch.complex128,
            )
        return torch.cat(outputs, dim=0)

    def project_inverse_batch(self, inverses, output_size):
        """Project cached, validated Euler inverses in one bounded batch."""
        if self._obj is None:
            raise RuntimeError('precomputed inverse path requires the validated projector')
        return self._obj.project(inverses, output_size=int(output_size), rotations_are_inverse=True)

    @torch.no_grad()
    def power_spectrum(self, current_size: int) -> torch.Tensor:
        """Return the tau² spectrum of the exact projector Fourier volume.

        The validated in-tree projector exposes RELION's padded/gridding-
        corrected projector-space spectrum directly.  For reflective or
        fallback projection backends, construct the same validated Fourier
        representation solely for this statistic so alignment state remains
        independent of backend-specific projection caches.
        """

        from relion_torch.fourier.projector import FourierProjector

        self.set_source_support(int(current_size))
        if isinstance(self._obj, FourierProjector):
            return self._obj.power_spectrum(current_size=int(current_size))
        projector = FourierProjector.from_real(
            self.reference,
            padding_factor=self.padding_factor,
            current_size=self.source_current_size,
        )
        return projector.power_spectrum(current_size=int(current_size))

    def __call__(self, angles_deg: torch.Tensor, output_size: int) -> torch.Tensor:
        angles = self._normalise_angles(angles_deg)
        if int(angles.shape[0]) != 1:
            return self.project_batch(angles, output_size)

        # The scalar path is used by fixed-angle/legacy expectation only.  One
        # synchronisation per particle here is acceptable; the global path never
        # enters it.
        cache_key = (
            self.source_cache_token,
            int(output_size),
            tuple(float(round(x, 8)) for x in angles[0].detach().cpu().tolist()),
        )
        cached = self._cache.get(cache_key)
        if cached is not None:
            self._cache.move_to_end(cache_key)
            return cached
        out = self._project_validated(angles, int(output_size))
        if out is None:
            out = self._fallback(angles, int(output_size))
        self._cache[cache_key] = out
        if len(self._cache) > self._cache_limit:
            self._cache.popitem(last=False)
        return out

    @staticmethod
    def _window_rfft(x: torch.Tensor, new_size: int) -> torch.Tensor:
        old_size = int(x.shape[-2])
        if new_size == old_size:
            return x
        if new_size > old_size or new_size < 2 or new_size % 2:
            raise ValueError("Fourier window must be an even size not larger than input")
        expected_half = old_size // 2 + 1
        if int(x.shape[-1]) != expected_half:
            raise ValueError(
                f"input is not an RFFT half-plane for size {old_size}: "
                f"shape={tuple(x.shape[-2:])}"
            )
        top = new_size // 2 + 1
        bottom = new_size - top
        head = x[..., :top, :new_size // 2 + 1]
        return head if bottom == 0 else torch.cat(
            (head, x[..., -bottom:, :new_size // 2 + 1]), dim=-2)

    def _fallback(self, angles_deg: torch.Tensor, output_size: int) -> torch.Tensor:
        # Correct but intentionally slow reference implementation; the validated
        # adapter above remains the default production path.
        ref = self.reference
        if self._fallback_fft is None:
            dims = tuple(range(-ref.ndim, 0))
            yy = [torch.arange(n, device=ref.device) for n in ref.shape]
            grids = torch.meshgrid(*yy, indexing="ij")
            parity = sum(grids) % 2
            sign = torch.where(parity == 0, 1.0, -1.0).to(ref.dtype)
            self._fallback_fft = torch.fft.fftn(ref * sign, norm="forward")
        full = self._fallback_fft
        n = ref.shape[-1]
        ky = torch.fft.fftfreq(output_size, device=ref.device) * output_size
        kx = torch.fft.rfftfreq(output_size, device=ref.device) * output_size
        yy, xx = torch.meshgrid(ky, kx, indexing="ij")
        base = (
            torch.stack((xx, yy, torch.zeros_like(xx)), -1)
            if ref.ndim == 3
            else torch.stack((xx, yy), -1)
        )
        outs = []
        for angle in angles_deg:
            mat = _euler_matrix(angle.unsqueeze(0))[0]
            if ref.ndim == 3:
                # For an orthogonal Euler matrix A, row-vector multiplication
                # by A is equivalent to column-vector multiplication by A^-1.
                coord = base @ mat
                # nearest-neighbour fallback is used only when validated API is unavailable.
                idx = torch.remainder(torch.round(coord).long() + n // 2, n)
                vals = full[idx[..., 2], idx[..., 1], idx[..., 0]]
            else:
                # RELION's 2-D projector uses (A^-1)[:2,:2].  In row-vector
                # form this is A[:2,:2], not inv(A[:2,:2]).T.
                coord = base @ mat[:2, :2]
                idx = torch.remainder(torch.round(coord).long() + n // 2, n)
                vals = full[idx[..., 1], idx[..., 0]]
            source_index = torch.round(coord)
            source_valid = source_index.square().sum(-1) <= (self.source_current_size // 2) ** 2
            output_valid = xx.square() + yy.square() <= (output_size // 2) ** 2
            vals = torch.where(source_valid & output_valid, vals, torch.zeros_like(vals))
            outs.append(vals)
        return torch.stack(outs)

def _semantic_call(fn: Any, roles: Mapping[str, Any]) -> Any:
    """Call a core function by matching RELION/Python semantic parameter names."""
    sig=inspect.signature(fn); kwargs={}
    for name,param in sig.parameters.items():
        low=name.lower()
        if low in ('self','cls') or param.kind in (inspect.Parameter.VAR_POSITIONAL,inspect.Parameter.VAR_KEYWORD):
            continue
        value=None; found=True
        if low in roles:value=roles[low]
        elif any(k in low for k in ('fourier_image','fimg','image','data')) and 'fourier_image' in roles:value=roles['fourier_image']
        elif any(k in low for k in ('rotation','matrix')) or low=='a':value=roles.get('rotation')
        elif 'numerator' in low:value=roles.get('numerator_weight')
        elif any(k in low for k in ('denominator','weight','ctf2')):value=roles.get('denominator_weight')
        elif 'tau2' in low or low=='tau':value=roles.get('tau2')
        elif 'fudge' in low:value=roles.get('tau2_fudge',1.0)
        elif 'preweight' in low:value=roles.get('preweight_iterations',10)
        elif any(k in low for k in ('normalise','normalize','normalization')):value=roles.get('normalise',1.0)
        elif low.startswith('do_') or low.startswith('is_'):value=roles.get(low,False)
        elif param.default is not inspect.Parameter.empty:found=False
        else:found=False
        if found and value is not None:kwargs[name]=value
    return fn(**kwargs)


class ValidatedBackprojectorAdapter:
    """Reflection adapter for the tested compact-grid backprojector/reconstructor."""
    def __init__(self, number_of_classes: int, original_size: int, current_size: int,
                 padding_factor: float, device: torch.device,
                 reference_dim: int = 3) -> None:
        mod=importlib.import_module('relion_torch.fourier.backprojector')
        cls=getattr(mod,'FourierBackprojector')
        self.objects=[]
        candidates={'original_size':original_size,'ori_size':original_size,'box_size':original_size,
                    'current_size':current_size,'padding_factor':padding_factor,'pad':padding_factor,
                    'device':device,'dtype':torch.float32,'reference_dim':reference_dim}
        for _ in range(number_of_classes):
            obj=None
            for name in ('create','initialise','initialize'):
                fn=getattr(cls,name,None)
                if callable(fn):
                    try: obj=fn(**_supported_kwargs(fn,candidates)); break
                    except Exception: pass
            if obj is None:
                try: obj=cls(**_supported_kwargs(cls,candidates))
                except Exception as exc: raise RuntimeError('cannot construct validated FourierBackprojector') from exc
            self.objects.append(obj)

    def add(
        self,
        class_index: int,
        fourier_image: torch.Tensor,
        rotation: torch.Tensor,
        numerator_weight: torch.Tensor,
        denominator_weight: torch.Tensor,
        *,
        observation_weights: torch.Tensor | None = None,
        orientation_chunk_size: int = 256,
    ) -> None:
        obj=self.objects[class_index]
        # RELION-Torch 0.1.6 exposes the validated compact-grid insertion API as
        # FourierBackprojector.accumulate().  The alignment optimiser passes
        # `fourier_image` with the complete numerator weighting already applied,
        # and `denominator_weight` as the matching posterior*CTF^2/sigma^2 grid.
        # Call that concrete API first; the reflective aliases below are kept
        # only for compatibility with older experimental backends.
        accumulate=getattr(obj,'accumulate',None)
        if callable(accumulate):
            accumulate(
                fourier_image,
                rotation,
                denominator_weight,
                observation_weights=observation_weights,
                orientation_chunk_size=orientation_chunk_size,
            )
            return
        methods=[getattr(obj,n,None) for n in ('backproject','backproject_2d','add_slice','insert_slice')]
        candidates={'fourier_image':fourier_image,'image':fourier_image,'data':fourier_image,
                    'rotation':rotation,'matrix':rotation,'A':rotation,
                    'numerator_weight':numerator_weight,'weight':denominator_weight,
                    'weights':denominator_weight,'denominator_weight':denominator_weight,
                    'ctf_weight':denominator_weight}
        errors=[]
        for fn in methods:
            if not callable(fn): continue
            for args in ((fourier_image,rotation,numerator_weight,denominator_weight),
                         (fourier_image,rotation,denominator_weight),(fourier_image,rotation),()):
                try:
                    kw=_supported_kwargs(fn,candidates)
                    if args:
                        for key in list(kw):
                            if key in ('fourier_image','image','data','rotation','matrix','A','weight','weights','numerator_weight','denominator_weight','ctf_weight'):
                                kw.pop(key,None)
                    fn(*args,**kw); return
                except Exception as exc: errors.append(exc)
        roles={'fourier_image':fourier_image,'rotation':rotation,'numerator_weight':numerator_weight,
               'denominator_weight':denominator_weight}
        for fn in methods:
            if callable(fn):
                try:_semantic_call(fn,roles);return
                except Exception as exc:errors.append(exc)
        raise RuntimeError(f'validated backprojector API could not be called: {errors[-1] if errors else "no method"}')

    def reconstruct_one(
        self,
        class_index: int,
        *,
        tau2: torch.Tensor | None = None,
        tau2_fudge: float = 1.0,
        preweight_iterations: int = 10,
        normalise: float = 1.0,
        minres_map: int = 5,
        sirm=None, skip_gridding=False, reconstruction_backend="auto", workspace=None, timer=None,
    ) -> torch.Tensor:
        """Call the in-tree reconstruction API exactly once.

        Numerical exceptions are intentionally not caught.  In particular a
        failed MAP reconstruction must never be retried with options=None.
        """
        from relion_torch.fourier.backprojector import FourierBackprojector
        from relion_torch.reconstruction.reconstruct import (
            ReconstructionOptions, reconstruct_backprojector,
        )
        index = int(class_index)
        if not 0 <= index < len(self.objects):
            raise IndexError(f"class_index out of range: {index}")
        obj = self.objects[index]
        if not isinstance(obj, FourierBackprojector):
            raise TypeError("Reconstruction requires the validated in-tree FourierBackprojector")
        if not math.isfinite(float(normalise)) or float(normalise) <= 0:
            raise ValueError("Reconstruction normalise must be finite and positive")
        if int(minres_map) < 0:
            raise ValueError("minres_map must be non-negative")
        options = ReconstructionOptions(
            tau2=tau2,
            tau2_fudge=float(tau2_fudge),
            preweight_iterations=int(preweight_iterations),
            normalise=float(normalise),
            min_resol_shell=int(minres_map),
            sirm=sirm,skip_gridding=skip_gridding,backend=reconstruction_backend,
        )
        result = reconstruct_backprojector(obj, options,workspace=workspace,timer=timer)
        image = result if torch.is_tensor(result) else result.map
        if not torch.is_tensor(image) or not bool(torch.isfinite(image).all()):
            raise FloatingPointError(f"class {index + 1}: invalid reconstruction")
        return image

    def reconstruct(
        self,
        tau2: Sequence[torch.Tensor] | None = None,
        tau2_fudge: float = 1.0,
        preweight_iterations: int = 10,
        normalise: Sequence[float] | None = None,
        minres_map: int = 5,
    ) -> list[torch.Tensor]:
        return [
            self.reconstruct_one(
                index,
                tau2=None if tau2 is None else tau2[index],
                tau2_fudge=tau2_fudge,
                preweight_iterations=preweight_iterations,
                normalise=1.0 if normalise is None else normalise[index],
                minres_map=minres_map,
            )
            for index in range(len(self.objects))
        ]

# Shared observation preparation API (also usable by future 3-D state machines).
from relion_torch.alignment.preparation import (
    prepare_particle_batch, ctf_rfft_batch, ParticlePreparationCache,
)
