"""Shared bounded preparation of 2-D observations for 2-D/3-D refinement.

No references, posterior values or iteration-dependent images are cached.
Random draws retain the original seed+record.row stream. Geometry caches have
an explicit byte cap; output tensors remain bounded by the caller's batch.
"""
from __future__ import annotations

from collections import OrderedDict
from contextlib import nullcontext
from dataclasses import dataclass
import math
from typing import Sequence, Any

import numpy as np
import torch

from relion_torch.fourier.conventions import _centered_radius, centered_rfft
from relion_torch.geometry.offsets import split_old_offset, dont_wrap_shift_2d_batch
from relion_torch.optics.ctf import CTFFrequencyGrid2D, CTFParameters, compute_ctf
from relion_torch.optics.aberrations import (
    correction_for, demodulate_records_, even_offset_for_records)


@dataclass
class PreparationGeometry:
    outside: torch.Tensor
    inside: torch.Tensor
    denominator: torch.Tensor
    identity_mask: bool
    shells: torch.Tensor
    checkerboard: torch.Tensor
    ctf_grid: CTFFrequencyGrid2D

    @property
    def byte_size(self):
        return sum(t.numel()*t.element_size() for t in
                   (self.outside, self.inside, self.denominator, self.shells,
                    self.checkerboard)) + self.ctf_grid.byte_size


class ParticlePreparationCache:
    """Bounded LRU of geometry and optics-only maps; no particle image cache."""
    def __init__(self, max_bytes: int = 32*1024**2):
        self.max_bytes = max(0, int(max_bytes))
        self.entries = OrderedDict()
        self.used_bytes = self.peak_bytes = self.hits = self.misses = 0

    def get(self, n, pixel, diameter, edge, device, dtype):
        dev = torch.device(device)
        if dev.type == 'cuda' and dev.index is None:
            dev = torch.device('cuda',torch.cuda.current_device())
        # A concrete tensor key supplies the CUDA device ordinal when needed.
        key = (int(n), float(pixel), float(diameter), float(edge), str(dev), dtype)
        if key in self.entries:
            self.hits += 1
            self.entries.move_to_end(key)
            return self.entries[key]
        self.misses += 1
        if n < 1 or not math.isfinite(pixel) or pixel <= 0:
            raise ValueError('box and pixel size must be positive')
        if not math.isfinite(edge) or edge <= 0:
            raise ValueError('mask edge must be positive and finite')
        radius_value = float(diameter)/(2.*float(pixel))
        if radius_value < 0:
            radius_value = n/2.
        if not math.isfinite(radius_value):
            raise ValueError('mask radius must be finite')
        radius = _centered_radius(n, 2, device=dev, dtype=dtype)
        outer = radius_value+edge
        # Exact comparisons/raised-cosine expression of softMaskOutsideMap.
        outside = torch.where(radius > outer, torch.ones_like(radius),
            torch.where(radius >= radius_value,
                        .5+.5*torch.cos(math.pi*(outer-radius)/edge),
                        torch.zeros_like(radius)))
        ky = torch.fft.fftfreq(n, device=dev)*n
        kx = torch.arange(n//2+1, device=dev, dtype=ky.dtype)
        shells = torch.floor(torch.sqrt(ky[:,None].square()+kx[None].square())+.5).long()
        yy = torch.arange(n, device=dev)[:, None]
        xx = torch.arange(n, device=dev)[None, :]
        checkerboard = torch.where(((yy+xx)&1)==0,1.,-1.).to(dtype)
        geo = PreparationGeometry(outside, 1.-outside, outside.sum(),
            radius_value >= math.sqrt(2.)*(n//2), shells, checkerboard,
            CTFFrequencyGrid2D.create(n,pixel,device=dev,dtype=dtype))
        self._insert(key, geo, geo.byte_size)
        return geo

    @staticmethod
    def _size(value):
        return value.numel()*value.element_size() if torch.is_tensor(value) else value.byte_size

    def _insert(self, key, value, size):
        # Geometry and aberrations share ONE budget. Oversize maps are transient.
        if size <= self.max_bytes:
            while self.entries and self.used_bytes+size > self.max_bytes:
                _, removed = self.entries.popitem(last=False)
                self.used_bytes -= self._size(removed)
            self.entries[key] = value
            self.used_bytes += size
            self.peak_bytes = max(self.peak_bytes, self.used_bytes)

    def get_aberration(self, coefficients, grid, kind):
        key = ('aberration', coefficients, grid.box_size, grid.pixel_size_angstrom,
               str(grid.x.device), grid.x.dtype, kind)
        if key in self.entries:
            self.hits += 1
            self.entries.move_to_end(key)
            return self.entries[key]
        self.misses += 1
        value = correction_for(coefficients, grid, kind)
        self._insert(key, value, self._size(value))
        return value

    def clear(self):
        self.entries.clear()
        self.used_bytes = 0


def _section(timer, name):
    return timer.section(name) if timer is not None else nullcontext()


def _count(counters, key, value=1, *, peak=False):
    if counters is not None:
        counters[key] = max(counters.get(key,0),int(value)) if peak else counters.get(key,0)+int(value)


def preparation_chunk_size(n: int, batch_size: int, max_work_bytes: int) -> int:
    if max_work_bytes <= 0:
        raise ValueError('preparation workspace must be positive')
    # Conservative transient-array estimate, not a cap on returned Fourier
    # arrays or on the allocator/library workspace. A single image is minimum.
    return max(1, min(batch_size, max_work_bytes//max(1,n*n*4*20)))


@torch.no_grad()
def prepare_particle_batch(
    images: np.ndarray | torch.Tensor, records: Sequence[Any], *,
    particle_diameter: float, mask_edge_pixels: float, zero_mask: bool,
    sigma2_by_shell: torch.Tensor, device: torch.device | str, seed: int,
    normalization_factors: Sequence[float] | torch.Tensor | None = None,
    cache: ParticlePreparationCache | None = None,
    max_work_bytes: int = 256*1024**2, timer=None, counters=None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return likelihood/unmasked FFT, integer XY and residual XY (pixels).

    ``records`` maps one-to-one to images, not dataset indices. Noise spectra
    are [S] or [B,S]. Normalization factors are avg_norm / particle_norm, not
    the inverse; raw images are borrowed and are never modified in place.
    Only geometry is reusable across iterations. Different grids must be
    supplied in separate batches, as required by the current observation model.
    """
    if images.ndim != 3 or images.shape[-2] != images.shape[-1]:
        raise ValueError('images must be [B,N,N]')
    b,n,_ = images.shape
    if b == 0 or len(records) != b:
        raise ValueError('records must match a nonempty image batch')
    pixel = float(records[0].pixel_size)
    if not math.isfinite(pixel) or pixel <= 0 or any(float(r.pixel_size)!=pixel for r in records):
        raise ValueError('all records in a preparation batch must have one finite positive pixel size')
    dev = torch.device(device)
    cache = cache if cache is not None else ParticlePreparationCache(0)
    with _section(timer, 'prepare.geometry'):
        geo = cache.get(n,pixel,particle_diameter,mask_edge_pixels,dev,torch.float32)
    _count(counters,'prepare_geometry_cache_bytes',cache.used_bytes,peak=True)
    offsets = [(r.origin_x_angstrom/pixel,r.origin_y_angstrom/pixel) for r in records]
    if not np.isfinite(np.asarray(offsets)).all():
        raise ValueError('particle offsets must be finite')
    sigma = torch.as_tensor(sigma2_by_shell, device=dev)
    if sigma.ndim == 1:
        sigma = sigma.unsqueeze(0).expand(b,-1)
    if sigma.ndim != 2 or sigma.shape[0] != b or sigma.shape[1] < 1:
        raise ValueError('sigma2_by_shell must be [S] or [B,S]')
    factors = None
    if normalization_factors is not None:
        # Host division is done by the caller, preserving the original scalar
        # normalization rounding. No per-particle device scalar read.
        factors = torch.as_tensor(normalization_factors,device=dev,dtype=torch.float32)
        if tuple(factors.shape) != (b,):
            raise ValueError('normalization_factors must have shape [B]')
    with _section(timer,'prepare.offset_metadata'):
        old = torch.tensor(offsets,device=dev,dtype=torch.float32)
        dec = split_old_offset(old)
    chunk = preparation_chunk_size(n,b,int(max_work_bytes))
    _count(counters,'prepare_effective_chunk_max',chunk,peak=True)
    _count(counters,'prepare_workspace_estimate_bytes',chunk*n*n*4*20,peak=True)
    _count(counters,'prepare_particles_batched',b)
    like_all = unmasked_all = None
    if chunk < b:
        like_all = torch.empty((b,n,n//2+1),device=dev,dtype=torch.complex64)
        unmasked_all = torch.empty_like(like_all)
    for start in range(0,b,chunk):
        end=min(b,start+chunk)
        with _section(timer,'prepare.normalize_and_shift'):
            src = images[start:end]
            if isinstance(src,np.ndarray):
                src = torch.as_tensor(np.array(src,copy=True),device=dev,dtype=torch.float32)
            else:
                src = src.detach().to(device=dev,dtype=torch.float32)
            if factors is not None:
                src = src*factors[start:end,None,None]
            shifted = dont_wrap_shift_2d_batch(src,dec.integer_xy[start:end])
        with _section(timer,'prepare.unmasked_fft'):
            unmasked = centered_rfft(shifted,ndim=2)
        _count(counters,'prepare_forward_fft_calls')
        noise = None
        if not zero_mask:
            # Keep seed+record.row and exactly the old real-then-imag draws.
            # RNG calls remain per particle; no random stream is re-partitioned.
            with _section(timer,'prepare.noise_draws'):
                lookup = sigma[start:end]
                shells = geo.shells
                sig = torch.sqrt(torch.clamp(lookup[:,shells.clamp_max(lookup.shape[-1]-1)],min=0.))
                sig = torch.where(shells[None] < lookup.shape[-1],sig,torch.zeros_like(sig))
                noise_ft = torch.empty((end-start,n,n//2+1),device=dev,dtype=torch.complex64)
                for j,record in enumerate(records[start:end]):
                    gen=torch.Generator(device=dev)
                    gen.manual_seed(int(seed)+record.row)
                    real=torch.randn((n,n//2+1),generator=gen,device=dev)*sig[j]
                    imag=torch.randn((n,n//2+1),generator=gen,device=dev)*sig[j]
                    noise_ft[j]=torch.complex(real,imag)
            with _section(timer,'prepare.noise_inverse_fft'):
                noise = torch.fft.irfft2(noise_ft,s=(n,n),dim=(-2,-1),norm='forward')*geo.checkerboard
            _count(counters,'prepare_inverse_fft_calls')
        with _section(timer,'prepare.mask'):
            if geo.identity_mask:
                likelihood=shifted
            else:
                add = ((geo.outside*shifted).sum((-2,-1),keepdim=True)/geo.denominator
                       if noise is None else noise)
                likelihood=geo.inside*shifted+geo.outside*add
        with _section(timer,'prepare.likelihood_fft'):
            like=centered_rfft(likelihood,ndim=2)
        with _section(timer,'prepare.aberration_demodulation'):
            demodulate_records_(records[start:end], geo.ctf_grid, like, unmasked, cache=cache)
        _count(counters,'prepare_geometry_cache_bytes',cache.used_bytes,peak=True)
        _count(counters,'prepare_forward_fft_calls')
        _count(counters,'prepare_microbatches')
        if like_all is None:
            return like,unmasked,dec.integer_xy,dec.residual_xy
        like_all[start:end]=like
        unmasked_all[start:end]=unmasked
    return like_all,unmasked_all,dec.integer_xy,dec.residual_xy


@torch.no_grad()
def ctf_rfft_batch(records: Sequence[Any], size: int, device, dtype=torch.float32, *,
                   frequency_grid: CTFFrequencyGrid2D | None = None,
                   phase_flipped_input=False, only_flip_phases=False, intact_first_peak=False,
                   max_work_bytes: int = 256*1024**2, timer=None, counters=None,
                   cache: ParticlePreparationCache | None = None):
    """Batch adapter to the existing physical CTF, with one host validation.

    Does not cache particle CTFs, group scales or premultiplication state.
    """
    if not records:
        raise ValueError('records must be nonempty')
    pixel=float(records[0].pixel_size)
    rows=[(r.defocus_u,r.defocus_v,r.defocus_angle,r.voltage_kv,r.cs_mm,
           r.amplitude_contrast,r.phase_shift,r.ctf_bfactor,r.ctf_scale) for r in records]
    host=np.asarray(rows,dtype=np.float64)
    if not np.isfinite(host).all() or np.any(host[:,3]<=0) or np.any((host[:,5]<0)|(host[:,5]>=1)):
        raise ValueError('CTF metadata must be finite, voltage positive and 0 <= Q0 < 1')
    if any(float(r.pixel_size)!=pixel for r in records):
        raise ValueError('CTF batch requires a common pixel size')
    params=torch.as_tensor(host,device=device,dtype=dtype)
    grid=frequency_grid or CTFFrequencyGrid2D.create(size,pixel,device=device,dtype=dtype)
    chunk=preparation_chunk_size(size,len(records),int(max_work_bytes))
    result=None if chunk>=len(records) else torch.empty((len(records),size,size//2+1),device=device,dtype=dtype)
    for start in range(0,len(records),chunk):
        end=min(len(records),start+chunk)
        with _section(timer,'prepare.ctf'):
            raw=compute_ctf(size,pixel,CTFParameters(*params[start:end].unbind(-1)),
                device=device,dtype=dtype,frequency_grid=grid,validate_parameters=False,
                gamma_offset=even_offset_for_records(records[start:end], grid, cache),
                phase_flipped_input=phase_flipped_input,only_flip_phases=only_flip_phases,
                intact_first_peak=intact_first_peak)
        _count(counters,'prepare_ctf_calls')
        if result is None:
            return raw
        result[start:end]=raw
    return result
