"""Reusable bounded translation coalescing for 2-D observations of 2-D/3-D maps.

The phase basis/planner originated in Class2D; angles and class/direction priors
remain the caller's responsibility. No alignment candidates are removed.
"""
from dataclasses import dataclass
import numpy as np
import torch

@dataclass(frozen=True, slots=True)
class OrientationMajorWorkspace:
    total_bytes: int
    phase_basis_bytes: int
    tile_bytes: int
    bytes_per_orientation: int
    max_orientation_rows: int
    max_coarse_groups: int


def plan_orientation_major_workspace(
    total_bytes: int,
    *,
    size: int,
    active_pixels: int,
    orientation_children: int,
    translation_slots: int,
) -> OrientationMajorWorkspace:
    """Conservative workspace model based on *compressed* orientation rows.

    The parent-major planner scales by retained translation parents. That is
    deliberately wrong for the orientation-major path: after grouping, the hot
    tensors scale with particle/class/fine-orientation rows instead. The model
    includes the single packed GEMM output, representative references, active
    statistics, numerator/denominator and a dense translation-weight rectangle,
    with additional slack for temporary elementwise results.
    """
    total = max(1, int(total_bytes))
    s = int(size)
    full = s * (s // 2 + 1)
    active = max(1, int(active_pixels))
    oc = max(1, int(orientation_children))
    slots = max(1, int(translation_slots))
    # Packed basis: real phase, imag phase, active |phase|^2, and
    # [mass, tx, ty, t^2]. This allocation is shared by all supertiles.
    basis_cols = 2 * full + active + 4
    basis_bytes = slots * basis_cols * 4
    available = max(1, total - basis_bytes)
    # Conservative peak per compressed fine-orientation row. The 48/56 terms
    # cover GEMM output, complex phase/reference/numerator, active prediction,
    # xbar, residual/power/cross temporaries and denominator. The translation
    # rectangle contributes one FP32 value per fine translation slot.
    per_orientation = max(1, 48 * full + 56 * active + 4 * slots + 1024)
    max_rows = max(oc, available // per_orientation)
    max_rows = max(oc, (max_rows // oc) * oc)
    max_groups = max(1, max_rows // oc)
    return OrientationMajorWorkspace(
        total_bytes=total,
        phase_basis_bytes=basis_bytes,
        tile_bytes=available,
        bytes_per_orientation=per_orientation,
        max_orientation_rows=max_rows,
        max_coarse_groups=max_groups,
    )


@dataclass(frozen=True, slots=True)
class OrientationMajorPhaseBasis:
    matrix: torch.Tensor
    full_pixels: int
    active_pixels: int
    translation_slots: int
    height: int
    width: int


@torch.no_grad()
def build_orientation_major_phase_basis(
    phase_bank: torch.Tensor,
    fine_translation_table: torch.Tensor,
    active_indices: torch.Tensor,
) -> OrientationMajorPhaseBasis:
    """Build the invariant RHS used by every orientation-major supertile.

    A single FP32 matrix packs phase.real, phase.imag, active phase power and
    translation moments. Each supertile therefore needs one large GEMM rather
    than separate real/imag/phase-power/translation matrix multiplications.
    """
    phase = phase_bank.reshape(-1, phase_bank.shape[-2] * phase_bank.shape[-1])
    translations = fine_translation_table.reshape(-1, 2).to(
        device=phase.device, dtype=torch.float32
    )
    if phase.shape[0] != translations.shape[0]:
        raise ValueError("phase and fine-translation slot counts differ")
    active_phase = phase.index_select(1, active_indices)
    phase_power = active_phase.real.square() + active_phase.imag.square()
    moments = torch.cat(
        (
            torch.ones((translations.shape[0], 1), device=phase.device, dtype=torch.float32),
            translations,
            translations.square().sum(-1, keepdim=True),
        ),
        dim=1,
    )
    matrix = torch.cat(
        (phase.real.to(torch.float32), phase.imag.to(torch.float32), phase_power, moments),
        dim=1,
    ).contiguous()
    return OrientationMajorPhaseBasis(
        matrix=matrix,
        full_pixels=phase.shape[1],
        active_pixels=active_indices.numel(),
        translation_slots=phase.shape[0],
        height=phase_bank.shape[-2],
        width=phase_bank.shape[-1],
    )


@dataclass
class OrientationTile:
    class_index: int
    parent_ids: torch.Tensor
    slots: torch.Tensor
    representatives: torch.Tensor
    rows: torch.Tensor
    orientations: torch.Tensor
    host_angular_ids: np.ndarray
    translations: int

    @property
    def groups(self):
        return len(self.rows)

    def coalesce(self, retained):
        w = retained.index_select(0,self.parent_ids).to(torch.float32)
        oc,tc = w.shape[1:]
        rectangle = w.new_zeros((self.groups*self.translations,oc,tc))
        rectangle.index_copy_(0,self.slots,w)
        return rectangle.reshape(self.groups,self.translations,oc,tc).permute(0,2,1,3).reshape(self.groups*oc,-1)


class OrientationSchedule:
    """One compact metadata readback per particle batch; none per parent/tile."""
    def __init__(self,particle,classes,orientation,translation,active,*,
                 translations,children,max_groups,device):
        ids = torch.nonzero(active,as_tuple=False).squeeze(1)
        packed = torch.stack((ids,particle[ids],classes[ids],orientation[ids],translation[ids]),1)
        host = packed.detach().cpu().numpy()
        self.d2h_bytes = host.nbytes
        self.parent_count = len(ids)
        self.total_parents = len(active)
        self.device,self.translations,self.children = device,int(translations),int(children)
        self.max_groups = max(1,int(max_groups))
        if len(host):
            order = np.lexsort((host[:,4],host[:,1],host[:,3],host[:,2]))
            self.host = host[order]
            h = self.host
            different = np.any(h[1:,1:4]!=h[:-1,1:4],axis=1)
            self.starts = np.r_[0,np.flatnonzero(different)+1,len(h)]
        else:
            self.host = host
            self.starts = np.array([0],dtype=np.int64)
        self.group_count = len(self.starts)-1

    def tiles(self):
        h,starts = self.host,self.starts
        first = 0
        while first<self.group_count:
            c = int(h[starts[first],2])
            last = min(first+self.max_groups,self.group_count)
            # Keep a class boundary outside the hot GPU computation.
            class_ids = h[starts[first:last],2]
            boundary = np.flatnonzero(class_ids!=c)
            if len(boundary):
                last = first+int(boundary[0])
            lo,hi = int(starts[first]),int(starts[last])
            part = h[lo:hi]
            reps = starts[first:last]-lo
            counts = np.diff(starts[first:last+1])
            groups = last-first
            slots = np.repeat(np.arange(groups),counts)*self.translations+part[:,4]
            rows = part[reps,1]
            orientations = part[reps,3]
            flat = np.concatenate((part[:,0],slots,reps,rows,orientations))
            gpu = torch.as_tensor(flat,device=self.device,dtype=torch.long)
            n = len(part)
            angular = (orientations[:,None]*self.children+np.arange(self.children)[None]).reshape(-1)
            yield OrientationTile(c,gpu[:n],gpu[n:2*n],gpu[2*n:2*n+groups],
                                  gpu[2*n+groups:2*n+2*groups],gpu[2*n+2*groups:],angular,self.translations)
            first = last


@dataclass
class OrientationStatistics:
    rows: torch.Tensor
    mass: torch.Tensor
    residual: torch.Tensor
    cross: torch.Tensor
    power: torch.Tensor
    offset_square: torch.Tensor
    numerator: torch.Tensor
    denominator: torch.Tensor
    shell_reduced: bool = False


def evaluate_orientation_statistics(grouped,phase_basis,*,rows,references,like_active,
                                    unmasked,prediction_active,numerator_factor,
                                    denominator_factor,inverse_noise,centres,active_indices,
                                    statistics_dtype,reduction=None,prepared_inputs=None):
    """Weighted phase GEMM plus SPA statistics for arbitrary orientation rows.

    Each row is one particle/class/fine orientation. ``centres`` is the prior
    centre minus the integer image shift, in Angstroms (not Class2D class means).
    Noise and scale use masked data; gridding uses unmasked data and inverse
    noise. The high-frequency image-power supplement is added by the caller
    once per particle after processing ALL rows.
    """
    reduced = grouped @ phase_basis.matrix
    f,a = phase_basis.full_pixels,phase_basis.active_pixels
    phase = torch.complex(reduced[:,:f],reduced[:,f:2*f]).reshape(-1,phase_basis.height,phase_basis.width)
    moments = reduced[:,2*f+a:]
    mass = moments[:,0]
    active_phase=phase.flatten(-2).index_select(-1,active_indices)
    fused=None
    shell_reduced=False
    if reduction is not None and hasattr(references,'reduced_statistics'):
        fused=references.reduced_statistics(rows,like_active,prediction_active,active_phase,
            reduced[:,2*f:2*f+a],mass,active_indices,statistics_dtype,reduction)
        shell_reduced=fused is not None
    if fused is None and hasattr(references,'fused_statistics'):
        fused=references.fused_statistics(rows,like_active,prediction_active,active_phase,
            reduced[:,2*f:2*f+a],mass,active_indices,statistics_dtype)
        if fused is None:references=references.materialize()
    if fused is not None:residual,cross,power=fused
    else:
        image = like_active.index_select(0,rows)
        prediction = references.flatten(-2).index_select(-1,active_indices)*prediction_active.index_select(0,rows)
        xbar = image*active_phase
        power = mass[:,None]*prediction.abs().square()
        cross = (prediction.conj()*xbar).real
        image_power = image.abs().square()*reduced[:,2*f:2*f+a]
        residual = (image_power+power-2*cross).clamp_min(0).to(statistics_dtype)
    centre = centres.index_select(0,rows)
    offset_square = (moments[:,3]-2*(moments[:,1:3]*centre).sum(-1)+mass*centre.square().sum(-1)).to(statistics_dtype).sum()
    inputs=None
    if prepared_inputs is not None:
        if hasattr(references,'fine'):
            inputs=prepared_inputs.fused(phase,rows,mass,references.fine.store)
        if inputs is None:inputs=prepared_inputs.eager(phase,rows,mass)
    if inputs is not None:numerator,denominator=inputs
    else:
        numerator = phase*unmasked.index_select(0,rows)*(numerator_factor*inverse_noise).index_select(0,rows)
        denominator = mass[:,None,None]*(denominator_factor*inverse_noise).index_select(0,rows)
    return OrientationStatistics(rows,mass,residual,cross,power,offset_square,numerator,denominator,shell_reduced)


