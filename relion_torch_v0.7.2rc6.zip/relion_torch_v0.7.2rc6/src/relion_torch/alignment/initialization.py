"""Shared bounded initialization Fourier pass (2-D observations, 2-D/3-D refs).

This is NOT E-step preparation: no origin shift, norm correction, group scale
or random-noise mask is applied. It preserves the initial-spectrum semantics
of the 0.2.10/RELION-3.1 path. Raw full-box FFTs may feed both noise statistics
and initial-reference insertion without retaining a dataset-sized FFT cache.
"""
from __future__ import annotations
from contextlib import nullcontext
import torch
from relion_torch.alignment.preparation import ParticlePreparationCache, preparation_chunk_size
from relion_torch.fourier.conventions import centered_rfft
from relion_torch.inference.alignment import rounded_shell_indices_2d
from relion_torch.relion_statistics import repair_negative_spectrum_relion


def section(context, name):
    return context.timer.section(name) if context is not None else nullcontext()


def count(context, name, value=1, *, peak=False):
    if context is not None:
        d = context.counters
        d[name] = max(d.get(name,0),int(value)) if peak else d.get(name,0)+int(value)


class InitialNoiseAccumulator:
    def __init__(self, dataset, device):
        self.dataset, self.device = dataset, torch.device(device)
        self.n, self.ns = dataset.box_size, dataset.box_size//2+1
        self.groups = sorted({record.group_number for record in dataset._records})
        self.group_lookup = {g:i for i,g in enumerate(self.groups)}
        shells = rounded_shell_indices_2d(self.n, self.device).flatten()
        self.valid = torch.nonzero(shells < self.ns, as_tuple=False).squeeze(-1)
        self.shells = shells.index_select(0,self.valid)
        self.shell_counts = torch.bincount(self.shells,minlength=self.ns).to(torch.float64)
        self.sums = torch.zeros((len(self.groups),self.ns), device=self.device,dtype=torch.float64)
        self.counts = torch.zeros(len(self.groups), device=self.device,dtype=torch.float64)
        self.average = torch.zeros((self.n,self.n//2+1), device=self.device,dtype=torch.complex128)
        self.processed = 0

    def add(self, fourier, indices):
        ft = fourier.to(torch.complex128)
        self.average += ft.sum(0)
        values = ft.flatten(1).index_select(1,self.valid)
        power = values.real.square()+values.imag.square()
        radial = torch.zeros((len(indices),self.ns),device=self.device,dtype=torch.float64)
        radial.scatter_add_(1,self.shells[None].expand(len(indices),-1),power)
        group = torch.tensor([self.group_lookup[self.dataset.record(i).group_number] for i in indices],
                             device=self.device,dtype=torch.long)
        self.sums.index_add_(0,group,radial)
        self.counts.index_add_(0,group,torch.ones(len(indices),device=self.device,dtype=torch.float64))
        self.processed += len(indices)

    def finish(self):
        if self.processed != len(self.dataset):
            raise ValueError('initial noise spectrum requires the full dataset exactly once')
        average = self.average/self.processed
        values = average.flatten().index_select(0,self.valid)
        shell = torch.zeros(self.ns,device=self.device,dtype=torch.float64)
        shell.scatter_add_(0,self.shells,values.real.square()+values.imag.square())
        shell /= self.shell_counts.clamp_min(1)
        means = self.sums/(self.counts[:, None]*self.shell_counts[None, :]).clamp_min(1)
        spectra = repair_negative_spectrum_relion(.5*(means-shell), minimum=1.e-20).to(torch.float32)
        return list(spectra.unbind(0))


def iter_initial_fourier_batches(dataset, *, device, batch_size, particle_diameter,
                                 mask_edge_pixels, zero_mask, work_bytes=256*1024**2,
                                 cache_bytes=32*1024**2, context=None):
    """Yield borrowed raw-masked Fourier batches; no dataset-size device cache."""
    n, pixel = dataset.box_size, dataset.pixel_size
    cache = ParticlePreparationCache(cache_bytes)
    with section(context,'geometry'):
        geo = cache.get(n,pixel,particle_diameter,mask_edge_pixels,device,torch.float32)
    count(context,'geometry_cache_bytes',cache.used_bytes,peak=True)
    micro = preparation_chunk_size(n,batch_size,work_bytes)
    count(context,'effective_microbatch_max',micro,peak=True)
    iterator = iter(dataset.iter_image_batches(device=device,batch_size=batch_size))
    while True:
        with section(context,'read_and_device_pool'):
            try:
                indices, images = next(iterator)
            except StopIteration:
                break
        count(context,'read_particles',len(indices)); count(context,'read_batches')
        for first in range(0,len(indices),micro):
            rows = indices[first:first+micro]
            src = images[first:first+micro]
            with section(context,'mask_fft'):
                if zero_mask and not geo.identity_mask:
                    bg = (geo.outside*src).sum((-2,-1),keepdim=True)/geo.denominator
                    image = geo.inside*src+geo.outside*bg
                else:
                    image = src
                ft = centered_rfft(image,ndim=2)
            count(context,'forward_fft_calls'); count(context,'fft_particles',len(rows))
            count(context,'microbatches')
            yield rows, ft, geo
    cache.clear()


def initialize_noise_batched(dataset, *, device, batch_size, particle_diameter,
                              mask_edge_pixels, zero_mask, work_bytes=256*1024**2,
                              cache_bytes=32*1024**2, context=None):
    stats = InitialNoiseAccumulator(dataset,device)
    for indices,ft,geo in iter_initial_fourier_batches(dataset,device=device,batch_size=batch_size,
            particle_diameter=particle_diameter,mask_edge_pixels=mask_edge_pixels,zero_mask=zero_mask,
            work_bytes=work_bytes,cache_bytes=cache_bytes,context=context):
        with section(context,'noise_spectrum'):
            stats.add(ft,indices)
        count(context,'noise_particles',len(indices))
    with section(context,'noise_finalize'):
        return stats.finish()
