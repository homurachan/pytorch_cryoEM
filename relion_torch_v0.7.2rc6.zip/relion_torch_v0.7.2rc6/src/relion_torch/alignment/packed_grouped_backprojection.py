"""Dense angle-ID lookup for bounded, additive SPA direction statistics."""
import numpy as np
import torch
from relion_torch.inference.slot_map import ClockSlotMap, SparseClockSlotMap


class PackedGroupedOrientationAccumulator:
    """Batch host metadata operations and GPU sums; flush before any eviction.

    Class/direction keys refer to the global grid, never particle-local IDs.
    Changed summation order can change rounding but never drops retained mass.
    """
    def __init__(self, insert, size, max_bytes, classes, orientations, *, counters=None, flush_rows=1024, sparse_keys=False, adaptive=False):
        self.insert, self.size, self.max_bytes = insert, int(size), max(0, int(max_bytes))
        self.classes, self.orientations = int(classes), int(orientations)
        self.counts = counters if counters is not None else {}
        self.flush_rows = max(1, int(flush_rows))
        self.direct_rows = self.flush_rows
        self.slot_type = SparseClockSlotMap if sparse_keys else ClockSlotMap
        self.capacity = 0
        self.map = self.numerator = self.denominator = None
        self.planned = False
        self.counts['group_cache_budget_bytes'] = self.max_bytes
        self.counts['group_cache_packed_lookup'] = 1
        self.adaptive = bool(adaptive)
        self.window_lookups = self.window_hits = self.cold_windows = 0

    def _count(self, key, n):
        self.counts[key] = self.counts.get(key, 0) + int(n)

    def _allocate(self, num, den):
        self.planned = True
        rowbytes = self.size * (self.size//2+1) * (num.element_size()+den.element_size())
        total = self.max_bytes // (rowbytes + 256)
        self.flush_rows = min(self.flush_rows, max(1, total//5))
        self.capacity = min(self.classes*self.orientations, max(0, total-self.flush_rows))
        self.counts['group_cache_row_capacity'] = self.capacity
        self.counts['group_cache_flush_rows'] = self.flush_rows
        if not self.capacity:
            return
        self.map = self.slot_type(self.classes*self.orientations, self.capacity)
        shape = (self.capacity, self.size, self.size//2+1)
        self.numerator = torch.empty(shape, device=num.device, dtype=num.dtype)
        self.denominator = torch.empty(shape, device=den.device, dtype=den.dtype)
        self.counts['grouped_peak_bytes'] = self.capacity*rowbytes

    def _flush(self, slots):
        keys = self.map.slot_to_row[slots]
        occupied = keys >= 0
        slots, keys = slots[occupied], keys[occupied]
        classes = keys // self.orientations
        for c in np.unique(classes):
            keep = classes == c
            ids, selected = keys[keep] % self.orientations, slots[keep]
            for start in range(0, len(ids), self.flush_rows):
                ix = torch.as_tensor(selected[start:start+self.flush_rows], device=self.numerator.device)
                angles = torch.as_tensor(ids[start:start+self.flush_rows], device=self.numerator.device)
                self.insert(int(c), angles, self.numerator.index_select(0, ix), self.denominator.index_select(0, ix))
                self._count('grouped_flushes', 1)
                self._count('grouped_flushed_rows', len(ix))
        self.map.release(slots)

    def add(self, c, ids, num, den, *, host_ids=None):
        if not len(ids):
            return
        c = int(c)
        host = np.asarray(host_ids, dtype=np.int64).reshape(-1) if host_ids is not None else ids.detach().cpu().numpy()
        if not 0 <= c < self.classes or np.any((host < 0) | (host >= self.orientations)):
            raise IndexError('statistical orientation outside global grid')
        if len(host) != len(ids):
            raise ValueError('host ID count differs from tensor ID count')
        if not self.planned:
            self._allocate(num, den)
        if not self.capacity:
            self._count('grouped_input_orientation_rows', len(ids))
            self._count('grouped_direct_rows', len(ids))
            for start in range(0,len(ids),self.flush_rows):
                self.insert(c,ids[start:start+self.flush_rows],num[start:start+self.flush_rows],den[start:start+self.flush_rows])
            return
        unique, inverse = np.unique(host, return_inverse=True)
        if len(unique) > self.capacity:
            capacity=self.capacity
            for start in range(0, len(unique), capacity):
                keep = (inverse >= start) & (inverse < start+capacity)
                ix = torch.as_tensor(np.flatnonzero(keep), device=num.device)
                self.add(c, ids.index_select(0, ix), num.index_select(0, ix), den.index_select(0, ix), host_ids=host[keep])
            return
        self._count('grouped_input_orientation_rows', len(ids))
        keys = c*self.orientations + unique
        slots = self.map.lookup(keys)
        missing = np.flatnonzero(slots < 0)
        self._count('grouped_cache_hits', len(keys)-len(missing))
        self._count('grouped_cache_misses', len(missing))
        self.window_lookups += len(keys)
        self.window_hits += len(keys)-len(missing)
        if len(missing):
            free = np.flatnonzero(self.map.slot_to_row < 0)
            shortage = len(missing)-len(free)
            if shortage > 0:
                protected = np.concatenate((slots[slots >= 0], free))
                target = min(self.capacity-len(protected), max(shortage, self.flush_rows))
                victims = self.map.victims(target, protected=protected)
                self._flush(victims)
                free = np.flatnonzero(self.map.slot_to_row < 0)
            fresh = free[:len(missing)]
            self.map.assign(keys[missing], fresh)
            slots[missing] = fresh
            ix = torch.as_tensor(fresh, device=num.device)
            self.numerator.index_fill_(0, ix, 0)
            self.denominator.index_fill_(0, ix, 0)
        ix = torch.as_tensor(slots[inverse], device=num.device)
        self.numerator.index_add_(0, ix, num)
        self.denominator.index_add_(0, ix, den)
        # Flush every retained sum before switching a persistently cold cache
        # to bounded direct insertion. Candidate weights remain unchanged.
        if self.adaptive and self.window_lookups >= max(4096,2*self.capacity):
            self.cold_windows = self.cold_windows+1 if self.window_hits < .01*self.window_lookups else 0
            self.window_lookups = self.window_hits = 0
            if self.cold_windows >= 2:
                self._flush(np.flatnonzero(self.map.slot_to_row>=0))
                self.numerator=self.denominator=self.map=None
                self.capacity=0
                self.flush_rows=self.direct_rows
                self._count('grouped_cache_bypass_switches',1)

    def finish(self):
        if self.map is not None:
            self._flush(np.flatnonzero(self.map.slot_to_row >= 0))
        # insert can be a bound method of the subclass: release GPU payloads
        # explicitly rather than waiting for cyclic GC between iterations.
        self.numerator = self.denominator = self.map = None
        self.planned = False
        self.capacity = 0
