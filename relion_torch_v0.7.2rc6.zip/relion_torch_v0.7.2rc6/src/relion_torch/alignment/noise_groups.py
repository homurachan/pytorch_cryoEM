"""Noise-group assignment matching RELION 3.1 Experiment::read.

Fresh inputs use group names (when micrograph names exist), otherwise one
group per micrograph. Numeric group IDs are derived metadata, not a substitute
for that rule. Continuations explicitly preserve saved numeric IDs so spectra
and scale arrays are never silently attached to different groups.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd


def _names(particles, label):
    values = particles[label]
    if values.isna().any() or values.astype(str).str.strip().eq('').any():
        raise ValueError(f"{label} must contain a nonempty name for every particle")
    return values.astype(str).to_numpy(copy=True)


def _pipeline_post(name):
    # filename.cpp decomposePipelineFileName: remove everything through the
    # first /jobNNN.../ component, retaining the entire following relative path.
    match = re.search(r'/job[0-9]{3}[^/]*(?:/|$)', name)
    return name[match.end():] if match else name


def assign_noise_groups(particles, *, preserve_numbers=False):
    """Return a copy with stable rlnGroupNumber/rlnGroupName, without reordering.

    New IDs follow first encounter in micrograph-sorted traversal, as upstream;
    retaining the input row order keeps image/source-row bookkeeping intact.
    With no micrograph column upstream uses one group, even if numeric IDs or
    group names were supplied. Optics groups do not define noise groups.
    """
    result = particles.copy()
    if preserve_numbers:
        if 'rlnGroupNumber' not in result:
            raise ValueError("continuation data STAR lacks rlnGroupNumber; cannot match saved noise spectra")
        numbers = pd.to_numeric(result['rlnGroupNumber'], errors='raise').to_numpy(dtype=np.float64)
        if not np.isfinite(numbers).all() or (numbers < 1).any() or (numbers != np.floor(numbers)).any():
            raise ValueError("saved rlnGroupNumber must contain positive integers")
        result['rlnGroupNumber'] = numbers.astype(np.int64)
        if 'rlnGroupName' not in result:
            result['rlnGroupName'] = [f'group_{g}' for g in result['rlnGroupNumber']]
        names = _names(result, 'rlnGroupName')
        for _, group in result.groupby('rlnGroupNumber', sort=False):
            if group['rlnGroupName'].astype(str).nunique() != 1:
                raise ValueError("saved noise group has inconsistent rlnGroupName values")
        result['rlnGroupName'] = names
        return result

    if 'rlnMicrographName' not in result:
        result['rlnGroupNumber'] = np.ones(len(result), dtype=np.int64)
        result['rlnGroupName'] = 'group'
        return result

    micrographs = _names(result, 'rlnMicrographName')
    # Frames of a movie belong to the same micrograph. The prefix before @ is
    # an image/frame locator, not a noise-group identifier.
    micrographs = np.asarray([name.split('@', 1)[-1] for name in micrographs], dtype=object)
    names = (_names(result, 'rlnGroupName') if 'rlnGroupName' in result else
             np.asarray([_pipeline_post(name) for name in micrographs], dtype=object))
    lookup = {}
    numbers = np.empty(len(result), dtype=np.int64)
    for row in np.argsort(micrographs, kind='stable'):
        name = names[row]
        if name not in lookup:
            lookup[name] = len(lookup) + 1
        numbers[row] = lookup[name]
    result['rlnGroupNumber'] = numbers
    result['rlnGroupName'] = names
    return result
