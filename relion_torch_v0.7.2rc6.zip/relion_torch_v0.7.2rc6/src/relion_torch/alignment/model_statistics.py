"""Shared RELION 3.1 statistics for 2-D observations and 2-D/3-D maps.

The scale and high-frequency expressions come from the corrected Class2D
path. Keep them shared: inverse noise belongs in scoring/backprojection, not
in these scale sums; the high-frequency image power is added once per image.
"""
from __future__ import annotations

import torch

from relion_torch.fourier.conventions import centered_rfft
from relion_torch.geometry.grids import signed_fft_indices
from relion_torch.inference.alignment import rounded_shell_indices_2d


def lowpass_model_spectra(tau2, data_vs_prior, *, original_size, pixel_size,
                          resolution, edge_shells=2.0):
    """Adjust CC output spectra after low-pass filtering the reference maps.

    MlOptimiser::maximization uses the squared raised-cosine window and an
    UNROUNDED shell cutoff here (the map filter has its own rounded cutoff).
    Shared by Class2D and Class3D; reconstruction/noise spectra are untouched.
    """
    if resolution is None or resolution <= 0:
        return tau2, data_vs_prior
    if edge_shells <= 0:
        raise ValueError("spectral low-pass edge must be positive")
    radius = float(original_size) * float(pixel_size) / float(resolution) - edge_shells / 2.0

    def filtered(curve):
        r = torch.arange(curve.numel(), device=curve.device, dtype=curve.dtype)
        t = ((r - radius) / edge_shells).clamp(0, 1)
        window = (0.5 + 0.5 * torch.cos(torch.pi * t)).square()
        return curve * window

    return [filtered(x) for x in tau2], [filtered(x) for x in data_vs_prior]

def initial_reference_tau2(reference: torch.Tensor, tau2_fudge: float) -> torch.Tensor:
    """MlModel::initialiseDataVersusPrior, for data_dim == 2.

    Average each stored RFFT coefficient once (fftw.cpp getSpectrum), then
    apply normfft/2 and tau2_fudge. This is it000 tau2, not the projector-space
    spectrum which replaces it before each expectation step.
    """
    if reference.ndim not in (2, 3) or any(v != reference.shape[-1] for v in reference.shape):
        raise ValueError("reference must be a square 2-D or cubic 3-D tensor")
    n = reference.shape[-1]
    fourier = centered_rfft(reference, ndim=reference.ndim)
    if reference.ndim == 2:
        shells = rounded_shell_indices_2d(n, reference.device)
    else:
        axis = torch.fft.fftfreq(n, d=1.0/n, device=reference.device, dtype=reference.dtype)
        x = torch.arange(n//2+1, device=reference.device, dtype=reference.dtype)
        radius2 = axis[:, None, None].square() + axis[None, :, None].square() + x[None, None, :].square()
        shells = torch.floor(radius2.sqrt() + 0.5).long()
    valid = shells <= n//2
    index = shells[valid]
    total = torch.zeros(n//2+1, device=reference.device, dtype=torch.float64)
    count = torch.zeros_like(total)
    total.scatter_add_(0, index, fourier.abs().to(torch.float64).square()[valid])
    count.scatter_add_(0, index, torch.ones_like(index, dtype=torch.float64))
    normfft = n*n if reference.ndim == 3 else 1
    return (0.5 * normfft * tau2_fudge * total / count.clamp_min(1)).to(reference.dtype)


def initial_data_vs_prior(tau2, sigma2, group_particle_counts, class_probability, reference_dim):
    """Initial evidence uses the inverse of the particle-weighted mean noise.

    tau2 already includes tau2_fudge. The 2*shell factor is specific to 3-D
    references with 2-D observations, and is one at the origin.
    """
    counts = torch.as_tensor(group_particle_counts, device=tau2.device, dtype=torch.float64)
    average_noise = (torch.stack(sigma2).to(torch.float64) * counts[:, None]).sum(0) / counts.sum()
    result = torch.where(average_noise > 0,
        tau2.to(torch.float64) * counts.sum() * class_probability / average_noise,
        torch.zeros_like(average_noise))
    if reference_dim == 3:
        shells = torch.arange(len(result), device=result.device, dtype=result.dtype)
        result = result / torch.where(shells > 0, 2.0*shells, torch.ones_like(shells))
    elif reference_dim != 2:
        raise ValueError("reference_dim must be 2 or 3")
    return result.to(torch.float32)


def accumulate_scale_statistics_(xa, aa, rows, cross_by_orientation, power_by_orientation, reliable, old_scales):
    """Accumulate posterior-weighted XA/AA over DVP>3 pixels; remove old scale.

    cross/power already include posterior weights and the old prediction
    scale. Shapes are [parent, orientation_child, active_pixel]. No inverse
    noise weighting is applied (CPU storeWeightedSums and GPU wavg).
    """
    scale = old_scales.to(xa.dtype)
    xa.index_add_(0, rows, (cross_by_orientation * reliable[:, None]).sum((1, 2)).to(xa.dtype) / scale)
    aa.index_add_(0, rows, (power_by_orientation * reliable[:, None]).sum((1, 2)).to(aa.dtype) / scale.square())


def add_high_resolution_power_(noise, masked_fourier, current_size):
    """Add full-image power above current_size once, without posterior mass.

    The caller also uses these residuals for norm correction. Count only the
    independent half-plane points, as in exp_power_img / op.power_img.
    """
    n = masked_fourier.shape[-2]
    if current_size >= n:
        return
    ns = n//2+1
    shells = rounded_shell_indices_2d(n, masked_fourier.device)
    y = signed_fft_indices(n, device=masked_fourier.device)
    high = (shells > current_size//2) & (shells < ns) & ~(
        (torch.arange(ns, device=masked_fourier.device)[None] == 0) & (y[:, None] < 0))
    if bool(high.any()):
        noise.scatter_add_(1, shells[high][None].expand(len(noise), -1),
            masked_fourier[:, high].abs().to(noise.dtype).square())
