"""Bounded packed orientation sums with batched eviction for 2-D observations.

The insert callback owns 2-D/3-D gridding. Each input already contains its
particle-specific CTF/noise factors; only these linear numerator/denominator
sums are shared across particles. This module does not select candidates.
"""
from collections import OrderedDict
import numpy as np
import torch


class GroupedOrientationAccumulator:
    def __init__(self, insert, size, max_bytes, *, counters=None, flush_rows=1024):
        self.insert = insert
        self.size = int(size)
        self.max_bytes = max(0, int(max_bytes))
        self.counts = counters if counters is not None else {}
        self.flush_rows = max(1, int(flush_rows))
        self.slots = OrderedDict()
        self.free = []
        self.numerator = self.denominator = None
        self.capacity = 0
        self.planned = False
        self.counts['group_cache_budget_bytes'] = self.max_bytes

    def _count(self, key, n):
        self.counts[key] = self.counts.get(key, 0) + int(n)

    def _allocate(self, num, den):
        self.planned = True
        pixels = self.size * (self.size//2+1)
        # Payload plus conservative index/rotation bookkeeping per flush row.
        rowbytes = pixels * (num.element_size()+den.element_size())
        total_rows = self.max_bytes // (rowbytes + 256)
        self.flush_rows = min(self.flush_rows, max(1, total_rows//5))
        self.capacity = max(0, total_rows-self.flush_rows)
        self.counts['group_cache_row_capacity'] = self.capacity
        self.counts['group_cache_flush_rows'] = self.flush_rows
        if not self.capacity:
            return
        shape = (self.capacity, self.size, self.size//2+1)
        self.numerator = torch.empty(shape, device=num.device, dtype=num.dtype)
        self.denominator = torch.empty(shape, device=den.device, dtype=den.dtype)
        self.free = list(range(self.capacity-1,-1,-1))
        self.counts['grouped_peak_bytes'] = max(self.counts.get('grouped_peak_bytes',0),self.capacity*rowbytes)

    def _flush(self, keys):
        # Several classes can share the packed cache; gridding is per class.
        by_class = {}
        for key in keys:
            slot = self.slots.pop(key)
            by_class.setdefault(key[0], []).append((key[1], slot))
            self.free.append(slot)
        for c, entries in by_class.items():
            for start in range(0,len(entries),self.flush_rows):
                part = entries[start:start+self.flush_rows]
                pairs = torch.as_tensor(part,device=self.numerator.device,dtype=torch.long)
                num = self.numerator.index_select(0,pairs[:,1])
                den = self.denominator.index_select(0,pairs[:,1])
                self.insert(c,pairs[:,0],num,den)
                self._count('grouped_flushes',1)
                self._count('grouped_flushed_rows',len(part))

    def add(self, c, ids, num, den, *, host_ids=None):
        if not len(ids):
            return
        if not self.planned:
            self._allocate(num,den)
        if not self.capacity:
            self._count('grouped_input_orientation_rows',len(ids))
            self.insert(c,ids,num,den)
            self._count('grouped_direct_rows',len(ids))
            return
        host = np.asarray(host_ids,dtype=np.int64) if host_ids is not None else ids.detach().cpu().numpy()
        unique, inverse = np.unique(host,return_inverse=True)
        # Bound an individual insertion even when the caller's tile is larger
        # than the cache. No input is discarded or moved into a hidden cache.
        if len(unique)>self.capacity:
            for start in range(0,len(unique),self.capacity):
                keep = (inverse>=start)&(inverse<start+self.capacity)
                ix = torch.as_tensor(np.flatnonzero(keep),device=num.device,dtype=torch.long)
                self.add(c,ids.index_select(0,ix),num.index_select(0,ix),den.index_select(0,ix),host_ids=host[keep])
            return
        self._count('grouped_input_orientation_rows',len(ids))
        keys = [(int(c),int(o)) for o in unique]
        needed = set(keys)
        missing = [key for key in keys if key not in self.slots]
        self._count('grouped_cache_hits',len(keys)-len(missing))
        self._count('grouped_cache_misses',len(missing))
        remove = max(0,len(missing)-len(self.free))
        if remove:
            # Flush enough rows in batches, excluding rows needed by this add.
            victims = []
            target = max(remove,min(self.flush_rows,len(self.slots)-len(needed.intersection(self.slots))))
            for key in self.slots:
                if key not in needed:
                    victims.append(key)
                    if len(victims)>=target:
                        break
            self._flush(victims)
        new_slots = []
        for key in missing:
            slot = self.free.pop()
            self.slots[key] = slot
            new_slots.append(slot)
        if new_slots:
            ix = torch.as_tensor(new_slots,device=num.device,dtype=torch.long)
            self.numerator.index_fill_(0,ix,0)
            self.denominator.index_fill_(0,ix,0)
        mapping = np.asarray([self.slots[key] for key in keys],dtype=np.int64)
        for key in keys:
            self.slots.move_to_end(key)
        ix = torch.as_tensor(mapping[inverse],device=num.device,dtype=torch.long)
        self.numerator.index_add_(0,ix,num)
        self.denominator.index_add_(0,ix,den)

    def finish(self):
        if self.slots:
            self._flush(list(self.slots))
