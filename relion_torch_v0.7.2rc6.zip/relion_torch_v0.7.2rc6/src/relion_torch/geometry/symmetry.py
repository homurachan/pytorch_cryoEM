"""RELION 3.1.4 rotational point groups and asymmetric-unit sampling.

Conventions/generators and AU planes follow src/symmetries.cpp and
healpix_sampling.cpp (RELION commit 2448e08). No external geometry library.
"""
from functools import lru_cache
import re
import math
import numpy as np
import torch
from .euler import relion_euler_matrix


def normalize_symmetry(name):
    name = str(name).strip().upper()
    if name == 'I': name = 'I2'
    if name in ('T', 'O', 'I1', 'I2', 'I3', 'I4'): return name
    if re.fullmatch(r'[CD][1-9][0-9]*', name): return name
    raise NotImplementedError('Supported rotational symmetries: Cn, Dn, T, O, I1-I4 (I=I2)')


def _rotation(axis, degrees):
    a = np.asarray(axis, dtype=float); a = a / np.linalg.norm(a)
    x,y,z = a; c = math.cos(math.radians(degrees)); s = math.sin(math.radians(degrees))
    cross = np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
    return c*np.eye(3)+(1-c)*np.outer(a,a)+s*cross


@lru_cache(maxsize=64)
def operators(name):
    """Read-only R matrices including identity; proper groups have L=identity."""
    name = normalize_symmetry(name)
    if name[0] in 'CD':
        n=int(name[1:]); values=[_rotation((0,0,1),360*k/n) for k in range(n)]
        if name[0]=='D': values += [v@_rotation((1,0,0),180) for v in values.copy()]
    else:
        definitions = {
            'T': [(3,(0,0,1)),(2,(0,math.sqrt(2/3),math.sqrt(1/3)))],
            'O': [(3,(1,1,1)),(4,(0,0,1))],
            'I2': [(2,(0,0,1)),(5,(.525731114,0,.850650807)),(3,(0,.356822076,.934172364))],
            'I1': [(2,(1,0,0)),(5,(.85065080702670,0,-.5257311142635)),(3,(.9341723640,.3568220765,0))],
            'I3': [(2,(-.5257311143,0,.8506508070)),(5,(0,0,1)),(3,(-.4911234778630044,.3568220764705179,.7946544753759428))],
            'I4': [(2,(.5257311143,0,.8506508070)),(5,(.8944271932547096,0,.4472135909903704)),(3,(.4911234778630044,.3568220764705179,.7946544753759428))],
        }
        expected={'T':12,'O':24}.get(name,60)
        generators=[_rotation(axis,360/n) for n,axis in definitions[name]]
        values=[np.eye(3)]
        for value in values:
            for generator in generators:
                candidate=value@generator
                if not any(np.max(np.abs(candidate-v))<2e-6 for v in values):
                    values.append(candidate)
                    if len(values)>expected: raise RuntimeError('Symmetry closure failed: '+name)
        if len(values)!=expected: raise RuntimeError('Incomplete symmetry group: '+name)
    out=np.stack(values);out.setflags(write=False)
    return out


def direction_vectors(directions):
    r,t=np.deg2rad(np.asarray(directions)).T
    return np.stack((np.sin(t)*np.cos(r),np.sin(t)*np.sin(r),np.cos(t)),axis=1)


def asymmetric_directions(directions, order, symmetry):
    """Return retained original NEST IDs, preserving native traversal/ties."""
    name=normalize_symmetry(symmetry); r,t=np.asarray(directions).T
    if name=='C1':return np.arange(len(r),dtype=np.int64)
    xyz=direction_vectors(directions)
    if name.startswith('C'):
        n=int(name[1:]); keep=(r>=-180/n)&(r<=180/n)
    elif name.startswith('D'):
        n=int(name[1:]);keep=t<=90
        if n>1:keep &= (r>=90-180/n)&(r<=90+180/n)
    else:
        if name=='T':
            planes=[[-.942809,0,0],[.471405,.272165,.7698],[.471404,.816497,0]]
            keep=((r>=90)&(r<=150))|(r==0)
        elif name=='O':
            planes=[[0,-1,1],[1,1,0],[-1,1,0]]
            keep=((r>=45)&(r<=135)&(t<=90))|(r==0)
        else:
            keep=np.ones(len(r),dtype=bool)
            planes=np.array([[0,1,0],[-.4999999839058737,-.8090170074556163,.3090169861701543],[.4999999839058737,-.8090170074556163,.3090169861701543]])
            if name=='I4':
                planes=-np.array([[0,0,1],[.187592467856686,-.303530987314591,-.491123477863004],[.187592467856686,.303530987314591,-.491123477863004]])
            angle={'I1':90.,'I2':0.,'I3':31.7174745559,'I4':-31.7174745559}[name]
            a=relion_euler_matrix(0.,angle,0.,dtype=torch.float64).numpy()
            planes=planes@a.T
        planes=np.asarray(planes,dtype=float);planes/=np.linalg.norm(planes,axis=1)[:,None]
        keep &= np.all(xyz@planes.T>=0,axis=1)
    ids=np.flatnonzero(keep)
    # Native seam correction is skipped when the reduced grid has >=4000 points.
    if len(ids)<4000:
        n=2**order;z=1-(1-1/n)**2/3
        dot=(2/3)*z+math.sqrt(1-4/9)*math.sqrt(1-z*z)*math.cos(math.pi/(4*n))
        cutoff=math.cos(.5*math.acos(np.clip(dot,-1,1)))
        retained=[]; mates=[]; ops=operators(name)
        for i in ids:
            if mates and np.any(np.einsum('kgj,j->kg',np.asarray(mates),xyz[i])>cutoff):continue
            retained.append(i);mates.append(np.einsum('j,gjk->gk',xyz[i],ops))
        ids=np.asarray(retained,dtype=np.int64)
    if not len(ids):raise ValueError('Symmetry leaves no directions at this HEALPix order')
    return ids


def angular_axis_distance(first, second, symmetry='C1'):
    best=None
    for op in operators(symmetry):
        mate=second@torch.tensor(op,device=second.device,dtype=second.dtype)
        distance=torch.rad2deg(torch.acos((first*mate).sum(-1).clamp(-1,1))).mean(-1)
        best=distance if best is None else torch.minimum(best,distance)
    return best


@lru_cache(maxsize=8)
def asymmetric_grid(order,symmetry):
    from relion_torch.sampling.relion_sampling import nest_directions
    directions=nest_directions(order)
    ids=asymmetric_directions(directions,order,symmetry)
    selected=directions[ids];selected.setflags(write=False);ids.setflags(write=False)
    return selected,ids


def direction_count(order,symmetry='C1'):
    return 12*4**order if normalize_symmetry(symmetry)=='C1' else len(asymmetric_grid(order,symmetry)[0])
