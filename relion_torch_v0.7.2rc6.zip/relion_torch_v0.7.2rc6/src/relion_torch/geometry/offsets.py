"""RELION old-offset decomposition and DONT_WRAP integer shifts."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import torch


def relion_round_tensor(x: torch.Tensor) -> torch.Tensor:
    """RELION 3.1 macros.h ROUND, including C++ double-literal promotion.

    Half-way values round away from zero. A float32 immediately below 0.5
    must not be rounded to 1 by first doing the addition in float32.
    Like C++ converting to int, results for NaN/Inf/out-of-range are undefined;
    callers validate metadata before invoking this device-only primitive.
    """
    value = x.to(torch.float64)
    return torch.where(value > 0, value + 0.5, value - 0.5).to(torch.int64)


@dataclass(frozen=True)
class OffsetDecomposition:
    integer_xy: torch.Tensor
    residual_xy: torch.Tensor


def split_old_offset(offset_xy_pixels: torch.Tensor) -> OffsetDecomposition:
    integer = relion_round_tensor(offset_xy_pixels)
    residual = offset_xy_pixels - integer.to(offset_xy_pixels.dtype)
    return OffsetDecomposition(integer, residual)


def dont_wrap_shift_2d(images: torch.Tensor, shift_xy: torch.Tensor) -> torch.Tensor:
    """Integer translate a batch of images with zero fill, never periodic wrap.

    Positive x moves image content to larger x indices; positive y moves image
    content to larger y indices. ``shift_xy`` may be shape ``(2,)`` or ``(B,2)``.
    """
    if images.ndim == 2:
        images = images.unsqueeze(0)
        squeeze = True
    elif images.ndim == 3:
        squeeze = False
    else:
        raise ValueError("images must be (H,W) or (B,H,W)")
    b, h, w = images.shape
    shifts = shift_xy.to(device=images.device, dtype=torch.int64)
    if shifts.ndim == 1:
        shifts = shifts.expand(b, -1)
    if tuple(shifts.shape) != (b, 2):
        raise ValueError(f"shift_xy must have shape (2,) or ({b},2)")
    out = torch.zeros_like(images)
    for i in range(b):
        sx, sy = int(shifts[i, 0]), int(shifts[i, 1])
        src_x0 = max(0, -sx); src_x1 = min(w, w - sx)
        src_y0 = max(0, -sy); src_y1 = min(h, h - sy)
        if src_x1 <= src_x0 or src_y1 <= src_y0:
            continue
        dst_x0 = src_x0 + sx; dst_x1 = src_x1 + sx
        dst_y0 = src_y0 + sy; dst_y1 = src_y1 + sy
        out[i, dst_y0:dst_y1, dst_x0:dst_x1] = images[i, src_y0:src_y1, src_x0:src_x1]
    return out[0] if squeeze else out


def dont_wrap_shift_2d_batch(images: torch.Tensor, shift_xy: torch.Tensor) -> torch.Tensor:
    """Batched integer translation without device scalar reads or wrapping.

    Two separable gathers use broadcast index views, avoiding a materialised
    B*H*W int64 coordinate tensor. Invalid pixels use where (not multiply by
    zero), so a NaN outside the source does not leak into the zero fill.
    """
    squeeze = images.ndim == 2
    if squeeze:
        images = images.unsqueeze(0)
    if images.ndim != 3:
        raise ValueError("images must be (H,W) or (B,H,W)")
    b, h, w = images.shape
    shifts = shift_xy.to(device=images.device, dtype=torch.int64)
    if shifts.ndim == 1:
        shifts = shifts.expand(b, -1)
    if tuple(shifts.shape) != (b, 2):
        raise ValueError(f"shift_xy must have shape (2,) or ({b},2)")
    # Beyond an entire image, all output is zero. Clamp before subtracting to
    # avoid overflowing coordinates for extreme but representable int64 shifts.
    sx = shifts[:, 0].clamp(-w, w)
    sy = shifts[:, 1].clamp(-h, h)
    x = torch.arange(w, device=images.device)[None, :] - sx[:, None]
    y = torch.arange(h, device=images.device)[None, :] - sy[:, None]
    valid = ((x >= 0) & (x < w))[:, None, :] & ((y >= 0) & (y < h))[:, :, None]
    out = images.gather(1, y.clamp(0, h-1)[:, :, None].expand(b, h, w))
    out = out.gather(2, x.clamp(0, w-1)[:, None, :].expand(b, h, w))
    out = torch.where(valid, out, torch.zeros((), device=out.device, dtype=out.dtype))
    return out[0] if squeeze else out
