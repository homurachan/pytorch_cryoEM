from __future__ import annotations

import torch


def signed_fft_indices(n: int, *, device: torch.device | str | None = None,
                       dtype: torch.dtype = torch.float32) -> torch.Tensor:
    """RELION FFTW logical coordinates (the even Nyquist row is positive).

    FOR_ALL_ELEMENTS_IN_FFTW_TRANSFORM uses i < XSIZE, where XSIZE=n/2+1.
    This differs from torch.fftfreq only at the even-size Nyquist row.
    """
    indices = torch.arange(n, device=device, dtype=dtype)
    return torch.where(indices < n // 2 + 1, indices, indices - n)


def rfft_frequency_coordinates_2d(
    n: int,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
    flatten: bool = False,
) -> torch.Tensor:
    """Return RFFT coordinates in Cartesian ``(x, y)`` pixel-frequency units."""

    kx = torch.arange(n // 2 + 1, device=device, dtype=dtype)
    ky = signed_fft_indices(n, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(ky, kx, indexing="ij")
    coords = torch.stack((xx, yy), dim=-1)
    return coords.reshape(-1, 2) if flatten else coords


def rfft_frequency_coordinates_3d(
    n: int,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
    flatten: bool = False,
) -> torch.Tensor:
    """Return RFFT coordinates in Cartesian ``(x, y, z)`` pixel-frequency units."""

    kx = torch.arange(n // 2 + 1, device=device, dtype=dtype)
    ky = signed_fft_indices(n, device=device, dtype=dtype)
    kz = signed_fft_indices(n, device=device, dtype=dtype)
    zz, yy, xx = torch.meshgrid(kz, ky, kx, indexing="ij")
    coords = torch.stack((xx, yy, zz), dim=-1)
    return coords.reshape(-1, 3) if flatten else coords


def rfft_multiplicity(
    n: int,
    ndim: int = 2,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """Multiplicity of RFFT coefficients in the corresponding full spectrum.

    Only the last (x) axis is reduced by RFFT. Interior x frequencies represent
    a conjugate pair and receive multiplicity two; x=0 and an even-size Nyquist
    column receive multiplicity one.
    """

    nx = n // 2 + 1
    mult_x = torch.full((nx,), 2.0, device=device, dtype=dtype)
    mult_x[0] = 1.0
    if n % 2 == 0:
        mult_x[-1] = 1.0
    shape = [1] * (ndim - 1) + [nx]
    return mult_x.reshape(shape).expand(*([n] * (ndim - 1)), nx)


def radial_frequency_pixels_2d(
    n: int,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    coords = rfft_frequency_coordinates_2d(n, device=device, dtype=dtype)
    return torch.linalg.vector_norm(coords, dim=-1)


def radial_frequency_pixels_3d(
    n: int,
    *,
    device: torch.device | str | None = None,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    coords = rfft_frequency_coordinates_3d(n, device=device, dtype=dtype)
    return torch.linalg.vector_norm(coords, dim=-1)
