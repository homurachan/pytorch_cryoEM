"""Unified RELION-3.1-style alignment optimiser.

The expectation and maximisation stages deliberately share one frozen noise
spectrum per iteration.  New noise, offset variance and Fourier-size state are
installed only for the following iteration, matching RELION's optimiser state
transition.
"""
from __future__ import annotations
from relion_torch.geometry.grids import signed_fft_indices


import ctypes
from dataclasses import dataclass
from functools import lru_cache
import math
from pathlib import Path
import shutil
import sys
import threading
import time
from typing import Any, Sequence

import mrcfile
import numpy as np
import pandas as pd
import torch

from relion_torch.alignment.core import (
    AlignmentDataset,
    ReferenceProjector,
    ValidatedBackprojectorAdapter,
    _euler_matrix,
    centered_rfft2,
    ctf_rfft,
    prepare_particle,
    read_reference,
)
from relion_torch.fourier.conventions import relion_soft_mask_outside_map
from relion_torch.alignment.model_statistics import initial_reference_tau2, initial_data_vs_prior
from relion_torch.inference.alignment import (
    AlignmentExpectation,
    AlignmentExpectationConfig,
    DenseBatchExpectation,
    SparseAdaptiveBatchExpectation,
    FourierSizeState,
    GlobalProjectionBank,
    coarse_size_from_sampling,
    dense_expectation_debug_dict,
    sparse_adaptive_debug_dict,
    expectation_debug_dict,
    independent_rfft_mask,
    phase_shift_rfft,
    rounded_shell_indices_2d,
)
from relion_torch.io.star import write_star
from relion_torch.reconstruction.ssnr import update_ssnr_arrays
from relion_torch.relion_statistics import (
    current_size_from_resolution_shell,
    repair_negative_spectrum_relion,
    repair_nonpositive_spectrum,
    resolution_shell_from_data_vs_prior,
    class_resolution_shell_from_data_vs_prior,
    shell_to_angstrom,
)
from relion_torch.sampling.relion_sampling import RelionSampling


@dataclass
class AlignmentConfig:
    input_star: Path
    references: list[Path]
    output_root: Path
    iterations: int = 1
    device: str = "cuda"
    batch_size: int = 8
    preread_images: bool = False
    io_batch_size: int = 256
    pool_size: int | None = None
    max_open_stacks: int = 8
    particle_io: str = "read"
    preread_max_gib: float | None = None
    reference_dim: int = 3
    healpix_order: int = 2
    psi_step: float | None = None
    offset_range_angstrom: float = 5.0
    offset_step_angstrom: float = 1.0
    offset_values_are_angstrom: bool = False
    oversampling: int = 0
    adaptive_fraction: float = 0.999
    skip_align: bool = False
    skip_rotate: bool = False
    skip_maximize: bool = False
    firstiter_cc: bool = False
    particle_diameter: float | None = None
    mask_edge_pixels: float = 5.0
    zero_mask: bool = False
    current_size: int | None = None
    coarse_size: int | None = None
    strict_highres_angstrom: float | None = None
    current_size_increment: int = 10
    minres_map: int = 5
    sigma_offset_angstrom: float = 10.0
    sigma_rot_deg: float = 0.0
    sigma_tilt_deg: float = 0.0
    sigma_psi_deg: float = 0.0
    tau2_fudge: float = 1.0
    padding_factor: float = 2.0
    preweight_iterations: int = 10
    random_seed: int = 0
    projector_backend: str = "validated"
    orientation_chunk_size: int = 256
    backprojector_chunk_size: int = 128
    write_debug: bool = False
    expected_accuracy_interface: bool = False
    expected_accuracy_trials: int = 100
    skip_expected_accuracy: bool = False
    # Continuation support.  iteration_offset is the last completed iteration;
    # a continued run writes offset+1 ... offset+iterations.
    iteration_offset: int = 0
    write_initial_state: bool = True


@dataclass(slots=True)
class _DensePreparedBatch:
    particle_indices: list[int]
    records: list[Any]
    group_indices: torch.Tensor
    sigma2_by_shell: torch.Tensor
    likelihood_ft: torch.Tensor
    unmasked_ft: torch.Tensor
    ctf: torch.Tensor
    integer_offsets: torch.Tensor
    offset_prior_angstrom: torch.Tensor
    orientation_prior_deg: torch.Tensor


@dataclass(slots=True)
class _DenseIterationStatistics:
    noise_sums: list[torch.Tensor]
    noise_counts: list[torch.Tensor]
    sigma_offset_square: torch.Tensor
    sigma_offset_weight: torch.Tensor
    backprojectors: ValidatedBackprojectorAdapter
    class_mass: torch.Tensor
    direction_mass: torch.Tensor


_C_RAND_LOCK = threading.Lock()

# RELION double-precision builds use XMIPP_EQUAL_ACCURACY = 1e-6.  This is
# also the threshold used by MlOptimiser::maximization() before updating SSNR
# arrays and reconstructing a class.
_RELION_EQUAL_ACCURACY = 1.0e-6


@lru_cache(maxsize=1)
def _c_random_functions() -> tuple[Any, Any]:
    # Windows cannot load the process runtime through CDLL(None). Linux keeps
    # its existing libc stream; Windows uses its own CRT and RAND_MAX below.
    libc = ctypes.CDLL("msvcrt.dll" if sys.platform.startswith("win") else None)
    srand = libc.srand
    rand = libc.rand
    srand.argtypes = [ctypes.c_uint]
    srand.restype = None
    rand.argtypes = []
    rand.restype = ctypes.c_int
    return srand, rand


def _relion_first_uniform(seed: int) -> float:
    """Return RELION 3.1's first ``rnd_unif(0,1)`` value for ``seed``.

    RELION 3.1 implements ``init_random_generator`` with the platform C
    ``srand`` and ``rnd_unif`` with the first ``rand`` result.  Accuracy
    estimation resets that generator for every tested particle and every error
    magnitude, so only this first value is required.  On the Linux platforms
    used by RELION this call reproduces the same axis choice.  A deterministic
    integer hash is retained as a portable fallback when the process C runtime
    does not export ``srand``/``rand``.
    """

    try:
        srand, rand = _c_random_functions()
        with _C_RAND_LOCK:
            srand(ctypes.c_uint(int(seed) & 0xFFFFFFFF))
            value = int(rand())
        # glibc RAND_MAX.  Only comparisons with 1/3, 2/3 and 1/2 are used,
        # so the fallback below remains harmless on non-glibc platforms.
        denominator = 32767.0 if sys.platform.startswith("win") else 2147483647.0
        return min(1.0, max(0.0, value / denominator))
    except Exception:
        value = (int(seed) ^ 0x9E3779B9) & 0xFFFFFFFF
        value ^= value >> 16
        value = (value * 0x7FEB352D) & 0xFFFFFFFF
        value ^= value >> 15
        value = (value * 0x846CA68B) & 0xFFFFFFFF
        value ^= value >> 16
        return value / float(2**32 - 1)


def _relion_accuracy_error_grid(mode: str) -> tuple[list[float], float]:
    """Return tested errors and RELION's out-of-range fallback value."""

    error = 0.0
    values: list[float] = []
    while True:
        if mode == "rotation":
            if error < 0.2:
                step = 0.05
            elif error < 1.0:
                step = 0.1
            elif error < 2.0:
                step = 0.2
            elif error < 5.0:
                step = 0.5
            elif error < 10.0:
                step = 1.0
            elif error < 20.0:
                step = 2.0
            else:
                step = 5.0
            limit = 30.0
        elif mode == "translation":
            if error < 1.0:
                step = 0.1
            elif error < 2.0:
                step = 0.2
            elif error < 5.0:
                step = 0.5
            elif error < 10.0:
                step = 1.0
            else:
                step = 2.0
            limit = 10.0
        else:
            raise ValueError(f"unknown accuracy mode {mode!r}")
        error += step
        if error > limit:
            return values, error
        values.append(error)


@lru_cache(maxsize=32)
def _relion_3d_coverage_shell_counts(max_shell: int) -> np.ndarray:
    """Count the voxels RELION uses for total Fourier completeness.

    ``MlModel::calculateTotalFourierCoverage`` builds an odd cube of side
    ``2*max_shell-1``, truncates each Euclidean radius to an integer shell,
    and averages the shell-wise Fourier coverage over all voxels with
    ``r <= max_shell``.  The slice-wise implementation keeps peak memory
    small even when a refinement reaches Nyquist.
    """

    radius = int(max_shell)
    if radius <= 0:
        return np.zeros(1, dtype=np.float64)
    axis = np.arange(1 - radius, radius, dtype=np.int64)
    yy, xx = np.meshgrid(axis, axis, indexing="ij")
    in_plane_squared = xx * xx + yy * yy
    counts = np.zeros(radius + 1, dtype=np.float64)
    for zz in axis:
        shells = np.floor(np.sqrt(in_plane_squared + zz * zz)).astype(
            np.int64, copy=False
        )
        valid = shells <= radius
        counts += np.bincount(
            shells[valid].reshape(-1), minlength=radius + 1
        )[: radius + 1]
    return counts


class AlignmentOptimiser:
    def __init__(self, config: AlignmentConfig, *, dataset: AlignmentDataset | None = None,
                 initial_references: Sequence[torch.Tensor] | None = None) -> None:
        self.config = config
        self._validate_config()
        # RELION disables adaptive oversampling when all orientations are fixed
        # (--skip_align or --skip_rotate).  Keeping a two-pass child search in
        # those modes changes both the hypothesis set and metadata semantics.
        if self.config.skip_align or self.config.skip_rotate:
            self.config.oversampling = 0
        self.device = torch.device(
            config.device
            if config.device != "cuda" or torch.cuda.is_available()
            else "cpu"
        )
        self.dataset = dataset if dataset is not None else AlignmentDataset.from_config(config)
        if initial_references is None:
            from relion_torch.io.reference_input import read_reference_images
            self.references = read_reference_images(config.references, self.device)
        else:
            if len(initial_references) != len(config.references):
                raise ValueError("in-memory reference count differs from configuration")
            self.references = [image.detach().to(device=self.device, dtype=torch.float32).clone()
                               for image in initial_references]
        if not self.references:
            raise ValueError("at least one reference is required")
        if any(int(ref.ndim) != int(config.reference_dim) for ref in self.references):
            shapes = [tuple(ref.shape) for ref in self.references]
            raise ValueError(
                f"reference_dim={config.reference_dim} is incompatible with references {shapes}"
            )

        self.particle_diameter_is_default = config.particle_diameter is None
        self.particle_diameter_angstrom = self._effective_particle_diameter()
        self.projectors = self._make_reference_projectors(self.references)
        # Keep the small model-PDF vector in double precision, matching the
        # RELION build used for parity tests.  Large likelihood/projection
        # tensors remain float32; only the occupancy state needs this range.
        self.class_prob = torch.full(
            (len(self.references),),
            1.0 / len(self.references),
            device=self.device,
            dtype=torch.float64,
        )
        self.direction_priors: torch.Tensor | None = None
        self.rotation_accuracy_deg = torch.zeros(
            len(self.references), device=self.device, dtype=torch.float64
        )
        self.translation_accuracy_angstrom = torch.zeros_like(
            self.rotation_accuracy_deg
        )
        self.orientability_contrib: list[torch.Tensor] | None = None

        self.group_ids = sorted(
            {self.dataset.record(index).group_number for index in range(len(self.dataset))}
        )
        self.group_to_index = {
            group_number: index for index, group_number in enumerate(self.group_ids)
        }
        self.group_particle_counts = [
            sum(
                self.dataset.record(index).group_number == group_number
                for index in range(len(self.dataset))
            )
            for group_number in self.group_ids
        ]
        self.group_names = self._group_names()

        self.sigma_offset_angstrom = float(config.sigma_offset_angstrom)
        self.sigma2 = self._initial_noise()
        self.tau2 = [self._reference_tau2(reference) for reference in self.references]
        self.data_vs_prior = [
            self._initial_data_vs_prior(class_index)
            for class_index in range(len(self.references))
        ]
        n_shells = self.dataset.box_size // 2 + 1
        self.sigma2_class = [
            torch.zeros(n_shells, device=self.device, dtype=reference.dtype)
            for reference in self.references
        ]
        self.fourier_coverage = [
            torch.zeros(n_shells, device=self.device, dtype=reference.dtype)
            for reference in self.references
        ]
        self.psnr_shell = self._safe_psnr_shell(self.data_vs_prior)

        offset_unit = (
            1.0 if config.offset_values_are_angstrom else self.dataset.pixel_size
        )
        self.sampling = RelionSampling(
            config.reference_dim,
            config.healpix_order,
            config.psi_step,
            config.offset_range_angstrom * offset_unit,
            config.offset_step_angstrom * offset_unit,
            config.oversampling,
        )
        if config.reference_dim == 3:
            nr_directions = len(self.sampling.directions)
            self.direction_priors = torch.full(
                (len(self.references), nr_directions),
                1.0 / max(1, nr_directions),
                device=self.device,
                dtype=torch.float32,
            )
        self.sizes = self._fourier_size_state()
        # ``self.psnr_shell`` is updated after maximisation for the next
        # iteration, whereas RELION serialises rlnCurrentResolution together
        # with the Fourier size that was actually used in the just-completed
        # expectation.  Preserve that working state separately so the two
        # fields cannot describe different iterations.
        self.working_psnr_shell = int(self.psnr_shell)
        self.working_current_size = int(self.sizes.current_size)

    def _updated_reference_projector(self, class_index):
        """Default eager update; Class3D substitutes a bounded projector pool."""
        return ReferenceProjector(self.references[class_index], self.config.padding_factor,
            self.config.projector_backend, current_size=self.sizes.current_size)

    def _make_reference_projectors(self, references):
        return [ReferenceProjector(r, self.config.padding_factor, self.config.projector_backend)
                for r in references]

    def _validate_config(self) -> None:
        from relion_torch.io.particle_store import ParticleIOOptions
        ParticleIOOptions.from_config(self.config).validate(self.config.batch_size)
        if self.config.iterations < 1:
            raise ValueError("iterations must be positive")
        if self.config.batch_size < 1:
            raise ValueError("batch_size must be positive")
        if self.config.orientation_chunk_size < 1:
            raise ValueError("orientation_chunk_size must be positive")
        if self.config.backprojector_chunk_size < 1:
            raise ValueError("backprojector_chunk_size must be positive")
        if self.config.reference_dim not in (2, 3):
            raise ValueError("reference_dim must be 2 or 3")
        if self.config.oversampling < 0:
            raise ValueError("oversampling must be non-negative")
        if not 0.0 < self.config.adaptive_fraction <= 1.0:
            raise ValueError("adaptive_fraction must be in (0,1]")
        if self.config.mask_edge_pixels < 0:
            raise ValueError("mask_edge_pixels must be non-negative")
        if self.config.sigma_offset_angstrom < 0:
            raise ValueError("sigma_offset_angstrom must be non-negative")
        if self.config.expected_accuracy_trials < 0:
            raise ValueError("expected_accuracy_trials must be non-negative")
        if self.config.iteration_offset < 0:
            raise ValueError("iteration_offset must be non-negative")

    @staticmethod
    def _column_name(frame: pd.DataFrame, name: str) -> str | None:
        for candidate in (name, "_" + name):
            if candidate in frame.columns:
                return candidate
        return None

    def _group_names(self) -> list[str]:
        group_column = self._column_name(self.dataset.particles, "rlnGroupNumber")
        name_column = self._column_name(self.dataset.particles, "rlnGroupName")
        names: list[str] = []
        for group_number in self.group_ids:
            fallback = f"group_{group_number}"
            if group_column is None or name_column is None:
                names.append(fallback)
                continue
            rows = self.dataset.particles[
                pd.to_numeric(
                    self.dataset.particles[group_column], errors="coerce"
                ).fillna(-1).astype(int)
                == int(group_number)
            ]
            if rows.empty:
                names.append(fallback)
                continue
            value = str(rows.iloc[0][name_column])
            names.append(value if value and value.lower() != "nan" else fallback)
        return names

    def _effective_particle_diameter(self) -> float:
        diameter = self.config.particle_diameter
        if diameter is None:
            # RELION's non-helical default is (ori_size-width_mask_edge)*pixel.
            diameter = (
                float(self.dataset.box_size) - float(self.config.mask_edge_pixels)
            ) * float(self.dataset.pixel_size)
        if diameter <= 0:
            raise ValueError("particle_diameter must be positive")
        return float(diameter)

    def _initial_noise(self) -> list[torch.Tensor]:
        """RELION initial per-group component variance.

        Under ``--zero_mask`` RELION applies the soft particle mask before both
        the individual particle power spectra and the average-image spectrum are
        accumulated.  The previous alignment path transformed the raw square
        images and therefore overestimated the iteration-0 noise.
        """

        n = self.dataset.box_size
        shells = rounded_shell_indices_2d(n, self.device)
        n_shells = n // 2 + 1
        # RELION averages the coefficients that are physically stored in the
        # FFTW R2C half-plane.  It does not apply a Hermitian multiplicity of
        # two to interior x columns during this initial spectrum estimate.
        valid = shells < n_shells
        sums = [
            torch.zeros(n_shells, device=self.device, dtype=torch.float64)
            for _ in self.group_ids
        ]
        counts = [torch.zeros_like(value) for value in sums]
        average_ft = torch.zeros(
            (n, n // 2 + 1), device=self.device, dtype=torch.complex128
        )
        mask_radius = self.particle_diameter_angstrom / (
            2.0 * float(self.dataset.pixel_size)
        )

        pool_size = self.dataset.io_options.effective_pool(self.config.batch_size)
        for particle_indices, raw_images in self.dataset.iter_image_batches(
                device=self.device, batch_size=1, pool_size=pool_size):
            particle_index = particle_indices[0]
            image = raw_images[0]
            if self.config.zero_mask:
                image = relion_soft_mask_outside_map(
                    image,
                    radius_pixels=mask_radius,
                    cosine_width_pixels=float(self.config.mask_edge_pixels),
                    ndim=2,
                )
            fourier = centered_rfft2(image).to(torch.complex128)
            average_ft += fourier
            group_index = self.group_to_index[
                self.dataset.record(particle_index).group_number
            ]
            power = fourier.real.square() + fourier.imag.square()
            sums[group_index].scatter_add_(0, shells[valid], power[valid])
            counts[group_index].scatter_add_(
                0, shells[valid], torch.ones_like(power[valid], dtype=torch.float64)
            )

        average_ft /= max(1, len(self.dataset))
        average_power = average_ft.real.square() + average_ft.imag.square()
        average_shell = torch.zeros(
            n_shells, device=self.device, dtype=torch.float64
        )
        average_count = torch.zeros_like(average_shell)
        average_shell.scatter_add_(0, shells[valid], average_power[valid])
        average_count.scatter_add_(
            0,
            shells[valid],
            torch.ones_like(average_power[valid], dtype=torch.float64),
        )
        average_shell /= average_count.clamp_min(1.0)

        spectra: list[torch.Tensor] = []
        for total, count in zip(sums, counts):
            particle_mean = total / count.clamp_min(1.0)
            sigma = 0.5 * (particle_mean - average_shell)
            sigma = repair_negative_spectrum_relion(sigma, minimum=1.0e-20)
            spectra.append(sigma.to(torch.float32))
        return spectra

    def _reference_tau2(self, reference: torch.Tensor) -> torch.Tensor:
        return initial_reference_tau2(reference, self.config.tau2_fudge)

    def _initial_data_vs_prior(self, class_index: int) -> torch.Tensor:
        return initial_data_vs_prior(self.tau2[class_index], self.sigma2,
            self.group_particle_counts, self.class_prob[class_index], self.config.reference_dim)

    def _safe_psnr_shell(self, curves: Sequence[torch.Tensor]) -> int:
        if not curves:
            return max(1, int(self.config.minres_map))
        return resolution_shell_from_data_vs_prior(
            torch.stack([curve.detach() for curve in curves]),
            min_shell=int(self.config.minres_map),
        )

    def _fourier_size_state(self) -> FourierSizeState:
        n = self.dataset.box_size
        if self.config.current_size is None:
            current = current_size_from_resolution_shell(
                n,
                self.psnr_shell,
                increment=self.config.current_size_increment,
            )
        else:
            current = int(self.config.current_size)
        current = min(n, max(2, current))
        if current % 2:
            current -= 1
        current = max(2, current)

        if (
            self.config.strict_highres_angstrom is not None
            and self.config.strict_highres_angstrom > 0
        ):
            # RELION lets strict_highres_exp override the usual coarse-size
            # choice even when adaptive oversampling is disabled.  Probability
            # scoring is restricted, while Mresol_fine and weighted sums retain
            # the full working current size.
            strict_shell = max(
                1,
                int(
                    math.floor(
                        n
                        * float(self.dataset.pixel_size)
                        / float(self.config.strict_highres_angstrom)
                        + 0.5
                    )
                ),
            )
            coarse = min(current, 2 * strict_shell)
        elif self.config.oversampling <= 0:
            # Without a strict cutoff, oversampling=0 is a single current-size pass.
            coarse = current
        elif self.config.coarse_size is not None:
            coarse = min(current, max(2, int(self.config.coarse_size)))
            if coarse % 2:
                coarse -= 1
        else:
            angular_step = (
                360.0 / (6.0 * (1 << self.config.healpix_order))
                if self.config.reference_dim == 3
                else self.sampling.actual_psi_step
            )
            coarse = coarse_size_from_sampling(
                original_size=n,
                pixel_size=self.dataset.pixel_size,
                particle_diameter=self.particle_diameter_angstrom,
                angular_step_deg=angular_step,
                reference_dim=self.config.reference_dim,
                current_size=current,
                strict_highres_angstrom=self.config.strict_highres_angstrom,
            )
        return FourierSizeState(
            n,
            self.dataset.pixel_size,
            current,
            coarse,
            self.config.strict_highres_angstrom,
        )

    def _refresh_fourier_sizes(self) -> None:
        self.psnr_shell = self._safe_psnr_shell(self.data_vs_prior)
        self.sizes = self._fourier_size_state()

    def _current_tau2(self) -> list[torch.Tensor]:
        """Return RELION's current projector-space tau虏 for every class.

        ``it000`` retains the raw-map spectrum used during model
        initialisation.  Before each expectation, RELION rebuilds ``PPref`` via
        ``computeFourierTransformMap(..., tau2_class, current_size, ...)`` and
        replaces the working tau虏 with the radial power of that padded,
        gridding-corrected projector.  Use the already-built projector objects
        here so the prior and the likelihood projections share one Fourier
        representation.
        """

        spectra: list[torch.Tensor] = []
        for projector in self.projectors:
            # Bind source support once per iteration, before both tau2 and any
            # coarse/fine/accuracy projections. Output sizes never rebind it.
            projector.set_source_support(self.sizes.current_size)
            tau = projector.power_spectrum(self.sizes.current_size).clone()
            tau[self.sizes.current_shell + 1 :] = 0.0
            spectra.append(tau)
        return spectra

    def _accuracy_ctf(self, record, n, dtype):
        return ctf_rfft(record, n, self.device, dtype)

    @torch.no_grad()
    def _accuracy_projector(self, projector, record):
        return projector

    def _calculate_expected_accuracies(
        self, sigma2_old: Sequence[torch.Tensor], *, particle_indices=None
    ) -> None:
        """Estimate RELION-style rotational and translational accuracies.

        This follows ``MlOptimiser::calculateExpectedAngularErrors``: for the
        configured number of trials (Class2D default 10; 3D default 100),
        perturb one deterministic Euler component or one image
        shift until the model likelihood ratio reaches ``P=0.01``
        (``-log(P)=4.60517``).  The candidate error schedule, CTF/noise
        weighting, current-size support and per-shell orientability histogram
        follow the RELION 3.1 routine.  Candidate projections are evaluated as
        batches, avoiding the original scalar while-loop cost.
        """

        n_trials = min(
            int(self.config.expected_accuracy_trials), len(self.dataset) if particle_indices is None else len(particle_indices)
        )
        n_classes = len(self.references)
        n_shells = self.dataset.box_size // 2 + 1
        self.orientability_contrib = [
            torch.zeros(n_shells, device=self.device, dtype=torch.float64)
            for _ in range(n_classes)
        ]
        if n_trials <= 0 or self.config.skip_align:
            self.rotation_accuracy_deg.zero_()
            self.translation_accuracy_angstrom.zero_()
            return

        size = int(self.sizes.likelihood_image_size(True))
        maximum_shell = int(self.sizes.likelihood_shell(True))
        shells = rounded_shell_indices_2d(size, self.device)
        active = independent_rfft_mask(size, maximum_shell, self.device)
        active_shells = shells[active]
        rotation_values, rotation_fallback = _relion_accuracy_error_grid(
            "rotation"
        )
        translation_values, translation_fallback = _relion_accuracy_error_grid(
            "translation"
        )
        rotation_errors = torch.tensor(
            rotation_values, device=self.device, dtype=torch.float32
        )
        translation_errors = torch.tensor(
            translation_values, device=self.device, dtype=torch.float32
        )
        threshold = 4.60517
        n = int(self.dataset.box_size)

        for class_index, projector in enumerate(self.projectors):
            if float(self.class_prob[class_index].item()) < 0.01:
                self.rotation_accuracy_deg[class_index] = 999.0
                self.translation_accuracy_angstrom[class_index] = 999.0
                continue

            accumulated_rotation = 0.0
            accumulated_translation = 0.0
            orientability = self.orientability_contrib[class_index]

            for trial in range(n_trials):
                particle_index = trial if particle_indices is None else int(particle_indices[trial])
                record = self.dataset.record(particle_index)
                group_index = self.group_to_index[record.group_number]
                # The upstream accuracy diagnostic builds A1/A2 directly
                # from metadata, including for a 2-D reference. It bypasses
                # HealpixSampling::addOneOrientation(). This is deliberately
                # NOT the psi-only Class2D search/backprojection convention.
                base_euler = (record.rot, record.tilt, record.psi)
                base_angles = torch.tensor(
                    [base_euler],
                    device=self.device,
                    dtype=torch.float32,
                )
                trial_projector = self._accuracy_projector(projector, record)
                base_projection = trial_projector(base_angles, size)[0]
                ctf_full = self._accuracy_ctf(record, n, base_projection.real.dtype)
                ctf = AlignmentExpectation._window_rfft(ctf_full, size).to(
                    base_projection.real.dtype
                )
                base_prediction = base_projection * ctf
                sigma = sigma2_old[group_index].to(
                    device=self.device, dtype=base_projection.real.dtype
                )[active_shells]
                inverse_two_sigma = torch.where(
                    sigma > 0.0,
                    1.0 / (2.0 * sigma),
                    torch.zeros_like(sigma),
                )
                random_value = _relion_first_uniform(
                    int(self.config.random_seed) + int(record.row)
                )

                if not self.config.skip_rotate:
                    if self.config.reference_dim == 3:
                        axis = (
                            0
                            if random_value < 0.3333
                            else (1 if random_value < 0.6667 else 2)
                        )
                    else:
                        axis = 2
                    perturbed_angles = base_angles.expand(
                        rotation_errors.numel(), -1
                    ).clone()
                    perturbed_angles[:, axis] += rotation_errors
                    perturbed = trial_projector.project_batch(
                        perturbed_angles,
                        size,
                        chunk_size=self.config.orientation_chunk_size,
                    )
                    delta = perturbed * ctf[None, ...] - base_prediction[None, ...]
                    coefficient = (
                        delta.real.square() + delta.imag.square()
                    )[:, active] * inverse_two_sigma[None, :]
                    snr = coefficient.sum(dim=-1)
                    crossing = torch.nonzero(
                        snr > threshold, as_tuple=False
                    ).squeeze(-1)
                    if crossing.numel() > 0:
                        first = int(crossing[0].item())
                        accumulated_rotation += rotation_values[first]
                        orientability.scatter_add_(
                            0,
                            active_shells,
                            coefficient[first].to(torch.float64),
                        )
                    else:
                        accumulated_rotation += rotation_fallback

                # RELION resets the same C RNG seed for the translation mode,
                # so the first uniform value is identical to the angular mode.
                shift_axis = 0 if random_value < 0.5 else 1
                shifts = torch.zeros(
                    (translation_errors.numel(), 2),
                    device=self.device,
                    dtype=base_projection.real.dtype,
                )
                shifts[:, shift_axis] = translation_errors
                phases = phase_shift_rfft(
                    (size, size // 2 + 1),
                    shifts,
                    self.device,
                    base_projection.real.dtype,
                    original_size=n,
                )
                translated = base_projection[None, ...] * phases
                delta = translated * ctf[None, ...] - base_prediction[None, ...]
                coefficient = (
                    delta.real.square() + delta.imag.square()
                )[:, active] * inverse_two_sigma[None, :]
                snr = coefficient.sum(dim=-1)
                crossing = torch.nonzero(
                    snr > threshold, as_tuple=False
                ).squeeze(-1)
                if crossing.numel() > 0:
                    first = int(crossing[0].item())
                    accumulated_translation += (
                        translation_values[first] * float(record.pixel_size)
                    )
                else:
                    accumulated_translation += (
                        translation_fallback * float(record.pixel_size)
                    )

            if self.config.skip_rotate:
                self.rotation_accuracy_deg[class_index] = 0.0
            else:
                self.rotation_accuracy_deg[class_index] = (
                    accumulated_rotation / float(n_trials)
                )
            self.translation_accuracy_angstrom[class_index] = (
                accumulated_translation / float(n_trials)
            )
            orientability_sum = orientability.sum()
            if float(orientability_sum.item()) > 0.0:
                orientability /= orientability_sum

        print(
            f"Estimated assignment accuracy ({n_trials} trial particles, metadata Euler): rotations "
            + ", ".join(
                f"{float(value):.6g} deg"
                for value in self.rotation_accuracy_deg.detach().cpu()
            )
            + "; translations "
            + ", ".join(
                f"{float(value):.6g} A"
                for value in self.translation_accuracy_angstrom.detach().cpu()
            )
        )

    def _class_resolution_shells(self) -> list[int]:
        # RELION keeps serialising the last stored data-versus-prior curve for
        # an empty class.  A zero class probability therefore does not imply an
        # artificial shell-zero/"inf" estimated resolution in the model STAR.
        return [
            class_resolution_shell_from_data_vs_prior(curve)
            for curve in self.data_vs_prior
        ]

    def _overall_completeness(self, class_index: int, shell: int) -> float:
        """Return RELION's 3-D voxel-weighted Fourier completeness.

        This is intentionally not an unweighted mean over radial shells.
        RELION expands the radial curve through the odd cube that fits inside
        the estimated-resolution radius and averages the value assigned to
        every voxel, including the origin shell.
        """

        coverage = self.fourier_coverage[class_index]
        max_shell = min(int(shell), int(coverage.numel()) - 1)
        if max_shell <= 0:
            # Native coverwindow=2*maxres-1 has no voxels at maxres=0:
            # report undefined completeness, not an apparently measured zero.
            return float("nan")
        counts = _relion_3d_coverage_shell_counts(max_shell)
        denominator = float(counts.sum())
        if denominator <= 0.0:
            return 0.0
        values = (
            coverage[: max_shell + 1]
            .detach()
            .to(device="cpu", dtype=torch.float64)
            .numpy()
        )
        return float(np.dot(counts, values) / denominator)

    def _model_blocks(
        self,
        reference_paths: Sequence[str],
        *,
        log_likelihood: float,
        average_pmax: float,
        initial_state: bool = False,
    ) -> dict[str, pd.DataFrame]:
        n = self.dataset.box_size
        pixel = self.dataset.pixel_size
        n_shells = n // 2 + 1
        spectral_index = np.arange(n_shells, dtype=np.int64)
        frequency = spectral_index.astype(np.float64) / (n * pixel)
        angstrom = np.full(n_shells, np.inf, dtype=np.float64)
        angstrom[1:] = 1.0 / frequency[1:]
        class_shells = self._class_resolution_shells()

        general = pd.DataFrame(
            [
                {
                    "rlnReferenceDimensionality": self.config.reference_dim,
                    "rlnDataDimensionality": 2,
                    "rlnOriginalImageSize": n,
                    # RELION serialises the pre-expectation it000 general
                    # state as inf/0.  The class rows still carry the initial
                    # DVP-derived estimated resolution used by expectationSetup.
                    "rlnCurrentResolution": (
                        float("inf")
                        if initial_state
                        else shell_to_angstrom(
                            n, pixel, self.working_psnr_shell
                        )
                    ),
                    "rlnCurrentImageSize": (
                        0 if initial_state else self.working_current_size
                    ),
                    "rlnPaddingFactor": self.config.padding_factor,
                    "rlnIsHelix": 0,
                    "rlnFourierSpaceInterpolator": 1,
                    "rlnMinRadiusNnInterpolation": 10,
                    "rlnPixelSize": pixel,
                    "rlnNrClasses": len(self.references),
                    "rlnNrBodies": 1,
                    "rlnNrGroups": len(self.group_ids),
                    "rlnTau2FudgeFactor": self.config.tau2_fudge,
                    "rlnNormCorrectionAverage": 1.0,
                    "rlnSigmaOffsetsAngst": self.sigma_offset_angstrom,
                    "rlnOrientationalPriorMode": 0,
                    "rlnSigmaPriorRotAngle": self.config.sigma_rot_deg,
                    "rlnSigmaPriorTiltAngle": self.config.sigma_tilt_deg,
                    "rlnSigmaPriorPsiAngle": self.config.sigma_psi_deg,
                    "rlnLogLikelihood": log_likelihood,
                    "rlnAveragePmax": average_pmax,
                }
            ]
        )
        classes = pd.DataFrame(
            {
                "rlnReferenceImage": list(reference_paths),
                "rlnClassDistribution": self.class_prob.detach().cpu().numpy(),
                "rlnAccuracyRotations": self.rotation_accuracy_deg.detach()
                .cpu()
                .numpy(),
                "rlnAccuracyTranslationsAngst": (
                    self.translation_accuracy_angstrom.detach().cpu().numpy()
                ),
                "rlnEstimatedResolution": [
                    shell_to_angstrom(n, pixel, shell) for shell in class_shells
                ],
                "rlnOverallFourierCompleteness": [
                    self._overall_completeness(class_index, shell)
                    for class_index, shell in enumerate(class_shells)
                ],
            }
        )
        blocks: dict[str, pd.DataFrame] = {
            "model_general": general,
            "model_classes": classes,
        }
        zeros = np.zeros(n_shells, dtype=np.float64)
        for class_index in range(len(self.references)):
            class_spectrum: dict[str, np.ndarray] = {
                "rlnSpectralIndex": spectral_index,
                "rlnResolution": frequency,
                "rlnAngstromResolution": angstrom,
                "rlnSsnrMap": self.data_vs_prior[class_index]
                .detach()
                .cpu()
                .numpy(),
                "rlnGoldStandardFsc": zeros,
                "rlnFourierCompleteness": self.fourier_coverage[class_index]
                .detach()
                .cpu()
                .numpy(),
                "rlnReferenceSigma2": self.sigma2_class[class_index]
                .detach()
                .cpu()
                .numpy(),
                "rlnReferenceTau2": self.tau2[class_index]
                .detach()
                .cpu()
                .numpy(),
            }
            if self.orientability_contrib is not None:
                class_spectrum["rlnSpectralOrientabilityContribution"] = (
                    self.orientability_contrib[class_index]
                    .detach()
                    .cpu()
                    .numpy()
                )
            blocks[f"model_class_{class_index + 1}"] = pd.DataFrame(
                class_spectrum
            )
        blocks["model_groups"] = pd.DataFrame(
            {
                "rlnGroupNumber": self.group_ids,
                "rlnGroupName": self.group_names,
                "rlnGroupNrParticles": self.group_particle_counts,
                "rlnGroupScaleCorrection": np.ones(len(self.group_ids)),
            }
        )
        for group_index in range(len(self.group_ids)):
            blocks[f"model_group_{group_index + 1}"] = pd.DataFrame(
                {
                    "rlnSpectralIndex": spectral_index,
                    "rlnResolution": frequency,
                    "rlnSigma2Noise": self.sigma2[group_index]
                    .detach()
                    .cpu()
                    .numpy(),
                }
            )
        if self.config.reference_dim == 3:
            number_of_directions = len(self.sampling.directions)
            if self.direction_priors is None:
                conditional_direction = torch.full(
                    (len(self.references), number_of_directions),
                    1.0 / max(1, number_of_directions),
                    device=self.device,
                    dtype=self.class_prob.dtype,
                )
            else:
                conditional_direction = self.direction_priors.to(
                    device=self.device, dtype=self.class_prob.dtype
                )
                row_sum = conditional_direction.sum(dim=1, keepdim=True)
                conditional_direction = torch.where(
                    row_sum > 0,
                    conditional_direction / row_sum.clamp_min(
                        torch.finfo(conditional_direction.dtype).tiny
                    ),
                    torch.full_like(
                        conditional_direction,
                        1.0 / max(1, number_of_directions),
                    ),
                )
            # RELION serialises pdf_direction as the joint class/direction
            # probability.  Internally this implementation keeps a conditional
            # direction distribution and a separate class prior.
            joint_direction = (
                conditional_direction
                * self.class_prob.to(conditional_direction.dtype)[:, None]
            )
            for class_index in range(len(self.references)):
                blocks[f"model_pdf_orient_class_{class_index + 1}"] = (
                    pd.DataFrame(
                        {
                            "rlnOrientationDistribution": joint_direction[
                                class_index
                            ]
                            .detach()
                            .cpu()
                            .numpy()
                        }
                    )
                )
        return blocks

    def _reference_image_names(self, iteration: int) -> list[str]:
        from relion_torch.io.reference_output import reference_image_names
        return reference_image_names(f"{self.config.output_root}_it{iteration:03d}",
                                     len(self.references), self.config.reference_dim)

    def _write_reference_maps(self, maps, iteration: int) -> list[str]:
        from relion_torch.io.reference_output import write_reference_images
        return write_reference_images(maps, f"{self.config.output_root}_it{iteration:03d}",
            reference_dim=self.config.reference_dim, pixel_size_angstrom=self.dataset.pixel_size,
            counters=getattr(self, '_perf_counters', None))

    def _write_initial_state(self) -> None:
        output = self.config.output_root
        self._write_data(
            self.dataset.particles.copy(), str(output) + "_it000_data.star"
        )
        if self.config.reference_dim == 2:
            reference_paths = self._write_reference_maps(self.references, 0)
        else:
            # 3-D retains its per-volume initial output and header semantics.
            reference_paths = []
            for class_index, source in enumerate(self.config.references, start=1):
                destination = Path(str(output) + f"_it000_class{class_index:03d}.mrc")
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
                reference_paths.append(str(destination))
        write_star(
            self._model_blocks(
                reference_paths,
                log_likelihood=0.0,
                average_pmax=0.0,
                initial_state=True,
            ),
            str(output) + "_it000_model.star",
            overwrite=True,
        )

    def _expectation_engine(self, iteration: int) -> AlignmentExpectation:
        def project(
            class_index: int, angles: torch.Tensor, size: int
        ) -> torch.Tensor:
            return self.projectors[class_index](angles, size)

        project.source_cache_token = lambda: tuple(p.source_cache_token for p in self.projectors)
        expectation_config = AlignmentExpectationConfig(
            adaptive_fraction=self.config.adaptive_fraction,
            firstiter_cc=self.config.firstiter_cc and iteration == 1,
            skip_align=self.config.skip_align,
            skip_rotate=self.config.skip_rotate,
            adaptive_oversampling=self.config.oversampling,
            sigma_offset_angstrom=self.sigma_offset_angstrom,
            sigma_rot_deg=self.config.sigma_rot_deg,
            sigma_tilt_deg=self.config.sigma_tilt_deg,
            sigma_psi_deg=self.config.sigma_psi_deg,
            chunk_size=self.config.orientation_chunk_size,
        )
        return AlignmentExpectation(
            self.sampling,
            self.sizes,
            project,
            self.class_prob,
            direction_priors=self.direction_priors,
            config=expectation_config,
        )

    def _dense_global_enabled(self) -> bool:
        """Return whether the matrix global-search path can be used."""

        return (
            not self.config.skip_align
            and not self.config.skip_rotate
            and self.config.oversampling >= 0
        )

    def _prepare_dense_batch(
        self,
        particle_indices: Sequence[int],
        sigma2_old: Sequence[torch.Tensor],
        raw_images: torch.Tensor | None = None,
    ) -> _DensePreparedBatch:
        records: list[Any] = []
        group_indices: list[int] = []
        sigma_rows: list[torch.Tensor] = []
        likelihood: list[torch.Tensor] = []
        unmasked: list[torch.Tensor] = []
        ctfs: list[torch.Tensor] = []
        integer_offsets: list[torch.Tensor] = []
        offset_priors: list[tuple[float, float]] = []
        orientation_priors: list[tuple[float, float, float]] = []
        pixel = float(self.dataset.pixel_size)

        for local_index, particle_index in enumerate(particle_indices):
            record = self.dataset.record(int(particle_index))
            group_index = self.group_to_index[record.group_number]
            likelihood_ft, unmasked_ft, integer_offset, _residual_offset = (
                prepare_particle(
                    self.dataset.load_image(int(particle_index)) if raw_images is None else raw_images[local_index],
                    record,
                    particle_diameter=self.particle_diameter_angstrom,
                    mask_edge_pixels=self.config.mask_edge_pixels,
                    zero_mask=self.config.zero_mask,
                    sigma2_by_shell=sigma2_old[group_index],
                    device=self.device,
                    seed=self.config.random_seed,
                )
            )
            ctf = ctf_rfft(
                record,
                self.dataset.box_size,
                self.device,
                likelihood_ft.real.dtype,
            )
            records.append(record)
            group_indices.append(group_index)
            sigma_rows.append(sigma2_old[group_index])
            likelihood.append(likelihood_ft)
            unmasked.append(unmasked_ft)
            ctfs.append(ctf)
            integer_offsets.append(integer_offset.to(device=self.device))
            offset_priors.append(
                (
                    record.origin_prior_x_angstrom
                    - float(integer_offset[0].item()) * pixel,
                    record.origin_prior_y_angstrom
                    - float(integer_offset[1].item()) * pixel,
                )
            )
            if self.config.reference_dim == 2:
                orientation_priors.append((0.0, 0.0, record.psi_prior))
            else:
                orientation_priors.append(
                    (record.rot_prior, record.tilt_prior, record.psi_prior)
                )

        real_dtype = likelihood[0].real.dtype
        return _DensePreparedBatch(
            particle_indices=[int(value) for value in particle_indices],
            records=records,
            group_indices=torch.as_tensor(
                group_indices, device=self.device, dtype=torch.long
            ),
            sigma2_by_shell=torch.stack(
                [value.to(device=self.device, dtype=real_dtype) for value in sigma_rows]
            ),
            likelihood_ft=torch.stack(likelihood),
            unmasked_ft=torch.stack(unmasked),
            ctf=torch.stack(ctfs),
            integer_offsets=torch.stack(integer_offsets).to(
                device=self.device, dtype=real_dtype
            ),
            offset_prior_angstrom=torch.as_tensor(
                offset_priors, device=self.device, dtype=real_dtype
            ),
            orientation_prior_deg=torch.as_tensor(
                orientation_priors, device=self.device, dtype=real_dtype
            ),
        )

    def _new_dense_statistics(self) -> _DenseIterationStatistics:
        n_shells = self.dataset.box_size // 2 + 1
        noise_sums = [
            torch.zeros(n_shells, device=self.device, dtype=torch.float64)
            for _ in self.group_ids
        ]
        noise_counts = [torch.zeros_like(value) for value in noise_sums]
        backprojectors = ValidatedBackprojectorAdapter(
            len(self.references),
            self.dataset.box_size,
            self.sizes.current_size,
            self.config.padding_factor,
            self.device,
            reference_dim=self.config.reference_dim,
        )
        return _DenseIterationStatistics(
            noise_sums=noise_sums,
            noise_counts=noise_counts,
            sigma_offset_square=torch.zeros(
                (), device=self.device, dtype=torch.float64
            ),
            sigma_offset_weight=torch.zeros(
                (), device=self.device, dtype=torch.float64
            ),
            backprojectors=backprojectors,
            class_mass=torch.zeros(
                len(self.references), device=self.device, dtype=torch.float64
            ),
            direction_mass=torch.zeros(
                (len(self.references), len(self.sampling.directions)),
                device=self.device,
                dtype=torch.float64,
            ),
        )

    @staticmethod
    def _batch_matrix_weighted_sum(
        weights: torch.Tensor,
        images: torch.Tensor,
    ) -> torch.Tensor:
        """Return ``weights @ images`` for real weights and complex images."""

        batch = int(weights.shape[0])
        leading = weights.shape[1:-1]
        nweights = int(np.prod(leading, dtype=np.int64))
        translations = int(weights.shape[-1])
        pixels = int(np.prod(images.shape[2:], dtype=np.int64))
        w = weights.reshape(batch, nweights, translations)
        x = images.reshape(batch, translations, pixels)
        real = torch.bmm(w, x.real)
        imag = torch.bmm(w, x.imag)
        return torch.complex(real, imag).reshape(batch, *leading, *images.shape[2:])

    def _scatter_dense_noise(
        self,
        statistics: _DenseIterationStatistics,
        values: torch.Tensor,
        coefficient_mass: torch.Tensor,
        shells: torch.Tensor,
        mask: torch.Tensor,
        group_indices: torch.Tensor,
    ) -> None:
        shell_index = shells[mask].reshape(-1)
        for group_index in range(len(self.group_ids)):
            rows = torch.nonzero(
                group_indices == group_index, as_tuple=False
            ).squeeze(-1)
            if rows.numel() == 0:
                continue
            selected = values.index_select(0, rows)[:, mask].to(torch.float64)
            count = coefficient_mass.index_select(0, rows).to(torch.float64)
            repeated_shells = shell_index.unsqueeze(0).expand(
                selected.shape[0], -1
            )
            statistics.noise_sums[group_index].scatter_add_(
                0, repeated_shells.reshape(-1), selected.reshape(-1)
            )
            statistics.noise_counts[group_index].scatter_add_(
                0,
                repeated_shells.reshape(-1),
                count[:, None].expand_as(selected).reshape(-1),
            )

    @torch.no_grad()
    def _accumulate_dense_batch(
        self,
        prepared: _DensePreparedBatch,
        expectation: DenseBatchExpectation,
        statistics: _DenseIterationStatistics,
        orientation_rotations: torch.Tensor,
    ) -> None:
        """Accumulate noise, offset and backprojection sufficient statistics.

        Translation hypotheses are collapsed before projection/backprojection,
        and particles sharing the same orientation bank are collapsed across
        each batch.  Every class/orientation is therefore inserted once per
        particle batch using ``sum_b sum_t w X`` and ``sum_b sum_t w``.  Noise
        residuals use the equivalent expanded quadratic identity, so no
        orientation/translation pair is revisited in Python.
        """

        bank = expectation.bank
        retained = expectation.retained_weights
        retained64 = retained.to(torch.float64)
        batch, nclass, norient, ntrans = retained.shape
        size = bank.image_size
        pixel = float(self.dataset.pixel_size)

        # Class and direction posterior masses remain entirely on-device.
        # Preserve the float64 raw-weight reduction supplied by the
        # expectation engine.  The large posterior tensor remains float32 for
        # performance, but very small positive class occupancies must not be
        # rounded away before the next model pdf is installed.
        statistics.class_mass += expectation.class_mass.sum(dim=0)
        orientation_mass = retained64.sum(dim=(0, 3))
        directions = bank.direction_indices.to(device=self.device)
        for class_index in range(nclass):
            statistics.direction_mass[class_index].scatter_add_(
                0, directions, orientation_mass[class_index]
            )

        # Posterior-weighted offset variance.
        translation_mass64 = retained64.sum(dim=(1, 2))
        translations64 = bank.translations_angstrom.to(
            device=self.device, dtype=torch.float64
        )
        delta = prepared.offset_prior_angstrom.to(torch.float64)[:, None, :] - translations64[None, :, :]
        statistics.sigma_offset_square += (
            translation_mass64[..., None] * delta.square()
        ).sum()
        statistics.sigma_offset_weight += translation_mass64.sum()

        likelihood = AlignmentExpectation._window_rfft(
            prepared.likelihood_ft, size
        )
        unmasked = AlignmentExpectation._window_rfft(
            prepared.unmasked_ft, size
        )
        ctf = AlignmentExpectation._window_rfft(prepared.ctf, size).to(
            dtype=likelihood.real.dtype
        )
        phase = bank.phase_factors.to(device=self.device)
        shifted_likelihood = likelihood[:, None, ...] * phase[None, ...]
        shifted_unmasked = unmasked[:, None, ...] * phase[None, ...]

        # M-step restores DC; only duplicate x=0,y<0 coefficients are excluded.
        # E-step and DLL normalizer continue to exclude DC.
        shells = rounded_shell_indices_2d(size, self.device)
        ky = signed_fft_indices(size, device=self.device)
        duplicate = (
            torch.arange(size // 2 + 1, device=self.device)[None, :] == 0
        ) & (ky[:, None] < 0)
        active_mstep = (
            (shells >= 0)
            & (shells <= self.sizes.current_shell)
            & ~duplicate
        )
        sigma_grid = prepared.sigma2_by_shell[
            :, shells.clamp_max(prepared.sigma2_by_shell.shape[-1] - 1)
        ]
        valid_sigma = (
            (shells[None, ...] < prepared.sigma2_by_shell.shape[-1])
            & (sigma_grid > 0)
            & active_mstep[None, ...]
        )
        inverse_sigma = torch.where(
            valid_sigma, 1.0 / sigma_grid, torch.zeros_like(sigma_grid)
        )
        numerator_factor = ctf * inverse_sigma
        denominator_base = ctf.square() * inverse_sigma

        # First noise term: sum_t marginal(t) * |X_t|^2.
        translation_mass = retained.sum(dim=(1, 2))
        shifted_power = (
            shifted_likelihood.real.square() + shifted_likelihood.imag.square()
        ).reshape(batch, ntrans, -1)
        noise_power = torch.bmm(
            translation_mass.unsqueeze(1), shifted_power
        ).squeeze(1).reshape(batch, size, size // 2 + 1)
        prediction_power = torch.zeros_like(noise_power)
        prediction_cross = torch.zeros_like(noise_power)

        projections = bank.projections.to(device=self.device)
        chunk = max(1, int(self.config.orientation_chunk_size))
        for start in range(0, norient, chunk):
            stop = min(start + chunk, norient)
            width = stop - start
            weights = retained[:, :, start:stop, :]
            orientation_weight = weights.sum(dim=-1)

            weighted_likelihood = self._batch_matrix_weighted_sum(
                weights, shifted_likelihood
            )
            reference = projections[:, start:stop, :]
            prediction = reference.unsqueeze(0) * ctf[:, None, None, ...]
            prediction_power += (
                orientation_weight[..., None, None]
                * (prediction.real.square() + prediction.imag.square())
            ).sum(dim=(1, 2))
            prediction_cross += (
                weighted_likelihood.real * prediction.real
                + weighted_likelihood.imag * prediction.imag
            ).sum(dim=(1, 2))

            # Translation-linear M-step numerator and denominator.
            weighted_unmasked = self._batch_matrix_weighted_sum(
                weights, shifted_unmasked
            )
            numerator = weighted_unmasked * numerator_factor[:, None, None, ...]
            denominator = (
                orientation_weight[..., None, None]
                * denominator_base[:, None, None, ...]
            )
            # Backprojection is also linear over particles.  All particles in
            # this batch share the same orientation bank, so collapse the batch
            # dimension before insertion and backproject each class/orientation
            # only once.
            numerator_by_orientation = numerator.sum(dim=0)
            denominator_by_orientation = denominator.sum(dim=0)
            observation_by_orientation = orientation_weight.sum(dim=0)
            rotations = orientation_rotations[start:stop]

            for class_index in range(nclass):
                observation = observation_by_orientation[class_index]
                keep = torch.nonzero(observation > 0, as_tuple=False).squeeze(-1)
                if keep.numel() == 0:
                    continue
                images = numerator_by_orientation[class_index].index_select(0, keep)
                sample_weight = denominator_by_orientation[class_index].index_select(
                    0, keep
                )
                selected_rotations = rotations.index_select(0, keep)
                selected_observation = observation.index_select(0, keep)
                statistics.backprojectors.add(
                    class_index,
                    images,
                    selected_rotations,
                    sample_weight,
                    sample_weight,
                    observation_weights=selected_observation,
                    orientation_chunk_size=self.config.backprojector_chunk_size,
                )

        residual_power = torch.clamp(
            noise_power + prediction_power - 2.0 * prediction_cross, min=0.0
        )
        # strict_highres_exp limits probability scoring only.  RELION's
        # storeWeightedSums re-evaluates retained hypotheses at the full working
        # current size, so noise sufficient statistics must cover current_shell.
        active_noise = (shells <= self.sizes.current_shell) & ~duplicate
        retained_mass = retained.sum(dim=(1, 2, 3))
        self._scatter_dense_noise(
            statistics,
            residual_power,
            retained_mass,
            shells,
            active_noise,
            prepared.group_indices,
        )

        # Above current_size, the residual is class-independent particle power.
        n = self.dataset.box_size
        n_shells = n // 2 + 1
        full_shells = rounded_shell_indices_2d(n, self.device)
        full_ky = signed_fft_indices(n, device=self.device)
        full_duplicate = (
            torch.arange(n // 2 + 1, device=self.device)[None, :] == 0
        ) & (full_ky[:, None] < 0)
        high_resolution = (
            (full_shells > self.sizes.current_shell)
            & (full_shells < n_shells)
            & ~full_duplicate
        )
        full_power = (
            prepared.likelihood_ft.real.square()
            + prepared.likelihood_ft.imag.square()
        )
        self._scatter_dense_noise(
            statistics,
            full_power,
            torch.ones(batch, device=self.device, dtype=full_power.dtype),
            full_shells,
            high_resolution,
            prepared.group_indices,
        )

    @torch.no_grad()
    def _accumulate_sparse_adaptive_batch(
        self,
        prepared: _DensePreparedBatch,
        expectation: SparseAdaptiveBatchExpectation,
        statistics: _DenseIterationStatistics,
    ) -> None:
        """Accumulate sparse fine-pass sufficient statistics without pose loops."""

        retained = expectation.retained_weights
        retained64 = retained.to(torch.float64)
        nparent, norient_child, ntrans_child = retained.shape
        batch = int(prepared.likelihood_ft.shape[0])
        size = int(self.sizes.current_size)
        parent_particle = expectation.parent_particle_indices
        parent_class = expectation.parent_class_indices

        parent_mass64 = expectation.parent_mass64
        statistics.class_mass += expectation.class_mass.sum(dim=0)
        coarse_direction = expectation.coarse.bank.direction_indices.to(
            device=self.device
        ).index_select(0, expectation.parent_orientation_indices)
        direction_key = (
            parent_class * statistics.direction_mass.shape[1] + coarse_direction
        )
        statistics.direction_mass.reshape(-1).scatter_add_(
            0, direction_key, parent_mass64
        )

        translation_mass64 = retained64.sum(dim=1)
        prior = prepared.offset_prior_angstrom.to(torch.float64).index_select(
            0, parent_particle
        )
        translation = expectation.child_translations_angstrom.to(torch.float64)
        delta = prior[:, None, :] - translation
        statistics.sigma_offset_square += (
            translation_mass64[..., None] * delta.square()
        ).sum()
        statistics.sigma_offset_weight += translation_mass64.sum()

        likelihood = AlignmentExpectation._window_rfft(
            prepared.likelihood_ft, size
        )
        unmasked = AlignmentExpectation._window_rfft(prepared.unmasked_ft, size)
        ctf = AlignmentExpectation._window_rfft(prepared.ctf, size).to(
            dtype=likelihood.real.dtype
        )
        shells = rounded_shell_indices_2d(size, self.device)
        ky = signed_fft_indices(size, device=self.device)
        duplicate = (
            torch.arange(size // 2 + 1, device=self.device)[None, :] == 0
        ) & (ky[:, None] < 0)
        active_mstep = (
            (shells >= 0)
            & (shells <= self.sizes.current_shell)
            & ~duplicate
        )
        sigma_grid = prepared.sigma2_by_shell[
            :, shells.clamp_max(prepared.sigma2_by_shell.shape[-1] - 1)
        ]
        valid_sigma = (
            (shells[None, ...] < prepared.sigma2_by_shell.shape[-1])
            & (sigma_grid > 0)
            & active_mstep[None, ...]
        )
        inverse_sigma = torch.where(
            valid_sigma, 1.0 / sigma_grid, torch.zeros_like(sigma_grid)
        )
        numerator_factor = ctf * inverse_sigma
        denominator_base = ctf.square() * inverse_sigma

        noise_power = torch.zeros(
            (batch, size, size // 2 + 1),
            device=self.device,
            dtype=likelihood.real.dtype,
        )
        prediction_power = torch.zeros_like(noise_power)
        prediction_cross = torch.zeros_like(noise_power)
        retained_mass = torch.zeros(
            batch, device=self.device, dtype=retained.dtype
        )

        blocks = expectation.projection_blocks
        unique_fine = int(blocks.projections.shape[0]) * norient_child
        aggregate_real = torch.zeros(
            (unique_fine, size, size // 2 + 1),
            device=self.device,
            dtype=likelihood.real.dtype,
        )
        aggregate_imag = torch.zeros_like(aggregate_real)
        aggregate_denominator = torch.zeros_like(aggregate_real)
        aggregate_observation = torch.zeros(
            unique_fine, device=self.device, dtype=likelihood.real.dtype
        )
        child_axis = torch.arange(
            norient_child, device=self.device, dtype=torch.long
        )
        phase_table = expectation.phase_factors.to(device=self.device)
        parent_chunk = max(1, int(self.config.orientation_chunk_size))

        for start in range(0, nparent, parent_chunk):
            stop = min(start + parent_chunk, nparent)
            particle_index = parent_particle[start:stop]
            weights = retained[start:stop]
            selected_likelihood = likelihood.index_select(0, particle_index)
            selected_unmasked = unmasked.index_select(0, particle_index)
            selected_ctf = ctf.index_select(0, particle_index)
            selected_numerator_factor = numerator_factor.index_select(
                0, particle_index
            )
            selected_denominator_base = denominator_base.index_select(
                0, particle_index
            )
            phases = phase_table.index_select(
                0, expectation.parent_translation_indices[start:stop]
            )
            shifted_likelihood = selected_likelihood[:, None, ...] * phases
            shifted_unmasked = selected_unmasked[:, None, ...] * phases
            reference = blocks.projections.index_select(
                0, expectation.parent_projection_block_indices[start:stop]
            )
            prediction = reference * selected_ctf[:, None, ...]

            translation_mass = weights.sum(dim=1)
            shifted_power = (
                shifted_likelihood.real.square()
                + shifted_likelihood.imag.square()
            ).reshape(stop - start, ntrans_child, -1)
            local_noise = torch.bmm(
                translation_mass.unsqueeze(1), shifted_power
            ).squeeze(1).reshape(stop - start, size, size // 2 + 1)
            noise_power.index_add_(0, particle_index, local_noise)

            orientation_weight = weights.sum(dim=-1)
            local_prediction_power = (
                orientation_weight[..., None, None]
                * (prediction.real.square() + prediction.imag.square())
            ).sum(dim=1)
            prediction_power.index_add_(
                0, particle_index, local_prediction_power
            )
            weighted_likelihood = self._batch_matrix_weighted_sum(
                weights, shifted_likelihood
            )
            local_cross = (
                weighted_likelihood.real * prediction.real
                + weighted_likelihood.imag * prediction.imag
            ).sum(dim=1)
            prediction_cross.index_add_(0, particle_index, local_cross)
            retained_mass.index_add_(
                0, particle_index, weights.sum(dim=(1, 2))
            )

            weighted_unmasked = self._batch_matrix_weighted_sum(
                weights, shifted_unmasked
            )
            numerator = (
                weighted_unmasked
                * selected_numerator_factor[:, None, ...]
            )
            denominator = (
                orientation_weight[..., None, None]
                * selected_denominator_base[:, None, ...]
            )
            fine_index = (
                expectation.parent_projection_block_indices[start:stop, None]
                * norient_child
                + child_axis[None, :]
            ).reshape(-1)
            aggregate_real.index_add_(
                0, fine_index, numerator.real.reshape(-1, size, size // 2 + 1)
            )
            aggregate_imag.index_add_(
                0, fine_index, numerator.imag.reshape(-1, size, size // 2 + 1)
            )
            aggregate_denominator.index_add_(
                0,
                fine_index,
                denominator.reshape(-1, size, size // 2 + 1),
            )
            aggregate_observation.index_add_(
                0, fine_index, orientation_weight.reshape(-1)
            )

        residual_power = torch.clamp(
            noise_power + prediction_power - 2.0 * prediction_cross, min=0.0
        )
        active_noise = (shells <= self.sizes.current_shell) & ~duplicate
        self._scatter_dense_noise(
            statistics,
            residual_power,
            retained_mass,
            shells,
            active_noise,
            prepared.group_indices,
        )

        n = self.dataset.box_size
        n_shells = n // 2 + 1
        full_shells = rounded_shell_indices_2d(n, self.device)
        full_ky = signed_fft_indices(n, device=self.device)
        full_duplicate = (
            torch.arange(n // 2 + 1, device=self.device)[None, :] == 0
        ) & (full_ky[:, None] < 0)
        high_resolution = (
            (full_shells > self.sizes.current_shell)
            & (full_shells < n_shells)
            & ~full_duplicate
        )
        full_power = (
            prepared.likelihood_ft.real.square()
            + prepared.likelihood_ft.imag.square()
        )
        self._scatter_dense_noise(
            statistics,
            full_power,
            torch.ones(batch, device=self.device, dtype=full_power.dtype),
            full_shells,
            high_resolution,
            prepared.group_indices,
        )

        fine_classes = blocks.class_indices[:, None].expand(
            -1, norient_child
        ).reshape(-1)
        fine_angles = blocks.angles_deg.reshape(-1, 3)
        rotations = _euler_matrix(fine_angles)
        aggregate = torch.complex(aggregate_real, aggregate_imag)
        for class_index in range(len(self.references)):
            keep = torch.nonzero(
                (fine_classes == class_index)
                & (aggregate_observation > 0.0),
                as_tuple=False,
            ).squeeze(-1)
            if keep.numel() == 0:
                continue
            images = aggregate.index_select(0, keep)
            sample_weight = aggregate_denominator.index_select(0, keep)
            observation = aggregate_observation.index_select(0, keep)
            statistics.backprojectors.add(
                class_index,
                images,
                rotations.index_select(0, keep),
                sample_weight,
                sample_weight,
                observation_weights=observation,
                orientation_chunk_size=self.config.backprojector_chunk_size,
            )

    def _finalize_dense_noise(
        self,
        statistics: _DenseIterationStatistics,
        sigma2_old: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        updated_spectra: list[torch.Tensor] = []
        for group_index, old_spectrum in enumerate(sigma2_old):
            updated = old_spectrum.to(torch.float64).clone()
            valid = statistics.noise_counts[group_index] > 0
            updated[valid] = statistics.noise_sums[group_index][valid] / (
                2.0 * statistics.noise_counts[group_index][valid]
            )
            updated = repair_nonpositive_spectrum(updated, minimum=1.0e-20)
            updated_spectra.append(updated.to(old_spectrum.dtype))
        return updated_spectra

    @staticmethod
    def _backprojector_weight_sum(backprojector: Any) -> float:
        """Return and validate RELION's class reconstruction gate statistic.

        The previous 0.2.1 implementation reduced the denominator to one
        scalar and then used the comparison result as a silent preserve-map
        switch.  A NaN therefore behaved exactly like an empty class because
        ``NaN > threshold`` is false.  Validate the Fourier weights before the
        reduction so a populated class can never be silently left unchanged.
        """

        weight = getattr(backprojector, "denominator", None)
        if weight is None:
            weight = getattr(backprojector, "weight", None)
        if weight is None:
            raise AttributeError("backprojector exposes neither denominator nor weight")
        tensor = torch.as_tensor(weight)
        if not bool(torch.isfinite(tensor).all()):
            nan_count = int(torch.isnan(tensor).sum().item())
            posinf_count = int(torch.isposinf(tensor).sum().item())
            neginf_count = int(torch.isneginf(tensor).sum().item())
            raise FloatingPointError(
                "backprojector weight contains non-finite values: "
                f"NaN={nan_count}, +Inf={posinf_count}, -Inf={neginf_count}"
            )
        if bool((tensor < 0).any()):
            raise FloatingPointError(
                "backprojector weight contains negative values "
                f"(minimum={float(tensor.min().item()):.9g})"
            )
        return float(tensor.sum(dtype=torch.float64).item())

    def _finish_maximization(
        self,
        backprojectors: ValidatedBackprojectorAdapter,
        class_mass: torch.Tensor,
        direction_mass: torch.Tensor,
        iteration: int,
        current_tau2: Sequence[torch.Tensor],
    ) -> list[torch.Tensor]:
        """Run RELION-style class-gated SSNR updates and reconstruction.

        RELION 3.1 deliberately uses the *previous* model class probability for
        the reconstruction gate, and updates the probability only after all
        class maps have been handled.  This yields a three-state lifecycle:

        1. previous probability > 0 and Fourier weight > epsilon: reconstruct;
        2. previous probability > 0 and Fourier weight <= epsilon: preserve;
        3. previous probability == 0: clear the real-space reference.

        The one-iteration delay between a class receiving zero posterior mass
        and its reference being cleared is observable in RELION Class2D output
        and is required for continuation parity.
        """

        number_of_classes = len(self.references)
        if len(backprojectors.objects) != number_of_classes:
            raise ValueError("backprojector/class count mismatch")

        maps = [reference.clone() for reference in self.references]
        new_tau2 = [value.clone() for value in self.tau2]
        new_sigma2_class = [value.clone() for value in self.sigma2_class]
        new_data_vs_prior = [value.clone() for value in self.data_vs_prior]
        new_fourier_coverage = [value.clone() for value in self.fourier_coverage]

        previous_class_prob = self.class_prob.detach().to(torch.float64).clone()
        total_mass = class_mass.sum()
        if not bool(torch.isfinite(total_mass)):
            raise FloatingPointError("total class posterior mass is non-finite")
        if float(total_mass.item()) > 0.0:
            # Keep the stored class pdf dtype unchanged.  The mass itself was
            # accumulated from the float64 raw-weight posterior, so small
            # positive occupancies such as 1e-13 remain representable here.
            next_class_prob = (class_mass / total_mass).to(self.class_prob.dtype)
        else:
            next_class_prob = class_mass.to(self.class_prob.dtype)

        for class_index in range(number_of_classes):
            posterior_mass = float(class_mass[class_index].item())
            previous_probability = float(previous_class_prob[class_index].item())
            next_probability = float(next_class_prob[class_index].item())
            weight_sum = self._backprojector_weight_sum(
                backprojectors.objects[class_index]
            )
            has_fourier_weight = weight_sum > _RELION_EQUAL_ACCURACY

            if self.config.reference_dim == 3 and getattr(getattr(self, 'options', None), 'write_unfil_map', False):
                # Use this E-step's merged soft-posterior statistics, before
                # reconstruction can release/spill the class accumulator. No
                # MAP prior, SIRM or reference postprocessing is applied here.
                from relion_torch.reconstruction.half_fsc import unregularized_map
                from relion_torch.io.mrc import write_mrc
                unfiltered = (unregularized_map(backprojectors.objects[class_index],
                    normalise=posterior_mass,preweight_iterations=self.config.preweight_iterations,
                    skip_gridding=getattr(getattr(self,"options",None),"skip_gridding",False),backend=getattr(getattr(self,"options",None),"reconstruction_backend","auto"))
                    if posterior_mass > 0.0 and has_fourier_weight
                    else torch.zeros_like(self.references[class_index]))
                if not torch.isfinite(unfiltered).all():
                    raise FloatingPointError(f'class {class_index + 1} unfiltered reconstruction is non-finite')
                write_mrc(str(self.config.output_root)+f'_it{iteration:03d}_class{class_index + 1:03d}_unfil.mrc',
                    unfiltered,pixel_size_angstrom=self.dataset.pixel_size)
                del unfiltered

            if previous_probability > 0.0 and has_fourier_weight:
                from relion_torch.reconstruction.workspace import ReconstructionWorkspace
                workspace=ReconstructionWorkspace(backprojectors.objects[class_index])
                ssnr = update_ssnr_arrays(
                    backprojectors.objects[class_index],
                    current_tau2[class_index],workspace=workspace,
                    tau2_fudge=self.config.tau2_fudge,
                )
                from relion_torch.reconstruction.sirm import sirm_options_from_config
                sirm = sirm_options_from_config(getattr(self, 'options', None))
                reconstruction = backprojectors.reconstruct_one(
                    class_index,
                    tau2=current_tau2[class_index],
                    tau2_fudge=self.config.tau2_fudge,
                    preweight_iterations=self.config.preweight_iterations,
                    normalise=posterior_mass,
                    skip_gridding=getattr(getattr(self,"options",None),"skip_gridding",False),
                    reconstruction_backend=getattr(getattr(self,"options",None),"reconstruction_backend","auto"),workspace=workspace,
                    timer=getattr(self,"_detail_timer",None),
                    minres_map=self.config.minres_map,
                    **({"sirm": sirm} if sirm is not None else {}),
                )
                if not torch.isfinite(reconstruction).all():
                    raise FloatingPointError(
                        f"class {class_index + 1} reconstruction is non-finite"
                    )
                del workspace
                maps[class_index] = reconstruction.to(self.device)
                new_tau2[class_index] = ssnr.tau2
                new_sigma2_class[class_index] = ssnr.sigma2
                new_data_vs_prior[class_index] = ssnr.data_vs_prior
                new_fourier_coverage[class_index] = ssnr.fourier_coverage
                self.references[class_index] = maps[class_index]
                self.projectors[class_index] = self._updated_reference_projector(class_index)
            elif previous_probability > 0.0:
                # Positive old pdf but no usable Fourier weights: RELION leaves
                # Iref and all stored spectra untouched.  The current posterior
                # may set the pdf to zero below, causing the map to be cleared
                # on the following maximization.
                print(
                    f"Class {class_index + 1}: preserving previous reference "
                    f"(previous probability={previous_probability:.6g}, "
                    f"current posterior mass={posterior_mass:.6g}, "
                    f"current probability={next_probability:.6g}, "
                    f"backprojector weight sum={weight_sum:.6g})"
                )
            else:
                # Outer empty-class branch in RELION: once the previous class
                # pdf is exactly zero, clear Iref.  Keep this iteration's stored
                # sigma2/DVP/coverage state; expectation setup on the next
                # iteration rebuilds a zero projector and installs zero
                # projector-space tau2.
                maps[class_index] = torch.zeros_like(self.references[class_index])
                self.references[class_index] = maps[class_index]
                self.projectors[class_index] = self._updated_reference_projector(class_index)
                # On the first clearing iteration ``current_tau2`` still comes
                # from the old projector, so this preserves the stored spectrum
                # exactly as RELION does.  On the following iteration it comes
                # from the already-zero projector and therefore installs a zero
                # tau2 array, while sigma2/DVP/coverage remain at their last
                # stored values.
                new_tau2[class_index] = current_tau2[class_index].clone()
                print(
                    f"Class {class_index + 1}: clearing reference because "
                    f"previous class probability is zero "
                    f"(current posterior mass={posterior_mass:.6g}, "
                    f"backprojector weight sum={weight_sum:.6g})"
                )

            if hasattr(backprojectors, "release"):
                backprojectors.release(class_index)
            if self.config.reference_dim == 3 and not getattr(self, '_defer_reference_output', False):
                array = maps[class_index].detach().cpu().float().numpy()
                if not np.isfinite(array).all():
                    raise FloatingPointError(
                        f"class {class_index + 1} output reference is non-finite"
                    )
                path = (
                    str(self.config.output_root)
                    + f"_it{iteration:03d}_class{class_index + 1:03d}.mrc"
                )
                with mrcfile.new(path, overwrite=True) as handle:
                    handle.set_data(array.astype(np.float32, copy=False))
                    handle.voxel_size = self.dataset.pixel_size

        # RELION updates model.pdf_class only after the map loop.
        self.class_prob = next_class_prob
        self.tau2 = new_tau2
        self.sigma2_class = new_sigma2_class
        self.data_vs_prior = new_data_vs_prior
        self.fourier_coverage = new_fourier_coverage
        self.psnr_shell = self._safe_psnr_shell(self.data_vs_prior)

        if (
            self.config.reference_dim == 3
            and not self.config.skip_align
            and not self.config.skip_rotate
        ):
            sums = direction_mass.sum(dim=1, keepdim=True)
            self.direction_priors = torch.where(
                sums > 0,
                direction_mass
                / sums.clamp_min(torch.finfo(torch.float64).tiny),
                torch.zeros_like(direction_mass),
            ).to(torch.float32)
        if self.config.reference_dim == 2 and not getattr(self, '_defer_reference_output', False):
            self._write_reference_maps(maps, iteration)
        return maps

    def _run_dense_global_iteration(
        self,
        iteration: int,
        sigma2_old: Sequence[torch.Tensor],
        current_tau2: Sequence[torch.Tensor],
    ) -> None:
        engine = self._expectation_engine(iteration)
        adaptive = int(self.config.oversampling) > 0
        bank_size = self.sizes.likelihood_image_size(not adaptive)
        bank_shell = (
            self.sizes.likelihood_shell(False)
            if adaptive
            else self.sizes.likelihood_shell(True)
        )
        build_start = time.perf_counter()
        bank = engine.build_global_projection_bank(
            pixel_size=self.dataset.pixel_size,
            image_size=bank_size,
            maximum_shell=bank_shell,
        )
        orientation_rotations = None if adaptive else _euler_matrix(bank.angles_deg)
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
        build_seconds = time.perf_counter() - build_start
        bank_mib = (
            bank.projections.numel() * bank.projections.element_size()
            / (1024.0 * 1024.0)
        )
        mode = (
            f"sparse adaptive oversampling order {self.config.oversampling}"
            if adaptive
            else "single-pass dense"
        )
        print(
            f"Dense global search ({mode}): "
            f"{bank.number_of_orientations} coarse orientations x "
            f"{bank.number_of_translations} coarse translations x "
            f"{bank.number_of_classes} classes; particle batch "
            f"{self.config.batch_size}; coarse bank {bank_mib:.1f} MiB; "
            f"built in {build_seconds:.3f} s"
        )

        statistics = None if self.config.skip_maximize else self._new_dense_statistics()
        updated = self.dataset.particles.copy()
        pmax_parts: list[np.ndarray] = []
        dll_parts: list[np.ndarray] = []
        angles_np = bank.angles_deg.detach().cpu().numpy() if not adaptive else None
        translations_np = (
            bank.translations_angstrom.detach().cpu().numpy()
            if not adaptive
            else None
        )
        output = self.config.output_root
        count = len(self.dataset)
        batch_size = max(1, int(self.config.batch_size))
        iteration_start = time.perf_counter()

        for batch_number, (particle_indices, raw_images) in enumerate(self.dataset.iter_image_batches(
                device=self.device, batch_size=batch_size)):
            start_index = particle_indices[0]
            stop = particle_indices[-1] + 1
            prepared = self._prepare_dense_batch(particle_indices, sigma2_old, raw_images)
            coarse = engine.run_global_batch(
                prepared.likelihood_ft,
                prepared.ctf,
                prepared.sigma2_by_shell,
                offset_prior_angstrom=prepared.offset_prior_angstrom,
                orientation_prior_deg=prepared.orientation_prior_deg,
                pixel_size=self.dataset.pixel_size,
                bank=bank,
            )
            if adaptive:
                expectation: DenseBatchExpectation | SparseAdaptiveBatchExpectation = (
                    engine.run_sparse_adaptive_batch(
                        prepared.likelihood_ft,
                        prepared.ctf,
                        prepared.sigma2_by_shell,
                        offset_prior_angstrom=prepared.offset_prior_angstrom,
                        orientation_prior_deg=prepared.orientation_prior_deg,
                        pixel_size=self.dataset.pixel_size,
                        coarse=coarse,
                    )
                )
                class_index, angles, translations, _directions = (
                    expectation.best_values()
                )
                class_np = class_index.detach().cpu().numpy()
                angles_batch_np = angles.detach().cpu().numpy()
                translation_batch_np = translations.detach().cpu().numpy()
            else:
                expectation = coarse
                class_index, orientation_index, translation_index = (
                    expectation.decode_flat_indices()
                )
                class_np = class_index.detach().cpu().numpy()
                orientation_np = orientation_index.detach().cpu().numpy()
                translation_np = translation_index.detach().cpu().numpy()
                assert angles_np is not None and translations_np is not None
                angles_batch_np = angles_np[orientation_np]
                translation_batch_np = translations_np[translation_np]

            integer_np = prepared.integer_offsets.detach().cpu().numpy()
            pmax_np = expectation.pmax.detach().cpu().numpy()
            dll_np = expectation.log_likelihood_contribution.detach().cpu().numpy()
            significant_np = expectation.significant_count.detach().cpu().numpy()
            pmax_parts.append(pmax_np)
            dll_parts.append(dll_np)

            for local_index, particle_index in enumerate(particle_indices):
                c = int(class_np[local_index])
                angle = angles_batch_np[local_index]
                total_xy = integer_np[local_index] * float(
                    self.dataset.pixel_size
                ) + translation_batch_np[local_index]
                self._set(updated, particle_index, "rlnClassNumber", c + 1)
                # RELION writes rot/tilt assignments only for a 3-D reference.
                # In Class2D they are metadata from an earlier 3-D alignment
                # and must remain unchanged; only psi is a 2-D hidden variable.
                if self.config.reference_dim == 3:
                    self._set(updated, particle_index, "rlnAngleRot", float(angle[0]))
                    self._set(updated, particle_index, "rlnAngleTilt", float(angle[1]))
                self._set(updated, particle_index, "rlnAnglePsi", float(angle[2]))
                self._set(
                    updated,
                    particle_index,
                    "rlnOriginXAngst",
                    float(total_xy[0]),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnOriginYAngst",
                    float(total_xy[1]),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnMaxValueProbDistribution",
                    float(pmax_np[local_index]),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnNrOfSignificantSamples",
                    int(significant_np[local_index]),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnLogLikeliContribution",
                    float(dll_np[local_index]),
                )

            if self.config.write_debug:
                payload = (
                    sparse_adaptive_debug_dict(expectation)
                    if adaptive
                    else dense_expectation_debug_dict(expectation)
                )
                payload["particle_indices"] = np.asarray(
                    particle_indices, dtype=np.int64
                )
                np.savez_compressed(
                    str(output)
                    + f"_it{iteration:03d}_expectation_debug_batch{batch_number:04d}.npz",
                    **payload,
                )

            if statistics is not None:
                expectation = engine.for_weighted_sums(expectation, pixel_size=self.dataset.pixel_size)
                if adaptive:
                    self._accumulate_sparse_adaptive_batch(
                        prepared, expectation, statistics
                    )
                else:
                    assert orientation_rotations is not None
                    self._accumulate_dense_batch(
                        prepared,
                        expectation,
                        statistics,
                        orientation_rotations,
                    )

            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)
            elapsed = time.perf_counter() - iteration_start
            if adaptive:
                coarse_parent_mean = float(
                    expectation.coarse.significant.sum(dim=(1, 2, 3)).float().mean().item()
                )
                fine_hypotheses = (
                    expectation.number_of_parents
                    * expectation.orientation_children
                    * expectation.translation_children
                )
                detail = (
                    f"; {expectation.number_of_parents} retained parent tiles "
                    f"({coarse_parent_mean:.1f}/particle), {fine_hypotheses} fine hypotheses"
                )
            else:
                detail = ""
            print(
                f"  global expectation {stop}/{count} particles "
                f"({elapsed:.2f} s elapsed){detail}"
            )

        pmax_values = np.concatenate(pmax_parts) if pmax_parts else np.zeros(0)
        dll_values = np.concatenate(dll_parts) if dll_parts else np.zeros(0)
        self._write_data(
            updated, str(output) + f"_it{iteration:03d}_data.star"
        )

        if statistics is None:
            self.dataset.replace_particles(updated)
            return

        sigma2_new = (
            [value.clone() for value in sigma2_old]
            if self.config.firstiter_cc and iteration == 1
            else self._finalize_dense_noise(statistics, sigma2_old)
        )
        if float(statistics.sigma_offset_weight.item()) > 0.0:
            sigma_offset_new = math.sqrt(
                max(
                    0.0,
                    float(
                        statistics.sigma_offset_square.item()
                        / (2.0 * statistics.sigma_offset_weight.item())
                    ),
                )
            )
            sigma_offset_new = max(sigma_offset_new, 1.0e-6)
        else:
            sigma_offset_new = self.sigma_offset_angstrom
        maps = self._finish_maximization(
            statistics.backprojectors,
            statistics.class_mass,
            statistics.direction_mass,
            iteration,
            current_tau2,
        )
        self.sigma2 = sigma2_new
        self.sigma_offset_angstrom = sigma_offset_new
        self._write_model_values(pmax_values, dll_values, iteration, maps)
        self.dataset.replace_particles(updated)

    def run(self) -> None:
        output = self.config.output_root
        output.parent.mkdir(parents=True, exist_ok=True)
        self.sampling.write_star(str(output) + "_sampling.star")
        if self.config.write_initial_state and self.config.iteration_offset == 0:
            self._write_initial_state()
        radius_pixels = self.particle_diameter_angstrom / (
            2.0 * float(self.dataset.pixel_size)
        )
        diameter_source = (
            "RELION default" if self.particle_diameter_is_default else "explicit"
        )
        print(
            f"Particle diameter: {self.particle_diameter_angstrom:.6g} A "
            f"({radius_pixels:.6g} px radius; {diameter_source})"
        )
        print(
            f"Initial PSNR resolution "
            f"{shell_to_angstrom(self.dataset.box_size, self.dataset.pixel_size, self.psnr_shell):.6g} A "
            f"(shell {self.psnr_shell}); current size {self.sizes.current_size}; "
            f"coarse size {self.sizes.coarse_size}"
        )

        first_iteration = int(self.config.iteration_offset) + 1
        final_iteration = int(self.config.iteration_offset) + int(self.config.iterations)
        for iteration in range(first_iteration, final_iteration + 1):
            # The new SSNR curve from iteration i-1 schedules iteration i.
            self._refresh_fourier_sizes()
            self.working_psnr_shell = int(self.psnr_shell)
            self.working_current_size = int(self.sizes.current_size)
            current_tau2 = self._current_tau2()
            # RELION's expectationSetup updates mymodel.tau2_class while
            # rebuilding PPref.  Install the same working prior before scoring
            # so skip-maximise runs and model serialisation see projector-space
            # tau虏 as well.
            self.tau2 = [spectrum.clone() for spectrum in current_tau2]
            sigma2_old = [spectrum.clone() for spectrum in self.sigma2]
            if (
                not self.config.skip_expected_accuracy
                and self.config.expected_accuracy_trials > 0
                and not self.config.skip_align
                and not (self.config.firstiter_cc and iteration == 1)
            ):
                self._calculate_expected_accuracies(sigma2_old)
            print(
                f"Iteration {iteration}: current size {self.sizes.current_size}; "
                f"coarse size {self.sizes.coarse_size}; "
                f"sigma offset {self.sigma_offset_angstrom:.6g} A"
            )

            if self._dense_global_enabled():
                self._run_dense_global_iteration(
                    iteration, sigma2_old, current_tau2
                )
                continue

            engine = self._expectation_engine(iteration)
            statistics = None if self.config.skip_maximize else self._new_dense_statistics()
            pmax_parts: list[float] = []
            dll_parts: list[float] = []
            debug: dict[str, dict[str, np.ndarray]] = {}
            updated = self.dataset.particles.copy()

            for particle_indices, raw_images in self.dataset.iter_image_batches(
                    device=self.device, batch_size=1,
                    pool_size=self.dataset.io_options.effective_pool(self.config.batch_size)):
                particle_index = particle_indices[0]
                record = self.dataset.record(particle_index)
                group_index = self.group_to_index[record.group_number]
                likelihood_ft, unmasked_ft, integer_offset, residual_offset = (
                    prepare_particle(
                        raw_images[0],
                        record,
                        particle_diameter=self.particle_diameter_angstrom,
                        mask_edge_pixels=self.config.mask_edge_pixels,
                        zero_mask=self.config.zero_mask,
                        sigma2_by_shell=sigma2_old[group_index],
                        device=self.device,
                        seed=self.config.random_seed,
                    )
                )
                ctf = ctf_rfft(
                    record,
                    self.dataset.box_size,
                    self.device,
                    likelihood_ft.real.dtype,
                )
                fixed_xy = (
                    residual_offset.detach().cpu().numpy()
                    * self.dataset.pixel_size
                )
                fixed_angles = (
                    (0.0, 0.0, record.psi)
                    if self.config.reference_dim == 2
                    else (record.rot, record.tilt, record.psi)
                )
                result = engine.run_particle(
                    likelihood_ft,
                    ctf,
                    sigma2_old[group_index],
                    fixed_angles=fixed_angles,
                    fixed_translation_angstrom=fixed_xy,
                    offset_prior_angstrom=(
                        record.origin_prior_x_angstrom
                        - float(integer_offset[0]) * self.dataset.pixel_size,
                        record.origin_prior_y_angstrom
                        - float(integer_offset[1]) * self.dataset.pixel_size,
                    ),
                    orientation_prior_deg=(
                        (0.0, 0.0, record.psi_prior)
                        if self.config.reference_dim == 2
                        else (
                            record.rot_prior,
                            record.tilt_prior,
                            record.psi_prior,
                        )
                    ),
                    pixel_size=self.dataset.pixel_size,
                )
                # Consume this particle with the SAME legacy numeric routines,
                # then discard its spectra/posterior instead of retaining N
                # full-box Fourier images on the GPU until maximization.
                if statistics is not None:
                    item = [(result, likelihood_ft, unmasked_ft, ctf,
                             integer_offset, group_index, record)]
                    if not (self.config.firstiter_cc and iteration == 1):
                        self._estimate_noise(item, sigma2_old, statistics=statistics, accumulate_only=True)
                    self._estimate_sigma_offset(item, statistics=statistics, accumulate_only=True)
                    self._maximize(item, iteration, sigma2_old=sigma2_old, current_tau2=current_tau2,
                                   statistics=statistics, accumulate_only=True)
                    del item
                pmax_parts.append(float(result.pmax))
                dll_parts.append(float(result.log_likelihood_contribution))

                best = result.best_point
                total_xy = (
                    integer_offset.detach().cpu().numpy()
                    * self.dataset.pixel_size
                    + np.asarray([best.x, best.y])
                )
                self._set(
                    updated, particle_index, "rlnClassNumber", best.class_index + 1
                )
                if self.config.reference_dim == 3:
                    self._set(updated, particle_index, "rlnAngleRot", best.rot)
                    self._set(updated, particle_index, "rlnAngleTilt", best.tilt)
                self._set(updated, particle_index, "rlnAnglePsi", best.psi)
                self._set(
                    updated,
                    particle_index,
                    "rlnOriginXAngst",
                    float(total_xy[0]),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnOriginYAngst",
                    float(total_xy[1]),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnMaxValueProbDistribution",
                    result.pmax,
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnNrOfSignificantSamples",
                    int(result.coarse.reported_significant_count),
                )
                self._set(
                    updated,
                    particle_index,
                    "rlnLogLikeliContribution",
                    result.log_likelihood_contribution,
                )
                if self.config.write_debug:
                    debug[f"particle_{particle_index:06d}"] = expectation_debug_dict(
                        result
                    )

            self._write_data(
                updated, str(output) + f"_it{iteration:03d}_data.star"
            )
            if self.config.write_debug:
                flattened: dict[str, np.ndarray] = {}
                for prefix, values in debug.items():
                    for key, value in values.items():
                        flattened[prefix + "__" + key] = value
                np.savez_compressed(
                    str(output)
                    + f"_it{iteration:03d}_expectation_debug.npz",
                    **flattened,
                )

            if self.config.skip_maximize:
                self.dataset.replace_particles(updated)
                continue

            # Both operations below consume the frozen E-step posterior.  Noise
            # is calculated now but not installed until the old-noise
            # backprojector reconstruction has finished.
            sigma2_new = (
                [value.clone() for value in sigma2_old]
                if self.config.firstiter_cc and iteration == 1
                else self._finalize_dense_noise(statistics, sigma2_old)
            )
            sigma_offset_new = self._estimate_sigma_offset([], statistics=statistics)
            maps = self._finish_maximization(
                statistics.backprojectors, statistics.class_mass,
                statistics.direction_mass, iteration, current_tau2,
            )
            self.sigma2 = sigma2_new
            self.sigma_offset_angstrom = sigma_offset_new
            self._write_model_values(np.asarray(pmax_parts), np.asarray(dll_parts), iteration, maps)
            self.dataset.replace_particles(updated)

    @staticmethod
    def _set(
        frame: pd.DataFrame,
        index: int,
        name: str,
        value: float | int,
    ) -> None:
        key = (
            name
            if name in frame.columns
            else ("_" + name if "_" + name in frame.columns else name)
        )
        if key not in frame.columns:
            frame[key] = np.nan if isinstance(value, (float, np.floating)) else 0
        if isinstance(value, (float, np.floating)):
            try:
                from pandas.api.types import is_integer_dtype

                if is_integer_dtype(frame[key].dtype):
                    frame[key] = frame[key].astype(np.float64)
            except Exception:
                pass
        frame.at[frame.index[index], key] = value

    def _write_data(self, particles: pd.DataFrame, path: str) -> None:
        write_star(
            {"optics": self.dataset.optics, "particles": particles},
            path,
            overwrite=True,
        )

    @staticmethod
    def _retained_hypotheses(result: Any):
        posterior64_values = getattr(result.fine, "posterior64", None)
        if posterior64_values is None:
            posterior64_values = result.fine.posterior.to(torch.float64)
        for point, posterior, posterior64, significant in zip(
            result.fine.points,
            result.fine.posterior,
            posterior64_values,
            result.fine.significant,
        ):
            if bool(significant.item()) and float(posterior64.item()) > 0.0:
                yield point, posterior, posterior64

    def _estimate_sigma_offset(self, results: Sequence[tuple[Any, ...]], *,
                               statistics: _DenseIterationStatistics | None = None,
                               accumulate_only: bool = False) -> float:
        weighted_square = (torch.zeros((), device=self.device, dtype=torch.float64)
                           if statistics is None else statistics.sigma_offset_square)
        total_weight = (torch.zeros_like(weighted_square)
                        if statistics is None else statistics.sigma_offset_weight)
        pixel = float(self.dataset.pixel_size)
        for result, _like, _unmasked, _ctf, integer, _group, record in results:
            prior_residual = torch.tensor(
                [
                    record.origin_prior_x_angstrom
                    - float(integer[0].item()) * pixel,
                    record.origin_prior_y_angstrom
                    - float(integer[1].item()) * pixel,
                ],
                device=self.device,
                dtype=torch.float64,
            )
            for point, _posterior, posterior64 in self._retained_hypotheses(result):
                translation = torch.tensor(
                    [point.x, point.y],
                    device=self.device,
                    dtype=torch.float64,
                )
                delta = prior_residual - translation
                weight = posterior64
                weighted_square += weight * torch.dot(delta, delta)
                total_weight += weight
        if accumulate_only:
            return self.sigma_offset_angstrom
        if float(total_weight.item()) <= 0.0:
            return self.sigma_offset_angstrom
        variance = weighted_square / (2.0 * total_weight)
        return max(math.sqrt(max(0.0, float(variance.item()))), 1.0e-6)

    def _maximize(
        self,
        results: Sequence[tuple[Any, ...]],
        iteration: int,
        *,
        sigma2_old: Sequence[torch.Tensor],
        current_tau2: Sequence[torch.Tensor],
        statistics: _DenseIterationStatistics | None = None,
        accumulate_only: bool = False,
    ) -> list[torch.Tensor]:
        n = self.dataset.box_size
        if statistics is None:
            backprojectors = ValidatedBackprojectorAdapter(
                len(self.references), n, self.sizes.current_size,
                self.config.padding_factor, self.device, reference_dim=self.config.reference_dim)
            class_mass = torch.zeros(len(self.references), device=self.device, dtype=torch.float64)
            direction_mass = torch.zeros((len(self.references), len(self.sampling.directions)),
                                         device=self.device, dtype=torch.float64)
        else:
            backprojectors = statistics.backprojectors
            class_mass = statistics.class_mass
            direction_mass = statistics.direction_mass

        shells = rounded_shell_indices_2d(n, self.device)
        ky = signed_fft_indices(n, device=self.device)
        duplicate = (
            torch.arange(n // 2 + 1, device=self.device)[None, :] == 0
        ) & (ky[:, None] < 0)
        active = (
            (shells >= 0)
            & (shells <= self.sizes.current_shell)
            & ~duplicate
        )

        for result, _like, unmasked, ctf, _integer, group_index, _record in results:
            sigma_lookup = sigma2_old[group_index].to(
                device=self.device, dtype=unmasked.real.dtype
            )
            sigma = sigma_lookup[shells.clamp_max(len(sigma_lookup) - 1)]
            valid_sigma = (
                (shells < len(sigma_lookup)) & (sigma > 0) & active
            )
            inverse_sigma = torch.where(
                valid_sigma, 1.0 / sigma, torch.zeros_like(sigma)
            )
            for point, posterior, posterior64 in self._retained_hypotheses(result):
                shift = torch.tensor(
                    [
                        [
                            point.x / self.dataset.pixel_size,
                            point.y / self.dataset.pixel_size,
                        ]
                    ],
                    device=self.device,
                    dtype=unmasked.real.dtype,
                )
                shifted = unmasked * phase_shift_rfft(
                    unmasked.shape[-2:],
                    shift,
                    self.device,
                    unmasked.real.dtype,
                    original_size=n,
                )[0]
                numerator_weight = posterior * ctf * inverse_sigma
                denominator_weight = (
                    posterior * ctf.square() * inverse_sigma
                )
                weighted = shifted * numerator_weight
                rotation = _euler_matrix(
                    torch.tensor(
                        [[point.rot, point.tilt, point.psi]],
                        device=self.device,
                        dtype=unmasked.real.dtype,
                    )
                )[0]
                backprojectors.add(
                    point.class_index,
                    weighted,
                    rotation,
                    numerator_weight,
                    denominator_weight,
                )
                class_mass[point.class_index] += posterior64
                if self.config.reference_dim == 3:
                    coarse_direction = (
                        point.direction_index >> (2 * self.config.oversampling)
                        if self.config.oversampling > 0
                        else point.direction_index
                    )
                    if 0 <= coarse_direction < direction_mass.shape[1]:
                        direction_mass[
                            point.class_index, coarse_direction
                        ] += posterior64

        if accumulate_only:
            return []
        return self._finish_maximization(
            backprojectors,
            class_mass,
            direction_mass,
            iteration,
            current_tau2,
        )

    def _estimate_noise(
        self,
        results: Sequence[tuple[Any, ...]],
        sigma2_old: Sequence[torch.Tensor],
        *, statistics: _DenseIterationStatistics | None = None,
        accumulate_only: bool = False,
    ) -> list[torch.Tensor]:
        n = self.dataset.box_size
        n_shells = n // 2 + 1
        if statistics is None:
            sums = [torch.zeros(n_shells, device=self.device, dtype=torch.float64)
                    for _ in self.group_ids]
            counts = [torch.zeros_like(value) for value in sums]
        else:
            sums, counts = statistics.noise_sums, statistics.noise_counts
        size = self.sizes.current_size
        shells = rounded_shell_indices_2d(size, self.device)
        ky = signed_fft_indices(size, device=self.device)
        duplicate = (
            torch.arange(size // 2 + 1, device=self.device)[None, :] == 0
        ) & (ky[:, None] < 0)
        # strict_highres_exp limits the E-step score, not the current-size
        # residuals used for the next noise spectrum.
        active = (shells <= self.sizes.current_shell) & ~duplicate
        full_shells = rounded_shell_indices_2d(n, self.device)
        full_ky = signed_fft_indices(n, device=self.device)
        full_duplicate = (
            torch.arange(n // 2 + 1, device=self.device)[None, :] == 0
        ) & (full_ky[:, None] < 0)
        high_resolution = (
            (full_shells > self.sizes.current_shell)
            & (full_shells < n_shells)
            & ~full_duplicate
        )
        high_resolution_shells = full_shells[high_resolution]

        for result, likelihood_ft, _unmasked, ctf, _integer, group_index, _record in results:
            # Above current_size, the residual is class-independent.  RELION
            # therefore adds the masked/noisy particle power once per image,
            # rather than once per retained orientation/translation hypothesis.
            if high_resolution_shells.numel() > 0:
                high_power = (
                    likelihood_ft.real.square() + likelihood_ft.imag.square()
                ).to(torch.float64)[high_resolution]
                sums[group_index].scatter_add_(
                    0, high_resolution_shells, high_power
                )
                counts[group_index].scatter_add_(
                    0, high_resolution_shells, torch.ones_like(high_power)
                )

            image = AlignmentExpectation._window_rfft(likelihood_ft, size)
            ctf_window = AlignmentExpectation._window_rfft(ctf, size)
            for point, _posterior, posterior64 in self._retained_hypotheses(result):
                angle = torch.tensor(
                    [[point.rot, point.tilt, point.psi]],
                    device=self.device,
                    dtype=image.real.dtype,
                )
                reference = self.projectors[point.class_index](angle, size)[0]
                if tuple(reference.shape[-2:]) != tuple(image.shape[-2:]):
                    reference = AlignmentExpectation._window_rfft(
                        reference, size
                    )
                shift = torch.tensor(
                    [
                        [
                            point.x / self.dataset.pixel_size,
                            point.y / self.dataset.pixel_size,
                        ]
                    ],
                    device=self.device,
                    dtype=image.real.dtype,
                )
                shifted = image * phase_shift_rfft(
                    image.shape[-2:],
                    shift,
                    self.device,
                    image.real.dtype,
                    original_size=n,
                )[0]
                residual = shifted - ctf_window * reference
                weight = posterior64
                power = (
                    residual.real.square() + residual.imag.square()
                ).to(torch.float64) * weight
                coefficient_weight = torch.ones_like(power) * weight
                sums[group_index].scatter_add_(
                    0, shells[active], power[active]
                )
                counts[group_index].scatter_add_(
                    0, shells[active], coefficient_weight[active]
                )

        if accumulate_only:
            return []
        updated_spectra: list[torch.Tensor] = []
        for group_index, old_spectrum in enumerate(sigma2_old):
            updated = old_spectrum.to(torch.float64).clone()
            valid = counts[group_index] > 0
            updated[valid] = sums[group_index][valid] / (
                2.0 * counts[group_index][valid]
            )
            updated = repair_nonpositive_spectrum(updated, minimum=1.0e-20)
            updated_spectra.append(updated.to(old_spectrum.dtype))
        return updated_spectra

    def _write_model_values(
        self,
        pmax: np.ndarray,
        dll: np.ndarray,
        iteration: int,
        maps: Sequence[torch.Tensor] | None,
    ) -> None:
        del maps
        pmax = np.asarray(pmax, dtype=float)
        dll = np.asarray(dll, dtype=float)
        reference_paths = self._reference_image_names(iteration)
        if self.config.firstiter_cc and iteration == 1:
            log_likelihood = float(dll.mean()) if dll.size else 0.0
        else:
            log_likelihood = float(dll.sum())
        write_star(
            self._model_blocks(
                reference_paths,
                log_likelihood=log_likelihood,
                average_pmax=float(pmax.mean()) if pmax.size else 0.0,
            ),
            str(self.config.output_root) + f"_it{iteration:03d}_model.star",
            overwrite=True,
        )

    def _write_model(
        self,
        results: Sequence[tuple[Any, ...]],
        iteration: int,
        maps: Sequence[torch.Tensor] | None,
    ) -> None:
        self._write_model_values(
            np.asarray([row[0].pmax for row in results], dtype=float),
            np.asarray(
                [row[0].log_likelihood_contribution for row in results],
                dtype=float,
            ),
            iteration,
            maps,
        )

    def expected_accuracy_interface(self) -> dict[str, Any]:
        """Return the latest RELION-style expected-accuracy state."""

        return {
            "rotation_accuracy_deg": [
                float(value)
                for value in self.rotation_accuracy_deg.detach().cpu()
            ],
            "translation_accuracy_angstrom": [
                float(value)
                for value in self.translation_accuracy_angstrom.detach().cpu()
            ],
            "trials": int(self.config.expected_accuracy_trials),
            "enabled": not self.config.skip_expected_accuracy,
            "adaptive_sampling_enabled": False,
        }
