"""Small dependency-free numerical optimisers shared by optics fitting."""
from __future__ import annotations
import torch


def lbfgs(function, initial, *, max_iter=100, tolerance=1.e-8, history_size=10, progress=None):
    """Minimise a scalar differentiable PyTorch objective, retaining the best iterate."""
    x = initial.detach().clone().requires_grad_(True)
    if x.numel() == 0:
        return x.detach(), {'evaluations': 0, 'converged': True}
    best_x = x.detach().clone()
    best = float('inf')
    evaluations = 0
    optimizer = torch.optim.LBFGS([x], lr=1., max_iter=max_iter,
        max_eval=max_iter*3, tolerance_grad=tolerance, tolerance_change=tolerance*tolerance,
        history_size=history_size, line_search_fn='strong_wolfe')

    def closure():
        nonlocal best, best_x, evaluations
        optimizer.zero_grad(set_to_none=True)
        loss = function(x)
        if not torch.isfinite(loss):
            raise FloatingPointError('Non-finite optimisation objective; check starting CTF parameters')
        loss.backward()
        if not torch.isfinite(x.grad).all():
            raise FloatingPointError('Non-finite optimisation gradient')
        evaluations += 1
        if progress is not None:
            progress(dict(evaluations=evaluations, iteration=int(optimizer.state[x].get('n_iter', 0))))
        value = float(loss.detach())
        if value < best:
            best, best_x = value, x.detach().clone()
        return loss

    initial_loss = float(function(x).detach())
    try:
        optimizer.step(closure)
        closure()
    except FloatingPointError:
        if not torch.isfinite(torch.tensor(best)):
            raise
    final = best_x.requires_grad_(True)
    final_loss = function(final)
    gradient, = torch.autograd.grad(final_loss, final)
    maximum = float(gradient.abs().max())
    return best_x.detach(), dict(initial_loss=initial_loss, final_loss=best,
        gradient_max=maximum, evaluations=evaluations,
        iterations=int(optimizer.state[x].get('n_iter', 0)), converged=maximum <= tolerance*10)


def independent_lbfgs(function_and_gradient, initial, *, max_iter=100, tolerance=1.e-8,
                      history_size=8, selected_function_and_gradient=None, progress=None):
    """Batched independent L-BFGS with a separate Armijo line search per row.

    Each row is a separate optimisation problem, so unrelated particles and
    batch boundaries do not affect a particle's step length or stopping rule.
    The callback returns losses (B,) and gradients (B,D). An optional selected
    callback takes (trial_rows, original_row_indices), evaluating only rows
    still waiting for an accepted line-search step. It must describe independent
    objectives with exactly the same normalization as the full callback.
    """
    x = initial.detach().clone()
    value, grad = function_and_gradient(x)
    if not torch.isfinite(value).all() or not torch.isfinite(grad).all():
        raise FloatingPointError('Non-finite initial independent objective')
    start = value.clone()
    evaluations, particle_evaluations, maximum_backtracks = 1, len(x), 0
    failed_search = torch.zeros(len(x), device=x.device, dtype=torch.bool)
    history = []
    active = grad.abs().amax(-1) > tolerance
    iterations = torch.zeros(len(x), device=x.device, dtype=torch.int64)
    for iteration in range(max_iter):
        if not bool(active.any()):
            break
        q = grad.clone()
        alphas = []
        for s, y, rho in reversed(history):
            alpha = rho*(s*q).sum(-1)
            alphas.append(alpha)
            q = q-alpha[:, None]*y
        if history:
            s, y, rho = history[-1]
            gamma = (s*y).sum(-1)/y.square().sum(-1).clamp_min(1.e-30)
            gamma = torch.where(rho > 0, gamma.clamp(1.e-8, 1.e8), torch.ones_like(gamma))
            q = q*gamma[:, None]
        for (s, y, rho), alpha in zip(history, reversed(alphas)):
            beta = rho*(y*q).sum(-1)
            q = q+s*(alpha-beta)[:, None]
        direction = -q
        slope = (direction*grad).sum(-1)
        direction = torch.where((slope >= 0)[:, None], -grad, direction)
        slope = (direction*grad).sum(-1)
        step = torch.ones_like(value)
        # Limit only the initial displacement, not the parameter search range.
        step = torch.minimum(step, 1./direction.abs().amax(-1).clamp_min(1.))
        pending = active.clone()
        nx, nv, ng = x.clone(), value.clone(), grad.clone()
        for backtrack in range(32):
            if selected_function_and_gradient is not None:
                rows = torch.nonzero(pending, as_tuple=False).flatten()
                trial = x[rows]+step[rows, None]*direction[rows]
                tv, tg = selected_function_and_gradient(trial, rows)
                ok = torch.isfinite(tv) & torch.isfinite(tg).all(-1)
                ok &= tv <= value[rows]+1.e-4*step[rows]*slope[rows]
                accepted = rows[ok]
                nx[accepted], nv[accepted], ng[accepted] = trial[ok], tv[ok], tg[ok]
                pending[accepted] = False
                particle_evaluations += len(rows)
            else:
                trial = x+step[:, None]*direction
                tv, tg = function_and_gradient(trial)
                ok = pending & torch.isfinite(tv) & torch.isfinite(tg).all(-1)
                ok &= tv <= value+1.e-4*step*slope
                nx = torch.where(ok[:, None], trial, nx)
                nv = torch.where(ok, tv, nv)
                ng = torch.where(ok[:, None], tg, ng)
                pending &= ~ok
                particle_evaluations += len(x)
            evaluations += 1
            maximum_backtracks = max(maximum_backtracks, backtrack+1)
            if progress is not None:
                # Scalars are resolved by the caller only when a message is due.
                progress(dict(iteration=iteration+1, evaluations=evaluations,
                              active=active, pending=pending, line_search_trial=backtrack+1))
            if not bool(pending.any()):
                break
            step = torch.where(pending, step*.5, step)
        s, y = nx-x, ng-grad
        curvature = (s*y).sum(-1)
        rho = torch.where(curvature > 1.e-20, curvature.clamp_min(1.e-30).reciprocal(), 0.)
        history.append((s, y, rho))
        if len(history) > history_size:
            history.pop(0)
        iterations += active.long()
        failed_search |= pending
        x, value, grad = nx, nv, ng
        active &= ~pending
        active &= grad.abs().amax(-1) > tolerance
    return x, dict(initial_loss=start.cpu().tolist(), final_loss=value.cpu().tolist(),
        gradient_max=grad.abs().amax(-1).cpu().tolist(), iterations=iterations.cpu().tolist(),
        converged=(grad.abs().amax(-1) <= tolerance*10).cpu().tolist(),
        evaluations=evaluations, particle_evaluations=particle_evaluations,
        maximum_line_search_trials=maximum_backtracks, line_search_failed=failed_search.cpu().tolist())
