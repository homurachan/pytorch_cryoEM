"""RELION 3.1 fast-subset schedule, separate from memory/compute batching.

The C rand + forward Fisher-Yates shuffle reproduces libstdc++'s legacy
std::random_shuffle algorithm (verified by the optional compiled test).
Other C/C++ runtimes can generate different permutations. The actual order,
seed and randomised flag are therefore checkpoint state, not reconstructed
from a NumPy RNG or from updated particle metadata.
"""
from __future__ import annotations
import ctypes
import hashlib
import warnings
import numpy as np
import torch


def native_subset_size(iteration: int, particles: int, classes: int, reference_dim: int = 2) -> int:
    """Return the upstream -1 sentinel for full-data stages, else subset size."""
    if iteration < 1 or particles < 1 or classes < 1 or reference_dim not in (2, 3):
        raise ValueError('iteration/N/K must be positive and reference_dim must be 2 or 3')
    minimum = (100 if reference_dim == 2 else 1500)*classes
    if iteration <= 5:
        size = minimum
    elif iteration <= 10:
        size = 3*minimum
    elif iteration <= 15:
        size = max(3*minimum, int(.3*particles))
    else:
        size = -1
    return -1 if size > particles else size


def fast_subset_size(iteration: int, particles: int, classes: int, reference_dim: int = 2) -> int:
    size = native_subset_size(iteration, particles, classes, reference_dim)
    return particles if size < 0 else size


class FastSubsetState:
    def __init__(self, optics_groups, seed: int, classes: int, reference_dim: int = 2):
        self.optics = np.asarray(optics_groups, dtype=np.int64).copy()
        if self.optics.ndim != 1 or not len(self.optics):
            raise ValueError('nonempty 1-D optics groups required')
        if seed < 0:
            raise ValueError('resolve random seed before constructing fast-subset state')
        self.seed, self.classes, self.reference_dim = int(seed), int(classes), int(reference_dim)
        self.order = np.arange(len(self.optics), dtype=np.int64)
        self.randomised = False
        self.iteration = 0

    def select(self, iteration: int):
        if iteration != self.iteration+1:
            raise ValueError('fast-subset iterations must be sequential; restore checkpoint state before continuation')
        raw = native_subset_size(iteration, len(self.order), self.classes, self.reference_dim)
        # Literal upstream do_subsets=(subset_size < N), including the -1 sentinel.
        if self.seed > 0 and (not self.randomised or raw < len(self.order)):
            from relion_torch.optimiser.alignment import _c_random_functions, _C_RAND_LOCK
            srand, rand = _c_random_functions()
            with _C_RAND_LOCK:
                srand(ctypes.c_uint((self.seed+iteration)&0xffffffff))
                for i in range(1, len(self.order)):
                    j = int(rand()) % (i+1)
                    self.order[i], self.order[j] = self.order[j], self.order[i]
            # Match Experiment::randomiseParticlesOrder; optics sorting is NOT a
            # stratified subset. Early groups can dominate small native subsets.
            self.order = self.order[np.argsort(self.optics[self.order], kind='stable')]
            self.randomised = True
        if self.seed == 0 and self.iteration == 0:
            warnings.warn('RELION fast_subsets with random_seed=0 skips shuffling; use a positive seed for random subsets.', RuntimeWarning)
        self.iteration = iteration
        selected = self.order[:len(self.order) if raw < 0 else raw].copy()
        return selected

    def state_dict(self):
        return dict(format='relion-fast-subsets-v1', order=torch.from_numpy(self.order.copy()),
                    optics=torch.from_numpy(self.optics.copy()), seed=self.seed, classes=self.classes,
                    reference_dim=self.reference_dim, iteration=self.iteration, randomised=self.randomised)

    def load_state_dict(self, value):
        if value.get('format') != 'relion-fast-subsets-v1':
            raise ValueError('unsupported fast-subset state')
        for key in ('seed', 'classes', 'reference_dim'):
            if int(value[key]) != getattr(self, key):
                raise ValueError(f'checkpoint fast-subset {key} differs')
        order = np.asarray(value['order'].cpu(), dtype=np.int64)
        if not np.array_equal(np.sort(order), np.arange(len(self.order))):
            raise ValueError('checkpoint particle order is not a dataset permutation')
        if not np.array_equal(np.asarray(value['optics'].cpu()), self.optics):
            raise ValueError('checkpoint optics/particle ordering differs')
        self.order = order.copy()
        self.iteration = int(value['iteration'])
        self.randomised = bool(value['randomised'])

    @staticmethod
    def digest(indices):
        return hashlib.sha256(np.asarray(indices, dtype='<i8').tobytes()).hexdigest()
