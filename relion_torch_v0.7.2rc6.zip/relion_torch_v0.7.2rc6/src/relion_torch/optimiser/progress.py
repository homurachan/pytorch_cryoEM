"""Throttled host-side progress display shared by iterative SPA programs.

No tensor reads, device synchronization, background threads or dependencies.
Counters describe completed particle work, not reconstruction/checkpoint work.
"""
import shutil
import sys
import time


def _duration(seconds):
    if seconds is None:
        return '--:--'
    value = max(0, int(seconds))
    hours, rest = divmod(value, 3600)
    minutes, seconds = divmod(rest, 60)
    return f'{hours}:{minutes:02d}:{seconds:02d}' if hours else f'{minutes:02d}:{seconds:02d}'


class ParticleProgress:
    """In-place terminal bar, or occasional newline snapshots in a log.

    Advance only after a successful effective particle batch. Context exit
    terminates the display on normal completion, exceptions and Ctrl+C. An
    incomplete/failed phase is never promoted to 100 percent.
    """
    def __init__(self, total, *, enabled=True, stream=None):
        self.total = max(0, int(total))
        self.enabled = bool(enabled)
        self.stream = sys.stdout if stream is None else stream
        self.terminal = bool(getattr(self.stream, 'isatty', lambda: False)())
        self.interval = .5 if self.terminal else 30.
        self.done = 0
        self.started = self.last_update = 0.
        self.line_width = 0

    def __enter__(self):
        if self.enabled:
            self.started = self.last_update = time.perf_counter()
            self._render(self.started)
        return self

    def update(self, completed):
        if not self.enabled:
            return
        self.done += int(completed)
        now = time.perf_counter()
        # Context exit supplies the single final line, after batch cleanup.
        if self.done < self.total and now-self.last_update >= self.interval:
            self._render(now)

    def _render(self, now, *, final=False, status=''):
        elapsed = max(0., now-self.started)
        fraction = min(1., self.done/self.total) if self.total else 1.
        percent = 100. if self.done >= self.total else min(99.9, 100*fraction)
        remaining = elapsed*max(0, self.total-self.done)/self.done if self.done else None
        if self.done >= self.total:
            remaining = 0.
        columns = shutil.get_terminal_size(fallback=(100, 24)).columns if self.terminal else 100
        prefix = '  Particles '
        suffix = (f' {percent:5.1f}% {self.done}/{self.total}'
                  f' | {_duration(elapsed)} ETA {_duration(remaining)}')
        if status:
            suffix += ' | '+status
        width = min(24, max(4, columns-len(prefix)-len(suffix)-3))
        filled = min(width, int(fraction*width))
        bar = '='*filled
        if filled < width:
            bar += '>'+'-'*(width-filled-1)
        line = prefix+'['+bar+']'+suffix
        if self.terminal:
            # Keep the cursor on one physical line even in a narrow terminal.
            line = line[:max(1, columns-1)]
            padding = max(0, min(self.line_width, columns-1)-len(line))
            self.stream.write('\r'+line+' '*padding+('\n' if final else ''))
            self.line_width = len(line)
        else:
            self.stream.write(line+'\n')
        self.stream.flush()
        self.last_update = now

    def __exit__(self, exc_type, exc_value, traceback):
        if self.enabled:
            status = ('interrupted' if issubclass(exc_type, KeyboardInterrupt) else 'failed') if exc_type else ''
            self._render(time.perf_counter(), final=True, status=status)
        return False
