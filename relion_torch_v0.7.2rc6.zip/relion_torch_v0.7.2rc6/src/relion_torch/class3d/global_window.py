"""Class3D adapter for cooperative coarse sweeps with an explicit byte grant."""
from dataclasses import replace
from relion_torch.inference.execution_policy import GlobalWindowPlan


def configure(owner,workload,plan,firstiter_cc):
    owner._class3d_window_plan=None
    options=owner.options
    if (getattr(owner,'optimized',False) or getattr(options,'combine_refine',False)
            or options.local_angular_search or owner.device.type!='cuda'
            or workload.fixed or firstiter_cc or plan.full_coarse or options.global_window_mib<=0
            or (owner.generate_seeds and owner.last_completed_iteration<2)):
        return plan
    # Broad posteriors leave too few simultaneous particle slots at the old
    # microbatch size. One-particle scorers retain complete hypotheses; their
    # requests cooperate in a bounded orientation-major window.
    trial=owner.memory_controller.plan(replace(workload,requested_batch=1))
    grant=min(int(options.global_window_mib*2**20),trial.projection_bytes//2)
    window=GlobalWindowPlan.make(batch=trial.particle_batch,orientations=workload.orientations,
        translations=workload.translations,classes=workload.classes,
        original_size=workload.original_size,coarse_pixels=workload.coarse_size*(workload.coarse_size//2+1),
        available_bytes=grant,maximum_bytes=grant)
    if not window.particles:return plan
    projection=trial.projection_bytes-window.estimated_bytes
    reserve=min(trial.fine_reserve_bytes,projection//4)
    owner._class3d_window_plan=window
    return replace(trial,projection_bytes=projection,fine_reserve_bytes=reserve,
        fine_cache_bytes=min(trial.full_fine_bytes,reserve),full_fine=False,cache_active=False,
        estimated_estep_extra_bytes=trial.estimated_estep_extra_bytes-window.estimated_bytes)


def evaluate(owner,indices,raw,sigma,engine,bank,timer,iteration):
    from relion_torch.auto_refine.global_window import evaluate_window
    engine.allowed_classes=None
    yield from evaluate_window(owner,indices,raw,sigma,engine,timer,iteration)
