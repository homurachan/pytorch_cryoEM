"""point-group SPA Class3D state machine; 2-D observations, 3-D references.

The E-step is immutable for an iteration. Global-search statistics coalesce
translations by orientation using shared SPA primitives and bounded packed
backprojection sums; fixed poses retain the parent path.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
from pathlib import Path
import gc
import json
import math
import os
import time
import warnings
import numpy as np
import pandas as pd
import torch
from relion_torch.inference.execution_policy import candidate_budget

from relion_torch.alignment.core import _euler_matrix
from relion_torch.alignment.model_statistics import (
    accumulate_scale_statistics_, add_high_resolution_power_, lowpass_model_spectra)
from relion_torch.version import __version__
from relion_torch.relion_statistics import shell_to_angstrom
from relion_torch.class2d.optimiser import Class2DOptimiser, Prepared
from relion_torch.class2d.performance import StageTimer, DetailTimer
from relion_torch.class2d.accumulation_statistics import ParticleNoiseAccumulator
from relion_torch.class2d.semantics import update_norm_corrections, update_group_scales
from relion_torch.inference.alignment import (
    AlignmentExpectationConfig, DenseBatchExpectation, SparseAdaptiveBatchExpectation,
    likelihood_rfft_mask, likelihood_inverse_noise, rounded_shell_indices_2d, phase_shift_rfft,
)
from relion_torch.geometry.grids import signed_fft_indices
from relion_torch.optimiser.alignment import AlignmentOptimiser, AlignmentConfig
from relion_torch.optimiser.subsets import FastSubsetState
from relion_torch.io.star import write_star
from relion_torch.io.mrc import write_mrc
from .sampling import Class3DSampling
from .expectation import Class3DExpectation, SplitParticleBatch
from .resources import ProjectorPool, BackprojectorPool, GroupedBackprojection3D, FineProjectionStore
from .references import solvent_mask_3d, lowpass_3d

MIB=1024**2

@dataclass
class PoseExpectation:
    projections: torch.Tensor       # B,K,S,W
    translations: torch.Tensor      # B,T,2 Angstrom residual offsets
    angles: torch.Tensor            # B,3
    phase: torch.Tensor             # B,T,S,W
    posterior: torch.Tensor         # B,K,T
    significant: torch.Tensor
    class_mass: torch.Tensor
    best_index: torch.Tensor
    pmax: torch.Tensor
    log_likelihood_contribution: torch.Tensor
    significant_count: torch.Tensor
    diff2: torch.Tensor
    log_prior: torch.Tensor
    @property
    def retained_weights(self):return self.posterior*self.significant.to(self.posterior.dtype)
    def best_values(self):
        t=self.best_index%self.translations.shape[1]
        c=torch.div(self.best_index,self.translations.shape[1],rounding_mode='floor')
        return c,self.angles,self.translations[torch.arange(len(c),device=c.device),t],None

@dataclass
class Moments3D:
    class_mass: torch.Tensor
    direction_mass: torch.Tensor
    offset_square: torch.Tensor
    noise: torch.Tensor
    xa: torch.Tensor
    aa: torch.Tensor


def _primitive(value):
    if isinstance(value,Path):return str(value)
    if isinstance(value,dict):return {str(k):_primitive(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_primitive(v) for v in value]
    if isinstance(value,np.generic):return value.item()
    return value

class Class3DOptimiser(AlignmentOptimiser):
    _defer_reference_output=True
    # These methods operate on 2-D particle observations and scalar model
    # corrections only. Their source remains shared with validated Class2D.
    option=Class2DOptimiser.option
    _optimized_execution=Class2DOptimiser._optimized_execution
    _prepare_execution_scalars=Class2DOptimiser._prepare_execution_scalars
    _detail_start=Class2DOptimiser._detail_start
    _detail_stop=Class2DOptimiser._detail_stop
    _raw_ctf_batch=Class2DOptimiser._raw_ctf_batch
    _raw_ctf=Class2DOptimiser._raw_ctf
    _accuracy_ctf=Class2DOptimiser._accuracy_ctf
    _check_optics_capabilities=Class2DOptimiser._check_optics_capabilities
    _load_optional_mask=Class2DOptimiser._load_optional_mask
    def _prepare_batch(self,indices,sigma_old,raw_images=None):
        window=getattr(self,'_global_window',None)
        if window is not None:
            cached=window.prepared.pop(tuple(indices),None)
            if cached is not None:return cached
        return Class2DOptimiser._prepare_batch(self,indices,sigma_old,raw_images)

    def __init__(self,config:AlignmentConfig,*,options,dataset,initial_references,
                 generate_seeds=False,checkpoint_state=None,startup=None,requested_options=None,memory_controller=None):
        if config.reference_dim!=3:raise ValueError('Class3D requires reference_dim=3')
        self.options=options
        self.requested_options=replace(requested_options or options,
            input_star=options.input_star,output_root=options.output_root)
        self.memory_controller=memory_controller
        self._memory_plan=None
        self._startup_checkpoint=checkpoint_state;self._startup_context=startup
        self.use_ctf=options.use_ctf;self.refs_are_ctf_corrected=options.ctf_corrected_ref
        self.do_norm=options.do_norm_correction;self.do_scale=options.do_scale_correction
        self.avg_norm_correction=1.;self.ctf_premultiplied=options.ctf_premultiplied
        self.generate_seeds=bool(generate_seeds);self.last_completed_iteration=config.iteration_offset
        self._direction_prior_reset_pending=False
        self._perf_counters={};self._detail_timer=None;self._iteration_history=[]
        super().__init__(config,dataset=dataset,initial_references=initial_references)
        self._check_optics_capabilities()
        if len(self.group_ids)==1:self.do_scale=False
        self.group_scales=torch.ones(len(self.group_ids),device=self.device,dtype=torch.float64)
        norms=self.dataset.particles.get('rlnNormCorrection',pd.Series(np.ones(len(dataset))))
        self.norm_corrections=torch.tensor(np.array(norms,dtype=np.float64,copy=True),device=self.device)
        if self.do_norm and (not bool(torch.isfinite(self.norm_corrections).all()) or bool((self.norm_corrections<=0).any())):
            raise ValueError('input norm correction must be positive and finite')
        self.has_premultiplied=self.ctf_premultiplied or any(r.ctf_premultiplied for r in dataset._records)
        if self.has_premultiplied and not self.use_ctf:raise ValueError('CTF-premultiplied particles require --ctf')
        self.sampling=Class3DSampling(3,config.healpix_order,config.psi_step,
            options.offset_range_pixels*dataset.pixel_size,options.offset_step_pixels*dataset.pixel_size,
            self.config.oversampling,0. if (config.skip_align or config.skip_rotate) else options.perturbation_factor,0.,symmetry=options.symmetry)
        if options.symmetry != "C1":
            self.direction_priors=torch.full((len(self.references),len(self.sampling.directions)),1./len(self.sampling.directions),device=self.device)
        if config.skip_align or config.skip_rotate:
            self.sampling.fix_orientations()
            self.direction_priors=torch.ones((len(self.references),1),device=self.device,dtype=torch.float32)
        self.generator=np.random.default_rng(config.random_seed)
        if checkpoint_state is None and not (config.skip_align or config.skip_rotate):self.sampling.advance(self.generator)
        explicit=self._load_optional_mask('solvent_mask')
        self._solvent_mask=explicit if explicit is not None else solvent_mask_3d(dataset.box_size,
            self.particle_diameter_angstrom/(2*dataset.pixel_size),config.mask_edge_pixels,self.device)
        self._subset_state=(FastSubsetState(dataset.particles.rlnOpticsGroup.to_numpy(),config.random_seed,
                             len(self.references),3) if options.fast_subsets else None)
        if checkpoint_state is not None:self.restore_checkpoint(checkpoint_state)
        else:
            ini=options.initial_high_resolution
            if ini and ini>0:
                self._set_references([lowpass_3d(x,ini,dataset.pixel_size) for x in self.references])
                self.tau2=[self._reference_tau2(x) for x in self.references]
                self.data_vs_prior=[self._initial_data_vs_prior(c) for c in range(len(self.references))]
            self._refresh_fourier_sizes()
        self._startup_checkpoint=None

    def _make_reference_projectors(self,references):
        support=self.config.current_size or self.dataset.box_size
        self._projector_pool=ProjectorPool(references,self.config.padding_factor,self.device,
            int(self.options.projector_cache_mib*MIB),current_size=support)
        return self._projector_pool.proxies()

    def _updated_reference_projector(self,c):
        self._projector_pool.references=self.references
        self._projector_pool.objects.pop(c,None);self._projector_pool.generation+=1
        return self._projector_pool.proxies()[c]

    def _set_references(self,values):
        if hasattr(self,'_projector_pool'):self._projector_pool.clear()
        self.references=[x.detach().to(self.device,dtype=torch.float32) for x in values]
        self.projectors=self._make_reference_projectors(self.references)
        if hasattr(self,'sizes'):self._projector_pool.set_support(self.sizes.current_size)

    def _initial_noise(self):
        if self._startup_checkpoint is not None:
            values=self._startup_checkpoint['sigma2']
            if len(values)!=len(self.group_ids):raise ValueError('checkpoint noise-group count mismatch')
            if self._startup_context:self._startup_context.counters['noise_spectrum_from_checkpoint']=1
            return [v.to(self.device,dtype=torch.float32).clone() for v in values]
        from relion_torch.alignment.initialization import initialize_noise_batched
        return initialize_noise_batched(self.dataset,device=self.device,batch_size=self.config.batch_size,
            particle_diameter=self.particle_diameter_angstrom,mask_edge_pixels=self.config.mask_edge_pixels,
            zero_mask=self.config.zero_mask,work_bytes=int(self.options.preprocess_work_mib*MIB),
            cache_bytes=int(self.options.preprocess_cache_mib*MIB),context=self._startup_context)

    def _observation_pose(self,records,indices,integer,pixel):
        # SPA has XY origin priors in Angstroms even for a 3-D reference.
        prior=torch.tensor([[r.origin_prior_x_angstrom,r.origin_prior_y_angstrom] for r in records],
                           device=self.device,dtype=torch.float32)
        centres=prior-integer*pixel
        angles=torch.tensor([[r.rot,r.tilt,r.psi] for r in records],device=self.device,dtype=torch.float32)
        return centres,angles

    def _angular_centres(self,indices):
        from relion_torch.sampling.local import resolve_prior_centres
        records=[self.dataset.record(int(i)) for i in indices]
        current=[[r.rot,r.tilt,r.psi] for r in records]
        prior=[[r.rot_prior,r.tilt_prior,r.psi_prior] for r in records]
        return resolve_prior_centres(current,prior)

    def _allowed_classes(self,indices,iteration):
        if not self.generate_seeds:return None
        if self.config.firstiter_cc and iteration==1:return torch.zeros(len(indices),device=self.device,dtype=torch.long)
        seediter=2 if self.config.firstiter_cc else 1
        if iteration!=seediter:return None
        from relion_torch.class2d.initialise import relion_c_random_values
        # Use global row identity, never a GPU worker or microbatch number.
        sources=self.dataset.source_row_indices()
        result=[int(relion_c_random_values(self.config.random_seed+int(sources[i]),1)[0])%len(self.references)
                for i in indices]
        return torch.tensor(result,device=self.device,dtype=torch.long)

    def _coarse_direction_indices(self,ids):
        mapper=getattr(self.sampling,"coarse_direction_indices",None)
        return mapper(ids) if mapper is not None else ids//len(self.sampling.psi_angles)

    def _execution_indices(self,selected):return selected

    def _execution_read_batch_size(self):
        window=getattr(self,'_class3d_window_plan',None)
        # Seed class restrictions are per particle. Keep their original path.
        seeds=self.generate_seeds and self.last_completed_iteration<2
        return self.config.batch_size if window is None or seeds else max(self.config.batch_size,window.particles)

    def _finish_expectation_execution(self,engine,timer):
        buffer=getattr(self,'_local_projection_buffer',None)
        if buffer is not None:
            engine.memory_counters.update(buffer.counts)
            buffer.release()
            self._local_projection_buffer=None

    def _make_engine(self,iteration):
        owner=self
        class Callback:
            fusion_mode=(owner.options.local_fusion if owner.options.local_angular_search and owner.options.local_projection_mode=="stream"
                         and getattr(owner.options,"auto_execution","optimized")!="reference" else "off")
            def fusion_inputs(self,c,inverses):return owner.projectors[c].fusion_inputs(inverses)
            def __call__(self,c,angles,size):return owner.projectors[c].project_batch(angles,size,chunk_size=owner.config.orientation_chunk_size)
            def project_inverse(self,c,inverses,size):return owner.projectors[c].project_inverse_batch(inverses,size)
            def source_cache_token(self):return (id(owner._projector_pool),owner._projector_pool.generation,owner.sizes.current_size)
        config=AlignmentExpectationConfig(adaptive_fraction=self.config.adaptive_fraction,
            firstiter_cc=self.config.firstiter_cc and iteration==1,cc_score_only=True,
            adaptive_oversampling=self.config.oversampling,sigma_offset_angstrom=self.sigma_offset_angstrom,
            chunk_size=self.config.orientation_chunk_size,cache_active_views=False,
            sigma_rot_deg=self.config.sigma_rot_deg,sigma_tilt_deg=self.config.sigma_tilt_deg,sigma_psi_deg=self.config.sigma_psi_deg,
            fine_score_mode=self.options.fine_score_mode,candidate_chunk_size=self.options.candidate_chunk_size,
            candidate_work_bytes=candidate_budget(self),weight_precision=self.options.weight_precision,
            dense_fine_execution=self.options.dense_fine_execution)
        engine=getattr(self,"expectation_type",Class3DExpectation)(self.sampling,self.sizes,Callback(),self.class_prob,
            direction_priors=self.direction_priors,config=config,
            reset_direction_prior=self._direction_prior_reset_pending,
            projection_cache_bytes=int(self.options.performance_cache_mib*MIB),
            coarse_cache_policy=self.options.coarse_cache_policy,
            coarse_host_cache_bytes=int(self.options.coarse_host_cache_mib*MIB),
            posterior_bytes=int(self.options.posterior_work_mib*MIB),
            coarse_score_chunk_size=self.options.coarse_score_chunk_size,particle_batch_size=self.options.batch_size,
            cache_active=self._memory_plan.cache_active if self._memory_plan is not None else True,
            fine_reserve_bytes=self._memory_plan.fine_reserve_bytes if self._memory_plan is not None else None)
        engine.detail_timer=self._detail_timer
        engine.local_coarse_mode=self.options.local_coarse_mode
        engine.global_fusion=self.options.global_fusion
        from relion_torch.inference.local_projection import streaming_local, LocalProjectionBuffer
        if streaming_local(self):
            buffer=getattr(self,'_local_projection_buffer',None)
            if buffer is None:
                budget=min(int(self.options.local_projection_mib*MIB),getattr(self,'_cache_ceiling',2**63-1))
                if self._memory_plan is not None:budget=min(budget,self._memory_plan.projection_bytes)
                buffer=LocalProjectionBuffer(budget,self.device)
                buffer.projection_reuse=self.options.local_projection_reuse
                buffer.fine_inputs=self.options.local_fine_inputs
                buffer.fine_chunking=self.options.local_fine_chunking
                buffer.statistics_inputs=self.options.local_statistics_inputs
                buffer.statistics_reduction=self.options.local_statistics_reduction
                buffer.work_bytes=candidate_budget(self)
                self._local_projection_buffer=buffer
                from relion_torch.inference.fused_projection import available
                enabled=available(self.device,engine.projector.fusion_mode)
                buffer.count('fusion_enabled',int(enabled),peak=True)
                if self.device.type=='cuda' and engine.projector.fusion_mode!='off' and not enabled and not getattr(self,'_fusion_notice',False):
                    print('  Local CUDA fusion unavailable; using the bounded PyTorch projection path.',flush=True)
                    self._fusion_notice=True
            engine.local_buffer=buffer
            engine.cache.max_bytes=0
            # Used by the independent scalar/reference path only in cached mode.
            engine.bulk_local=False
        from relion_torch.inference.global_fine import configure
        configure(self,engine)
        return engine

    def _build_projection_bank(self,engine,timer,pixel):
        if engine.local_buffer is not None:return None
        size,shell=self.sizes.coarse_likelihood_grid(self.config.oversampling)
        for attempt in range(3):
            failed=False
            try:
                return timer.call('coarse_projection_setup',engine.build_global_projection_bank,pixel_size=pixel,
                    image_size=size,maximum_shell=shell)
            except torch.cuda.OutOfMemoryError:
                if self.memory_controller is None or attempt==2:raise
                failed=True
            if failed:
                engine.release_projection_storage()
                engine.cache.max_bytes=engine.cache.max_bytes//2 if attempt==0 else 0
                engine.cache_active=False
                gc.collect()
                with torch.cuda.device(self.device):torch.cuda.empty_cache()
                self.memory_controller.recovered_oom()
                self._perf_counters['projection_setup_oom_retries']=self._perf_counters.get('projection_setup_oom_retries',0)+1

    def _pose_expectation(self,p,engine):
        """Fixed Euler angles with the native single-pass XY grid.

        ml_optimiser.cpp:1769-1780 disables perturbation and oversampling for
        BOTH skip-align and skip-rotate. The shared constructor enforces this.
        """
        b=len(p.indices);k=len(self.references);s=self.sizes.current_size;device=self.device
        over=0
        if self.config.oversampling!=0:raise RuntimeError("Fixed orientations require native single-pass sampling")
        trans=(p.residual[:,None,:] if self.config.skip_align else
            torch.tensor(self.sampling.translations,device=device,dtype=torch.float32)[None].expand(b,-1,-1))
        t=trans.shape[1];tc=4**over
        expected=b*(k+t*tc)*s*(s//2+1)*8*8+b*k*t*tc*112
        if expected>candidate_budget(self):raise SplitParticleBatch('fixed-pose observation workspace')
        if b*k*t*tc*112>int(self.options.posterior_work_mib*MIB):raise SplitParticleBatch('fixed-pose posterior workspace')
        projections=torch.stack([self.projectors[c].project_batch(p.angles,s,self.config.orientation_chunk_size)
                                 for c in range(k)],dim=1)
        high,logs=engine._highres_terms_batch(p.like,p.sigma,self.sizes.current_shell)
        # Native CPU orientation-prior normalization for fixed directions.
        cp=torch.log(self.class_prob)-torch.log(self.class_prob.mean())
        logp=cp[:,None].expand(k,t)[None].expand(b,-1,-1).clone()
        if not self.config.skip_align:
            coarse_xy=torch.as_tensor(self.sampling.prior_translations,device=device,dtype=torch.float32)
            delta=(coarse_xy[None]-p.centres[:,None]).square().sum(-1)
            if self.sigma_offset_angstrom**2<.0001:prior=(delta==0).to(torch.float32)
            else:prior=torch.exp(-.5*delta/self.sigma_offset_angstrom**2)
            prior=prior/prior.mean(-1,keepdim=True).clamp_min(torch.finfo(prior.dtype).tiny)
            logp+=torch.where(prior>0,prior.log(),-torch.inf)[:,None]
        if engine.allowed_classes is not None:
            # Restricted seed-class range has mean equal to its own PDF.
            logp=logp-cp[engine.allowed_classes][:,None,None]
            logp=logp.masked_fill(torch.arange(k,device=device)[None,:,None]!=engine.allowed_classes[:,None,None],-torch.inf)
        def score(xy,size,maxshell,prior):
            phase=phase_shift_rfft((size,size//2+1),xy/self.dataset.pixel_size,device,torch.float32,
                                  original_size=self.dataset.box_size)
            mask=likelihood_rfft_mask(size,maxshell,device,firstiter_cc=engine.config.firstiter_cc)
            shells=rounded_shell_indices_2d(size,device)[mask]
            image=engine._window_rfft(p.like,size)[:,mask]
            scoring_projections=(projections if size==s else torch.stack([
                self.projectors[c].project_batch(p.angles,size,self.config.orientation_chunk_size)
                for c in range(k)],dim=1))
            pred=scoring_projections[:,:,mask]*engine._window_rfft(p.prediction,size)[:,None,mask]
            inv=likelihood_inverse_noise(p.sigma,shells,firstiter_cc=engine.config.firstiter_cc)
            shifted=image[:,None,:]*phase[:,:,mask]
            cross=torch.einsum('btf,bkf->bkt',shifted.real,pred.real*inv[:,None])+torch.einsum('btf,bkf->bkt',shifted.imag,pred.imag*inv[:,None])
            xnorm=(image.abs().square()*inv).sum(-1)
            rnorm=(pred.abs().square()*inv[:,None]).sum(-1)
            diff=(.5*(xnorm[:,None,None]+rnorm[:,:,None]-2*cross)).clamp_min(0)+high[:,None,None]
            if not torch.isfinite(prior.flatten(1)).any(1).all():
                raise ValueError('Fixed-pose particle has no candidate with a non-zero prior')
            if engine.config.firstiter_cc:
                cr=torch.einsum('btf,bkf->bkt',shifted.real,pred.real)+torch.einsum('btf,bkf->bkt',shifted.imag,pred.imag)
                cr=cr/(image.abs().square().sum(-1)[:,None,None]*pred.abs().square().sum(-1)[:,:,None]).clamp_min(1e-30).sqrt()
                best=cr.masked_fill(~torch.isfinite(prior),-torch.inf).flatten(1).argmax(1)
                post=torch.zeros_like(diff).flatten(1);post.scatter_(1,best[:,None],1);post=post.reshape_as(diff)
                significant=post.bool();pmax=torch.ones(b,device=device);count=torch.ones(b,device=device,dtype=torch.long)
                dll=cr.flatten(1).gather(1,best[:,None]).squeeze(1)
            else:
                sel=engine._select_weights(prior.flatten(1),diff.flatten(1),self.config.adaptive_fraction)
                post=sel.posterior.reshape_as(diff);significant=sel.significant.reshape_as(diff)
                best=sel.best_index;pmax=sel.pmax;count=sel.reported_significant_count;dll=sel.log_evidence-logs
            return diff,phase,post,significant,best,pmax,count,dll
        coarse_size=self.sizes.likelihood_image_size(not bool(over))
        result=score(trans,coarse_size,self.sizes.likelihood_shell(not bool(over)),logp)
        reported=result[6]
        self._perf_counters['fixed_coarse_hypotheses']=self._perf_counters.get('fixed_coarse_hypotheses',0)+b*k*t
        diff,phase,post,significant,best,pmax,_,dll=result
        if coarse_size!=s:
            phase=phase_shift_rfft((s,s//2+1),trans/self.dataset.pixel_size,device,torch.float32,
                                  original_size=self.dataset.box_size)
        if not torch.isfinite(dll).all():raise FloatingPointError('fixed-pose posterior has nonfinite evidence')
        mass=(post.to(torch.float64)*significant).sum(-1)
        return PoseExpectation(projections,trans,p.angles,phase,post,significant,mass,best,pmax,dll,reported,diff,logp)

    def _evaluate(self,indices,raw,sigma_old,engine,bank,timer,iteration,_oom_retry=False):
        engine.posterior_bytes=max(engine.posterior_bytes,int(self.options.posterior_work_mib*MIB))
        window=getattr(self,'_class3d_window_plan',None)
        if (window is not None and getattr(self,'_global_window',None) is None
                and not _oom_retry and len(indices)>self.config.batch_size
                and not (self.generate_seeds and iteration<=2)):
            from .global_window import evaluate
            self._perf_counters['global_window_budget_bytes']=window.budget_bytes
            self._perf_counters['global_window_estimated_bytes']=window.estimated_bytes
            self._perf_counters['execution_estimated_estep_extra_bytes']=self._memory_plan.estimated_estep_extra_bytes+window.estimated_bytes
            yield from evaluate(self,indices,raw,sigma_old,engine,bank,timer,iteration)
            return
        from relion_torch.inference.local_projection import streaming_local, merge_counters
        # HalfOptimiser has already selected compact support and isolated optics.
        if not streaming_local(self) or hasattr(self,'_sampling_root'):
            if engine.local_buffer is not None:engine.local_buffer.begin_batch()
            yield from self._evaluate_scored(indices,raw,sigma_old,engine,bank,timer,iteration,_oom_retry)
            return
        from relion_torch.sampling.selected import select_sampling,subset_selected_sampling
        root=getattr(self.sampling,'root',self.sampling)
        scope=getattr(self,'_local_support_scope',None)
        try:
            positions=None
            if scope is not None and scope[1].root is root:
                lookup={int(index):row for row,index in enumerate(scope[0])}
                if all(int(index) in lookup for index in indices):positions=[lookup[int(index)] for index in indices]
            if positions is not None:
                compact,support=timer.call('local_candidate_setup',subset_selected_sampling,scope[1],scope[2],positions)
                self._perf_counters['local_candidate_reused_particles']=self._perf_counters.get('local_candidate_reused_particles',0)+len(indices)
            else:
                compact,support=timer.call('local_candidate_setup',select_sampling,root,self._angular_centres(indices),self.options.angular_sigmas,
                    int(self.options.sampling_work_mib*MIB),mode=self.options.local_candidate_search,counters=self._perf_counters)
        except MemoryError:
            if len(indices)==1:raise
            mid=len(indices)//2
            yield from self._evaluate(indices[:mid],raw[:mid],sigma_old,engine,None,timer,iteration,_oom_retry)
            yield from self._evaluate(indices[mid:],raw[mid:],sigma_old,engine,None,timer,iteration,_oom_retry)
            return
        previous=self.sampling
        local=None
        try:
            self._local_support_scope=(np.asarray(indices).copy(),compact,support)
            self.sampling=compact
            local=self._make_engine(iteration)
            local.precomputed_support=support
            local.local_buffer.begin_batch()
            self._perf_counters['compact_sampling_batches']=self._perf_counters.get('compact_sampling_batches',0)+1
            yield from self._evaluate_scored(indices,raw,sigma_old,local,None,timer,iteration,_oom_retry)
        finally:
            if scope is None:self.__dict__.pop('_local_support_scope',None)
            else:self._local_support_scope=scope
            self.sampling=previous
            if local is not None:
                merge_counters(engine.memory_counters,local.memory_counters)
                if self.memory_controller is not None:self.memory_controller.observe(local.memory_counters)
                local.release_projection_storage()

    def _score_prepared(self,p,engine,bank,timer,iteration):
        """Shared scoring hook; specialised latent-variable tasks may extend it."""
        if self.config.skip_align or self.config.skip_rotate:
            return timer.call('fixed_expectation',self._pose_expectation,p,engine)
        local=self.options.local_angular_search
        centres=self._angular_centres(p.indices) if local else None
        scorer=engine.run_local_batch if local else engine.run_global_batch
        window=getattr(self,'_global_window',None)
        coarse=None if window is None else window.coarse.pop(tuple(p.indices),None)
        if coarse is None:
            coarse=timer.call('coarse_expectation',scorer,p.like,p.prediction,p.sigma,
                offset_prior_angstrom=p.centres,orientation_prior_deg=centres,pixel_size=self.dataset.pixel_size,bank=bank)
        return (timer.call('fine_expectation',engine.run_sparse_adaptive_batch,p.like,p.prediction,p.sigma,
            offset_prior_angstrom=p.centres,orientation_prior_deg=None,pixel_size=self.dataset.pixel_size,coarse=coarse)
            if self.config.oversampling>0 else coarse)

    def _evaluate_scored(self,indices,raw,sigma_old,engine,bank,timer,iteration,_oom_retry=False):
        """Split only particle batches; preserve full candidate sets and seeds."""
        # A budget rebalance invalidates slab ownership, including banks held by
        # outer split-batch frames. Let the engine rebuild under its new limit.
        if bank is not None and all(bank is not b for b in engine._global_projection_banks.values()):bank=None
        failure=None;oom=False;posterior_need=None
        try:
            if not (self.config.skip_align or self.config.skip_rotate or self.options.local_angular_search):engine.check_coarse_budget(len(indices))
            elif self.options.local_angular_search and not (self.config.skip_align or self.config.skip_rotate):
                support=getattr(engine,'precomputed_support',None)
                if support is not None:
                    # Check the actual support before image preparation. A
                    # nearby outlier may use spare budget without rescoring or
                    # releasing the batch's reserved projection workspace.
                    self._perf_counters['local_preflight_batches']=self._perf_counters.get('local_preflight_batches',0)+1
                    try:
                        engine.check_local_budget(len(indices),int(support.counts.max()),engine.sampling.number_of_translations)
                    except SplitParticleBatch as exc:
                        from .posterior_budget import grow_posterior
                        grown=False
                        if not _oom_retry and exc.required_posterior_bytes is not None:
                            grown,_=grow_posterior(self,engine,exc.required_posterior_bytes,
                                particles=len(indices),preserve_projection=True)
                        if not grown:
                            self._perf_counters['local_preflight_rejected_batches']=self._perf_counters.get('local_preflight_rejected_batches',0)+1
                            raise
            p=timer.call('prepare_particles',self._prepare_batch,indices,sigma_old,raw)
            engine.allowed_classes=self._allowed_classes(indices,iteration)
            result=self._score_prepared(p,engine,bank,timer,iteration)
            # M-step uses current-size Fourier data; this remains inside the
            # uncommitted scoring transaction so OOM retries cannot double count.
            result=engine.for_weighted_sums(result,pixel_size=self.dataset.pixel_size)
        except SplitParticleBatch as exc:
            failure=str(exc)
            posterior_need=exc.required_posterior_bytes
            # Do not retain partial coarse/posterior tensors in recursive frames.
            p=None;result=None;coarse=None
        except torch.cuda.OutOfMemoryError as exc:
            if self.memory_controller is None:raise
            failure=str(exc);oom=True
            p=None;result=None;coarse=None
        # Leave the exception scope before retrying: its traceback owns failed
        # temporaries. Preprocessing is deterministic per source particle/iteration.
        # The caller commits statistics only AFTER this generator yields.
        if oom:
            engine.release_projection_storage(disable=True)
            gc.collect()
            with torch.cuda.device(self.device):torch.cuda.empty_cache()
            self.memory_controller.recovered_oom()
            print('  CUDA scoring allocation failed; released projection cache and retrying uncommitted particles.',flush=True)
            self._perf_counters['evaluation_oom_retries']=self._perf_counters.get('evaluation_oom_retries',0)+1
            if not _oom_retry:
                yield from self._evaluate(indices,raw,sigma_old,engine,bank,timer,iteration,True)
                return
        if failure is not None:
            if hasattr(self,'_execution_admission_failed'):self._execution_admission_failed()
            # A broad single-particle posterior needs more budget, not a smaller
            # candidate set. This admission is separate from real CUDA OOM.
            diagnostic=''
            if len(indices)==1 and self.memory_controller is not None and posterior_need is not None:
                from .posterior_budget import grow_posterior
                grown,diagnostic=grow_posterior(self,engine,posterior_need)
                if grown:
                    yield from self._evaluate(indices,raw,sigma_old,engine,None,timer,iteration,_oom_retry)
                    return
            if len(indices)==1:
                automatic=self.memory_controller is not None and getattr(self.memory_controller,'automatic',True)
                hint=('reduce other GPU memory use or use more GPU memory; --gpu-memory-percent only helps below 100%'
                      if automatic else 'increase --posterior-work-mib or --candidate-work-mib')
                detail=f'; {diagnostic}' if diagnostic else ''
                raise MemoryError(f'{failure}; even one particle does not fit{detail}. Please {hint}; candidates were not truncated.')
            self._perf_counters['particle_batch_splits']=self._perf_counters.get('particle_batch_splits',0)+1
            mid=len(indices)//2
            yield from self._evaluate(indices[:mid],raw[:mid],sigma_old,engine,bank,timer,iteration,_oom_retry=oom or _oom_retry)
            yield from self._evaluate(indices[mid:],raw[mid:],sigma_old,engine,bank,timer,iteration,_oom_retry=oom or _oom_retry)
        else:yield p,result

    def _parent_tiles(self,result,limit):
        """Yield only retained parent rows; no orientation-major coalescing."""
        retained=result.retained_weights
        device=self.device
        if isinstance(result,SparseAdaptiveBatchExpectation):
            ids=torch.nonzero(retained.flatten(1).ne(0).any(1),as_tuple=False).squeeze(1)
            self._perf_counters['fine_zero_parents_skipped']=self._perf_counters.get('fine_zero_parents_skipped',0)+result.number_of_parents-len(ids)
            self._perf_counters['fine_nonzero_parents']=self._perf_counters.get('fine_nonzero_parents',0)+len(ids)
            oc=result.orientation_children
            child=torch.arange(oc,device=device)
            for start in range(0,len(ids),limit):
                ix=ids[start:start+limit];rows=result.parent_particle_indices[ix];cs=result.parent_class_indices[ix]
                ori=result.parent_orientation_indices[ix];trans=result.parent_translation_indices[ix]
                refs=result.projection_blocks.projections.index_select(0,result.parent_projection_block_indices[ix])
                yield rows,cs,self._coarse_direction_indices(ori),refs,retained[ix],result.phase_factors[trans],result.child_translations_angstrom[ix],result.child_angles_deg[ix],ori[:,None]*oc+child
        elif isinstance(result,DenseBatchExpectation):
            positions=torch.nonzero(retained.ne(0),as_tuple=False)
            for start in range(0,len(positions),limit):
                ix=positions[start:start+limit];rows,cs,local_ori,t=ix.unbind(1)
                ori=result.global_orientations(rows,local_ori)
                refs=torch.empty((len(ix),1,result.bank.image_size,result.bank.image_size//2+1),device=device,dtype=torch.complex64)
                host=cs.cpu().numpy()
                for c in np.unique(host):
                    loc=torch.tensor(np.flatnonzero(host==c),device=device)
                    refs[loc,0]=result.bank.projections.gather(int(c),ori[loc])
                yield rows,cs,self._coarse_direction_indices(ori),refs,retained[rows,cs,local_ori,t,None,None],result.bank.phase_factors[t,None],result.bank.translations_angstrom[t,None],result.bank.angles_deg[ori,None],ori[:,None]
        else:
            positions=torch.nonzero(retained.ne(0),as_tuple=False)
            for start in range(0,len(positions),limit):
                rows,cs,t=positions[start:start+limit].unbind(1)
                yield rows,cs,None,result.projections[rows,cs,None],retained[rows,cs,t,None,None],result.phase[rows,t,None],result.translations[rows,t,None],result.angles[rows,None],None

    def _accumulate_parent(self,p,result,bps,grouper):
        n=self.dataset.box_size;s=self.sizes.current_size;ns=n//2+1;b=len(p.indices);k=len(self.references)
        dtype=torch.float32 if self.options.accumulation_precision=='float32' else torch.float64
        shell=rounded_shell_indices_2d(s,self.device);yy=signed_fft_indices(s,device=self.device)
        active=(shell<=s//2)&~((torch.arange(s//2+1,device=self.device)[None]==0)&(yy[:,None]<0))
        idx=torch.nonzero(active.flatten(),as_tuple=False).squeeze(1);sh=shell.flatten()[idx]
        window=Class3DExpectation._window_rfft
        x=window(p.like,s);u=window(p.unmasked,s)
        factor=window(p.prediction,s);numfactor=window(p.numerator,s);denfactor=window(p.denominator,s)
        inv_shell=torch.where(p.sigma>0,p.sigma.reciprocal(),0.)
        inv=inv_shell[:,shell.clamp_max(ns-1)]
        noise=torch.zeros((b,ns),device=self.device,dtype=dtype);xa=torch.zeros(b,device=self.device,dtype=dtype);aa=torch.zeros_like(xa)
        pixel_budget=min(32*MIB,candidate_budget(self)//16)
        reducer=ParticleNoiseAccumulator(noise,sh,max_pixel_bytes=pixel_budget,allow_float32=True)
        oc=result.orientation_children if isinstance(result,SparseAdaptiveBatchExpectation) else 1
        tc=result.translation_children if isinstance(result,SparseAdaptiveBatchExpectation) else 1
        groupreserve=grouper.max_bytes if grouper is not None else 0
        work=candidate_budget(self)-groupreserve-reducer.reserved_bytes
        per=s*(s//2+1)*8*(tc+6*oc+12)+256*oc*tc
        if per>work:raise MemoryError(f'One Class3D parent statistics tile requires {per/MIB:.2f} MiB; increase candidate workspace.')
        limit=max(1,min(self.options.candidate_chunk_size,work//per))
        self._perf_counters['parent_tile_limit']=limit
        self._perf_counters['noise_pixel_buffer_peak_bytes']=max(self._perf_counters.get('noise_pixel_buffer_peak_bytes',0),reducer.reserved_bytes)
        offset2=torch.zeros((),device=self.device,dtype=dtype)
        dirs=torch.zeros((k,len(self.sampling.directions)),device=self.device,dtype=dtype)
        for rows,cs,di,refs,w,phase,translations,angles,angleids in self._parent_tiles(result,limit):
            self._perf_counters['accumulation_tiles']+=1
            with self._detail_timer.section('accumulate.parent_phase'):
                wf=w.to(torch.float32)
                phase_flat=phase.flatten(-2)
                phase_sum=self._batch_matrix_weighted_sum(wf,phase_flat).reshape(len(rows),oc,s,s//2+1)
                xbar=x[rows,None]*phase_sum
                pred=refs*factor[rows,None]
                masso=wf.sum(-1)
                shifted=x[rows,None]*phase
            with self._detail_timer.section('accumulate.parent_noise_scale'):
                shiftactive=shifted.flatten(-2).index_select(-1,idx)
                pa=pred.flatten(-2).index_select(-1,idx)
                xb=xbar.flatten(-2).index_select(-1,idx)
                xpower=(wf.sum(1)[...,None]*shiftactive.abs().square()).sum(1)
                power=masso[...,None]*pa.abs().square()
                cross=(pa.conj()*xb).real
                residual=(xpower+power.sum(1)-2*cross.sum(1)).clamp_min(0).to(dtype)
                reducer.add(rows,residual)
                if self.do_scale:
                    reliable=torch.stack(self.data_vs_prior)[cs][:,sh]>3.
                    accumulate_scale_statistics_(xa,aa,rows,cross,power,reliable,p.old_scales[rows])
            with self._detail_timer.section('accumulate.parent_offsets'):
                # p.centres already equals global origin prior - integer shift.
                d2=(translations-p.centres[rows,None]).square().sum(-1)
                offset2+=(wf.sum(1).to(dtype)*d2.to(dtype)).sum()
                if di is not None:
                    dirs.view(-1).index_add_(0,cs*dirs.shape[1]+di,w.to(dtype).sum((1,2)))
            with self._detail_timer.section('accumulate.parent_backprojection'):
                numerator=u[rows,None]*phase_sum*(numfactor[rows]*inv[rows])[:,None]
                denominator=masso[...,None,None]*(denfactor[rows]*inv[rows])[:,None]
                host=cs.cpu().numpy()
                for c in np.unique(host):
                    loc=torch.as_tensor(np.flatnonzero(host==c),device=self.device)
                    a=numerator[loc].reshape(-1,s,s//2+1);z=denominator[loc].reshape_as(a.real)
                    if grouper is not None:
                        grouper.add(int(c),angleids[loc].reshape(-1),a,z)
                    else:
                        bps.add(int(c),a,_euler_matrix(angles[loc].reshape(-1,3)),torch.ones_like(z),z,
                            orientation_chunk_size=self.config.backprojector_chunk_size)
                        self._perf_counters['backprojector_calls']+=1
        reducer.finish()
        # Frequencies beyond the current reference support contribute to noise
        # and normalization once per particle, not once per retained hypothesis.
        add_high_resolution_power_(noise,p.like,s)
        return Moments3D(result.class_mass.sum(0).to(dtype),dirs,offset2,noise,xa,aa)

    def _accumulate(self,p,result,bps,grouper):
        if not isinstance(result,(SparseAdaptiveBatchExpectation,DenseBatchExpectation)):
            return self._accumulate_parent(p,result,bps,grouper)
        from relion_torch.alignment.orientation_statistics import (
            OrientationSchedule, plan_orientation_major_workspace,
            build_orientation_major_phase_basis,evaluate_orientation_statistics,
        )
        n=self.dataset.box_size;s=self.sizes.current_size;b=len(p.indices);k=len(self.references)
        dtype=torch.float32 if self.options.accumulation_precision=='float32' else torch.float64
        shell=rounded_shell_indices_2d(s,self.device);yy=signed_fft_indices(s,device=self.device)
        active=(shell<=s//2)&~((torch.arange(s//2+1,device=self.device)[None]==0)&(yy[:,None]<0))
        idx=torch.nonzero(active.flatten(),as_tuple=False).squeeze(1);sh=shell.flatten()[idx]
        retained=result.retained_weights
        sparse=isinstance(result,SparseAdaptiveBatchExpectation)
        if sparse:
            rows=result.parent_particle_indices;cs=result.parent_class_indices
            ori=result.parent_orientation_indices;tr=result.parent_translation_indices
            phase=result.phase_factors;oc=result.orientation_children;tc=result.translation_children
            translations=torch.as_tensor(self.sampling.fine_translations(self.config.oversampling),
                                         device=self.device,dtype=torch.float32)
        else:
            positions=torch.nonzero(retained.ne(0),as_tuple=False)
            rows,cs,ori,tr=positions.unbind(1)
            retained=retained[rows,cs,ori,tr,None,None]
            ori=result.global_orientations(rows,ori)
            phase=result.bank.phase_factors[:,None];oc=tc=1
            translations=result.bank.translations_angstrom[:,None]
        active_parent=retained.flatten(1).ne(0).any(1)
        noise=torch.zeros((b,n//2+1),device=self.device,dtype=dtype)
        xa=torch.zeros(b,device=self.device,dtype=dtype);aa=torch.zeros_like(xa)
        pixel_budget=min(32*MIB,candidate_budget(self)//16)
        reducer=ParticleNoiseAccumulator(noise,sh,max_pixel_bytes=pixel_budget,allow_float32=True)
        work=candidate_budget(self)-(grouper.max_bytes if grouper is not None else 0)-reducer.reserved_bytes
        # Reserve compact scheduling metadata and the input weight rectangle in
        # addition to the shared Class2D compressed-row workspace model.
        metadata_bytes=len(rows)*96
        # Batch conversions/weighted factors are bounded separately from tiles.
        prepared_bytes=b*s*(s//2+1)*40 if self.options.local_statistics_inputs!='off' else 0
        if prepared_bytes>max(0,work-metadata_bytes)//4:
            prepared_bytes=0
        work-=prepared_bytes
        plan=plan_orientation_major_workspace(max(1,work-metadata_bytes),size=s,active_pixels=len(idx),
            orientation_children=oc,translation_slots=phase.shape[0]*tc)
        minimum=plan.phase_basis_bytes+oc*plan.bytes_per_orientation
        if work-metadata_bytes<minimum:
            self._perf_counters['orientation_major_workspace_fallback_batches']=self._perf_counters.get('orientation_major_workspace_fallback_batches',0)+1
            del reducer,noise,xa,aa,retained
            return self._accumulate_parent(p,result,bps,grouper)
        max_groups=min(plan.max_coarse_groups,max(1,self.options.candidate_chunk_size))
        with self._detail_timer.section('accumulate.orientation_schedule',full=True):
            schedule=OrientationSchedule(rows,cs,ori,tr,active_parent,translations=phase.shape[0],children=oc,
                                         max_groups=max_groups,device=self.device)
        counts=self._perf_counters
        for key,value in [('orientation_schedule_d2h_bytes',schedule.d2h_bytes),
                          ('orientation_major_groups',schedule.group_count),
                          ('orientation_major_parent_rows',schedule.parent_count),
                          ('fine_nonzero_parents',schedule.parent_count if sparse else 0),
                          ('fine_zero_parents_skipped',schedule.total_parents-schedule.parent_count if sparse else 0)]:
            counts[key]=counts.get(key,0)+int(value)
        counts['orientation_workspace_estimate_bytes']=max(counts.get('orientation_workspace_estimate_bytes',0),
            prepared_bytes+metadata_bytes+plan.phase_basis_bytes+max_groups*oc*plan.bytes_per_orientation+reducer.reserved_bytes+(grouper.max_bytes if grouper else 0))
        key=(id(phase),s,oc,tc)
        if getattr(self,'_orientation_basis_key',None)!=key:
            self._orientation_basis=build_orientation_major_phase_basis(phase,translations,idx)
            self._orientation_basis_key=key
        basis=self._orientation_basis
        window=Class3DExpectation._window_rfft
        x=window(p.like,s).flatten(-2).index_select(-1,idx);u=window(p.unmasked,s)
        factor=window(p.prediction,s).flatten(-2).index_select(-1,idx)
        numfactor=window(p.numerator,s);denfactor=window(p.denominator,s)
        inv_shell=torch.where(p.sigma>0,p.sigma.reciprocal(),0.)
        inv=inv_shell[:,shell.clamp_max(n//2)]
        prepared_inputs=None
        if prepared_bytes:
            from relion_torch.inference.statistics_inputs import StatisticsInputs
            prepared_inputs=StatisticsInputs(u,numfactor,denfactor,inv)
            counts['statistics_prepared_batches']=counts.get('statistics_prepared_batches',0)+1
            counts['statistics_prepared_reserved_bytes']=max(counts.get('statistics_prepared_reserved_bytes',0),prepared_bytes)
        offset2=torch.zeros((),device=self.device,dtype=dtype)
        dirs=torch.zeros((k,len(self.sampling.directions)),device=self.device,dtype=dtype)
        dvp=torch.stack(self.data_vs_prior)[:,sh]>3. if self.do_scale else None
        for tile in schedule.tiles():
            counts['accumulation_tiles']+=1
            counts['orientation_major_tiles']=counts.get('orientation_major_tiles',0)+1
            with self._detail_timer.section('accumulate.orientation_statistics',full=True):
                grouped=tile.coalesce(retained)
                representative_parents=tile.parent_ids.index_select(0,tile.representatives)
                if sparse:
                    blocks=result.parent_projection_block_indices.index_select(0,representative_parents)
                    source=result.projection_blocks.projections
                    refs=(source.statistics_references(blocks,host_schedule=(tile.class_index,tile.host_angular_ids[::oc]//oc)
                          if self.options.local_statistics_inputs!='off' else None) if isinstance(source,FineProjectionStore)
                          else source.statistics_references(blocks) if hasattr(source,"statistics_references")
                          else source.index_select(0,blocks).reshape(-1,s,s//2+1))
                else:
                    refs=result.bank.projections.gather(tile.class_index,tile.orientations)
                image_rows=tile.rows.repeat_interleave(oc)
                reduction=(sh,n//2+1,dvp[tile.class_index] if self.do_scale else torch.zeros_like(sh,dtype=torch.bool))
                with self._detail_timer.section('accumulate.statistics_math',full=True):
                    stat=evaluate_orientation_statistics(grouped,basis,rows=image_rows,references=refs,like_active=x,
                        unmasked=u,prediction_active=factor,numerator_factor=numfactor,denominator_factor=denfactor,
                        inverse_noise=inv,centres=p.centres,active_indices=idx,statistics_dtype=dtype,reduction=reduction,
                        prepared_inputs=prepared_inputs)
                if stat.shell_reduced:noise.index_add_(0,image_rows,stat.residual)
                else:reducer.add(image_rows,stat.residual)
                if self.do_scale:
                    scales=p.old_scales.index_select(0,image_rows).to(dtype)
                    rel=dvp[tile.class_index]
                    cross=stat.cross if stat.shell_reduced else stat.cross[:,rel].sum(-1)
                    power=stat.power if stat.shell_reduced else stat.power[:,rel].sum(-1)
                    xa.index_add_(0,image_rows,cross.to(dtype)/scales)
                    aa.index_add_(0,image_rows,power.to(dtype)/scales.square())
                offset2+=stat.offset_square
                direction=self._coarse_direction_indices(tile.orientations).repeat_interleave(oc)
                dirs[tile.class_index].index_add_(0,direction,stat.mass.to(dtype))
            with self._detail_timer.section('accumulate.orientation_backprojection',full=True):
                angular=tile.orientations[:,None]*oc+torch.arange(oc,device=self.device)[None]
                # Skip exactly zero fine orientation rows, including the unused
                # seven CC children; this is not a posterior threshold.
                keep=(stat.mass!=0).detach().cpu().numpy()
                ids=torch.as_tensor(np.flatnonzero(keep),device=self.device,dtype=torch.long)
                angleids=angular.reshape(-1).index_select(0,ids)
                numerator=stat.numerator.index_select(0,ids);denominator=stat.denominator.index_select(0,ids)
                counts['orientation_major_rows']=counts.get('orientation_major_rows',0)+len(ids)
                if grouper is not None:
                    grouper.add(tile.class_index,angleids,numerator,denominator,host_ids=tile.host_angular_ids[keep])
                else:
                    # The result already owns exactly these parent/child angles.
                    # Do not rebuild all local children during every statistics tile.
                    if sparse:
                        angles=result.child_angles_deg.index_select(0,representative_parents).reshape(-1,3).index_select(0,ids)
                    else:
                        angles=result.bank.angles_deg.index_select(0,tile.orientations).index_select(0,ids)
                    bps.add(tile.class_index,numerator,_euler_matrix(angles),torch.ones_like(denominator),denominator,
                            orientation_chunk_size=self.config.backprojector_chunk_size)
                    counts['backprojector_calls']+=1
        reducer.finish()
        add_high_resolution_power_(noise,p.like,s)
        return Moments3D(result.class_mass.sum(0).to(dtype),dirs,offset2,noise,xa,aa)

    def _postprocess(self,iteration,cc):
        values=self.references
        if cc and self.options.initial_high_resolution:
            values=[lowpass_3d(x,self.options.initial_high_resolution,self.dataset.pixel_size) for x in values]
            self.tau2,self.data_vs_prior=lowpass_model_spectra(
                self.tau2,self.data_vs_prior,original_size=self.dataset.box_size,
                pixel_size=self.dataset.pixel_size,resolution=self.options.initial_high_resolution)
        if self.options.flatten_solvent:
            values=[x*self._solvent_mask for x in values]
        if cc and self.generate_seeds:
            values=[values[0].clone() for _ in values]
            for name in ('tau2','sigma2_class','data_vs_prior','fourier_coverage'):
                a=getattr(self,name);setattr(self,name,[a[0].clone() for _ in a])
            self.class_prob.fill_(1./len(values))
            self.direction_priors=self.direction_priors[0:1].expand(len(values),-1).clone()
        self._set_references(values)

    def _model_blocks(self,reference_paths,*,log_likelihood,average_pmax,initial_state=False):
        blocks=super()._model_blocks(reference_paths,log_likelihood=log_likelihood,
            average_pmax=average_pmax,initial_state=initial_state)
        blocks['model_general']['rlnNormCorrectionAverage']=self.avg_norm_correction
        blocks['model_groups']['rlnGroupScaleCorrection']=self.group_scales.detach().cpu().numpy()
        return blocks

    def _write_sampling(self,iteration):
        from relion_torch.inference.local_projection import streaming_local
        stream=streaming_local(self)
        table=None if stream else self.sampling.fine_sampling_table(0)
        sm=self.sampling.state_dict()
        general={'rlnReferenceDimensionality':3,'rlnSymmetryGroup':self.options.symmetry,'rlnHealpixOrder':sm['healpix_order'],
            'rlnPsiStep':sm['psi_step'],'rlnOffsetRange':sm['offset_range']/self.dataset.pixel_size,
            'rlnOffsetStep':sm['offset_step']/self.dataset.pixel_size,'rlnSamplingPerturbInstance':sm['random_perturbation'],
            'rlnSamplingPerturbFactor':sm['perturbation_factor'],
            'rlnTorchAngularSearchMode':'local' if self.options.local_angular_search else 'global',
            'rlnSigmaPriorRotAngle':self.options.angular_sigmas[0],
            'rlnSigmaPriorTiltAngle':self.options.angular_sigmas[1],
            'rlnSigmaPriorPsiAngle':self.options.angular_sigmas[2]}
        if stream:
            general['rlnTorchCompactSampling']=1
            write_star({'sampling_general':pd.DataFrame([general]),
                'sampling_directions':pd.DataFrame({'rlnAngleRot':self.sampling.directions[:,0],
                    'rlnAngleTilt':self.sampling.directions[:,1]}),
                'sampling_psi':pd.DataFrame({'rlnAnglePsi':self.sampling.psi_angles})},
                f'{self.config.output_root}_it{iteration:03d}_sampling.star')
            return
        write_star({'sampling_general':pd.DataFrame([general]),'sampling_directions':pd.DataFrame({
            'rlnAngleRot':table.orientation_angles[:,0,0], 'rlnAngleTilt':table.orientation_angles[:,0,1],
            'rlnAnglePsi':table.orientation_angles[:,0,2]})},f'{self.config.output_root}_it{iteration:03d}_sampling.star')

    def _write_outputs(self,iteration,ll,pmax,updated):
        root=str(self.config.output_root);paths=self._reference_image_names(iteration)
        # 3-D volumes are each written once, after reference postprocessing.
        self._write_reference_maps(self.references,iteration)
        data=self.dataset.particles_in_source_order(updated)
        write_star({'optics':self.dataset.optics,'particles':data},f'{root}_it{iteration:03d}_data.star')
        write_star(self._model_blocks(paths,log_likelihood=ll,average_pmax=pmax,initial_state=(iteration==0)),f'{root}_it{iteration:03d}_model.star')
        self.dataset.replace_particles(updated)
        self._write_sampling(iteration)
        self._perf_counters['reference_output_files']=len(self.references)
        self._perf_counters['reference_output_data_bytes']=sum(x.numel()*x.element_size() for x in self.references)
        self._perf_counters['output_source_order_rows']=len(data)
        self._perf_counters['reference_output_readbacks']=0

    def save_checkpoint(self,iteration):
        root=f'{self.config.output_root}_it{iteration:03d}'
        state={'format':'relion-torch-class3d-v1','package_version':__version__,'iteration':iteration,
            'config':_primitive(asdict(self.requested_options)),'data_star':str(Path(root+'_data.star').resolve()),
            'memory_policy':{'automatic':self.requested_options.auto_memory,'gpu_memory_percent':self.requested_options.gpu_memory_percent},
            'last_memory_plan':self._memory_plan.as_dict() if self._memory_plan is not None else None,
            'input_star':str(Path(self.options.input_star).resolve()),
            'source_row_indices':torch.from_numpy(self.dataset.source_row_indices().copy()),
            'references':[x.detach().cpu().clone() for x in self.references],
            'sampling':self.sampling.state_dict(),'rng_state':_primitive(self.generator.bit_generator.state),
            'subset_state':self._subset_state.state_dict() if self._subset_state else None,
            'avg_norm_correction':self.avg_norm_correction,'refs_are_ctf_corrected':self.refs_are_ctf_corrected,
            'sigma_offset':self.sigma_offset_angstrom,'generate_seeds':self.generate_seeds,
            'direction_prior_reset_pending':self._direction_prior_reset_pending,
            'angular_search':{'mode':'local' if self.options.local_angular_search else 'global',
                              'sigmas_deg':list(self.options.angular_sigmas),'sigma_cutoff':3.},
            'working_psnr_shell':self.working_psnr_shell,'working_current_size':self.working_current_size,
            'history':self._iteration_history}
        for key in ('class_prob','direction_priors','norm_corrections','group_scales','rotation_accuracy_deg','translation_accuracy_angstrom'):
            state[key]=getattr(self,key).detach().cpu().clone()
        for key in ('sigma2','tau2','sigma2_class','data_vs_prior','fourier_coverage'):
            state[key]=[x.detach().cpu().clone() for x in getattr(self,key)]
        state['orientability_contrib']=None if self.orientability_contrib is None else [x.detach().cpu() for x in self.orientability_contrib]
        tmp=Path(root+'_state.pt.tmp');dest=Path(root+'_state.pt');torch.save(state,tmp);os.replace(tmp,dest)
        write_star({'optimiser_general':pd.DataFrame([{'rlnCurrentIteration':iteration,
            'rlnDataStarFile':str(Path(root+'_data.star').resolve()),'rlnModelStarFile':str(Path(root+'_model.star').resolve()),
            'rlnSamplingStarFile':str(Path(root+'_sampling.star').resolve()),'rlnTorchCheckpoint':str(dest.resolve()),
            'rlnDo3DClassification':1,'rlnDoAutoRefine':0,'rlnDoFastSubsetOptimisation':int(self.options.fast_subsets)}])},root+'_optimiser.star')

    def restore_checkpoint(self,state):
        if state.get('format')!='relion-torch-class3d-v1':raise ValueError('not a Class3D checkpoint')
        rows=np.asarray(state['source_row_indices'],dtype=np.int64)
        if not np.array_equal(np.sort(rows),np.arange(len(self.dataset))):raise ValueError('checkpoint source row permutation invalid')
        order=torch.tensor(np.argsort(rows,kind='stable'),dtype=torch.long)
        for key in ('class_prob','direction_priors','norm_corrections','group_scales','rotation_accuracy_deg','translation_accuracy_angstrom'):
            x=state[key]
            if key=='norm_corrections':x=x.index_select(0,order)
            setattr(self,key,x.to(self.device).clone())
        for key in ('sigma2','tau2','sigma2_class','data_vs_prior','fourier_coverage'):
            setattr(self,key,[x.to(self.device).clone() for x in state[key]])
        if (state.get('package_version') in {f'0.3.{i}' for i in range(9)}
                and int(state['iteration'])==1 and self.config.firstiter_cc
                and self.options.initial_high_resolution):
            # Legacy CC checkpoints already contain a filtered map, but their
            # spectra missed its squared window. Correct copied spectra once;
            # never refilter the map or replay the historical alignment step.
            self.tau2,self.data_vs_prior=lowpass_model_spectra(
                self.tau2,self.data_vs_prior,original_size=self.dataset.box_size,
                pixel_size=self.dataset.pixel_size,resolution=self.options.initial_high_resolution)
        self.avg_norm_correction=float(state['avg_norm_correction']);self.refs_are_ctf_corrected=bool(state['refs_are_ctf_corrected'])
        self.sigma_offset_angstrom=float(state['sigma_offset']);self.generate_seeds=bool(state['generate_seeds'])
        self.last_completed_iteration=int(state['iteration'])
        self._restore_sampling(state)
        self.generator.bit_generator.state=state['rng_state'];self._iteration_history=state.get('history',[])
        self.working_psnr_shell=int(state['working_psnr_shell']);self.working_current_size=int(state['working_current_size'])
        o=state.get('orientability_contrib');self.orientability_contrib=None if o is None else [x.to(self.device) for x in o]
        if self._subset_state is not None:
            sub=state.get('subset_state')
            if sub is not None:
                sub=dict(sub);sub['order']=torch.tensor(rows[np.asarray(sub['order'])]);sub['optics']=sub['optics'].index_select(0,order)
                self._subset_state.load_state_dict(sub)
            else:
                warnings.warn('Enabling fast-subsets after full-data iterations changes only future iterations.',RuntimeWarning)
                for it in range(1,self.last_completed_iteration+1):self._subset_state.select(it)
        self._set_references(state['references']);self._refresh_fourier_sizes()

    def _restore_sampling(self,state):
        saved=state['sampling']
        old_count=len(Class3DSampling.from_state(saved).directions)
        if saved.get("symmetry","C1")!=self.options.symmetry:raise ValueError("Continuation cannot change point group")
        if tuple(self.direction_priors.shape)!=(len(self.references),old_count):
            raise ValueError('checkpoint direction prior shape does not match its sampling grid')
        self._direction_prior_reset_pending=bool(state.get('direction_prior_reset_pending',False))
        wanted=self.sampling.state_dict()
        grid_fields=('healpix_order','psi_step','offset_range','offset_step','adaptive_oversampling','fixed_orientation')
        changed=[name for name in grid_fields if wanted[name]!=saved.get(name,False if name=='fixed_orientation' else None)]
        if not changed:
            self.sampling=Class3DSampling.from_state(saved)
            return
        # Keep the newly requested grid. No old projection/fine/backprojection
        # tables survive restore; all engines are constructed after this step.
        self.sampling.random_perturbation=float(saved['random_perturbation'])
        new_count=len(self.sampling.directions)
        if new_count!=old_count:
            # RELION ml_model.cpp initialisePdfDirection: do not interpolate
            # the old PDF or change pdf_class. See the scorer for joint priors.
            self.direction_priors=torch.full((len(self.references),new_count),1./new_count,
                device=self.device,dtype=self.direction_priors.dtype)
            self._direction_prior_reset_pending=True
        print('Class3D continuation sampling: '
            +', '.join(f'{name}={saved.get(name)} -> {wanted[name]}' for name in changed)
            +('; reset joint direction prior' if new_count!=old_count else '; preserve direction prior'),flush=True)

    @torch.no_grad()
    def expectation_step(self,it):
        """Finish one immutable E-step, returning transportable weighted sums."""
        from relion_torch.inference.permanent_workers import accuracy,batches
        from relion_torch.optimiser.progress import ParticleProgress
        root=Path(self.config.output_root);root.parent.mkdir(parents=True,exist_ok=True)
        k=len(self.references);n=self.dataset.box_size;pixel=self.dataset.pixel_size;ns=n//2+1;ng=len(self.group_ids)
        stat=torch.float32 if self.options.accumulation_precision=='float32' else torch.float64
        old_buffer=getattr(self,'_local_projection_buffer',None)
        if old_buffer is not None:old_buffer.release()
        self._local_projection_buffer=None
        begin=time.perf_counter();cc=self.config.firstiter_cc and it==1
        if not hasattr(self,'half_id'):
            print('=============================',flush=True)
        if self.options.progress:
            print(f'Preparing Class3D iteration {it}/{self.config.iteration_offset+self.config.iterations}...',flush=True)
        self._orientation_basis=None;self._orientation_basis_key=None
        timer=StageTimer(self.options.timing,self.device);self._detail_timer=DetailTimer(timer.enabled,self.device,self.options.timing_detail_samples)
        if timer.enabled and self.device.type=='cuda':torch.cuda.reset_peak_memory_stats(self.device)
        self._perf_counters=dict(particles=0,batches=0,raw_batches=0,coarse_hypotheses=0,fine_parents=0,fine_children=0,accumulation_tiles=0,backprojector_calls=0,reference_dim=3,orientation_major_tiles=0)
        selected=(getattr(self,'_distributed_selected',None) if getattr(self,'_distributed_prepared',False) else (None if self._subset_state is None else self._subset_state.select(it)))
        count=len(self.dataset) if selected is None else len(selected)
        sub=dict(enabled=selected is not None,total=len(self.dataset),selected=count,fraction=count/len(self.dataset))
        if selected is not None:sub['order_sha256']=FastSubsetState.digest(selected)
        self._prepare_execution_scalars();self._refresh_fourier_sizes()
        ini=self.options.initial_high_resolution
        if ini and ini>0 and (it==1 or (it==2 and self.config.firstiter_cc)):
            self.psnr_shell=max(1,min(n//2-1,int(math.floor(n*pixel/ini+.5))));self.sizes=self._fourier_size_state()
        self.working_psnr_shell=self.psnr_shell;self.working_current_size=self.sizes.current_size
        self._projector_pool.set_support(self.sizes.current_size)
        if self.memory_controller is not None:
            from .memory import plan_iteration
            # Plans are installed only at iteration boundaries, when no old
            # slab/posterior is live. CUDA cached blocks can then be reclaimed.
            self._projector_pool.clear()
            gc.collect()
            with torch.cuda.device(self.device):torch.cuda.empty_cache()
            timer.call('gpu_memory_planning',plan_iteration,self,selected,firstiter_cc=cc)
        sigma_old=[x.clone() for x in self.sigma2]
        if getattr(self,'_permanent_pool',None) is not None:
            current_tau=timer.call('reference_spectra',self._permanent_pool.spectra,self)
        elif getattr(self,'_distributed_prepared',False):current_tau=self.tau2
        else:current_tau=timer.call('reference_spectra',self._current_tau2)
        self.tau2=[x.clone() for x in current_tau]
        if not getattr(self,'_distributed_prepared',False) and not (cc or self.config.skip_align or self.config.skip_expected_accuracy):
            timer.call('expected_accuracy',accuracy,self,sigma_old,particle_indices=selected)
        if not getattr(self,'_distributed_prepared',False) and not (self.config.skip_align or self.config.skip_rotate):self.sampling.advance(self.generator)
        resolution=shell_to_angstrom(n,pixel,self.working_psnr_shell)
        print(f'Class3D iteration {it}: K={k}, {self.options.symmetry}, HEALPix={self.sampling.healpix_order}, resolution={resolution:.4g} A, coarse={self.sizes.coarse_size}, selected={count}, mode={"CC" if cc else "Gaussian"}',flush=True)
        if getattr(self,'_permanent_pool',None) is not None:
            return self._permanent_pool.expectation(self,it,selected,timer,begin)
        engine=self._make_engine(it);bank=None
        if not (self.config.skip_align or self.config.skip_rotate):
            bank=self._build_projection_bank(engine,timer,pixel)
        bps=BackprojectorPool(k,n,self.sizes.current_size,self.config.padding_factor,self.device,
            int(self.options.backprojector_cache_mib*MIB),int(self.options.backprojector_host_gib*1024**3),self._perf_counters)
        if (self.options.local_angular_search and self.options.local_fusion!='off'
                and getattr(self.options,'auto_execution','optimized')!='reference'
                and not (self.options.strict_highres_angstrom and self.options.strict_highres_angstrom>0)):
            bps.fusion_mode=self.options.local_gridding
        elif not self.options.local_angular_search and getattr(self.options,"auto_execution","optimized")!="reference":
            bps.fusion_mode=self.options.global_gridding
        grouper=None
        if not (self.config.skip_align or self.config.skip_rotate) and engine.local_buffer is None and getattr(self, 'use_grouped_backprojection', True):
            table=self.sampling.fine_sampling_table(self.config.oversampling)
            angles=torch.tensor(table.orientation_angles,device=self.device,dtype=torch.float32).reshape(-1,3)
            from relion_torch.inference.work_planning import statistics_cache_budget
            group_budget=statistics_cache_budget(candidate_budget(self),self.sizes.current_size,
                len(angles),k,8**self.config.oversampling,4**self.config.oversampling,
                12 if self.options.accumulation_precision=='float32' else 24)
            grouper=GroupedBackprojection3D(bps,angles,group_budget,
                slab_rows=self.config.backprojector_chunk_size,chunk_size=self.config.backprojector_chunk_size,counters=self._perf_counters)
        mass=torch.zeros(k,device=self.device,dtype=stat);direction=torch.zeros((k,len(self.sampling.directions)),device=self.device,dtype=stat)
        groupmass=torch.zeros(ng,device=self.device,dtype=stat);noisesum=torch.zeros((ng,ns),device=self.device,dtype=stat)
        gx=torch.zeros_like(groupmass);ga=torch.zeros_like(groupmass);offset2=torch.zeros((),device=self.device,dtype=stat)
        normpower=torch.zeros(len(self.dataset),device=self.device,dtype=stat)
        updated=self.dataset.particles.copy();dll=0.;pmax=0.
        deferred=None
        if getattr(self,'optimized',False):
            from relion_torch.inference.deferred_metadata import DeferredParticleMetadata
            deferred=DeferredParticleMetadata(updated,self.device,self._perf_counters)
        for label in ('rlnAngleRot','rlnAngleTilt','rlnAnglePsi','rlnOriginXAngst','rlnOriginYAngst','rlnLogLikeliContribution','rlnMaxValueProbDistribution'):
            updated[label]=updated[label].astype(float) if label in updated else np.zeros(len(updated))
        if self.options.local_angular_search:
            print(f'Local angular search: sigma={self.options.angular_sigmas} degrees, cutoff=3 sigma',flush=True)
        with ParticleProgress(count, enabled=self.options.progress) as progress:
            for indices,raw in timer.batches(batches(self,self._execution_indices(selected))):
                self._perf_counters['raw_batches']+=1
                for p,result in self._evaluate(indices,raw,sigma_old,engine,bank,timer,it):
                    self._perf_counters['batches']+=1;self._perf_counters['particles']+=len(p.indices)
                    self._perf_counters['effective_particle_batch_max']=max(self._perf_counters.get('effective_particle_batch_max',0),len(p.indices))
                    if isinstance(result,SparseAdaptiveBatchExpectation):
                        best,angles,trans,_=result.best_values()
                        self._perf_counters['coarse_hypotheses']+=result.coarse.diff2.numel();self._perf_counters['fine_parents']+=result.number_of_parents
                        self._perf_counters['fine_children']+=result.diff2.numel()
                        for name,value in (result.execution_stats or {}).items():
                            if name.endswith(('_bytes','_max')):self._perf_counters[name]=max(self._perf_counters.get(name,0),int(value))
                            else:self._perf_counters[name]=self._perf_counters.get(name,0)+int(value)
                    elif isinstance(result,DenseBatchExpectation):
                        best,o,t=result.decode_flat_indices();angles=result.bank.angles_deg[o];trans=result.bank.translations_angstrom[t]
                        self._perf_counters['coarse_hypotheses']+=result.diff2.numel()
                    else:best,angles,trans,_=result.best_values()
                    m=timer.call('accumulate',self._accumulate,p,result,bps,grouper)
                    # The enclosing coarse timer has already waited for CUDA.
                    self._detail_timer.flush_totals(synchronized=True)
                    mass+=m.class_mass;direction+=m.direction_mass;offset2+=m.offset_square
                    retained=result.class_mass.sum(1).to(stat);groupmass.index_add_(0,p.groups,retained)
                    noisesum.index_add_(0,p.groups,m.noise);gx.index_add_(0,p.groups,m.xa);ga.index_add_(0,p.groups,m.aa)
                    normpower[p.indices]=m.noise.sum(1)
                    origin=p.integer*pixel+trans
                    if deferred is not None:
                        deferred.append(p.indices,best,angles,origin,result)
                    else:
                        with self._detail_timer.section('output.batch_metadata'):
                            ix=p.indices
                            updated.loc[ix,'rlnClassNumber']=best.cpu().numpy()+1
                            for j,col in enumerate(('rlnAngleRot','rlnAngleTilt','rlnAnglePsi')):updated.loc[ix,col]=angles[:,j].cpu().numpy()
                            updated.loc[ix,'rlnOriginXAngst']=origin[:,0].cpu().numpy();updated.loc[ix,'rlnOriginYAngst']=origin[:,1].cpu().numpy()
                            updated.loc[ix,'rlnLogLikeliContribution']=result.log_likelihood_contribution.cpu().numpy()
                            updated.loc[ix,'rlnMaxValueProbDistribution']=result.pmax.cpu().numpy()
                            updated.loc[ix,'rlnNrOfSignificantSamples']=result.significant_count.cpu().numpy()
                        dll+=float(result.log_likelihood_contribution.sum());pmax+=float(result.pmax.sum())
                    if self.options.write_debug:
                        torch.save({'indices':p.indices,'diff2':result.diff2.cpu(),'posterior':result.posterior.cpu(),
                            'significant':result.significant.cpu(),'class_mass':result.class_mass.cpu()},f'{root}_it{it:03d}_batch{p.indices[0]:08d}_debug.pt')
                    progress.update(len(p.indices))
                    if hasattr(self,'_execution_committed'):self._execution_committed()
                    # Do not keep the preceding fine/coarse posterior alive
                    # while the next batch is evaluated on the right-hand side.
                    p=None;result=None;m=None;best=None;angles=None;trans=None
                    retained=None;origin=None
        if deferred is not None:
            timer.call('output_metadata_flush',deferred.flush)
            dll=deferred.dll;pmax=deferred.pmax
            deferred=None
        if self.options.progress:print('  Reconstructing maps and updating model...',flush=True)
        if grouper is not None:timer.call('flush_grouped_backprojection',grouper.finish)
        # Snapshot counters, then release ALL owners before reconstruction.
        # The last posterior and the store itself both own cached slabs.
        self._finish_expectation_execution(engine,timer)
        self._perf_counters.update(engine.memory_counters)
        self._perf_counters.update(projection_cache_peak_bytes=engine.cache.peak,
            projection_cache_hits=engine.cache.hits,projection_cache_misses=engine.cache.misses,
            projection_cache_effective_limit_bytes=engine.cache.max_bytes,
            posterior_effective_limit_bytes=max(engine.posterior_bytes,int(self.options.posterior_work_mib*MIB)))
        if self.memory_controller is not None:self.memory_controller.observe(engine.memory_counters)
        result=None;p=None;bank=None;raw=None;m=None
        engine.release_projection_storage()
        del engine
        if grouper is not None:grouper.angles=None
        grouper=None
        self._orientation_basis=None;self._orientation_basis_key=None
        projector_stats=dict(projector_device_peak_bytes=self._projector_pool.peak,
            projector_builds=self._projector_pool.builds,projector_evictions=self._projector_pool.evictions)
        self._projector_pool.clear()
        gc.collect()
        if self.memory_controller is not None:
            with torch.cuda.device(self.device):torch.cuda.empty_cache()
            self._perf_counters['cuda_allocated_before_reconstruction_bytes']=torch.cuda.memory_allocated(self.device)
        if self.options.symmetry != "C1":
            from relion_torch.fourier.symmetry import symmetrise_backprojector_
            for c in range(k):
                timer.call("point_group_symmetry",symmetrise_backprojector_,bps.objects[c],self.options.symmetry,
                    backend=self.options.symmetry_backend,counters=self._perf_counters)
        if getattr(self,'_distributed_prepared',False):
            selected=self._processed_indices;count=len(selected)
        total=float(mass.sum())
        if (not math.isfinite(total) or total<=0) and not getattr(self,'_distributed_prepared',False):raise FloatingPointError('no finite retained posterior mass')

        return dict(bps=bps, mass=mass, direction=direction, offset2=offset2, normpower=normpower, updated=updated, dll=dll, pmax=pmax, groupmass=groupmass, noisesum=noisesum, gx=gx, ga=ga, current_tau=current_tau, selected=selected, count=count, sub=sub, cc=cc, begin=begin, timer=timer, projector_stats=projector_stats, total=total)

    @torch.no_grad()
    def maximization_step(self,it,packet):
        """Consume an E-step packet after any cross-half FSC rendezvous."""
        if getattr(self,'_permanent_pool',None) is not None:
            return self._permanent_pool.maximization(self,it,packet)
        root=Path(self.config.output_root);root.parent.mkdir(parents=True,exist_ok=True)
        k=len(self.references);n=self.dataset.box_size;pixel=self.dataset.pixel_size;ns=n//2+1;ng=len(self.group_ids)

        bps=packet['bps']
        mass=packet['mass']
        direction=packet['direction']
        offset2=packet['offset2']
        normpower=packet['normpower']
        updated=packet['updated']
        dll=packet['dll']
        pmax=packet['pmax']
        groupmass=packet['groupmass']
        noisesum=packet['noisesum']
        gx=packet['gx']
        ga=packet['ga']
        current_tau=packet['current_tau']
        selected=packet['selected']
        count=packet['count']
        sub=packet['sub']
        cc=packet['cc']
        begin=packet['begin']
        timer=packet['timer']
        projector_stats=packet['projector_stats']
        total=packet['total']
        shell_key=(n,str(self.device))
        if getattr(self,'_noise_shell_count_key',None)!=shell_key:
            fullshell=rounded_shell_indices_2d(n,self.device);fy=signed_fft_indices(n,device=self.device)
            unique=(fullshell<ns)&~((torch.arange(n//2+1,device=self.device)[None]==0)&(fy[:,None]<0))
            self._noise_shell_counts=torch.bincount(fullshell[unique],minlength=ns).to(torch.float64)
            self._noise_shell_count_key=shell_key
        shell_counts=self._noise_shell_counts
        timer.call('reconstruct_and_model',self._finish_maximization,bps,mass.to(torch.float64),direction.to(torch.float64),it,current_tau)
        # Maximization has installed the newly estimated class/direction
        # probabilities; the native uniform reset applies to one E-step.
        self._direction_prior_reset_pending=False
        self.sigma_offset_angstrom=math.sqrt(max(0.,float(offset2)/(2*total)))
        if self.do_norm:
            ix=torch.tensor(np.arange(len(self.dataset)) if selected is None else selected,device=self.device,dtype=torch.long)
            norm,avg=update_norm_corrections(self.norm_corrections[ix],self.avg_norm_correction,normpower[ix].to(torch.float64),total)
            self.norm_corrections.index_copy_(0,ix,norm);self.avg_norm_correction=avg
            updated['rlnNormCorrection']=self.norm_corrections.cpu().numpy()
        if self.do_scale and not cc:self.group_scales=update_group_scales(gx.to(torch.float64),ga.to(torch.float64),self.group_particle_counts)
        if not cc:
            for g in range(ng):
                if float(groupmass[g])<=0 or float(noisesum[g].sum())==0:continue
                sp=noisesum[g].to(torch.float64)/(2*groupmass[g].double()*shell_counts.clamp_min(1))
                if self.has_premultiplied:sp=sp.clamp_min(1e-15)
                for j in range(1,ns):sp[j]=torch.where(sp[j]<1e-14,sp[j-1],sp[j])
                self.sigma2[g]=sp.to(torch.float32)
        if self.use_ctf:self.refs_are_ctf_corrected=True
        timer.call('postprocess_references',self._postprocess,it,cc)
        # Preserve the Fourier support actually used by this E-step in
        # the model metadata. Next iteration derives support from new DVP.
        ll=dll/(total if cc else 1.);pm=pmax/total
        if self.options.progress:print('  Writing maps, STAR files and checkpoint...',flush=True)
        timer.call('write_outputs',self._write_outputs,it,ll,pm,updated)
        self.last_completed_iteration=it
        self._iteration_history.append(dict(iteration=it,LL=ll,Pmax=pm,class_probability=self.class_prob.cpu().tolist(),current_size=self.sizes.current_size,subset=sub))
        timer.call('checkpoint',self.save_checkpoint,it)
        self._perf_counters.update(**projector_stats,current_fourier_size=self.sizes.current_size,
            selected_particles=count,total_particles=len(self.dataset))
        memory={}
        if timer.enabled and self.device.type=='cuda':memory=dict(cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(self.device),cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved(self.device))
        if self._memory_plan is not None:
            memory['automatic_plan']=self._memory_plan.as_dict()
            memory['oom_recoveries_total']=self.memory_controller.oom_recoveries
        timer.write(root,iteration=it,total_seconds=time.perf_counter()-begin,counters=self._perf_counters,
                    mode='class3d-orientation',details=self._detail_timer.report(),memory=memory,subset=sub)
        resolution=shell_to_angstrom(n,pixel,self.psnr_shell)
        print(f'  resolution={resolution:.4g} A; LL={ll:.7g}; Pmax={pm:.6g}; elapsed={time.perf_counter()-begin:.3f}s',flush=True)
        self._perf_norm_values=None;self._perf_prediction_scales=None
        # The last posterior owns its projection store: release it before
        # allocating the next iteration's resident bank/cache.
        result=None;p=None;bank=None


        return self.references

    @torch.no_grad()
    def run(self):
        root=Path(self.config.output_root);root.parent.mkdir(parents=True,exist_ok=True)
        if self.config.write_initial_state:
            self._write_outputs(0,0.,0.,self.dataset.particles.copy());self.save_checkpoint(0)
        if self._startup_context:self._startup_context.finish(root,continued=self.last_completed_iteration>0)
        for it in range(self.config.iteration_offset+1,self.config.iteration_offset+self.config.iterations+1):
            packet=self.expectation_step(it)
            self.maximization_step(it,packet)
            del packet
        return self.references
