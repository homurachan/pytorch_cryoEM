"""Budget-only recovery before statistical commit; never alter candidate support."""
import gc
import math
import torch
from relion_torch.inference.memory_planning import MIB


def grow_posterior(owner, engine, required, *, particles=1, preserve_projection=False):
    """Grow repeatedly from live headroom, retaining a bounded projection cache.

    Return (success, diagnostic). This is not a CUDA allocation failure and must
    not call release_projection_storage(disable=True) or recovered_oom().
    """
    controller=owner.memory_controller
    if controller is None or not controller.automatic or controller.last_plan is None:
        return False, ''
    required=int(required)
    if required<=engine.posterior_bytes:
        return False, 'posterior demand did not increase; refusing an unchanged retry'
    gc.collect()
    limit,resident=engine.projection_storage_budget()
    # Reserve a modest growth step so nearby broad particles do not repeatedly
    # rescore for a few KiB. Extra slack is optional, not an admission condition.
    step=64*MIB
    target=((max(required+step,(required*9+7)//8)+step-1)//step)*step
    admission=controller.posterior_capacity(target,limit,resident)
    if not admission['admitted'] or (preserve_projection and admission['projection_bytes']<limit):
        target=required
        admission=controller.posterior_capacity(target,limit,resident)
    counts=owner._perf_counters
    counts['posterior_budget_checks']=counts.get('posterior_budget_checks',0)+1
    if preserve_projection and admission['projection_bytes']<limit:
        counts['posterior_budget_denials']=counts.get('posterior_budget_denials',0)+1
        return False, 'local batch growth would consume its reserved projection workspace'
    if admission['admitted'] and admission['projection_bytes']<limit:
        # Pinned slabs cannot be resized by merely changing the LRU limit.
        # Recreate their owners, then measure rather than assume reclamation.
        limit=admission['projection_bytes']
        engine.resize_projection_storage(limit)
        owner.options.performance_cache_mib=limit/MIB
        gc.collect()
        with torch.cuda.device(owner.device):torch.cuda.empty_cache()
        admission=controller.posterior_capacity(target,limit,0)
        if not admission['admitted'] and target!=required:
            target=required
            admission=controller.posterior_capacity(target,limit,0)
        counts['posterior_cache_releases']=counts.get('posterior_cache_releases',0)+1
        if admission['admitted'] and admission['projection_bytes']<limit:
            limit=admission['projection_bytes']
            engine.resize_projection_storage(limit)
            owner.options.performance_cache_mib=limit/MIB
    if not admission['admitted']:
        counts['posterior_budget_denials']=counts.get('posterior_budget_denials',0)+1
        return False, (f"live safe headroom {admission['available_bytes']/MIB:.1f} MiB, "
                       f"required posterior/workspace reserve {admission['reserved_work_bytes']/MIB:.1f} MiB "
                       '(including both posterior passes; projection storage may be released)')
    previous=engine.posterior_bytes
    engine.posterior_bytes=target
    owner.options.posterior_work_mib=target/MIB
    feedback={'posterior_observed_bytes_per_particle':math.ceil(required/max(1,particles))}
    if preserve_projection:feedback['local_posterior_observed_bytes_per_particle']=feedback['posterior_observed_bytes_per_particle']
    controller.observe(feedback)
    counts['posterior_cache_rebalances']=counts.get('posterior_cache_rebalances',0)+1
    counts['posterior_budget_growth_bytes']=counts.get('posterior_budget_growth_bytes',0)+target-previous
    counts['posterior_growth_slack_bytes']=max(counts.get('posterior_growth_slack_bytes',0),target-required)
    counts['posterior_effective_limit_bytes']=max(counts.get('posterior_effective_limit_bytes',0),target)
    print(f'  Posterior budget: {previous/MIB:.1f} -> {target/MIB:.1f} MiB (required {required/MIB:.1f} MiB); '
          f'projection limit={limit/MIB:.1f} MiB; admitting the same {particles} particle(s) (budget rebalance, no CUDA OOM).',flush=True)
    return True, ''
