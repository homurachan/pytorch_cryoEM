"""Class3D geometry adapter for the shared SPA memory planner."""
import math
from dataclasses import replace
import numpy as np
import torch
from relion_torch.fourier.conventions import padded_size
from relion_torch.inference.memory_planning import (
    MIB, GIB, MemorySnapshot, InferenceWorkload, memory_limits,
)


def volume_payloads(n, current, pad):
    p = padded_size(n, pad)
    radius = int(math.floor((current//2)*(p/float(n))+.5))
    side = 2*(radius+1)+1
    projector = p*p*(p//2+1)*8
    compact_voxels = side*side*(side//2+1)
    backprojector = compact_voxels*12
    # Compact shell/index/MAP/double-precision preweight/convolution arrays,
    # plus the final full padded IFFT and real-space/gridding temporary arrays.
    reconstruction = compact_voxels*160 + 3*projector + n**3*48
    return projector, backprojector, reconstruction


def configure_startup(controller, options, n):
    snap = MemorySnapshot.read(controller.device)
    ceiling, _, _, available = memory_limits(snap, controller.percent, controller.allocator_fraction)
    projector, _, _ = volume_payloads(n, n, options.padding_factor)
    references = options.number_of_classes*n**3*4
    temporary = 3*projector+n**3*64+256*MIB
    if references+projector+temporary > available:
        raise MemoryError('Automatic GPU budget cannot fit reference initialization/FFT workspace; '
                          'increase --gpu-memory-percent or use a larger GPU.')
    capacity = max(1, min(options.number_of_classes, (available-references-temporary)//projector))
    options.projector_cache_mib = capacity*projector/MIB
    options.reference_max_gib = max(references/GIB, ceiling/GIB)
    options.preprocess_work_mib = min(256., max(64., available/MIB/32))
    options.preprocess_cache_mib = 32.
    psi = options.psi_step_deg or 360./(6*(1 << options.healpix_order))
    from relion_torch.geometry.symmetry import direction_count
    table = direction_count(options.healpix_order,options.symmetry)*math.ceil(360./psi)*(1+8**options.oversampling)*40
    if not (options.local_angular_search and options.local_projection_mode=='stream') and not (hasattr(options,"auto_local_healpix_order") and options.healpix_order>=options.auto_local_healpix_order):
        options.sampling_work_mib = max(options.sampling_work_mib, math.ceil(table/MIB))


def plan_iteration(optimiser, selected=None, *, firstiter_cc=False):
    o = optimiser
    controller = o.memory_controller
    n, current = o.dataset.box_size, o.sizes.current_size
    fixed = o.config.skip_align or o.config.skip_rotate
    coarse,shell = o.sizes.coarse_likelihood_grid(o.config.oversampling)
    no = 1 if fixed else o.sampling.number_of_orientations
    width = no
    if o.options.local_angular_search:
        from relion_torch.sampling.local import select_local_angular_support
        population = np.arange(len(o.dataset)) if selected is None else np.asarray(selected)
        # A deterministic, evenly spread probe adds no random draws. The scorer
        # still checks the exact width for EVERY batch, including unsampled poles.
        probe = population[np.linspace(0, len(population)-1, min(128,len(population)), dtype=int)]
        support = select_local_angular_support(o.sampling.directions, o.sampling.psi_angles,
            o._angular_centres(probe), o.options.angular_sigmas, symmetry=o.options.symmetry)
        width = max(1, int(support.counts.max()))
    from relion_torch.inference.alignment import likelihood_rfft_mask
    active = int(likelihood_rfft_mask(coarse, shell, torch.device('cpu'),
                                    firstiter_cc=firstiter_cc).sum())
    projector, bp, recon = volume_payloads(n, current, o.config.padding_factor)
    if o.options.symmetry != "C1":recon=max(recon, bp+64*MIB)
    workload = InferenceWorkload(len(o.references), no, o.sampling.number_of_translations,
        coarse, current, n, o.config.oversampling, o.requested_options.batch_size,
        projector, bp, recon, width, active, o.options.local_angular_search, fixed,
        int(o.options.sampling_work_mib*MIB*2) if getattr(o,"compact_local_sampling",False) and o.options.local_angular_search else None)
    workload=replace(workload,fine_likelihood_size=o.sizes.likelihood_image_size(True))
    if getattr(o,'optimized',False):
        from relion_torch.auto_refine.execution import projection_limit
        limit=projection_limit(o.options,2**63-1,o._cache_ceiling)
        workload=replace(workload,prefer_full_fine=True,
            projection_max_bytes=None if limit==2**63-1 else limit,
            requested_batch=min(workload.requested_batch,o._batch_ceiling))
    from relion_torch.inference.local_projection import streaming_local
    stream=streaming_local(o)
    if stream:
        workload=replace(workload,prefer_full_fine=False,
            auto_batch_max=min(o.options.local_batch_max,getattr(o,"_batch_ceiling",2**31-1)),
            projection_max_bytes=min(int(o.options.local_projection_mib*MIB),getattr(o,'_cache_ceiling',2**63-1)),
            sampling_table_bytes=int(o.options.sampling_work_mib*MIB*2))
    plan = controller.plan(workload)
    from .global_window import configure as configure_class3d_window
    plan=configure_class3d_window(o,workload,plan,firstiter_cc)
    if getattr(o,'optimized',False) and not stream:
        from relion_torch.auto_refine.execution import cap_memory_plan
        plan=cap_memory_plan(plan,o,len(o.references)*no*active*8)
        controller.last_plan=plan
    if stream:
        candidate=min(plan.candidate_bytes,getattr(o,'_work_ceiling',2**63-1))
        plan=replace(plan,candidate_bytes=candidate,geometry_bytes=min(plan.geometry_bytes,candidate//8),
            cache_active=False,full_coarse=False,full_fine=False,
            fine_cache_bytes=0,fine_reserve_bytes=0)
        controller.last_plan=plan
    # Keep current-size fine/weighted-sum storage in the payload budget even
    # under strict-highres. A smaller likelihood does not shrink reconstruction.
    plan=replace(plan,coarse_image_size=coarse,coarse_maximum_shell=shell,
        coarse_active_pixels=active,fine_likelihood_image_size=o.sizes.likelihood_image_size(True),
        weighted_sum_image_size=current,full_coarse_active_bytes=0 if fixed else len(o.references)*no*active*8)
    from relion_torch.inference.global_fine import plan_execution
    plan=plan_execution(o,plan,firstiter_cc)
    controller.last_plan=plan
    for name, value in dict(projector_cache_mib=plan.projector_bytes/MIB,
            backprojector_cache_mib=plan.backprojector_bytes/MIB,
            performance_cache_mib=plan.projection_bytes/MIB,
            candidate_work_mib=plan.candidate_bytes/MIB, posterior_work_mib=plan.posterior_bytes/MIB,
            preprocess_work_mib=plan.preprocess_bytes/MIB, preprocess_cache_mib=32.,
            batch_size=plan.particle_batch).items():
        setattr(o.options, name, value)
    o.config.batch_size = plan.particle_batch
    if stream:
        # The planner owns execution limits in automatic mode. Grow useful work
        # tiles as well as particles; per-call byte checks still cap exact sizes.
        o.config.orientation_chunk_size=max(o.requested_options.orientation_chunk_size,
            min(512,max(64,plan.candidate_bytes//(4*MIB))))
        o.config.backprojector_chunk_size=max(o.requested_options.backprojector_chunk_size,
            min(512,max(32,plan.candidate_bytes//max(1,o.sizes.current_size*(o.sizes.current_size//2+1)*96))))
        o.options.orientation_chunk_size=o.config.orientation_chunk_size
        o.options.backprojector_chunk_size=o.config.backprojector_chunk_size
    pool = o._projector_pool
    pool.max_bytes = plan.projector_bytes
    pool.capacity = max(1, min(len(o.references), plan.projector_bytes//pool.per_class_bytes))
    o._memory_plan = plan
    window=getattr(o,'_class3d_window_plan',None)
    if window is not None:
        print(f'  Global coarse window: {window.particles} particles, {window.estimated_bytes/MIB:.0f} MiB charged to the existing projection grant.',flush=True)
    if stream:
        print(f'  GPU plan: local projections=stream, reusable buffer={plan.projection_bytes/MIB:.0f} MiB, '
              f'candidate={plan.candidate_bytes/MIB:.0f} MiB, posterior={plan.posterior_bytes/MIB:.0f} MiB, '
              f'batch={plan.particle_batch}; no cross-batch projection cache.',flush=True)
        return plan
    mode = 'full + active' if plan.cache_active else ('full' if plan.full_coarse else 'bounded')
    fine_mode=plan.global_fine_backend if plan.global_fine_backend!='cached' else ('off' if not plan.full_fine_bytes else ('full' if plan.full_fine else 'bounded'))
    print(f'  GPU plan: coarse={mode} ({coarse}px, {active} active frequencies), full coarse needs {plan.full_coarse_bytes/GIB:.2f} GiB, '
          f'projection cache={plan.projection_bytes/GIB:.2f} GiB, '
          f'fine={fine_mode}, full fine needs {plan.full_fine_bytes/GIB:.2f} GiB, '
          f'fine retained/buffer capacity={(plan.fine_stream_bytes if plan.global_fine_stream else plan.fine_cache_bytes)/GIB:.2f} GiB, '
          f'candidate={plan.candidate_bytes/MIB:.0f} MiB, posterior={plan.posterior_bytes/MIB:.0f} MiB, '
          f'batch={plan.particle_batch}; replanned for this iteration.', flush=True)
    return plan
