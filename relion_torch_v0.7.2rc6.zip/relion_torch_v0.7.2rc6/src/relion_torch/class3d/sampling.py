"""C1 3-D HEALPix sampling with RELION 3.1.4's A @ R perturbation.

The shared NEST child traversal is preserved. q is advanced once per global
iteration, never per batch. PCG64 draws are checkpointed (not bitwise libc RNG).
"""
from dataclasses import replace
import numpy as np
import torch
from relion_torch.sampling.relion_sampling import RelionSampling, psi_grid, SamplingPoint
from relion_torch.geometry.euler import relion_euler_matrix, matrix_to_relion_euler

class Class3DSampling(RelionSampling):
    def __post_init__(self):
        if self.reference_dim!=3:raise ValueError('Class3DSampling requires reference_dim=3')
        q=self.random_perturbation;self.random_perturbation=0.
        super().__post_init__();self.random_perturbation=q
        self._tables={}
        self.fixed_orientation=False
    def fix_orientations(self):
        """Native addOneOrientation(0,0,0,true) used by skipped rotations."""
        self.fixed_orientation=True
        self._directions=np.array([[0.,0.]],dtype=np.float64)
        self._psi=np.array([0.],dtype=np.float64)
        self.actual_psi_step=360.
        self.adaptive_oversampling=0;self.perturbation_factor=0.;self.random_perturbation=0.
        self._tables.clear()
    def advance(self,rng):
        p=float(self.perturbation_factor)
        if p:
            q=self.random_perturbation+float(rng.uniform(.5*p,p))
            self.random_perturbation=(q+p)%(2*p)-p
        else:self.random_perturbation=0.
        self._tables.clear()
    def angular_sampling(self):return 360.0/(6*(1<<self.healpix_order))
    @property
    def prior_translations(self):
        return self._translations.copy()
    @property
    def translations(self):
        return self._translations.copy()+self.random_perturbation*self.offset_step
    def fine_sampling_table(self,order=None):
        over=self.adaptive_oversampling if order is None else int(order)
        key=(over,float(self.random_perturbation))
        if key in self._tables:return self._tables[key]
        table=super().fine_sampling_table(over)
        angles=table.orientation_angles.copy()
        if self.random_perturbation:
            flat=torch.as_tensor(angles.reshape(-1,3),dtype=torch.float64)
            a=relion_euler_matrix(flat[:,0],flat[:,1],flat[:,2])
            dq=self.random_perturbation*self.angular_sampling()
            r=relion_euler_matrix(dq,dq,dq,dtype=torch.float64)
            angles=matrix_to_relion_euler(a@r).numpy().reshape(angles.shape)
        table=replace(table,orientation_angles=angles,
            translations=table.translations+self.random_perturbation*self.offset_step)
        self._tables[key]=table
        return table
    def fine_translations(self,order=None):
        """Translation metadata without constructing any angular child table."""
        from relion_torch.sampling.relion_sampling import oversampled_translation
        over=self.adaptive_oversampling if order is None else int(order)
        values=(self._translations[:,None,:].copy() if over==0 else
                np.stack([oversampled_translation(x,self.offset_step,over) for x in self._translations]))
        return values+self.random_perturbation*self.offset_step
    def state_dict(self):
        return dict(healpix_order=self.healpix_order,psi_step=self.actual_psi_step,
            offset_range=self.offset_range,offset_step=self.offset_step,
            adaptive_oversampling=self.adaptive_oversampling,perturbation_factor=self.perturbation_factor,
            random_perturbation=self.random_perturbation,symmetry=self.symmetry,fixed_orientation=self.fixed_orientation)
    @classmethod
    def from_state(cls,state):
        obj=cls(3,**{k:v for k,v in state.items() if k != 'fixed_orientation'})
        if state.get('fixed_orientation',False):obj.fix_orientations()
        return obj
