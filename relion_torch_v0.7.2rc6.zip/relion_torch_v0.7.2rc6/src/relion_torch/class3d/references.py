"""Genuinely three-dimensional reference mask and initial low-pass."""
import math
from pathlib import Path
import numpy as np
import torch
import mrcfile
from relion_torch.io.star import read_star

def solvent_mask_3d(n,radius,edge,device):
    a=torch.arange(n,device=device,dtype=torch.float32)-n//2
    r=(a[:,None,None].square()+a[None,:,None].square()+a[None,None,:].square()).sqrt()
    if edge<=0:return (r<=radius).float()
    t=((r-radius)/edge).clamp(0,1)
    return .5*(1+torch.cos(math.pi*t))

def lowpass_3d(volume,resolution,pixel_size,edge_shells=2):
    if resolution is None or resolution<=0:return volume
    n=volume.shape[-1]
    a=torch.fft.fftfreq(n,d=1/n,device=volume.device,dtype=volume.dtype)
    x=torch.arange(n//2+1,device=volume.device,dtype=volume.dtype)
    r=(a[:,None,None].square()+a[None,:,None].square()+x[None,None,:].square()).sqrt()
    # fftw.cpp lowPassFilterMap: cosine across filter_edge_width Fourier shells.
    cutoff=math.floor(n*pixel_size/resolution+.5)
    half=int(edge_shells)//2
    lo=max(0.,cutoff-half);hi=min(n*(n//2+1),cutoff+half)
    if hi<=lo:weight=(r<=cutoff).to(volume.dtype)
    else:weight=.5*(1+torch.cos(math.pi*((r-lo)/(hi-lo)).clamp(0,1)))
    f=torch.fft.rfftn(torch.fft.ifftshift(volume),dim=(-3,-2,-1),norm='forward')
    return torch.fft.fftshift(torch.fft.irfftn(f*weight,s=volume.shape,dim=(-3,-2,-1),norm='forward')).to(volume.dtype)

def resolve_references(names):
    refs=[]
    for name in names:
        p=Path(name).expanduser().resolve()
        if p.suffix.lower()=='.star':
            blocks=read_star(p)
            frames=blocks.values() if isinstance(blocks,dict) else [blocks]
            found=False
            for frame in frames:
                for col in ('rlnReferenceImage','_rlnReferenceImage'):
                    if col in frame:
                        for value in frame[col]:
                            if '@' in str(value):raise ValueError('Class3D needs separate cubic MRC volumes, not 2-D stack locators')
                            q=Path(str(value));refs.append(q if q.is_absolute() else (p.parent/q).resolve())
                        found=True
            if not found:raise ValueError(f'No rlnReferenceImage in {p}')
        else:refs.append(p)
    return refs

def load_references(names,k,n,pixel,device,max_gib):
    refs=resolve_references(names)
    if len(refs) not in (1,k):raise ValueError(f'--ref must give one seed or exactly K={k} reference volumes')
    if k*n**3*4>max_gib*2**30:raise MemoryError('Working real-space references exceed --reference-max-gib')
    volumes=[]
    for p in refs:
        with mrcfile.open(p,permissive=False) as h:
            if h.data is None or h.data.shape!=(n,n,n):raise ValueError(f'{p}: reference must be cubic {n}^3, got {None if h.data is None else h.data.shape}')
            vox=np.array([h.voxel_size.x,h.voxel_size.y,h.voxel_size.z],dtype=float)
            if not np.isfinite(vox).all() or (vox<=0).any():raise ValueError(f'{p}: reference voxel size is missing/invalid')
            if not np.allclose(vox,pixel,rtol=1e-4,atol=1e-5):raise ValueError(f'{p}: voxel size {vox} differs from particle pixel size {pixel}')
            array=np.array(h.data,dtype=np.float32,copy=True)
        if not np.isfinite(array).all():raise ValueError(f'{p}: nonfinite reference')
        volumes.append(torch.as_tensor(array,device=device))
    seeds=len(volumes)==1 and k>1
    if seeds:volumes=[volumes[0].clone() for _ in range(k)];refs=refs*k
    return volumes,refs,seeds
