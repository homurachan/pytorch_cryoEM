"""Bounded in-memory 3-D model/projection resources. No scratch-file I/O.

The budgets bound retained array payloads, not CUDA allocator/FFT workspaces.
An oversized indivisible model is rejected explicitly rather than approximated.
"""
from collections import OrderedDict
from dataclasses import replace
import math
import numpy as np
import torch
from relion_torch.alignment.core import ReferenceProjector, ValidatedBackprojectorAdapter, _euler_matrix
from relion_torch.fourier.conventions import padded_size
from relion_torch.fourier.backprojector import FourierBackprojector

from relion_torch.inference.projection_cache import ProjectionCache as ByteLRU

class ProjectorPool:
    def __init__(self, references, pad, device, max_bytes, current_size=None):
        self.references=references;self.pad=pad;self.device=torch.device(device)
        self.support=int(current_size or references[0].shape[-1]);self.max_bytes=int(max_bytes)
        p=padded_size(references[0].shape[-1],pad)
        self.per_class_bytes=p*p*(p//2+1)*8
        if self.max_bytes<self.per_class_bytes:
            raise MemoryError(f'One padded 3-D projector requires {self.per_class_bytes/2**20:.3f} MiB; '
                              f'increase --projector-cache-mib (currently {self.max_bytes/2**20:g}).')
        self.capacity=min(len(references),max(1,self.max_bytes//self.per_class_bytes));self.objects=OrderedDict()
        self.builds=self.evictions=self.peak=0;self.generation=0
    def acquire(self,c):
        if c in self.objects:
            self.objects.move_to_end(c);return self.objects[c]
        while len(self.objects)>=self.capacity:
            self.objects.popitem(last=False);self.evictions+=1
        obj=ReferenceProjector(self.references[c],self.pad,current_size=self.support)
        self.objects[c]=obj;self.builds+=1;self.peak=max(self.peak,len(self.objects)*self.per_class_bytes)
        return obj
    def clear(self):
        self.objects.clear();self.generation+=1
    def set_support(self,s):
        if self.support!=int(s):self.clear();self.support=int(s)
    def proxies(self):return [ProjectorHandle(self,c) for c in range(len(self.references))]

class ProjectorHandle:
    def __init__(self,pool,c):self.pool=pool;self.c=c
    @property
    def reference(self):return self.pool.references[self.c]
    @property
    def source_cache_token(self):return (id(self.pool),self.pool.generation,self.pool.support,self.c)
    def set_source_support(self,s):self.pool.set_support(s)
    def project_batch(self,angles,output_size,chunk_size=64):
        return self.pool.acquire(self.c).project_batch(angles,output_size,chunk_size=chunk_size)
    def project_inverse_batch(self,inverses,output_size):
        return self.pool.acquire(self.c).project_inverse_batch(inverses,output_size)
    def __call__(self,angles,output_size):return self.project_batch(angles,output_size)
    def fusion_inputs(self,inverses):return self.pool.acquire(self.c)._obj,inverses
    def power_spectrum(self,current_size):
        self.set_source_support(current_size);return self.pool.acquire(self.c).power_spectrum(current_size)

class ProjectionStore:
    """Lazy K x orientation planes, with a shared byte-bounded GPU LRU."""
    def __init__(self,projector,angles,k,size,cache,max_chunk=64,key_prefix='coarse',geometry=None):
        self.projector=projector;self.angles=angles;self.size=int(size);self.cache=cache
        self.max_chunk=max(1,int(max_chunk));self.prefix=key_prefix
        self.shape=(int(k),len(angles),self.size,self.size//2+1)
        self.device=angles.device;self.dtype=torch.complex64
        self.calls=0
        self.geometry=geometry
    def element_size(self):return 8
    def project(self,c,ids):
        callback=getattr(self.projector,"project_inverse",None)
        if callback is not None and self.geometry is not None:
            inverse=self.geometry.gather(self.angles,ids)
            counts=self.geometry.counts
            counts["projection_generation_calls"]=counts.get("projection_generation_calls",0)+1
            counts["projection_generated_rows"]=counts.get("projection_generated_rows",0)+len(inverse)
            counts["projection_generation_block_max"]=max(counts.get("projection_generation_block_max",0),len(inverse))
            return callback(c,inverse,self.size)
        return self.projector(c,self.angles[ids],self.size)
    def gather(self,c,ids):
        ids=torch.as_tensor(ids,device=self.device,dtype=torch.long).reshape(-1)
        # CPU transfer occurs at a bounded projection request, not per pixel.
        host=ids.detach().cpu().numpy();unique,inverse=np.unique(host,return_inverse=True)
        found={};missing=[]
        for o in unique:
            x=self.cache.get((self.prefix,int(c),int(o)))
            if x is None:missing.append(int(o))
            else:found[int(o)]=x
        for a in range(0,len(missing),self.max_chunk):
            sub=missing[a:a+self.max_chunk]
            ti=torch.as_tensor(sub,device=self.device,dtype=torch.long)
            values=self.project(c,ti)
            if values.ndim==2:values=values[None]
            self.calls+=1
            for j,o in enumerate(sub):
                found[o]=values[j];self.cache.put((self.prefix,int(c),o),values[j])
        if not len(host):return torch.empty((0,self.size,self.size//2+1),device=self.device,dtype=self.dtype)
        result=torch.stack([found[int(o)] for o in unique])
        return result.index_select(0,torch.as_tensor(inverse,device=self.device,dtype=torch.long))
    def slice_active(self,c,start,stop,active):
        return self.gather(c,torch.arange(start,stop,device=self.device)).flatten(-2).index_select(-1,active)

class FineProjectionStore:
    """Fine parent-block adapter over a persistent packed projection cache."""
    def __init__(self,store,classes,orientations,oc):
        self.store=store;self.classes=classes;self.orientations=orientations;self.oc=oc
        self.shape=(len(classes),oc,store.shape[-2],store.shape[-1])
        self.device=store.device;self.dtype=store.dtype
        # One batched metadata readback per result; subsequent class/child
        # mapping uses host arrays rather than repeated class + angle readbacks.
        metadata=torch.stack((classes,orientations),1).detach().cpu().numpy()
        if classes.device.type != "cpu":self.store._count("metadata_d2h_calls")
        self.host_classes,self.host_orientations=metadata[:,0],metadata[:,1]
    def element_size(self):return 8
    def _gather(self,ids,active=None):
        host=ids.detach().cpu().numpy().reshape(-1)
        if ids.device.type != "cpu":self.store._count("index_d2h_calls")
        return self._gather_host(host,active)
    def gather_active_host(self,ids,active):
        """Dense schedules already own CPU block IDs; avoid uploading then reading back."""
        return self._gather_host(np.asarray(ids,dtype=np.int64).reshape(-1),active)
    def _gather_host(self,host,active=None):
        if np.any((host<0)|(host>=self.shape[0])):raise IndexError('Fine projection block outside support')
        cs,co=self.host_classes[host],self.host_orientations[host]
        tail=(active.numel(),) if active is not None else self.shape[-2:]
        if len(host) and np.all(cs==cs[0]):
            angles=(co[:,None]*self.oc+np.arange(self.oc)[None]).reshape(-1)
            values=(self.store.gather_host(int(cs[0]),angles) if active is None
                    else self.store.gather_selected_host(int(cs[0]),angles,active))
            self.store._count('single_class_copy_avoided_rows',len(angles))
            return values.reshape(len(host),self.oc,*tail)
        out=torch.empty((len(host),self.oc,*tail),device=self.device,dtype=self.dtype)
        for c in np.unique(cs):
            positions=np.flatnonzero(cs==c)
            angles=(co[positions,None]*self.oc+np.arange(self.oc)[None]).reshape(-1)
            values=(self.store.gather_host(int(c),angles) if active is None
                    else self.store.gather_selected_host(int(c),angles,active))
            ix=torch.as_tensor(positions,device=self.device,dtype=torch.long)
            out.index_copy_(0,ix,values.reshape(len(positions),self.oc,*tail))
        return out
    def fusion_available(self):
        if not getattr(self.store,'fine_score_fusion',True):return False
        return self._fusion_backend_available()
    def _fusion_backend_available(self):
        from relion_torch.inference.fused_projection import available
        fallback=getattr(self.store,'fallback',None)
        mode=getattr(getattr(fallback,'projector',None),'fusion_mode','off')
        return available(self.device,mode)
    def prepare_fine_inputs(self,blocks,image,factor,inv,highres,phase,active,*,phase_active,work_bytes):
        # Cached/global stores do not have the local execution arena.
        if not hasattr(self.store,'buffer'):return None
        from relion_torch.inference.fine_inputs import prepare
        return prepare(self,blocks,image,factor,inv,highres,phase,active,
                       phase_active=phase_active,work_bytes=work_bytes)
    def fused_score(self,blocks,shifted,factor,inv,highres,active):
        if not self.fusion_available():return None
        from relion_torch.inference.fused_projection import score
        host=blocks.detach().cpu().numpy();cs=self.host_classes[host];co=self.host_orientations[host]
        out=torch.empty((len(host),self.oc,shifted.shape[1]),device=self.device,dtype=shifted.real.dtype)
        for c in np.unique(cs):
            positions=np.flatnonzero(cs==c)
            ids=(co[positions,None]*self.oc+np.arange(self.oc)[None]).reshape(-1)
            rows=torch.as_tensor(np.repeat(positions,self.oc),device=self.device)
            part=score(self.store,int(c),ids,shifted,factor,inv,highres,active,rows)
            if part is None:return None
            out.index_copy_(0,torch.as_tensor(positions,device=self.device),part.reshape(len(positions),self.oc,-1))
        return out
    def statistics_references(self,blocks,*,host_schedule=None):
        if getattr(self.store,'fine_statistics_fusion',True) and self._fusion_backend_available():
            from relion_torch.inference.fused_projection import StatisticsReferences
            return StatisticsReferences(self,blocks,host_schedule=host_schedule)
        return self.index_select(0,blocks).reshape(-1,*self.shape[-2:])
    def index_select(self,dim,ids):
        if dim!=0:raise ValueError('FineProjectionStore only permits block-axis gather')
        return self._gather(ids)
    def gather_active(self,ids,active_indices):
        return self._gather(ids,active_indices)

class _Objects:
    def __init__(self,pool):self.pool=pool
    def __len__(self):return self.pool.k
    def __getitem__(self,c):return self.pool.acquire(c)
    def __iter__(self):
        for c in range(len(self)):yield self[c]

class BackprojectorPool:
    """At most capacity GPU grids; exact inactive grids spill only to RAM."""
    def add(self,c,values,rotations,numerator_weight,denominator_weight,*,observation_weights=None,orientation_chunk_size=256):
        self.acquire(c).accumulate(values,rotations,denominator_weight,observation_weights=observation_weights,
            orientation_chunk_size=orientation_chunk_size,fusion_mode=getattr(self,'fusion_mode','off'),fusion_counters=self.counts)
    reconstruct_one=ValidatedBackprojectorAdapter.reconstruct_one
    def __init__(self,k,n,size,pad,device,max_bytes,host_bytes,counters):
        self.k=k;self.n=n;self.size=size;self.pad=pad;self.device=torch.device(device);self.counts=counters
        p=padded_size(n,pad);eff=p/n;radius=int(math.floor(size/2*eff+.5));side=2*(radius+1)+1
        self.per_class_bytes=side*side*(side//2+1)*12
        self.capacity=min(k,int(max_bytes)//self.per_class_bytes)
        if self.capacity<1:
            raise MemoryError(f'One 3-D backprojector requires {self.per_class_bytes/2**20:.3f} MiB; increase --backprojector-cache-mib.')
        if max(0,k-self.capacity)*self.per_class_bytes>host_bytes:
            raise MemoryError('Worst-case inactive 3-D accumulators exceed --backprojector-host-gib; increase its explicit RAM budget or lower K/work size.')
        self.gpu=OrderedDict();self.host={};self.objects=_Objects(self)
        self.counts['backprojector_bytes_per_class']=self.per_class_bytes
        self.counts['backprojector_device_class_capacity']=self.capacity
    def acquire(self,c):
        c=int(c)
        if not 0<=c<self.k:raise IndexError(c)
        if c in self.gpu:self.gpu.move_to_end(c);return self.gpu[c]
        while len(self.gpu)>=self.capacity:
            key,old=self.gpu.popitem(last=False)
            self.host[key]=replace(old,numerator_real=old.numerator_real.cpu(),numerator_imag=old.numerator_imag.cpu(),denominator=old.denominator.cpu())
            self.counts['backprojector_spills']=self.counts.get('backprojector_spills',0)+1
        if c in self.host:
            old=self.host.pop(c)
            obj=replace(old,numerator_real=old.numerator_real.to(self.device),numerator_imag=old.numerator_imag.to(self.device),denominator=old.denominator.to(self.device))
            self.counts['backprojector_reloads']=self.counts.get('backprojector_reloads',0)+1
        else:obj=FourierBackprojector.create(self.n,current_size=self.size,padding_factor=self.pad,reference_dim=3,device=self.device)
        self.gpu[c]=obj
        self.counts['backprojector_device_peak_bytes']=max(self.counts.get('backprojector_device_peak_bytes',0),len(self.gpu)*self.per_class_bytes)
        self.counts['backprojector_host_peak_bytes']=max(self.counts.get('backprojector_host_peak_bytes',0),len(self.host)*self.per_class_bytes)
        return obj
    def release(self,c):self.gpu.pop(c,None);self.host.pop(c,None)

from relion_torch.alignment.packed_grouped_backprojection import PackedGroupedOrientationAccumulator

class GroupedBackprojection3D(PackedGroupedOrientationAccumulator):
    """3-D gridding adapter for shared packed, batched orientation sums."""
    def __init__(self,bps,angles,max_bytes,slab_rows=32,chunk_size=32,counters=None):
        self.bps,self.angles,self.chunk = bps,angles,chunk_size
        self.slab_rows = max(1,int(slab_rows))
        super().__init__(self._insert,bps.size,max_bytes,bps.k,len(angles),counters=counters)

    def _insert(self,c,ids,num,den):
        mats=_euler_matrix(self.angles.index_select(0,ids))
        self.bps.add(c,num,mats,torch.ones_like(den),den,orientation_chunk_size=self.chunk)
        self._count('backprojector_calls',1)
        self._count('backprojected_orientation_rows',len(ids))
