"""Class3D reuses v0.2.17 posterior/scorers with lazy projection storage.

The coarse objective is algebraically factored to reuse particle-side work.
Projection caching and tiling change execution, not support or adaptive thresholds;
floating-point product and accumulation order may differ.
"""
from __future__ import annotations
import math
from dataclasses import replace
from contextlib import nullcontext
import numpy as np
import torch
from relion_torch.inference.alignment import (
    AlignmentExpectation, GlobalProjectionBank, FineProjectionBlocks,
    DenseBatchExpectation, likelihood_rfft_mask, likelihood_inverse_noise, rounded_shell_indices_2d,
    phase_shift_rfft,
)
from .resources import ByteLRU, ProjectionStore, FineProjectionStore
from relion_torch.inference.projection_cache import ContiguousProjectionStore, IndexedProjectionStore
from relion_torch.inference.reference_scoring import PreparedReferenceScorer
from relion_torch.inference.work_planning import projection_chunk_rows, fine_cache_reserve
from relion_torch.fourier.projection_geometry import EulerInverseCache
from relion_torch.inference.alignment import relion_weight_selection_batch
Tensor=torch.Tensor

class SplitParticleBatch(MemoryError):
    """Retry the SAME particles as smaller batches, without reducing sampling."""
    def __init__(self,message,required_posterior_bytes=None):
        super().__init__(message)
        self.required_posterior_bytes=required_posterior_bytes

class Class3DExpectation(AlignmentExpectation):
    def __init__(self,*args,projection_cache_bytes,posterior_bytes,reset_direction_prior=False,coarse_score_chunk_size=0,particle_batch_size=8,cache_active=True,fine_reserve_bytes=None,coarse_cache_policy='auto',coarse_host_cache_bytes=1024*2**20,**kwargs):
        super().__init__(*args,**kwargs)
        self.cache=ByteLRU(projection_cache_bytes)
        self.posterior_bytes=int(posterior_bytes)
        self.allowed_classes=None
        self.reset_direction_prior=bool(reset_direction_prior)
        self.memory_counters={}
        self.coarse_score_chunk_size=int(coarse_score_chunk_size)
        self.particle_batch_size=int(particle_batch_size)
        self.geometry=EulerInverseCache(min(128*2**20,self.config.candidate_work_bytes//8),self.memory_counters)
        self._fine_stores={}
        self.cache_active=bool(cache_active)
        self.fine_reserve_bytes=fine_reserve_bytes
        self.local_buffer=None
        self.fine_buffer=None
        self.fine_coarse_bytes=0
        self.coarse_cache_policy=coarse_cache_policy
        self.coarse_host_cache_bytes=max(0,int(coarse_host_cache_bytes))

    def projection_storage_budget(self):
        """Return the owned projection limit and the actual retained payload."""
        if self.local_buffer is not None:
            value=self.local_buffer.values
            return self.local_buffer.max_bytes, 0 if value is None else value.numel()*value.element_size()
        if self.fine_buffer is not None:
            value=self.fine_buffer.values
            return (self.cache.max_bytes+self.fine_buffer.max_bytes,
                    self.cache.bytes+(0 if value is None else value.numel()*value.element_size()))
        return self.cache.max_bytes, self.cache.bytes

    def resize_projection_storage(self, max_bytes):
        """Rebuild bounded stores without the persistent real-OOM backoff.

        Old banks remain valid lazy projectors, but must no longer be selected by
        the scoring caller: new banks reserve slabs using the new shared limit.
        """
        self.release_projection_storage()
        self._global_projection_banks.clear();self._fine_stores.clear()
        self.cache.max_bytes=max(0,int(max_bytes))
        if self.local_buffer is not None:
            self.local_buffer.release()
            self.local_buffer.max_bytes=self.cache.max_bytes
            self.local_buffer.counts['local_projection_budget_bytes']=self.cache.max_bytes
            self.cache.max_bytes=0
        if self.fine_buffer is not None:
            from relion_torch.inference.global_fine import partition
            coarse,fine=partition(max_bytes,self.fine_coarse_bytes,self.fine_buffer.max_bytes)
            self.cache.max_bytes=coarse
            self.fine_buffer.max_bytes=fine
            self.memory_counters['fine_stream_projection_effective_budget_bytes']=fine
        if self.fine_reserve_bytes is not None:
            self.fine_reserve_bytes=min(self.fine_reserve_bytes,max(0,int(max_bytes))//4)

    def release_projection_storage(self, *, disable=False):
        """Release store owners too; clearing only the registry leaves slabs live.

        Existing bank objects remain valid exact lazy projectors for safe OOM
        retries. Call only before statistical commit or after the final flush.
        """
        self._selected_fine_geometry=None
        for bank in self._global_projection_banks.values():
            bank.projections.release_storage()
        for store in self._fine_stores.values():
            store.release_storage()
        self.cache.clear()
        if self.fine_buffer is not None:
            self.fine_buffer.release()
            if disable:
                self.fine_buffer.max_bytes=0
                self.memory_counters['fine_stream_projection_effective_budget_bytes']=0
        if self.local_buffer is not None and disable:
            self.local_buffer.release()
            self.local_buffer.max_bytes=0
            self.local_buffer.counts['local_projection_budget_bytes']=0
        self.geometry.items.clear();self.geometry.bytes=0
        if disable:
            self.cache.max_bytes=0
            self.geometry.max_bytes=0
            self.memory_counters['projection_cache_disabled_after_oom']=1
    def _sync_source_caches(self):
        old=getattr(self,'_lazy_signature',None)
        signature=super()._sync_source_caches()
        if old is not None and old!=signature and hasattr(self,'cache'):
            self.cache.clear()
            self._fine_stores.clear()
            if self.fine_buffer is not None:self.fine_buffer.release()
        self._lazy_signature=signature
        return signature
    def check_coarse_budget(self,batch_size):
        count=batch_size*len(self.class_probabilities)*self.sampling.number_of_orientations*self.sampling.number_of_translations
        # Live scores, priors, weights, sort/cumsum indices and masks.
        estimated=count*112
        self.memory_counters['posterior_observed_bytes_per_particle']=max(self.memory_counters.get('posterior_observed_bytes_per_particle',0),estimated//batch_size)
        self.memory_counters['coarse_posterior_estimated_bytes']=max(self.memory_counters.get('coarse_posterior_estimated_bytes',0),estimated)
        if estimated>self.posterior_bytes:raise SplitParticleBatch(f'coarse posterior estimate {estimated/2**20:.1f} MiB exceeds posterior budget',estimated)
    def check_local_budget(self,batch_size,width,translations):
        from relion_torch.inference.posterior_estimates import local_posterior_bytes
        estimated=local_posterior_bytes(batch_size,len(self.class_probabilities),width,translations)
        self.memory_counters['local_posterior_observed_bytes_per_particle']=max(
            self.memory_counters.get('local_posterior_observed_bytes_per_particle',0),estimated//batch_size)
        self.memory_counters['posterior_observed_bytes_per_particle']=max(self.memory_counters.get('posterior_observed_bytes_per_particle',0),estimated//batch_size)
        self.memory_counters['coarse_posterior_estimated_bytes']=max(self.memory_counters.get('coarse_posterior_estimated_bytes',0),estimated)
        self.memory_counters['local_posterior_estimated_bytes']=max(self.memory_counters.get('local_posterior_estimated_bytes',0),estimated)
        if estimated>self.posterior_bytes:
            raise SplitParticleBatch(f'local posterior estimate {estimated/2**20:.1f} MiB exceeds posterior budget',estimated)
    def run_local_batch(self,*args,**kwargs):
        from relion_torch.inference.local_search import LocalSearchWorkspaceError
        try:
            return super().run_local_batch(*args,**kwargs)
        except LocalSearchWorkspaceError as exc:
            raise SplitParticleBatch(str(exc)) from exc
    def _global_orientation_tensors(self,device,dtype):
        table=self.sampling.fine_sampling_table(0)
        angles=torch.as_tensor(table.orientation_angles[:,0],device=device,dtype=dtype)
        directions=torch.as_tensor(table.direction_indices[:,0],device=device,dtype=torch.long)
        psi=torch.arange(len(angles),device=device)%len(self.sampling.psi_angles)
        return angles,directions,psi
    def _fine_geometry_for_parents(self,parents,order,*,device,dtype):
        select=getattr(self.sampling,'selected_fine_sampling_table',None)
        if self.local_buffer is None or select is None:
            return super()._fine_geometry_for_parents(parents,order,device=device,dtype=dtype)
        unique,inverse=torch.unique(parents,sorted=True,return_inverse=True)
        host=unique.detach().cpu().numpy()
        key=(id(self.sampling),float(self.sampling.random_perturbation),int(order),str(device),dtype,host.tobytes())
        cached=getattr(self,'_selected_fine_geometry',None)
        if cached is None or cached[0]!=key:
            # A new parent domain invalidates stores whose internal IDs are compact.
            for store in self._fine_stores.values():store.release_storage()
            self._fine_stores.clear()
            table=select(host,order)
            tensors=(torch.as_tensor(table.orientation_angles,device=device,dtype=dtype),
                torch.as_tensor(table.direction_indices,device=device,dtype=torch.long),
                torch.as_tensor(table.orientation_ids,device=device,dtype=torch.long),
                torch.as_tensor(table.translations,device=device,dtype=dtype))
            self._selected_fine_geometry=(key,tensors)
            c=self.memory_counters
            c['local_fine_geometry_builds']=c.get('local_fine_geometry_builds',0)+1
            c['local_fine_geometry_parent_rows']=c.get('local_fine_geometry_parent_rows',0)+len(host)
            c['local_fine_geometry_avoided_parent_rows']=c.get('local_fine_geometry_avoided_parent_rows',0)+self.sampling.number_of_orientations-len(host)
        else:tensors=cached[1]
        return tensors,inverse,unique
    def build_global_projection_bank(self,*,pixel_size,image_size=None,maximum_shell=None):
        coarse_size,coarse_shell=self.sizes.coarse_likelihood_grid(self.config.adaptive_oversampling)
        size=int(coarse_size if image_size is None else image_size)
        shell=int(coarse_shell if maximum_shell is None else maximum_shell)
        signature=self._sync_source_caches();key=(size,shell,bool(self.config.firstiter_cc))
        if key in self._global_projection_banks:return self._global_projection_banks[key]
        device=self.class_probabilities.device
        angles,directions,psi=self._global_orientation_tensors(device,torch.float32)
        trans=torch.as_tensor(self.sampling.translations,device=device,dtype=torch.float32)
        phase=phase_shift_rfft((size,size//2+1),trans/pixel_size,device,torch.float32,original_size=self.sizes.original_size)
        store=ProjectionStore(self.projector,angles,len(self.class_probabilities),size,self.cache,
                              max_chunk=projection_chunk_rows(size,self.config.candidate_work_bytes,self.config.chunk_size),
                              key_prefix=('coarse',size),geometry=self.geometry)
        active = torch.nonzero(likelihood_rfft_mask(size,shell,device,
            firstiter_cc=self.config.firstiter_cc).flatten(),as_tuple=False).squeeze(1)
        local=any(x>0 for x in (self.config.sigma_rot_deg,self.config.sigma_tilt_deg,self.config.sigma_psi_deg))
        if self.local_buffer is not None:
            from relion_torch.inference.local_projection import BlockProjectionStore
            store=BlockProjectionStore(store,active,self.local_buffer)
            bank=GlobalProjectionBank(angles,directions,psi,trans,store,phase,size,shell,signature)
            self._global_projection_banks[key]=bank
            return bank
        packed = local or math.prod(store.shape)*8 > self.cache.max_bytes
        store_type=IndexedProjectionStore if packed else ContiguousProjectionStore
        reserve = self.fine_reserve_bytes if self.fine_reserve_bytes is not None else fine_cache_reserve(
            self.cache.max_bytes,self.sizes.current_size,self.particle_batch_size,self.config.adaptive_oversampling)
        kwargs = dict(counters=self.memory_counters, reserve_bytes=reserve,
            counter_prefix="local_projection_cache" if local else "coarse_projection_cache") if packed else {}
        # A current-size bank requested by for_weighted_sums only needs full
        # planes; do not duplicate its active frequencies under strict-highres.
        weighted_only=(self.sizes.strict_shell() is not None and size==self.sizes.current_size
                       and (size,shell)!=(coarse_size,coarse_shell))
        cache_active=self.cache_active and not weighted_only
        if packed and not local and not weighted_only and device.type=='cuda' and self.coarse_cache_policy!='clock':
            from relion_torch.inference.sweep_projection_cache import SweepProjectionStore
            store_type=SweepProjectionStore
            held=sum(getattr(b.projections,'host_bytes',0) for b in self._global_projection_banks.values())
            kwargs['host_max_bytes']=max(0,self.coarse_host_cache_bytes-held) if self.coarse_cache_policy=='auto' else 0
        store = store_type(store,active,key=('coarse-resident',*key),cache_active=cache_active,**kwargs)
        self.memory_counters['coarse_contiguous_bank_bytes'] = sum(
            x.numel()*x.element_size() for x in (store.values,store.active_values) if x is not None)
        self.memory_counters['coarse_contiguous_banks'] = int(store.values is not None)
        self.memory_counters['coarse_active_banks'] = int(store.active_values is not None)
        bank=GlobalProjectionBank(angles,directions,psi,trans,store,phase,size,shell,signature)
        self._global_projection_banks[key]=bank
        self.memory_counters['coarse_projection_full_bank_avoided_bytes']=math.prod(store.shape)*8
        return bank
    def _build_sparse_fine_projection_blocks(self,parent_class_indices,parent_orientation_indices,fine_angles,*,order,image_size):
        no=fine_angles.shape[0];oc=fine_angles.shape[1]
        key=parent_class_indices*no+parent_orientation_indices
        unique,inverse=torch.unique(key,sorted=True,return_inverse=True)
        cs=torch.div(unique,no,rounding_mode='floor');ori=unique%no
        cache_key=(image_size,order)
        store=self._fine_stores.get(cache_key)
        if store is None:
            from relion_torch.inference.global_fine import FineProjector, configure_store
            hybrid=getattr(self,'global_fine_backend','cached')=='hybrid'
            callback=FineProjector(self.projector) if hybrid else self.projector
            fallback=ProjectionStore(callback,fine_angles.reshape(-1,3),len(self.class_probabilities),image_size,self.cache,
                max_chunk=projection_chunk_rows(image_size,self.config.candidate_work_bytes,self.config.chunk_size),
                key_prefix=('fine',image_size,order),geometry=self.geometry)
            buffer=self.local_buffer if self.local_buffer is not None else self.fine_buffer
            if buffer is not None:
                from relion_torch.inference.local_projection import BlockProjectionStore
                store=BlockProjectionStore(fallback,None,buffer)
            else:
                store=IndexedProjectionStore(fallback,None,key=('fine-packed',image_size,order),
                    counters=self.memory_counters,reserve_bytes=0,counter_prefix='fine_projection_cache',cache_active=False)
            configure_store(self,store)
            store.detail_timer=getattr(self,"detail_timer",None)
            self._fine_stores[cache_key]=store
        lazy=FineProjectionStore(store,cs,ori,oc)
        blocks=FineProjectionBlocks(unique,cs,ori,fine_angles.index_select(0,ori),lazy)
        self.memory_counters['fine_projection_full_bank_avoided_bytes']=max(self.memory_counters.get('fine_projection_full_bank_avoided_bytes',0),math.prod(lazy.shape)*8)
        return blocks,inverse
    def _dense_log_prior(self,bank,batch_size,*,offset_prior_angstrom,orientation_prior_deg,dtype,device):
        # ml_optimiser.cpp convertAllSquaredDifferencesToWeights uses the
        # UNPERTURBED coarse translation grid for both adaptive passes. Actual
        # phase shifts use getTranslations(), including q and fine children.
        original=self.config
        class_prob=self.class_probabilities
        direction_priors=self.direction_priors
        try:
            self.config=replace(original,sigma_offset_angstrom=0.)
            if self.reset_direction_prior:
                # initialisePdfDirection(newsize) sets JOINT P(class,direction)
                # to 1/(K*Ndir), while keeping pdf_class for reconstruction and
                # the empty-class guard. The shared scorer stores conditional
                # P(direction|class), so use uniform scoring priors only here.
                self.class_probabilities=torch.full_like(class_prob,1./len(class_prob))
                self.direction_priors=None
            logp=super()._dense_log_prior(bank,batch_size,offset_prior_angstrom=offset_prior_angstrom,
                orientation_prior_deg=orientation_prior_deg,dtype=dtype,device=device)
        finally:
            self.config=original
            self.class_probabilities=class_prob
            self.direction_priors=direction_priors
        if self.reset_direction_prior:
            # Native RELION still skips classes whose saved pdf_class is zero.
            logp=logp.masked_fill((class_prob<=0).to(device)[None,:,None,None],-torch.inf)
        trans=torch.as_tensor(self.sampling.prior_translations,device=device,dtype=dtype)
        d=(trans[None]-offset_prior_angstrom.to(dtype)[:,None]).square().sum(-1)
        if original.sigma_offset_angstrom**2<.0001:
            prior=(d==0).to(dtype)
        else:
            prior=torch.exp(-.5*d/original.sigma_offset_angstrom**2)
        prior=prior/prior.mean(-1,keepdim=True).clamp_min(torch.finfo(dtype).tiny)
        tlog=torch.where(prior>0,prior.log(),torch.full_like(prior,-torch.inf))
        if self.allowed_classes is not None:
            allowed=self.allowed_classes.to(device)
            mask=torch.arange(len(self.class_probabilities),device=device)[None]==allowed[:,None]
            logp=logp.masked_fill(~mask[:,:,None,None],-torch.inf)
            # Seed generation restricts class range BEFORE averaging the
            # direction PDF in native RELION; do not retain an extra log(K).
            joint=logp[...,0]
            meanlog=torch.logsumexp(joint.flatten(1),1)-math.log(bank.number_of_orientations)
            logp=logp-meanlog[:,None,None,None]
        return logp+tlog[:,None,None,:]

    @torch.no_grad()
    def run_sparse_adaptive_batch(self,*args,**kwargs):
        if self.fine_buffer is not None:self.fine_buffer.begin_batch()
        coarse=kwargs.get('coarse')
        if coarse is not None:
            counts=coarse.significant.flatten(1).sum(1).cpu().numpy()
            oc=8**self.config.adaptive_oversampling
            tc=4**self.config.adaptive_oversampling
            parents=int(counts.sum());b=len(counts)
            # Include selected-parent metadata plus padded posterior/sort work.
            estimated=parents*(64+oc*48+tc*8+oc*tc*32)+b*int(counts.max())*oc*tc*112
            self.memory_counters['posterior_observed_bytes_per_particle']=max(self.memory_counters.get('posterior_observed_bytes_per_particle',0),estimated//b)
            self.memory_counters['fine_posterior_estimated_bytes']=max(self.memory_counters.get('fine_posterior_estimated_bytes',0),estimated)
            if estimated>self.posterior_bytes:
                raise SplitParticleBatch(f'fine posterior estimate {estimated/2**20:.1f} MiB exceeds posterior budget',estimated)
        return super().run_sparse_adaptive_batch(*args,**kwargs)

    @torch.no_grad()
    def run_global_batch(self, *args, **kwargs):
        return self.run_global_batches([(args, kwargs)])[0]

    @torch.no_grad()
    def run_global_batches(self, batches):
        """Cooperative orientation tiles, complete independent posteriors.

        Every microbatch keeps its original GEMM shape and global selection.
        A tile is projected once for matching requests, then released before
        the next tile. No persistent cache capacity is needed for this reuse.
        All generators are closed on failure before the transaction is retried.
        """
        from relion_torch.inference.global_schedule import score_windows
        return score_windows(self, batches)

    def _global_batch_requests(
        self,
        particle_ft: Tensor,
        ctf: Tensor,
        sigma2_by_shell: Tensor,
        *,
        offset_prior_angstrom: Tensor,
        orientation_prior_deg: Tensor | None,
        pixel_size: float,
        bank: GlobalProjectionBank | None = None,
    ) -> DenseBatchExpectation:
        """Matrix-based global orientation/translation expectation."""

        if self.config.skip_align or self.config.skip_rotate:
            raise RuntimeError("run_global_batch is only valid for global rotation search")
        if particle_ft.ndim == 2:
            particle_ft = particle_ft.unsqueeze(0)
        if ctf.ndim == 2:
            ctf = ctf.unsqueeze(0)
        if sigma2_by_shell.ndim == 1:
            sigma2_by_shell = sigma2_by_shell.unsqueeze(0)
        batch_size = int(particle_ft.shape[0])
        if ctf.shape[0] != batch_size or sigma2_by_shell.shape[0] != batch_size:
            raise ValueError("particle, CTF and sigma2 batch sizes must match")
        self.check_coarse_budget(batch_size)
        source_signature = self._sync_source_caches()
        if bank is not None and bank.source_signature is not None and bank.source_signature != source_signature:
            raise RuntimeError("stale projection bank: source reference/support changed; rebuild the bank")
        bank = bank or self.build_global_projection_bank(pixel_size=pixel_size)
        device = particle_ft.device
        dtype = particle_ft.real.dtype
        size = bank.image_size
        image = self._window_rfft(particle_ft, size)
        ctf_window = self._window_rfft(ctf, size)
        mask = likelihood_rfft_mask(size, bank.maximum_shell, device, firstiter_cc=self.config.firstiter_cc)
        shells = rounded_shell_indices_2d(size, device)
        active_shells = shells[mask]
        for key,value in (('coarse_likelihood_image_size_max',size),
                          ('coarse_likelihood_shell_max',bank.maximum_shell),
                          ('coarse_likelihood_active_pixels_max',active_shells.numel())):
            self.memory_counters[key]=max(self.memory_counters.get(key,0),int(value))
        image_active = image[:, mask]
        ctf_active = ctf_window[:, mask].to(dtype=dtype)
        invsigma = likelihood_inverse_noise(sigma2_by_shell.to(device=device, dtype=dtype),
            active_shells, firstiter_cc=self.config.firstiter_cc)
        highres, logsigma = self._highres_terms_batch(
            particle_ft, sigma2_by_shell, self.sizes.current_shell
        )

        phase_active = self._cached_spectral_view(
            ('coarse-phase', size, bank.maximum_shell), bank.phase_factors, mask, active_shells.numel())
        if phase_active is None:
            phase_active = bank.phase_factors.to(device=device)[:, mask]
        shifted = image_active.unsqueeze(1) * phase_active.unsqueeze(0)
        cc = self.config.firstiter_cc
        xpower = image_active.real.square() + image_active.imag.square()
        xnorm = (xpower if cc else xpower * invsigma).sum(-1)
        nc, no, nt = bank.number_of_classes, bank.number_of_orientations, bank.number_of_translations
        # Class support is resolved BEFORE any projections/scores are requested.
        log_prior = self._dense_log_prior(
            bank, batch_size, offset_prior_angstrom=offset_prior_angstrom,
            orientation_prior_deg=orientation_prior_deg, dtype=torch.float64, device=device)
        support = torch.isfinite(log_prior).any(dim=(2,3)).detach().cpu().numpy()
        diff2 = torch.full((batch_size,nc,no,nt),torch.inf,device=device,dtype=dtype)
        cc_all = torch.full_like(diff2,-torch.inf) if cc else None
        active_indices = bank.projections.active_indices
        detail = getattr(self, 'detail_timer', None)
        section = lambda name: detail.section(name, full=True) if detail is not None else nullcontext()
        prepared=PreparedReferenceScorer(shifted,ctf_active,invsigma,highres,xnorm,cc=cc,
            fusion_mode=getattr(self,'global_fusion','off'),counters=self.memory_counters)
        self.memory_counters['coarse_prepared_batches']=self.memory_counters.get('coarse_prepared_batches',0)+1
        for class_index in range(nc):
            host_rows = np.flatnonzero(support[:,class_index])
            if len(host_rows) == 0:
                continue
            all_rows = len(host_rows) == batch_size
            row_ids = slice(None) if all_rows else torch.as_tensor(host_rows,device=device,dtype=torch.long)
            scorer=prepared if all_rows else prepared.select(row_ids)
            try:
                chunk,workspace=scorer.plan(no,self.config.candidate_work_bytes,self.coarse_score_chunk_size)
            except MemoryError as exc:
                raise SplitParticleBatch(str(exc)) from exc
            self.memory_counters['coarse_score_orientation_block_max']=max(self.memory_counters.get('coarse_score_orientation_block_max',0),chunk)
            self.memory_counters['coarse_scoring_workspace_estimated_bytes']=max(self.memory_counters.get('coarse_scoring_workspace_estimated_bytes',0),workspace)
            for start in range(0,no,chunk):
                stop = min(start+chunk,no)
                reference = yield (bank, class_index, start, stop, active_indices)
                with section('global.coarse_score'):
                    score = scorer.score(reference)
                diff2[row_ids,class_index,start:stop,:] = -score if cc else score
                if cc:
                    cc_all[row_ids,class_index,start:stop,:] = score
                reference = score = None
                self.memory_counters['coarse_score_tiles']=self.memory_counters.get('coarse_score_tiles',0)+1
            key = 'coarse_cc_scored_hypotheses' if cc else 'coarse_gaussian_scored_hypotheses'
            self.memory_counters[key] = self.memory_counters.get(key,0)+len(host_rows)*no*nt
        skipped = int((~support).sum())*no*nt
        self.memory_counters['coarse_skipped_class_hypotheses'] = self.memory_counters.get('coarse_skipped_class_hypotheses',0)+skipped
        flat_prior = log_prior.reshape(batch_size, -1)
        flat_diff = diff2.reshape(batch_size, -1)
        valid = torch.isfinite(flat_prior)
        if not bool(torch.all(valid.any(dim=-1))):
            raise RuntimeError("at least one particle has no hypothesis with non-zero prior")

        if self.config.firstiter_cc:
            assert cc_all is not None
            flat_cc = cc_all.reshape(batch_size, -1)
            score = torch.where(valid, flat_cc, torch.full_like(flat_cc, -torch.inf))
            best = torch.argmax(score, dim=-1)
            posterior_flat = torch.zeros_like(score)
            posterior_flat.scatter_(1, best[:, None], 1.0)
            posterior64_flat = posterior_flat.to(torch.float64)
            significant_flat = posterior_flat.to(torch.bool)
            reported_count = torch.ones(
                batch_size, device=device, dtype=torch.long
            )
            significant_weight = torch.ones(
                batch_size, device=device, dtype=torch.float64
            )
            raw_log_evidence = score.gather(1, best[:, None]).squeeze(1).to(
                torch.float64
            )
            pmax = torch.ones(batch_size, device=device, dtype=torch.float64)
        else:
            selection = relion_weight_selection_batch(
                flat_prior, flat_diff, self.config.adaptive_fraction,
                weight_dtype=torch.float32 if self.config.weight_precision=='float32' else torch.float64,
                compact_positive=True, counters=self.memory_counters,
                fusion_mode=getattr(self,'global_fusion','off'), detail_timer=detail)
            posterior_flat = selection.posterior
            posterior64_flat = selection.posterior64
            significant_flat = selection.significant
            best = selection.best_index
            reported_count = selection.reported_significant_count
            significant_weight = selection.significant_weight
            raw_log_evidence = selection.log_evidence
            pmax = selection.pmax

        posterior = posterior_flat.reshape_as(diff2)
        significant = significant_flat.reshape_as(diff2)
        posterior64 = posterior64_flat.reshape_as(diff2)
        class_mass = (
            posterior64 * significant.to(torch.float64)
        ).sum(dim=(2, 3))
        dll = (
            raw_log_evidence
            if self.config.firstiter_cc
            else raw_log_evidence - logsigma.to(torch.float64)
        )
        return DenseBatchExpectation(
            bank=bank,
            diff2=diff2,
            log_prior=log_prior,
            posterior=posterior,
            significant=significant,
            class_mass=class_mass,
            best_flat_index=best,
            pmax=pmax,
            log_likelihood_contribution=dll,
            highres_xi2_half=highres,
            log_sigma2=logsigma,
            reported_significant_count=reported_count,
            significant_weight=significant_weight,
            log_evidence=raw_log_evidence,
            cross_correlation=cc_all,
        )
