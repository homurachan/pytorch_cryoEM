"""Validated point-group Class3D task setup and iteration-boundary continuation."""
from __future__ import annotations
from pathlib import Path
from dataclasses import fields, replace
import math
import torch
from relion_torch.alignment.core import AlignmentDataset
from relion_torch.optimiser.alignment import AlignmentConfig
from relion_torch.class2d.performance import StartupContext
from relion_torch.io.star import read_star
from .config import Class3DConfig, CONTINUATION_SAMPLING_OVERRIDES
from .references import load_references
from .optimiser import Class3DOptimiser

EXECUTION_OVERRIDES={
    'local_coarse_mode',
    'coarse_cache_policy','coarse_host_cache_mib', 'global_window_mib', 'global_fine_mode', 'global_fine_mib', 'global_fine_statistics',
    'skip_gridding','preweight_iterations','symmetry_backend','reconstruction_backend','global_fusion','global_gridding',
    'local_projection_reuse','local_fine_inputs','local_statistics_reduction','local_gridding',
    'local_candidate_search','local_fine_chunking','local_statistics_inputs',
    'devices','worker_threads','worker_chunk_size','gpu_memory_percent','auto_memory','local_batch_max','local_fusion','local_projection_mode','local_projection_mib',
    'device','batch_size','pool_size','preread_images','io_batch_size','max_open_stacks','particle_io',
    'preread_max_gib','coarse_score_chunk_size','orientation_chunk_size','backprojector_chunk_size','candidate_chunk_size',
    'candidate_work_mib','posterior_work_mib','sampling_work_mib','performance_cache_mib','projector_cache_mib',
    'backprojector_cache_mib','backprojector_host_gib','reference_max_gib','fine_score_mode','dense_fine_execution',
    'weight_precision','accumulation_precision','preprocess_work_mib','preprocess_cache_mib',
    'timing','timing_detail_samples','write_debug','write_unfil_map','fast_subsets','progress',
}
from relion_torch.reconstruction.sirm import SIRM_CONTINUATION_FIELDS, sirm_options_from_config
PATH_FIELDS={'input_star','output_root','continue_from','solvent_mask','sirm_mask'}

def load_checkpoint(path):
    p=Path(path).expanduser().resolve()
    if p.suffix=='.star':
        blocks=read_star(p);found=[]
        for frame in blocks.values():
            if 'rlnTorchCheckpoint' in frame:found.extend(frame['rlnTorchCheckpoint'].astype(str).tolist())
        if len(found)!=1:raise ValueError('Class3D continuation requires its .pt or own optimiser STAR containing rlnTorchCheckpoint; native RELION STAR-only import is not supported.')
        q=Path(found[0]);p=q if q.is_absolute() else p.parent/q
    if not p.is_file():raise FileNotFoundError(f'Checkpoint not found: {p}')
    # Only ordinary tensors and primitive containers are saved. Do not execute
    # arbitrary pickle globals from an untrusted state file.
    state=torch.load(p,map_location='cpu',weights_only=True)
    if not isinstance(state,dict) or state.get('format')!='relion-torch-class3d-v1':
        raise ValueError('This is not a supported Class3D checkpoint (Class2D state cannot be used as a 3-D state).')
    return state

def validate(options):
    if options.local_coarse_mode not in ('auto','direct','shared'):raise ValueError('Invalid local-coarse-mode')
    if options.global_fine_mode not in ('auto','cached','stream','hybrid'):raise ValueError('Invalid global-fine-mode')
    if options.global_fine_statistics not in ('auto','tensor','fused'):raise ValueError('Invalid global-fine-statistics')
    if not math.isfinite(options.global_fine_mib) or options.global_fine_mib<0:raise ValueError('global-fine-mib must be finite and nonnegative')
    if options.coarse_cache_policy not in ('auto','fixed','clock'):raise ValueError('Invalid coarse-cache-policy')
    if not math.isfinite(options.global_window_mib) or options.global_window_mib<0:raise ValueError('global-window-mib must be finite and nonnegative')
    if not math.isfinite(options.coarse_host_cache_mib) or options.coarse_host_cache_mib<0:raise ValueError('coarse-host-cache-mib must be finite and nonnegative')
    if options.sirm_mask is not None:
        options.sirm_mask=Path(options.sirm_mask).expanduser().resolve()
    sirm_options_from_config(options)
    if options.worker_threads<1 or options.worker_chunk_size<1:raise ValueError("Worker threads and chunk size must be positive")
    if not math.isfinite(options.gpu_memory_percent) or not 0 < options.gpu_memory_percent <= 100:
        raise ValueError('gpu-memory-percent must be finite and in (0, 100]')
    from relion_torch.geometry.symmetry import normalize_symmetry
    options.symmetry=normalize_symmetry(options.symmetry)
    if options.local_projection_mode not in ('stream','cached'):raise ValueError('local-projection-mode must be stream or cached')
    if not math.isfinite(options.local_projection_mib) or options.local_projection_mib<0:raise ValueError('local-projection-mib must be finite and nonnegative')
    if options.local_batch_max<0:raise ValueError("local-batch-max must be nonnegative")
    if options.local_fusion not in ("auto","off","required"):raise ValueError("Invalid local-fusion")
    if options.dense_fine_execution not in ('auto','reference'):raise ValueError('dense-fine-execution must be auto or reference')
    for name in ('local_projection_reuse','local_fine_inputs','local_statistics_reduction','local_candidate_search','local_fine_chunking','local_statistics_inputs'):
        if getattr(options,name) not in ('auto','off'):raise ValueError('Invalid '+name)
    if options.local_gridding not in ('auto','off','required','ordered'):raise ValueError('Invalid local_gridding')
    if options.global_gridding not in ("auto","off","required","ordered"):raise ValueError("Invalid global_gridding")
    for name in ("symmetry_backend","reconstruction_backend","global_fusion"):
        if getattr(options,name) not in ("auto","off","required"):raise ValueError("Invalid "+name)
    sigmas=options.angular_sigmas  # validates finite values, including disabled ones
    if options.local_angular_search and (options.skip_align or options.skip_rotate):
        raise ValueError('Local angular search cannot be combined with fixed angles (--skip-align/--skip-rotate)')
    if options.number_of_classes<1 or options.iterations<1:raise ValueError('K and final iteration must be positive')
    if not 0<=options.healpix_order<=6:raise ValueError('healpix-order must be between 0 and 6')
    if not 0<=options.oversampling<=2:raise ValueError('this release supports oversampling 0, 1 or 2')
    if not 0<=options.perturbation_factor<=1:raise ValueError('perturbation-factor must be in [0,1]')
    if not 0<options.adaptive_fraction<=1:raise ValueError('adaptive-fraction must be in (0,1]')
    if options.random_seed<0:raise ValueError('Use a non-negative explicit random seed for reproducible continuation')
    if (not math.isfinite(options.offset_step_pixels) or not math.isfinite(options.offset_range_pixels)
        or options.offset_step_pixels<=0 or options.offset_range_pixels<0):
        raise ValueError('finite offset-step >0 and offset-range >=0 required')
    if options.psi_step_deg is not None and (not math.isfinite(options.psi_step_deg) or options.psi_step_deg<=0):
        raise ValueError('psi-step must be positive and finite')
    if options.padding_factor<1 or not math.isfinite(options.padding_factor):raise ValueError('pad must be finite and >=1')
    if options.tau2_fudge<=0:raise ValueError('tau2-fudge must be positive')
    if options.fast_subsets and options.iterations<20:raise ValueError('RELION fast-subsets requires a final absolute iteration target >=20')
    if options.solvent_mask is not None and not options.flatten_solvent:raise ValueError('--solvent-mask requires --flatten-solvent')
    if (options.ctf_premultiplied or options.ctf_phase_flipped or options.only_flip_phases or options.intact_first_peak) and not options.use_ctf:
        raise ValueError('CTF observation options require --ctf')
    for name in ('candidate_work_mib','posterior_work_mib','sampling_work_mib','projector_cache_mib','backprojector_cache_mib','preprocess_work_mib','reference_max_gib'):
        x=float(getattr(options,name))
        if not math.isfinite(x) or x<=0:raise ValueError(f'{name} must be positive and finite')
    for name in ('performance_cache_mib','preprocess_cache_mib','backprojector_host_gib'):
        x=float(getattr(options,name))
        if not math.isfinite(x) or x<0:raise ValueError(f'{name} must be nonnegative and finite')
    for name in ('batch_size','orientation_chunk_size','backprojector_chunk_size','candidate_chunk_size','io_batch_size','max_open_stacks'):
        if getattr(options,name)<1:raise ValueError(f'{name} must be positive')
    if options.coarse_score_chunk_size<0:raise ValueError('coarse-score-chunk-size must be nonnegative')
    if not (options.skip_align or options.skip_rotate):
        psi=options.psi_step_deg or (360./(6*(1<<options.healpix_order)))
        from relion_torch.geometry.symmetry import direction_count
        no=direction_count(options.healpix_order,options.symmetry)*int(math.ceil(360./psi))
        table_bytes=no*(1+8**options.oversampling)*40
        cuda_execution=str(options.device).startswith('cuda') or bool(options.devices and 'cpu' not in options.devices)
        if table_bytes>options.sampling_work_mib*1024**2 and not (options.local_angular_search and options.local_projection_mode=='stream') and not (options.auto_memory and cuda_execution and torch.cuda.is_available()):
            raise MemoryError(f'3-D sampling table estimate {table_bytes/1024**2:.1f} MiB exceeds --sampling-work-mib; no directions were dropped.')
    if options.initial_high_resolution is not None and options.initial_high_resolution<=0:raise ValueError('ini-high must be positive')

def run_class3d(options:Class3DConfig,*,checkpoint_state=None):
    from relion_torch.inference.permanent_workers import devices
    if devices(options):options=replace(options,device="cpu")
    from relion_torch.inference.memory_planning import CudaMemoryController
    validate(options)
    device=torch.device('cpu' if options.device=='cuda' and not torch.cuda.is_available() else options.device)
    if device.type=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA is not available; use --device cpu for CPU testing')
    # Always restore a pre-existing allocator limit, including on failure.
    with CudaMemoryController(device, options.gpu_memory_percent, automatic=options.auto_memory) as guard:
        controller=guard if options.auto_memory and guard.enabled else None
        return _run_class3d(replace(options), checkpoint_state=checkpoint_state,
                            requested_options=options, memory_controller=controller)


def _run_class3d(options:Class3DConfig,*,checkpoint_state=None,requested_options=None,memory_controller=None):
    validate(options)
    state=checkpoint_state if checkpoint_state is not None else (load_checkpoint(options.continue_from) if options.continue_from else None)
    if state is not None:
        changed_sampling={name for name in CONTINUATION_SAMPLING_OVERRIDES
            if name in state['config'] and getattr(options,name)!=state['config'][name]}
        if options.skip_align and changed_sampling:
            raise ValueError('Cannot change sampling during --skip-align continuation: particle poses are fixed')
        if options.skip_rotate and changed_sampling-{'offset_range_pixels','offset_step_pixels'}:
            raise ValueError('Only offset range/step may change during --skip-rotate continuation: angles are fixed')
        for f in fields(options):
            if f.name in SIRM_CONTINUATION_FIELDS or f.name in EXECUTION_OVERRIDES or f.name in CONTINUATION_SAMPLING_OVERRIDES or f.name in ('output_root','continue_from','iterations','input_star'):
                continue
            if f.name not in state['config']:continue
            wanted=getattr(options,f.name);saved=state['config'][f.name]
            if f.name in PATH_FIELDS:
                wanted=None if wanted is None else str(wanted);saved=None if saved is None else str(saved)
            if isinstance(wanted,tuple):wanted=list(wanted)
            if wanted!=saved:
                raise ValueError(f'Class3D continuation scientific configuration differs: {f.name}; use the CLI to restore checkpoint settings.')
    offset=0 if state is None else int(state['iteration'])
    if options.iterations<=offset:raise ValueError(f'Final iteration {options.iterations} must exceed checkpoint iteration {offset}')
    device=torch.device('cpu' if options.device=='cuda' and not torch.cuda.is_available() else options.device)
    if device.type=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA is not available; use --device cpu for CPU testing')
    if state is None:
        if options.input_star is None or not options.references:raise ValueError('A new Class3D task requires --i and at least one --ref')
        inputstar=Path(options.input_star).expanduser().resolve()
    else:
        inputstar=Path(state['data_star'])
        if not inputstar.is_file():raise FileNotFoundError('Checkpoint data STAR is missing. Keep the saved data STAR and original particle stacks with the .pt file.')
    options.output_root=Path(options.output_root).expanduser().resolve()
    options.output_root.parent.mkdir(parents=True,exist_ok=True)
    options.input_star=Path(options.input_star or state['input_star']).expanduser().resolve()
    config=make_alignment_config(options,inputstar,device,offset,state is None)
    startup=StartupContext(options.timing,device)
    dataset=startup.timer.call('dataset_open_and_preread',AlignmentDataset.from_config,config,
        preserve_noise_groups=state is not None,shared_preread=bool(options.devices))
    try:
        from relion_torch.inference.permanent_workers import configure_coordinator
        configure_coordinator(options,dataset.box_size)
        if memory_controller is not None:
            from .memory import configure_startup
            configure_startup(memory_controller,options,dataset.box_size)
        if state is None:
            refs,paths,seeds=startup.timer.call('load_3d_references',load_references,options.references,
                options.number_of_classes,dataset.box_size,dataset.pixel_size,
                torch.device('cpu') if memory_controller is not None else device,options.reference_max_gib)
        else:
            refs=state['references'];paths=[Path(f'checkpoint_class{c+1:03d}.mrc') for c in range(len(refs))]
            seeds=state['generate_seeds']
            if len(refs)!=options.number_of_classes:raise ValueError('checkpoint K mismatch')
            if any(tuple(x.shape)!=(dataset.box_size,)*3 for x in refs):raise ValueError('checkpoint reference grid mismatch')
            if sum(x.numel()*4 for x in refs)>options.reference_max_gib*2**30:raise MemoryError('checkpoint references exceed --reference-max-gib')
        config.references=paths
        optimiser=Class3DOptimiser(config,options=options,dataset=dataset,initial_references=refs,
            generate_seeds=seeds,checkpoint_state=state,startup=startup,
            requested_options=requested_options,memory_controller=memory_controller)
        refs=None
        from relion_torch.inference.permanent_workers import PermanentPool,devices
        if devices(options):
            pool=PermanentPool(options)
            try:
                pool.bind(optimiser)
                return optimiser.run()
            finally:pool.close()
        return optimiser.run()
    finally:dataset.close()


def make_alignment_config(options,inputstar,device,offset=0,write_initial_state=True):
    return AlignmentConfig(inputstar,[],options.output_root,iterations=options.iterations-offset,
        device=str(device),batch_size=options.batch_size,preread_images=options.preread_images,
        io_batch_size=options.io_batch_size,pool_size=options.pool_size,max_open_stacks=options.max_open_stacks,
        particle_io=options.particle_io,preread_max_gib=options.preread_max_gib,reference_dim=3,
        healpix_order=0 if (options.skip_align or options.skip_rotate) else options.healpix_order,
        psi_step=360. if (options.skip_align or options.skip_rotate) else options.psi_step_deg,
        offset_range_angstrom=options.offset_range_pixels,offset_step_angstrom=options.offset_step_pixels,
        oversampling=options.oversampling,adaptive_fraction=options.adaptive_fraction,
        skip_align=options.skip_align,skip_rotate=options.skip_rotate,firstiter_cc=options.firstiter_cc,
        particle_diameter=options.particle_diameter_angstrom,mask_edge_pixels=options.mask_edge_pixels,
        zero_mask=options.zero_mask,current_size=options.current_size,strict_highres_angstrom=options.strict_highres_angstrom,
        minres_map=options.minres_map,sigma_offset_angstrom=options.sigma_offset_angstrom,
        sigma_rot_deg=options.angular_sigmas[0],sigma_tilt_deg=options.angular_sigmas[1],sigma_psi_deg=options.angular_sigmas[2],
        tau2_fudge=options.tau2_fudge,padding_factor=options.padding_factor,preweight_iterations=options.preweight_iterations,
        random_seed=options.random_seed,orientation_chunk_size=options.orientation_chunk_size,
        backprojector_chunk_size=options.backprojector_chunk_size,write_debug=options.write_debug,
        expected_accuracy_trials=options.expected_accuracy_trials,skip_expected_accuracy=options.skip_expected_accuracy,
        iteration_offset=offset,write_initial_state=write_initial_state)
