"""Configuration for point-group SPA Class3D (2-D observations, 3-D references)."""
from dataclasses import dataclass
from pathlib import Path

# RELION 3.1.4 parseContinue permits these sampling changes for classification.
CONTINUATION_SAMPLING_OVERRIDES = frozenset({
    'healpix_order', 'psi_step_deg', 'oversampling',
    'offset_range_pixels', 'offset_step_pixels',
    'sigma_ang_deg', 'sigma_rot_deg', 'sigma_tilt_deg', 'sigma_psi_deg',
})

@dataclass
class Class3DConfig:
    input_star: Path | None
    output_root: Path
    references: tuple[str, ...] = ()
    number_of_classes: int = 1
    iterations: int = 25
    continue_from: Path | None = None
    device: str = 'cuda'
    devices: str = ""
    worker_threads: int = 1
    worker_chunk_size: int = 256
    gpu_memory_percent: float = 100.
    auto_memory: bool = True
    symmetry: str = 'C1'
    healpix_order: int = 2
    psi_step_deg: float | None = None
    sigma_ang_deg: float = -1.0
    sigma_rot_deg: float = -1.0
    sigma_tilt_deg: float = -1.0
    sigma_psi_deg: float = -1.0
    offset_range_pixels: float = 5.0
    offset_step_pixels: float = 2.0
    oversampling: int = 1
    adaptive_fraction: float = .999
    perturbation_factor: float = .5
    random_seed: int = 1
    firstiter_cc: bool = False
    initial_high_resolution: float | None = None
    current_size: int | None = None
    strict_highres_angstrom: float | None = None
    skip_align: bool = False
    skip_rotate: bool = False
    use_ctf: bool = False
    ctf_corrected_ref: bool = False
    ctf_premultiplied: bool = False
    ctf_phase_flipped: bool = False
    only_flip_phases: bool = False
    intact_first_peak: bool = False
    do_norm_correction: bool = False
    do_scale_correction: bool = False
    particle_diameter_angstrom: float | None = None
    mask_edge_pixels: float = 5.0
    zero_mask: bool = False
    flatten_solvent: bool = False
    solvent_mask: Path | None = None
    tau2_fudge: float = 4.0
    padding_factor: float = 2.0
    preweight_iterations: int = 10
    minres_map: int = 5
    sigma_offset_angstrom: float = 10.0
    batch_size: int = 8
    pool_size: int | None = None
    preread_images: bool = False
    io_batch_size: int = 256
    max_open_stacks: int = 8
    particle_io: str = 'read'
    preread_max_gib: float | None = None
    orientation_chunk_size: int = 64
    coarse_score_chunk_size: int = 0  # auto; explicit positive values cap the global score tile
    backprojector_chunk_size: int = 32
    candidate_chunk_size: int = 1024
    candidate_work_mib: float = 512.0
    posterior_work_mib: float = 512.0
    sampling_work_mib: float = 256.0
    local_projection_mode: str = 'stream'
    local_projection_mib: float = 1024.0
    local_batch_max: int = 64
    local_fusion: str = "auto"
    local_coarse_mode: str = 'auto'
    local_projection_reuse: str = 'off'
    local_fine_inputs: str = 'auto'
    local_candidate_search: str = 'auto'
    local_fine_chunking: str = 'auto'
    local_statistics_inputs: str = 'auto'
    local_statistics_reduction: str = 'auto'
    local_gridding: str = 'auto'
    performance_cache_mib: float = 256.0
    global_window_mib: float = 2048.0
    global_fine_mode: str = 'auto'
    global_fine_statistics: str = 'auto'
    global_fine_mib: float = 512.0
    coarse_cache_policy: str = 'auto'
    coarse_host_cache_mib: float = 1024.0
    projector_cache_mib: float = 2048.0
    backprojector_cache_mib: float = 4096.0
    backprojector_host_gib: float = 16.0
    reference_max_gib: float = 4.0
    fine_score_mode: str = 'auto'
    dense_fine_execution: str = 'auto'
    weight_precision: str = 'float32'
    accumulation_precision: str = 'float32'
    preprocess_work_mib: float = 256.0
    preprocess_cache_mib: float = 32.0
    batch_preprocess: bool = True
    initialization_mode: str = 'batched'
    performance_mode: str = 'optimized'
    fast_subsets: bool = False
    skip_expected_accuracy: bool = False
    expected_accuracy_trials: int = 100
    timing: bool = False
    progress: bool = True
    timing_detail_samples: int = 32
    write_debug: bool = False
    sirm: bool = False
    sirm_threshold: float = .3
    sirm_histogram: float = 0.
    sirm_iterations: int = 30
    sirm_mask: Path | None = None
    write_unfil_map: bool = False
    skip_gridding: bool = False
    symmetry_backend: str = "auto"
    reconstruction_backend: str = "auto"
    global_fusion: str = "auto"
    global_gridding: str = "auto"

    @property
    def angular_sigmas(self):
        from relion_torch.sampling.local import resolve_angular_sigmas
        return resolve_angular_sigmas(self.sigma_ang_deg, self.sigma_rot_deg, self.sigma_tilt_deg, self.sigma_psi_deg)

    @property
    def local_angular_search(self):
        return any(x > 0 for x in self.angular_sigmas)
