"""Conservative opportunistic CUDA cache budgets, never a scientific setting."""
from __future__ import annotations
import torch


def available_cache_bytes(device) -> int:
    device = torch.device(device)
    if device.type != 'cuda':
        return 0
    free, total = torch.cuda.mem_get_info(device)
    reusable = max(0, torch.cuda.memory_reserved(device)-torch.cuda.memory_allocated(device))
    # Leave room for projection/objective temporaries and other CUDA clients.
    # Allocation can still race with another process; callers also catch OOM.
    reserve = max(512*1024**2, int(total*.10))
    return max(0, int(free)+reusable-reserve)
