from __future__ import annotations
from pathlib import Path
from collections import OrderedDict
import numpy as np
import pandas as pd
import torch
import warnings
from relion_torch.ctf_refine.cuda_memory import available_cache_bytes

from relion_torch.io.star import read_star, write_star
from relion_torch.io.particles import parse_image_reference, owned_array
from relion_torch.io.mrc import read_mrc, mrc_pixel_size
from relion_torch.io.mrc_stack import MRCStackCache
from relion_torch.fourier.conventions import centered_rfft, fourier_shift_2d, padded_size
from relion_torch.fourier.projector import FourierProjector
from relion_torch.geometry.euler import relion_euler_matrix
from relion_torch.optics.observation import ObservationModel
from relion_torch.ctf_refine.timing import NULL_TIMER, timed_method


class RefinementData:
    def __init__(self, path, *, device, dtype, max_open_stacks=8, timing=None):
        self.timer = timing or NULL_TIMER
        self.path = Path(path).resolve()
        self.blocks = read_star(self.path, exact_floats=True)
        if 'particles' not in self.blocks or 'optics' not in self.blocks:
            raise ValueError('CTF refinement requires a RELION 3.1 STAR with data_optics and data_particles')
        self.particles = self.blocks['particles'].copy().reset_index(drop=True)
        self.optics = self.blocks['optics'].copy().reset_index(drop=True)
        self.device, self.dtype = torch.device(device), dtype
        if self.particles.empty:
            raise ValueError('No input particles')
        required = ['rlnImageName', 'rlnOpticsGroup', 'rlnRandomSubset', 'rlnAngleRot',
                    'rlnAngleTilt', 'rlnAnglePsi', 'rlnOriginXAngst', 'rlnOriginYAngst',
                    'rlnDefocusU', 'rlnDefocusV', 'rlnDefocusAngle']
        missing = [x for x in required if x not in self.particles]
        if missing:
            raise ValueError('Missing required particle columns: '+', '.join(missing))
        for name in required[1:]:
            value = pd.to_numeric(self.particles[name], errors='coerce').to_numpy(dtype=float)
            if not np.isfinite(value).all():
                raise ValueError(f'Missing or non-finite values in {name}')
        subset = np.asarray(self.particles.rlnRandomSubset, dtype=float)
        if not np.isin(subset, [1, 2]).all():
            raise ValueError('rlnRandomSubset must contain only the original half labels 1 or 2')
        optics_ids = np.asarray(self.particles.rlnOpticsGroup, dtype=float)
        if np.any(optics_ids != optics_ids.astype(int)):
            raise ValueError('Particle optics group IDs must be integers')
        self.references = [parse_image_reference(str(s), self.path.parent) for s in self.particles.rlnImageName]
        self.cache = MRCStackCache(max_open=max_open_stacks)
        self.refresh_model()
        if not set(optics_ids.astype(int)).issubset(self.model.groups):
            raise ValueError('Particles reference an unknown optics group')
        for group_id, group in self.model.groups.items():
            rows = self.particles[optics_ids == group_id]
            if len(rows):
                self.model.parameters(rows, group_id)
            if int(group.row.get('rlnCtfDataAreCtfPremultiplied', 0)):
                raise ValueError('CTF refinement currently requires non-CTF-premultiplied SPA particles')
        if 'rlnMicrographName' in self.particles:
            mg = self.particles.rlnMicrographName
            valid = mg.notna() & ~mg.astype(str).isin(['', '?', '.', 'None', 'nan'])
            if valid.any() and not valid.all():
                raise ValueError('rlnMicrographName is missing for only part of the input; provide complete names or remove the column')
            self.has_micrographs = bool(valid.all())
        else:
            self.has_micrographs = False
        self.initial_particles = self.particles.copy(deep=True)

    @timed_method('optics.refresh_model', cuda=True)
    def refresh_model(self):
        self.model = ObservationModel(self.optics, source_dir=self.path.parent,
                                      device=self.device, dtype=self.dtype)

    def chunks(self, indices, batch_size):
        # Keep only a single optics grid in each tensor; preserve logical row IDs.
        indices = np.asarray(indices, dtype=np.int64)
        ids = np.asarray(self.particles.iloc[indices].rlnOpticsGroup, dtype=int)
        for group_id in dict.fromkeys(ids.tolist()):
            selected = indices[ids == group_id]
            for start in range(0, len(selected), batch_size):
                yield group_id, selected[start:start+batch_size]

    def fitting_units(self, mode, batch_size):
        if 'm' in mode:
            if not self.has_micrographs:
                raise ValueError('Per-micrograph fitting requires rlnMicrographName')
            for name, rows in self.particles.groupby('rlnMicrographName', sort=False):
                yield str(name), rows.index.to_numpy(dtype=np.int64)
        else:
            for group_id, indices in self.chunks(np.arange(len(self.particles)), batch_size):
                yield f'optics{group_id}_rows{indices[0]}', indices

    def observed(self, indices, group_id):
        g = self.model.groups[int(group_id)]
        with self.timer.section('particles.read'):
            tensors = [self.cache.read_image(self.references[int(i)][1], self.references[int(i)][0],
                        device='cpu', dtype=self.dtype) for i in indices]
        self.timer.count('particle_images_read', len(indices))
        if any(t.shape != (g.box_size, g.box_size) for t in tensors):
            raise ValueError(f'Particle shape does not match optics group {group_id}')
        real = self.timer.call('particles.stack', torch.stack, tensors)
        real = self.timer.call('particles.h2d', real.to, self.device, cuda=True,
            nbytes=real.numel()*real.element_size() if self.device.type == 'cuda' else 0)
        with self.timer.section('particles.validate', cuda=True):
            if not torch.isfinite(real).all():
                raise ValueError('Non-finite input particle pixels')
        with self.timer.section('particles.metadata'):
            rows = self.particles.iloc[indices]
            origins = owned_array(rows[['rlnOriginXAngst', 'rlnOriginYAngst']].to_numpy(dtype=float))
        with self.timer.section('particles.origins_to_device', cuda=True):
            shifts = torch.as_tensor(origins, device=self.device, dtype=self.dtype)/g.pixel_size
        transformed = self.timer.call('particles.fft', centered_rfft, real, ndim=2, cuda=True)
        return self.timer.call('particles.shift', fourier_shift_2d, transformed, shifts, sign=-1., cuda=True)

    @timed_method('metadata.euler', cuda=True)
    def rotations(self, indices):
        angles = owned_array(self.particles.iloc[indices][['rlnAngleRot', 'rlnAngleTilt', 'rlnAnglePsi']].to_numpy(dtype=float))
        return relion_euler_matrix(*angles.T, device=self.device, dtype=self.dtype)

    @timed_method('output.star_write')
    def write(self, path):
        blocks = OrderedDict((k, v.copy()) for k, v in self.blocks.items())
        particles = self.particles.copy()
        particles['rlnImageName'] = [(f'{index}@' if index is not None else '')+p.as_posix()
                                    for index, p in self.references]
        optics = self.optics.copy()
        if 'rlnMtfFileName' in optics:
            for i, value in optics.rlnMtfFileName.items():
                if pd.notna(value) and str(value) not in ('None', 'none', '?', '.', ''):
                    optics.loc[i, 'rlnMtfFileName'] = parse_image_reference(str(value), self.path.parent)[1].as_posix()
        blocks['optics'], blocks['particles'] = optics, particles
        target = Path(path)
        temporary = target.with_name(target.name+'.tmp')
        write_star(blocks, temporary, precision=17, deterministic=True)
        temporary.replace(target)

    def close(self):
        self.cache.close()


class HalfReferences:
    def __init__(self, *, postprocess=None, half1=None, half2=None, mask=None,
                 reference_pixel=None, padding=2., device='cpu', dtype=torch.float32,
                 resident_halves=2, no_fsc_weight=False, timing=None, build_device="auto"):
        self.timer = timing or NULL_TIMER
        self.device, self.dtype = torch.device(device), dtype
        if resident_halves not in (1, 2):
            raise ValueError('resident_halves must be 1 or 2')
        if build_device not in ('auto', 'cpu', 'cuda'):
            raise ValueError('build_device must be auto, cpu or cuda')
        if build_device == 'cuda' and self.device.type != 'cuda':
            raise ValueError('CUDA reference building requires a CUDA execution device')
        self.build_device = build_device
        self.build_devices = []
        self.resident_halves = resident_halves
        self._resident = OrderedDict()
        self._weights = {}
        pp = read_star(postprocess, exact_floats=True) if postprocess else {}
        base = Path(postprocess).resolve().parent if postprocess else Path.cwd()
        general = pp.get('general')
        general = {} if general is None or general.empty else general.iloc[0]
        half1 = half1 or general.get('rlnUnfilteredMapHalf1')
        half2 = half2 or general.get('rlnUnfilteredMapHalf2')
        mask = mask or general.get('rlnMaskName')
        if not half1 or not half2:
            raise ValueError('Provide --f postprocess.star or both --m1 and --m2')
        self.paths = [parse_image_reference(str(p), base)[1] for p in (half1, half2)]
        if self.paths[0] == self.paths[1]:
            raise ValueError('Half-map 1 and half-map 2 must be separate input maps')
        self.pixel = float(reference_pixel or mrc_pixel_size(self.paths[0]) or 0)
        if self.pixel <= 0 or not np.isfinite(self.pixel):
            raise ValueError('Reference maps require a positive pixel size (--angpix_ref)')
        self.mask_path = None
        if mask is not None and str(mask) not in ('', 'None', 'nan', '?', '.'):
            self.mask_path = parse_image_reference(str(mask), base)[1]
        mask_tensor = self.timer.call('reference.read_maps', read_mrc, self.mask_path, dtype=dtype) if self.mask_path else None
        self._host_projectors = []
        for path in self.paths:
            volume = self.timer.call('reference.read_maps', read_mrc, path, dtype=dtype)
            if volume.ndim != 3 or len(set(volume.shape)) != 1 or volume.shape[0] % 2 or not torch.isfinite(volume).all():
                raise ValueError('Half maps must be finite, even-sized cubic volumes')
            if self._host_projectors and volume.shape[0] != self.size:
                raise ValueError('Half maps must have equal dimensions')
            self.size = volume.shape[0]
            if not reference_pixel:
                pixel = mrc_pixel_size(path)
                if pixel is not None and abs(pixel-self.pixel) > 1.e-5:
                    raise ValueError('Half maps have different pixel sizes')
            if mask_tensor is not None:
                if mask_tensor.shape != volume.shape or not torch.isfinite(mask_tensor).all():
                    raise ValueError('Reference mask shape/values are invalid')
                volume = volume*mask_tensor
            self._build_projector(volume, padding)
        if no_fsc_weight:
            self.fsc = np.ones(self.size//2+1)
        else:
            table = pp.get('fsc')
            if table is None or 'rlnFourierShellCorrelationCorrected' not in table:
                raise ValueError('Provide PostProcess corrected FSC with --f, or explicitly select --no_fsc_weight')
            if 'rlnSpectralIndex' not in table:
                raise ValueError('PostProcess FSC requires rlnSpectralIndex')
            index = np.asarray(table.rlnSpectralIndex, dtype=float)
            if not np.array_equal(index, np.arange(self.size//2+1)):
                raise ValueError('PostProcess FSC shell indices do not match the reference box')
            self.fsc = np.asarray(table.rlnFourierShellCorrelationCorrected, dtype=float)
            if not np.isfinite(self.fsc).all():
                raise ValueError('Non-finite reference FSC')
            self.fsc = np.where(self.fsc >= .143, self.fsc, 0.)

    def _build_projector(self, volume, padding):
        half = len(self._host_projectors)+1
        # Evict before constructing the next padded transform. Materialize host
        # backing only on eviction; two fitting resident halves need no roundtrip.
        while len(self._resident) >= self.resident_halves:
            self._evict_one()
        p = padded_size(volume.shape[0], padding)
        estimate = (6*p**3+4*volume.numel())*volume.element_size()
        use_cuda = (self.device.type == 'cuda' and self.build_device != 'cpu'
                    and (self.build_device == 'cuda' or estimate <= available_cache_bytes(self.device)))
        if use_cuda:
            try:
                self._build_cuda_projector(volume, padding, half)
                self.build_devices.append('cuda')
                return
            except torch.cuda.OutOfMemoryError:
                if self.build_device == 'cuda':
                    raise
                self.timer.count('reference_cuda_oom_fallbacks')
                warnings.warn('CUDA reference FFT exceeded available memory; building this half on CPU', RuntimeWarning)
                torch.cuda.empty_cache()
        self._host_projectors.append(self.timer.call('reference.cpu_fourier',
            FourierProjector.from_real, volume, padding_factor=padding))
        self.build_devices.append('cpu')

    def _build_cuda_projector(self, volume, padding, half):
        # Keep temporary CUDA allocations in this frame so OOM unwinds them
        # before the caller retries. Publish cache entries only after success.
        device_volume = self.timer.call('reference.volume_h2d', volume.to, self.device,
            cuda=True, nbytes=volume.numel()*volume.element_size())
        resident = self.timer.call('reference.cuda_fourier', FourierProjector.from_real,
            device_volume, padding_factor=padding, cuda=True)
        self._host_projectors.append(None)
        self._resident[half] = resident

    def _host_backing(self, half):
        host = self._host_projectors[half-1]
        if host is None:
            resident = self._resident[half]
            host_data = self.timer.call('reference.backing_d2h', resident.data.cpu, cuda=True,
                nbytes=resident.data.numel()*resident.data.element_size())
            host = FourierProjector(host_data, resident.original_size, resident.padded_size,
                resident.padding_factor, resident.reference_dim, resident.interpolation, resident.source_current_size)
            self._host_projectors[half-1] = host
        return host

    def _evict_one(self):
        half = next(iter(self._resident))
        self._host_backing(half)
        del self._resident[half]

    @property
    def host_projectors(self):
        """CPU backing, lazily materialized for compatibility with direct callers."""
        for half in (1, 2):
            self._host_backing(half)
        return self._host_projectors

    def projector(self, half):
        half = int(half)
        if half not in (1, 2):
            raise ValueError('Half must be 1 or 2')
        if half in self._resident:
            self.timer.count('reference_cache_hits')
            self._resident.move_to_end(half)
            return self._resident[half]
        while len(self._resident) >= self.resident_halves:
            self._evict_one()
        host = self._host_backing(half)
        self.timer.count('reference_cache_misses')
        device_data = self.timer.call('reference.h2d', host.data.to, self.device, cuda=True,
            nbytes=host.data.numel()*host.data.element_size() if self.device.type == 'cuda' else 0)
        resident = FourierProjector(device_data, host.original_size, host.padded_size,
            host.padding_factor, host.reference_dim, host.interpolation, host.source_current_size)
        self._resident[half] = resident
        return resident

    @timed_method('projection.total')
    def predict(self, data, indices, group_id, *, opposite=False, apply_odd=True, gradients=False):
        self.timer.count('projected_particles', len(indices))
        self.timer.count('projected_particles_with_gradients', len(indices) if gradients else 0)
        rows = data.particles.iloc[indices]
        halves = np.asarray(rows.rlnRandomSubset, dtype=int)
        chosen = 3-halves if opposite else halves
        group = data.model.groups[int(group_id)]
        shape = (len(indices), group.box_size, group.box_size//2+1)
        complex_dtype = torch.complex128 if data.dtype == torch.float64 else torch.complex64
        values = torch.empty(shape, device=data.device, dtype=complex_dtype)
        derivative = torch.empty((*shape, 2), device=data.device, dtype=complex_dtype) if gradients else None
        for half in (1, 2):
            sel = np.flatnonzero(chosen == half)
            if not len(sel):
                continue
            result = self.timer.call('projection.sample_and_optics', data.model.predict,
                self.projector(half), data.rotations(np.asarray(indices)[sel]),
                group_id, self.pixel, apply_odd=apply_odd, gradients=gradients, cuda=True)
            with self.timer.section('projection.scatter', cuda=True):
                sel_t = torch.as_tensor(sel, device=data.device)
                if gradients:
                    values[sel_t], derivative[sel_t] = result
                else:
                    values[sel_t] = result
        return (values, derivative) if gradients else values

    @timed_method('reference.fsc_weight', cuda=True)
    def weight(self, group, kmin, *, multiplicity=False, exclusion=None):
        key = (group.identifier, group.box_size, group.pixel_size, float(kmin), multiplicity, exclusion)
        if key in self._weights:
            self.timer.count('weight_cache_hits')
            return self._weights[key]
        self.timer.count('weight_cache_misses')
        n = group.box_size
        x = torch.arange(n//2+1, device=self.device, dtype=self.dtype)[None, :].expand(n, -1)
        ya = torch.arange(n, device=self.device, dtype=self.dtype)
        # Reproduce ReferenceMap::getHollowWeight, including its boundary convention.
        y = torch.where(ya <= n//2+1, ya, ya-n)[:, None].expand(-1, n//2+1)
        xa, ya = x/(n*group.pixel_size), y/(n*group.pixel_size)
        xr, yr = xa*(self.size*self.pixel), ya*(self.size*self.pixel)
        xi = torch.floor(xr+.5).long()
        yi = torch.where(yr >= 0, torch.floor(yr+.5), torch.floor(yr+self.size+.5)).long()
        signed_y = torch.where(yi > self.size//2, yi-self.size, yi)
        shell = torch.floor((xi.square()+signed_y.square()).to(self.dtype).sqrt()+.5).long().clamp(max=self.size//2)
        weight = torch.as_tensor(self.fsc, device=self.device, dtype=self.dtype)[shell]
        radius = (xa.square()+ya.square()).sqrt()
        valid = (xi < self.size//2+1) & (yi >= 0) & (yi < self.size)
        if kmin > 0:
            valid &= radius >= 1./kmin
        if exclusion is not None:
            low, high = exclusion
            resolution = radius.clamp_min(1.e-30).reciprocal()
            valid &= ~((resolution > low) & (resolution <= high))
        weight = torch.where(valid, weight, 0.)
        if multiplicity:
            weight = weight*torch.where(x == 0, 1., 2.)
        self._weights[key] = weight
        return weight
