"""CTF refinement workflow, stage checkpoints and scientific diagnostics."""
from __future__ import annotations
from pathlib import Path
import hashlib
import html
import json
import sys
import time
import numpy as np
import torch

from relion_torch.io.mrc import write_mrc
from relion_torch.ctf_refine.data import RefinementData, HalfReferences
from relion_torch.ctf_refine.parameters import expanded_modes, refine_parameters
from relion_torch.ctf_refine.global_fit import (accumulate_global, fit_odd, fit_even,
    fit_magnification, adapt_astigmatism, update_optics)
from relion_torch.version import __version__
from relion_torch.ctf_refine.timing import CtfTimer


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()


def save_diagnostics(root, group_id, arrays):
    directory = root/'diagnostics'
    directory.mkdir(exist_ok=True)
    paths = {}
    for name, value in arrays.items():
        filename = f'optics_{group_id}_{name}.mrc'
        write_mrc(directory/filename, value)
        paths[name] = 'diagnostics/'+filename
    return paths


def assert_missing_micrograph_contract(data, initial):
    if data.has_micrographs:
        return
    current = data.particles
    for label in ('rlnDefocusAngle', 'rlnPhaseShift', 'rlnCtfBfactor', 'rlnCtfScalefactor', 'rlnSphericalAberration'):
        if label in initial:
            if label not in current or not np.array_equal(initial[label].to_numpy(), current[label].to_numpy(), equal_nan=True):
                raise RuntimeError(f'No-micrograph preservation contract violated: {label}')
        elif label in current:
            raise RuntimeError(f'No-micrograph preservation contract violated: added {label}')
    before = np.asarray(initial.rlnDefocusU, dtype=float)-np.asarray(initial.rlnDefocusV, dtype=float)
    after = np.asarray(current.rlnDefocusU, dtype=float)-np.asarray(current.rlnDefocusV, dtype=float)
    if not np.allclose(before, after, rtol=0., atol=1.e-8):
        raise RuntimeError('No-micrograph preservation contract violated: astigmatism amplitude')


def render_report(path, report, particles, initial):
    rows = []
    for stage in report['stages']:
        rows.append('<tr><td>'+html.escape(stage['name'])+'</td><td>'+str(stage.get('seconds', ''))+'</td></tr>')
    delta = .5*(np.asarray(particles.rlnDefocusU, dtype=float)+np.asarray(particles.rlnDefocusV, dtype=float)
                 -np.asarray(initial.rlnDefocusU, dtype=float)-np.asarray(initial.rlnDefocusV, dtype=float))
    counts, edges = np.histogram(delta, bins=40)
    peak = max(1, int(counts.max()))
    bars = ''.join(f'<rect x="{20+i*12}" y="{160-140*c/peak:.2f}" width="10" height="{140*c/peak:.2f}" fill="#237b9e"/>'
                   for i, c in enumerate(counts))
    links = []
    for stage in report['stages']:
        for group_id, group in stage.get('optics_groups', {}).items():
            for name, relative in group.get('diagnostics', {}).items():
                links.append(f'<li>Optics {html.escape(str(group_id))}: <a href="{html.escape(relative)}">{html.escape(name)}</a></li>')
    warnings = ''.join('<li>'+html.escape(x)+'</li>' for x in report.get('notes', []))
    text = f'''<!doctype html><meta charset="utf-8"><title>CTF refinement</title>
<style>body{{font:16px system-ui;max-width:980px;margin:40px auto;padding:0 24px;color:#163042}}td,th{{padding:8px 24px;border-bottom:1px solid #ddd}}code{{background:#edf4f7}}svg{{max-width:100%}}</style>
<h1>RELION PyTorch CTF refinement</h1><p>{report['particles']} particles; {report['optics_groups']} optics groups. Device: {html.escape(report['device'])}.</p>
<p>Output: <a href="particles_ctf_refine.star">particles_ctf_refine.star</a> · <a href="ctf_refine_report.json">Full numerical report</a></p>
<p>Half references: own half for particle CTF fitting; opposite half for optical aberrations and magnification. Original half labels and poses are preserved.</p>
<table><tr><th>Stage</th><th>Seconds</th></tr>{''.join(rows)}</table>
<h2>Mean defocus change (Å)</h2><svg viewBox="0 0 540 200" role="img" aria-label="Defocus change histogram">{bars}<text x="20" y="185">{edges[0]:.3g}</text><text x="455" y="185">{edges[-1]:.3g}</text></svg>
<p>Median: {np.median(delta):.5g} Å; RMS: {np.sqrt(np.mean(delta*delta)):.5g} Å.</p>
<h2>Run notes</h2><ul>{warnings}</ul><h2>Fourier diagnostics</h2><p>MRC arrays use unshifted RFFT coordinates (y, non-negative x).</p><ul>{''.join(links)}</ul>
<p>A lower fitting loss is not a replacement for validation by subsequent refinement and postprocessing.</p>'''
    Path(path).write_text(text, encoding='utf-8')


def run(args):
    started = time.perf_counter()
    output = Path(args.o).resolve()
    output.mkdir(parents=True, exist_ok=True)
    checkpoint = output/'ctf_refine_state.json'
    if (checkpoint.exists() or (output/'particles_ctf_refine.star').exists()) and not args.only_do_unfinished:
        raise ValueError('Output already contains a refinement. Use a new directory or --only_do_unfinished')
    device = args.device
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if str(device).startswith('cuda') and not torch.cuda.is_available():
        raise ValueError('CUDA was requested but this PyTorch installation has no available CUDA device')
    dtype = torch.float64 if args.dtype == 'float64' else torch.float32
    torch.set_num_threads(args.j)
    log_path = output/'ctf_refine.log'
    def progress(message):
        with log_path.open('a', encoding='utf-8') as handle:
            handle.write(message+'\n')
        if args.verb:
            print(message, flush=True)
    timer = CtfTimer(getattr(args, 'timing', False), device, output=output,
        samples=getattr(args, 'timing_samples', 32), progress=progress,
        metadata=dict(version=__version__, torch_version=str(torch.__version__),
            projection_dtype=args.dtype, fitting_dtype='float64', batch_size=args.batch_size,
            projection_batch=args.projection_batch, cpu_threads=args.j,
            fit_cache_mib=args.fit_cache_mib))
    data = None
    status = 'error'
    try:
        if timer.enabled:
            if torch.device(device).type == 'cuda':
                timer.metadata['gpu_name'] = torch.cuda.get_device_name(device)
            progress(f'Timing enabled: all-call wall times, first {timer.samples} CUDA samples per section per interval; see ctf_refine_timing.txt/json and ctf_refine_timing_batches.jsonl.')
        data = timer.call('startup.metadata', RefinementData, args.i, device=device,
                          dtype=dtype, max_open_stacks=args.max_open_stacks, timing=timer)
        original = data.initial_particles.copy(deep=True)
        mode = args.fit_mode or ('fpmfm' if data.has_micrographs else 'fpfff')
        expanded_modes(mode)
        do_ctf = args.fit_defocus or args.fit_mode is not None or args.bf0 or args.bf_only
        if not data.has_micrographs:
            if do_ctf and mode not in ('fpfff', 'fffff'):
                raise ValueError('Without rlnMicrographName, only --fit_mode fpfff (per-particle defocus) or fffff is allowed')
            if args.fit_bfacs:
                raise ValueError('Without rlnMicrographName, B-factor and CTF scale must remain fixed')
            progress('No micrograph names: preserve astigmatism, phase, B/scale and Cs; no magnification-induced CTF conversion.')
        if (args.bf0 or args.bf_only) and mode[1] != 'p':
            raise ValueError('Brute-force initial defocus scanning requires per-particle defocus fitting')
        stages = []
        if args.fit_aniso:
            stages.append('magnification')
        if do_ctf and mode != 'fffff':
            stages.append('ctf_parameters')
        if args.fit_bfacs:
            stages.append('bfactor_scale')
        if args.fit_beamtilt or args.fit_aberr or args.trefoil:
            stages.append('aberrations')
        if not stages:
            raise ValueError('Select at least one fit: --fit_defocus, --fit_aniso, --fit_beamtilt, --trefoil, --fit_aberr, or --fit_bfacs')
        reference = timer.call('startup.references', HalfReferences, postprocess=args.f, half1=args.m1, half2=args.m2, mask=args.mask,
            reference_pixel=args.angpix_ref, padding=args.pad, device=device, dtype=dtype,
            resident_halves=args.resident_halves, no_fsc_weight=args.no_fsc_weight, timing=timer,
            build_device=getattr(args, "reference_build_device", "auto"))
        excluded = {'o', 'only_do_unfinished', 'device', 'j', 'batch_size', 'projection_batch', 'resident_halves', 'verb', 'debug', 'max_open_stacks', 'fit_cache_mib', 'fit_gpu_cache_mib', 'reference_build_device', 'timing', 'timing_samples'}
        scientific_options = {k: v for k, v in vars(args).items() if k not in excluded}
        files = set(reference.paths+[p for _, p in data.references])
        if reference.mask_path:
            files.add(reference.mask_path)
        for group in data.model.groups.values():
            mtf = group.row.get('rlnMtfFileName')
            if mtf is not None and str(mtf) not in ('None', 'none', 'nan', '?', '.', ''):
                from relion_torch.io.particles import parse_image_reference
                files.add(parse_image_reference(str(mtf), data.path.parent)[1])
        # Scientific checkpoint schema is unchanged: completed 0.4.0 stages
        # can be resumed. The executable version is recorded separately below.
        provenance = dict(version='0.4.0', options=scientific_options, input_star_sha256=sha256(args.i),
            postprocess_sha256=sha256(args.f) if args.f else None,
            files=[dict(path=str(p), size=p.stat().st_size, mtime_ns=p.stat().st_mtime_ns) for p in sorted(files, key=str)])
        signature = hashlib.sha256(json.dumps(provenance, sort_keys=True).encode()).hexdigest()
        notes = ['Fixed-pose refinement; references are not reconstructed inside this command.',
                 'Magnification is fitted in a separate first stage when combined with other fits.',
                 'B/scale fitting uses the modular weighted least-squares objective with L-BFGS (not the legacy radial scan).',
                 'Statistics/parameter fitting use float64; projection precision is selected by --dtype.']
        if not data.has_micrographs:
            notes += ['No micrograph names: input astigmatism, phase shift, B-factor, scale and standalone Cs are preserved, including during magnification fitting.',
                      'Even-aberration fitting includes global n=0,2,... terms, as in RELION; fixed STAR CTF fields do not freeze these global aberrations.']
        if args.no_fsc_weight:
            notes.append('FSC weighting explicitly disabled by --no_fsc_weight.')
        report = dict(version=__version__, particles=len(data.particles), optics_groups=len(data.model.groups),
            device=str(device), projection_dtype=args.dtype, has_micrographs=data.has_micrographs,
            fit_mode=mode if do_ctf else 'fffff', stages=[], notes=notes, provenance=provenance)
        completed = []
        if checkpoint.exists():
            saved = json.loads(checkpoint.read_text(encoding='utf-8'))
            if saved['signature'] != signature:
                raise ValueError('Resume inputs or scientific options differ from the checkpoint')
            stage_path = output/saved['particle_star']
            if sha256(stage_path) != saved['star_sha256']:
                raise ValueError('Checkpoint STAR content has changed')
            data.close()
            data = timer.call('startup.resume_metadata', RefinementData, stage_path, device=device,
                              dtype=dtype, max_open_stacks=args.max_open_stacks, timing=timer)
            completed, report = saved['completed'], saved['report']
            report['device'] = str(device)
            report['version'] = __version__
            progress('Resuming completed stages: '+', '.join(completed))
        report['reference_build_devices'] = reference.build_devices
        report['fit_gpu_cache_mib'] = getattr(args, 'fit_gpu_cache_mib', 512.)
        report.pop('timing_files', None)
        if timer.enabled:
            report['timing_files'] = ['ctf_refine_timing.json', 'ctf_refine_timing.txt', 'ctf_refine_timing_batches.jsonl']
        timer.metadata.update(particles=len(data.particles), optics_groups=len(data.model.groups),
            resumed_completed_stages=list(completed), requested_stages=stages,
            optics_grids=[dict(group=int(key), box=int(group.box_size), pixel_size=float(group.pixel_size))
                          for key, group in data.model.groups.items()])
        timer.checkpoint('startup', fields={'resumed_completed_stages': list(completed)})
        for name in stages:
            if name in completed:
                continue
            progress('Starting '+name)
            begin_stage = time.perf_counter()
            result = {'name': name}
            if name in ('ctf_parameters', 'bfactor_scale'):
                fitting_mode = mode if name == 'ctf_parameters' else ('ffffm' if args.bfac_per_mg else 'ffffp')
                limit = args.kmin_bfac if name == 'bfactor_scale' else args.kmin_defocus
                progress(f'CTF fit_mode={fitting_mode}; minimum fitting resolution={limit:g} Angstrom (0 disables low-frequency exclusion); batch_size={args.batch_size}, projection_batch={args.projection_batch}, host statistics cache={args.fit_cache_mib:g} MiB per unit')
                result['fits'] = refine_parameters(data, reference, fitting_mode,
                    batch_size=args.batch_size, prediction_batch=args.projection_batch,
                    max_iter=0 if args.bf_only and name == 'ctf_parameters' else args.max_defocus_iters,
                    tolerance=args.tolerance, kmin=args.kmin_bfac if name == 'bfactor_scale' else args.kmin_defocus,
                    progress=progress, brute_force_range=args.bf_range if (args.bf0 or args.bf_only) and name == 'ctf_parameters' else None,
                    brute_force_step=args.bf_step, cache_mib=args.fit_cache_mib, cache_directory=output,
                    gpu_cache_mib=getattr(args, "fit_gpu_cache_mib", 512.))
                statuses = [flag for fit in result['fits'] for flag in np.atleast_1d(fit['converged']).tolist()]
                result['convergence'] = dict(total=len(statuses), converged=sum(statuses), unconverged=statuses.count(False))
                if result['convergence']['unconverged']:
                    message = f"{name}: {statuses.count(False)}/{len(statuses)} fits did not meet the gradient tolerance; best finite results retained."
                    report['notes'].append(message)
                    progress(message)
            else:
                is_mag = name == 'magnification'
                do_odd = not is_mag and (args.fit_beamtilt or args.trefoil)
                do_even = not is_mag and args.fit_aberr
                accumulators = accumulate_global(data, reference, odd=do_odd, even=do_even,
                    magnification=is_mag, batch_size=args.projection_batch, progress=progress)
                result['optics_groups'] = {}
                for group_id, stats in accumulators.items():
                    group = data.model.groups[group_id]
                    group_result = {'diagnostics': {}}
                    if is_mag:
                        update, info, arrays = timer.call('optics.fit_magnification', fit_magnification,
                            group, stats, reference.weight(group, args.kmin_mag), cuda=True)
                        update_optics(data, group_id, update)
                        if data.has_micrographs and not args.keep_astig:
                            adapt_astigmatism(data, group_id, info['delta_matrix'], per_particle=args.part_astig)
                        group_result['magnification'] = info
                        group_result['diagnostics'].update(timer.call('output.diagnostics', save_diagnostics, output, group_id, arrays))
                    if do_odd:
                        degree = max(3, args.odd_aberr_max_n) if args.trefoil else args.odd_aberr_max_n
                        update, info, arrays = timer.call('optics.fit_odd', fit_odd, group, stats,
                            reference.weight(group, args.kmin_tilt, exclusion=(args.xr0_t, args.xr1_t) if args.xr1_t > 0 else None),
                            max_degree=degree, max_iter=args.max_aberration_iters, tolerance=args.tolerance, cuda=True)
                        update_optics(data, group_id, update)
                        group_result['odd'] = info
                        if not info['converged']:
                            message = f'Optics group {group_id}: odd-aberration fit did not meet the gradient tolerance.'
                            report['notes'].append(message)
                            progress(message)
                        group_result['diagnostics'].update(timer.call('output.diagnostics', save_diagnostics, output, group_id, arrays))
                    if do_even:
                        update, info, arrays = timer.call('optics.fit_even', fit_even, group, stats,
                            reference.weight(group, args.kmin_aberr, exclusion=(args.xr0_a, args.xr1_a) if args.xr1_a > 0 else None),
                            max_degree=args.even_aberr_max_n, max_iter=args.max_aberration_iters, tolerance=args.tolerance, cuda=True)
                        update_optics(data, group_id, update)
                        group_result['even'] = info
                        if not info['converged']:
                            message = f'Optics group {group_id}: even-aberration fit did not meet the gradient tolerance.'
                            report['notes'].append(message)
                            progress(message)
                        group_result['diagnostics'].update(timer.call('output.diagnostics', save_diagnostics, output, group_id, arrays))
                    result['optics_groups'][str(group_id)] = group_result
                    timer.checkpoint('optics_fit', fields={'stage': name, 'optics_group': int(group_id)})
            data.refresh_model()
            assert_missing_micrograph_contract(data, original)
            result['seconds'] = time.perf_counter()-begin_stage
            report['stages'].append(result)
            completed.append(name)
            stage_filename = f'stage_{len(completed):02d}_{name}.star'
            data.write(output/stage_filename)
            with timer.section('output.checkpoint'):
                atomic_json(checkpoint, dict(signature=signature, completed=completed, report=report,
                    particle_star=stage_filename, star_sha256=sha256(output/stage_filename)))
            timer.checkpoint('stage', fields={'stage': name, 'stage_wall_seconds': result['seconds']})
        assert_missing_micrograph_contract(data, original)
        data.write(output/'particles_ctf_refine.star')
        report['seconds_this_invocation'] = time.perf_counter()-started
        report['output_star'] = str(output/'particles_ctf_refine.star')
        timer.call('output.reports', atomic_json, output/'ctf_refine_report.json', report)
        timer.call('output.reports', render_report, output/'ctf_refine_report.html', report, data.particles, original)
        progress('Written '+str(output/'particles_ctf_refine.star'))
        status = 'complete'
        return report
    finally:
        error = sys.exc_info()[1]
        if data is not None:
            data.close()
        try:
            timer.finish('interrupted' if isinstance(error, KeyboardInterrupt) else status, error=error)
        except Exception as timing_error:
            if error is None:
                raise
            # Never obscure the original fitting failure with a reporting error.
            print(f'Could not finalize timing report: {timing_error}', file=sys.stderr)
