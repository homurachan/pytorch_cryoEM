"""Optional CTF profiling with all-call host timing and bounded CUDA samples.

Reuses the existing shared DetailTimer event backend. Samples are collected at
completed fit-unit boundaries, never by synchronizing each objective or kernel.
"""
from collections import defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
import json
import time
import uuid
import torch

from relion_torch.class2d.performance import DetailTimer


def _entry():
    return dict(calls=0, wall_inclusive_seconds=0., wall_self_seconds=0.,
                bytes=0, cuda_observed_calls=0, cuda_sampled_calls=0,
                cuda_sampled_host_seconds=0., cuda_sampled_stream_seconds=0.)


class CtfTimer:
    def __init__(self, enabled=False, device='cpu', *, output=None, samples=32,
                 progress=print, metadata=None):
        self.enabled, self.device = bool(enabled), torch.device(device)
        self.samples, self.progress = int(samples), progress
        if self.samples < 0:
            raise ValueError('Timing sample count must be nonnegative')
        self.output = Path(output) if output is not None else None
        self.total, self.interval = defaultdict(_entry), defaultdict(_entry)
        self.counters, self.interval_counters = defaultdict(int), defaultdict(int)
        self.stack = []
        self.completed_records, self.completed_fit_units = 0, 0
        self.collection_seconds, self.reporting_seconds = 0., 0.
        self.run_id = uuid.uuid4().hex if self.enabled else None
        self.metadata = dict(metadata or {})
        self.started_utc = datetime.now(timezone.utc).isoformat() if self.enabled else None
        self.started = self.interval_started = time.perf_counter() if self.enabled else 0.
        self.detail = self._new_detail()

    def _new_detail(self):
        return DetailTimer(self.enabled and self.device.type == 'cuda', self.device, self.samples)

    @contextmanager
    def section(self, name, *, cuda=False, nbytes=0):
        if not self.enabled:
            yield
            return
        start = time.perf_counter()
        frame = [name, 0.]
        self.stack.append(frame)
        token = None
        try:
            token = self.detail.start(name) if cuda else None
            yield
        finally:
            try:
                self.detail.stop(token)
            finally:
                elapsed = time.perf_counter()-start
                assert self.stack.pop() is frame
                own = max(0., elapsed-frame[1])
                if self.stack:
                    self.stack[-1][1] += elapsed
                for table in (self.total, self.interval):
                    row = table[name]
                    row['calls'] += 1
                    row['wall_inclusive_seconds'] += elapsed
                    row['wall_self_seconds'] += own
                    row['bytes'] += int(nbytes)

    def call(self, name, function, *args, cuda=False, nbytes=0, **kwargs):
        with self.section(name, cuda=cuda, nbytes=nbytes):
            return function(*args, **kwargs)

    def count(self, name, value=1):
        if self.enabled:
            self.counters[name] += int(value)
            self.interval_counters[name] += int(value)

    def _collect(self):
        start = time.perf_counter()
        details = self.detail.report()  # at most one device sync per boundary
        for name, sample in details.items():
            for table in (self.total, self.interval):
                row = table[name]
                row['cuda_observed_calls'] += sample['observed_calls']
                row['cuda_sampled_calls'] += sample['sampled_calls']
                row['cuda_sampled_host_seconds'] += sample['sampled_host_seconds']
                row['cuda_sampled_stream_seconds'] += sample['sampled_cuda_stream_seconds'] or 0.
        self.detail = self._new_detail()  # release event objects after each unit
        self.collection_seconds += time.perf_counter()-start

    def _sections(self, table):
        result = {}
        for name, values in sorted(table.items()):
            row = dict(values)
            row['mean_wall_ms'] = 1000*row['wall_inclusive_seconds']/max(1, row['calls'])
            count = row['cuda_sampled_calls']
            row['mean_sampled_cuda_ms'] = 1000*row['cuda_sampled_stream_seconds']/count if count else None
            if not count:
                row['cuda_sampled_stream_seconds'] = None
            result[name] = row
        return result

    def snapshot(self, status='running'):
        wall = time.perf_counter()-self.started
        measured = sum(row['wall_self_seconds'] for row in self.total.values())
        return dict(timing_schema_version=1, run_id=self.run_id, status=status,
            started_utc=self.started_utc, device=str(self.device), metadata=self.metadata,
            completed_fit_units=self.completed_fit_units, completed_records=self.completed_records,
            wall_seconds=wall, measured_self_wall_seconds=measured,
            unattributed_wall_seconds=max(0., wall-measured),
            timing_collection_seconds=self.collection_seconds, timing_reporting_seconds=self.reporting_seconds,
            cuda_samples_per_section_per_interval=self.samples,
            semantics=[
                'Wall measurements cover every instrumented call and include host work, launch overhead and waits.',
                'wall_self_seconds subtracts nested sections; inclusive sections overlap and must not be summed.',
                'CUDA stream intervals sample the first N calls of each CUDA-labelled section per interval; do not extrapolate or add to wall time.',
                'CUDA stream intervals can include launch/idle gaps; they are not kernel-only busy time, utilization or power.',
                'Detail CUDA synchronization occurs only at completed-unit/stage/report boundaries, never per objective.',
                'Bytes are logical tensor payload for transfers and array payload for disk I/O, not measured hardware traffic.',
                'Unattributed wall includes uninstrumented code, logging and profiling overhead; it is not GPU idle time.',
                'All timings describe this invocation only; resumed/skipped stages are not re-timed.'],
            sections=self._sections(self.total), counters=dict(self.counters))

    def _write_summary(self, status):
        if self.output is None:
            return
        report = self.snapshot(status)
        path = self.output/'ctf_refine_timing.json'
        temporary = path.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n', encoding='utf-8')
        temporary.replace(path)
        lines = [f"CTF timing: {status}; run {self.run_id}",
                 f"Wall: {report['wall_seconds']:.3f} s; completed fit units: {self.completed_fit_units}",
                 'Seconds below are HOST/WALL SELF (exclusive); CUDA samples are separate stream intervals.',
                 'Section                                       calls    self(s)  incl(s) CUDA mean(ms) samples/observed  MiB']
        for name, row in sorted(report['sections'].items(), key=lambda pair: -pair[1]['wall_self_seconds']):
            average = '-' if row['mean_sampled_cuda_ms'] is None else f"{row['mean_sampled_cuda_ms']:.4f}"
            lines.append(f"{name:44} {row['calls']:7d} {row['wall_self_seconds']:9.3f} {row['wall_inclusive_seconds']:8.3f} {average:>13} {row['cuda_sampled_calls']:6d}/{row['cuda_observed_calls']:<8d} {row['bytes']/1024**2:9.2f}")
        lines += ['', f"Unattributed wall: {report['unattributed_wall_seconds']:.3f} s",
                  f"Timing collection/reporting: {self.collection_seconds:.3f}/{self.reporting_seconds:.3f} s",
                  '', *report['semantics'], '', 'Counters:', json.dumps(report['counters'], indent=2)]
        text_path = self.output/'ctf_refine_timing.txt'
        text_tmp = text_path.with_suffix('.txt.tmp')
        text_tmp.write_text('\n'.join(lines)+'\n', encoding='utf-8')
        text_tmp.replace(text_path)

    def checkpoint(self, kind, *, fields=None, status='running'):
        if not self.enabled:
            return
        if self.stack:
            raise RuntimeError('Timing checkpoints must be outside timed sections')
        self._collect()
        now = time.perf_counter()
        self.completed_records += 1
        if kind == 'fit_unit':
            self.completed_fit_units += 1
        record = dict(run_id=self.run_id, record=self.completed_records, kind=kind, status=status,
                      interval_wall_seconds=now-self.interval_started,
                      sections=self._sections(self.interval), counters=dict(self.interval_counters),
                      fields=fields or {})
        report_start = time.perf_counter()
        if self.output is not None:
            self.output.mkdir(parents=True, exist_ok=True)
            with (self.output/'ctf_refine_timing_batches.jsonl').open('a', encoding='utf-8') as handle:
                handle.write(json.dumps(record, allow_nan=False)+'\n')
        if kind != 'fit_unit' or self.completed_fit_units == 1 or self.completed_fit_units % 10 == 0:
            self._write_summary(status)
            top = sorted(self.interval.items(), key=lambda pair: -pair[1]['wall_self_seconds'])[:4]
            self.progress('[timing] '+kind+': '+', '.join(f'{name} self={row["wall_self_seconds"]:.3f}s' for name, row in top))
        self.reporting_seconds += time.perf_counter()-report_start
        self.interval.clear()
        self.interval_counters.clear()
        self.interval_started = time.perf_counter()

    def finish(self, status='complete', *, error=None):
        if self.enabled:
            if error is not None:
                self.metadata['error_type'] = type(error).__name__
            self.checkpoint('finish', fields={'error': str(error) if error else None}, status=status)


NULL_TIMER = CtfTimer()


def timed_method(name, *, cuda=False):
    def decorate(function):
        @wraps(function)
        def wrapped(self, *args, **kwargs):
            with getattr(self, 'timer', NULL_TIMER).section(name, cuda=cuda):
                return function(self, *args, **kwargs)
        return wrapped
    return decorate
