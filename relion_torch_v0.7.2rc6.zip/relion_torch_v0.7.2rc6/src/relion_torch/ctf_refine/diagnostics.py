"""Lightweight, dependency-free memory snapshots; no CUDA cache flushing."""
from pathlib import Path
import os
import torch


def memory_snapshot(device):
    result = {}
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):
                result['host_rss_mib'] = int(line.split()[1])/1024.
                break
    except OSError:
        if os.name == 'nt':
            try:
                import ctypes
                from ctypes import wintypes
                class Counters(ctypes.Structure):
                    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)]+[
                        (name, ctypes.c_size_t) for name in ('PeakWorkingSetSize', 'WorkingSetSize',
                        'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
                        'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage')]
                counters = Counters()
                counters.cb = ctypes.sizeof(counters)
                handle = ctypes.windll.kernel32.GetCurrentProcess
                handle.restype = wintypes.HANDLE
                read = ctypes.windll.psapi.GetProcessMemoryInfo
                read.argtypes = (wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD)
                if read(handle(), ctypes.byref(counters), counters.cb):
                    result['host_rss_mib'] = counters.WorkingSetSize/1024**2
            except (AttributeError, OSError):
                pass
    device = torch.device(device)
    if device.type == 'cuda' and torch.cuda.is_available():
        result['cuda_allocated_mib'] = torch.cuda.memory_allocated(device)/1024**2
        result['cuda_reserved_mib'] = torch.cuda.memory_reserved(device)/1024**2
        stats = torch.cuda.memory_stats(device)
        result['cuda_allocation_retries'] = stats.get('num_alloc_retries', 0)
    return result


def describe_memory(snapshot):
    names = [('host_rss_mib', 'host RSS'), ('cuda_allocated_mib', 'CUDA allocated'),
             ('cuda_reserved_mib', 'CUDA reserved')]
    parts = [f'{label}={snapshot[key]:.1f} MiB' for key, label in names if key in snapshot]
    if 'cuda_allocation_retries' in snapshot:
        parts.append(f"CUDA allocation retries={snapshot['cuda_allocation_retries']}")
    return '; '.join(parts)
