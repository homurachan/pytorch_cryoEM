"""Streaming optics-group sufficient statistics and parametric fits.

Equations follow RELION 3.1.4 tilt_estimator/helper, aberration_estimator and
magnification_estimator/helper (Jasenko Zivanov et al., GPL-2.0-or-later).
Only PyTorch/NumPy are used, including the small nonlinear optimisations.
"""
from __future__ import annotations
import math
import numpy as np
import torch

from relion_torch.optics.ctf import electron_wavelength_angstrom
from relion_torch.optics.zernike import basis, indices as zernike_indices, extract_tilt, format_coefficients
from relion_torch.optimiser.numerical import lbfgs
from relion_torch.ctf_refine.timing import NULL_TIMER


def accumulate_global(data, references, *, odd=False, even=False, magnification=False,
                      batch_size=8, progress=print):
    timer = getattr(data, 'timer', NULL_TIMER)
    accumulators = {}
    count = 0
    chunks = 0
    def process_chunk(group_id, selected):
        rows = data.particles.iloc[selected]
        obs = data.observed(selected, group_id).to(torch.complex128)
        ctf = timer.call('optics.ctf', data.model.ctf, rows, group_id, cuda=True).to(torch.float64)
        stats = accumulators.setdefault(group_id, {})
        def add(name, value):
            with timer.section('optics.statistics_reduce', cuda=True):
                value = value.detach().sum(0)
            value = timer.call('optics.statistics_d2h', value.cpu, cuda=True,
                nbytes=value.numel()*value.element_size() if value.device.type == 'cuda' else 0)
            with timer.section('optics.statistics_host_add'):
                if name in stats:
                    stats[name] += value
                else:
                    stats[name] = value
        if odd:
            pred = references.predict(data, selected, group_id, opposite=True, apply_odd=False).to(torch.complex128)
            add('odd_xy', ctf*pred.conj()*obs)
            add('odd_w', ctf.square()*pred.abs().square())
        if even or magnification:
            prediction = references.predict(data, selected, group_id, opposite=True,
                                             apply_odd=True, gradients=magnification)
            if magnification:
                pred, gradient = prediction
                gradient = gradient.to(torch.complex128)
            else:
                pred = prediction
            pred = pred.to(torch.complex128)
            if even:
                # Native getGamma excludes the existing even-Zernike offset:
                # this estimates the absolute even coefficients, not an increment.
                gamma = timer.call('optics.ctf', data.model.ctf, rows, group_id,
                    include_even=False, return_gamma=True, cuda=True).to(torch.float64)
                si, co = torch.sin(gamma), torch.cos(gamma)
                power = pred.abs().square()
                cross = (obs*pred.conj()).real
                add('even_Axx', power*si*si)
                add('even_Axy', power*si*co)
                add('even_Ayy', power*co*co)
                add('even_bx', -cross*si)
                add('even_by', -cross*co)
            if magnification:
                gx, gy = gradient[..., 0], gradient[..., 1]
                residual = obs-ctf*pred
                add('mag_Axx', ctf.square()*gx.abs().square())
                add('mag_Axy', ctf.square()*(gx.conj()*gy).real)
                add('mag_Ayy', ctf.square()*gy.abs().square())
                add('mag_bx', ctf*(gx.conj()*residual).real)
                add('mag_by', ctf*(gy.conj()*residual).real)
    for group_id, selected in data.chunks(np.arange(len(data.particles)), batch_size):
        timer.call('optics.statistics_chunk', process_chunk, group_id, selected, cuda=True)
        chunks += 1
        count += len(selected)
        progress(f'Optics statistics: {count}/{len(data.particles)} particles')
        if chunks % 32 == 0 or count == len(data.particles):
            timer.checkpoint('optics_statistics', fields=dict(processed_particles=count,
                total_particles=len(data.particles), chunks=chunks, odd=odd, even=even,
                magnification=magnification))
    return accumulators


def linear_phase_initial(raw_basis, phase, weight):
    if not bool((weight > 0).any()):
        raise ValueError('No signal in the selected aberration fitting frequencies')
    total = weight.sum().clamp_min(1.e-30)
    norms = ((raw_basis.square()*weight).sum((-2, -1))/total).sqrt().clamp_min(1.e-20)
    scaled = raw_basis/norms[:, None, None]
    gram = torch.einsum('ihw,jhw,hw->ij', scaled, scaled, weight)/total
    # Physical frequencies occupy only part of the Zernike unit disk. Degree
    # 0/2/4 (and 1/3) terms can then be strongly correlated. Whiten the small
    # weighted Gram matrix instead of asking L-BFGS to undo that correlation.
    lower, status = torch.linalg.cholesky_ex((gram+gram.T)*.5)
    if int(status) != 0:
        raise ValueError('Insufficient independent frequencies for the requested aberration degree')
    identity = torch.eye(len(raw_basis), device=gram.device, dtype=gram.dtype)
    transform = torch.linalg.solve_triangular(lower.T, identity, upper=True)/norms[:, None]
    design = torch.einsum('ji,jhw->ihw', transform, raw_basis)
    solution = torch.einsum('ihw,hw,hw->i', design, phase, weight)/total
    return design, transform, solution


def fit_odd(group, stats, weight, *, max_degree=0, max_iter=150, tolerance=1.e-9):
    device = group.x.device
    cross = stats['odd_xy'].to(device)
    power = stats['odd_w'].to(device)
    weight = weight.to(torch.float64)
    degree = max(3, max_degree)
    raw = basis(group.x.to(torch.float64), group.y.to(torch.float64), 'odd', degree)
    active = list(range(len(raw))) if max_degree >= 3 else [0, 1, 3, 4]
    raw_active = raw[active]
    observed_phase = torch.angle(cross)
    fitting_weight = power*weight
    design, transform, initial = linear_phase_initial(raw_active, observed_phase, fitting_weight)
    normal = fitting_weight.sum().clamp_min(1.e-30)
    def objective(x):
        phase = torch.einsum('c,chw->hw', x, design)
        return (weight*(power-2*(torch.polar(torch.ones_like(phase), -phase)*cross).real)).sum()/normal
    starts = [initial, torch.zeros_like(initial)]
    if len(group.odd) >= max(active)+1:
        starts.append(torch.linalg.solve(transform, torch.as_tensor(group.odd[active], device=device)))
    best_initial = min(starts, key=lambda x: float(objective(x)))
    optimal, info = lbfgs(objective, best_initial, max_iter=max_iter, tolerance=tolerance)
    coefficients = torch.zeros(len(raw), device=device, dtype=torch.float64)
    coefficients[active] = transform@optimal
    fitted = torch.einsum('c,chw->hw', coefficients, raw)
    wavelength = float(electron_wavelength_angstrom(torch.tensor(float(group.row.get('rlnVoltage', 300)), dtype=torch.float64)))
    cs = float(group.row.get('rlnSphericalAberration', 2.7))
    residual, tx, ty = extract_tilt(coefficients.cpu().numpy(), cs, wavelength)
    update = {'rlnBeamTiltX': tx, 'rlnBeamTiltY': ty}
    if max_degree >= 3 or abs(cs) < 1.e-12:
        update['rlnOddZernike'] = format_coefficients(residual)
    # For beamtilt-only, native fits a nuisance shift but writes only the tilt.
    return update, dict(**info, beam_tilt_x_mrad=tx, beam_tilt_y_mrad=ty,
                        coefficients=coefficients.cpu().tolist()), {
        'odd_observed_phase': observed_phase.cpu(), 'odd_fitted_phase': fitted.cpu(),
        'odd_residual_phase': torch.angle(torch.polar(torch.ones_like(fitted), observed_phase-fitted)).cpu(),
        'odd_weight': fitting_weight.cpu()}


def fit_even(group, stats, weight, *, max_degree=4, max_iter=150, tolerance=1.e-9):
    device = group.x.device
    ax, ay, az, bx, by = [stats['even_'+s].to(device) for s in ('Axx', 'Axy', 'Ayy', 'bx', 'by')]
    weight = weight.to(torch.float64)
    determinant = ax*az-ay.square()
    # Positive semidefinite normal equations can acquire tiny negative roundoff.
    valid = determinant > (ax*az).abs()*1.e-14
    denominator = torch.where(valid, determinant, torch.ones_like(determinant))
    ox = torch.where(valid, (az*bx-ay*by)/denominator, 0.)
    oy = torch.where(valid, (ax*by-ay*bx)/denominator, 0.)
    phase = torch.atan2(oy, ox)
    weight = weight*valid
    raw = basis(group.x.to(torch.float64), group.y.to(torch.float64), 'even', max_degree)
    design, transform, initial = linear_phase_initial(raw, phase, weight*determinant.abs().sqrt())
    normal = (weight*(ax+az)).sum().clamp_min(1.e-30)
    def objective(x):
        theta = torch.einsum('c,chw->hw', x, design)
        co, si = torch.cos(theta), torch.sin(theta)
        return (weight*(ax*co.square()+2*ay*co*si+az*si.square()-2*bx*co-2*by*si)).sum()/normal
    starts = [initial, torch.zeros_like(initial)]
    if len(group.even) <= len(raw):
        old = torch.zeros_like(initial)
        old[:len(group.even)] = torch.as_tensor(group.even, device=device)
        starts.append(torch.linalg.solve(transform, old))
    chosen = min(starts, key=lambda x: float(objective(x)))
    optimal, info = lbfgs(objective, chosen, max_iter=max_iter, tolerance=tolerance)
    coefficients = transform@optimal
    fitted = torch.einsum('c,chw->hw', coefficients, raw)
    update = {'rlnEvenZernike': format_coefficients(coefficients.cpu().tolist())}
    return update, dict(**info, coefficients=coefficients.cpu().tolist()), {
        'even_observed_phase': phase.cpu(), 'even_fitted_phase': fitted.cpu(),
        'even_residual_phase': torch.angle(torch.polar(torch.ones_like(fitted), phase-fitted)).cpu(),
        'even_weight': (weight*determinant.abs().sqrt()).cpu()}


def fit_magnification(group, stats, weight):
    device = group.x.device
    ax, ay, az, bx, by = [stats['mag_'+s].to(device) for s in ('Axx', 'Axy', 'Ayy', 'bx', 'by')]
    weight = weight.to(torch.float64).clone()
    # Same excluded rectangle boundary as solveLinearlyFreq.
    weight[0] = weight[-1] = 0
    weight[:, 0] = weight[:, -1] = 0
    n = group.box_size
    x = group.grid.x.to(torch.float64)*(n*group.pixel_size)
    y = group.grid.y.to(torch.float64)*(n*group.pixel_size)
    zero = torch.zeros_like(x)
    fx = torch.stack((x, y, zero, zero))
    fy = torch.stack((zero, zero, x, y))
    normal = torch.einsum('ihw,jhw,hw->ij', fx, fx, weight*ax)
    normal += torch.einsum('ihw,jhw,hw->ij', fx, fy, weight*ay)
    normal += torch.einsum('ihw,jhw,hw->ij', fy, fx, weight*ay)
    normal += torch.einsum('ihw,jhw,hw->ij', fy, fy, weight*az)
    rhs = torch.einsum('ihw,hw->i', fx, weight*bx)+torch.einsum('ihw,hw->i', fy, weight*by)
    singular = torch.linalg.svdvals(normal)
    if float(singular[0]) <= 0 or float(singular[-1]/singular[0]) < 1.e-12:
        raise ValueError(f'Insufficient directional information to fit magnification in optics group {group.identifier}')
    delta = torch.eye(2, device=device, dtype=torch.float64)+torch.linalg.solve(normal, rhs).reshape(2, 2)
    updated = delta@group.matrix.to(torch.float64)
    if not torch.isfinite(updated).all() or float(torch.linalg.det(updated)) <= 0:
        raise ValueError('Magnification fit produced an invalid matrix')
    update = {f'rlnMagMat{i}{j}': float(updated[i, j]) for i in range(2) for j in range(2)}
    eig = torch.linalg.svdvals(updated)
    dx = (delta[0, 0]-1)*x+delta[0, 1]*y
    dy = delta[1, 0]*x+(delta[1, 1]-1)*y
    return update, dict(delta_matrix=delta.cpu().tolist(), matrix=updated.cpu().tolist(),
        mean_magnification=float(eig.mean()), anisotropy_percent=float((eig.max()-eig.min())*100),
        condition=float(singular[0]/singular[-1])), {
        'magnification_fitted_dx': dx.cpu(), 'magnification_fitted_dy': dy.cpu(),
        'magnification_weight': weight.cpu()}


def adapt_astigmatism(data, group_id, delta, *, per_particle=False):
    """CTF coordinate change; call only for genuine micrographs when permitted."""
    selected = data.particles.index[np.asarray(data.particles.rlnOpticsGroup, dtype=int) == group_id].to_numpy()
    if not len(selected):
        return
    rows = data.particles.loc[selected]
    u = torch.tensor(np.asarray(rows.rlnDefocusU), dtype=torch.float64)
    v = torch.tensor(np.asarray(rows.rlnDefocusV), dtype=torch.float64)
    angle = torch.tensor(np.asarray(rows.rlnDefocusAngle), dtype=torch.float64)*math.pi/180
    co, si = angle.cos(), angle.sin()
    a = torch.stack((u*co*co+v*si*si, (u-v)*co*si, (u-v)*co*si, u*si*si+v*co*co), -1).reshape(-1, 2, 2)
    inv = torch.linalg.inv(torch.as_tensor(delta, dtype=torch.float64))
    transformed = inv.T@a@inv
    if not per_particle:
        names = np.asarray(rows.rlnMicrographName)
        for name in dict.fromkeys(names.tolist()):
            sel = np.flatnonzero(names == name)
            mean = transformed[sel].mean(0)
            average_defocus = transformed[sel].diagonal(dim1=-2, dim2=-1).mean(-1)
            common_astigmatism = mean-torch.eye(2, dtype=torch.float64)*mean.trace()/2
            transformed[sel] = common_astigmatism+average_defocus[:, None, None]*torch.eye(2, dtype=torch.float64)
    eig, vec = torch.linalg.eigh(transformed)
    data.particles.loc[selected, 'rlnDefocusU'] = eig[:, 1].numpy()
    data.particles.loc[selected, 'rlnDefocusV'] = eig[:, 0].numpy()
    data.particles.loc[selected, 'rlnDefocusAngle'] = (torch.atan2(vec[:, 1, 1], vec[:, 0, 1])*180/math.pi).remainder(180).numpy()


def update_optics(data, group_id, updates):
    row_index = data.optics.index[np.asarray(data.optics.rlnOpticsGroup, dtype=int) == group_id][0]
    for name, value in updates.items():
        if name not in data.optics:
            if name in ('rlnOddZernike', 'rlnEvenZernike'):
                data.optics[name] = ['[]']*len(data.optics)
            else:
                default = 1. if name in ('rlnMagMat00', 'rlnMagMat11') else 0.
                data.optics[name] = default
        data.optics.loc[row_index, name] = value
