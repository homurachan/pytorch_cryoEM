"""Modular CTF least squares, following RELION's phase-polynomial parameters.

The objective/analytic gradients follow modular_ctf_optimisation.cpp (Jasenko
Zivanov, GPL-2.0-or-later). Optimisation is implemented with PyTorch L-BFGS.
"""
from __future__ import annotations
from dataclasses import dataclass
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
import math
import time
import numpy as np
import torch
from relion_torch.ctf_refine.cuda_memory import available_cache_bytes

from relion_torch.optics.ctf import electron_wavelength_angstrom
from relion_torch.optics.observation import metadata_values
from relion_torch.optimiser.numerical import independent_lbfgs, lbfgs
from relion_torch.ctf_refine.diagnostics import memory_snapshot, describe_memory
from relion_torch.ctf_refine.timing import NULL_TIMER, timed_method


def expanded_modes(mode):
    if len(mode) != 5 or any(c not in 'fpm' for c in mode):
        raise ValueError('fit_mode must contain five f/p/m characters (phase, defocus, astigmatism, Cs, B/scale)')
    return [mode[0], mode[1], mode[2], mode[2], mode[3], mode[4], mode[4]]


def encode_ctf(rows, group):
    def get(name, default=None):
        return torch.as_tensor(metadata_values(rows, group.row, name, default), dtype=torch.float64)
    u, v, angle = get('rlnDefocusU'), get('rlnDefocusV'), get('rlnDefocusAngle', 0)*math.pi/180
    wavelength = electron_wavelength_angstrom(get('rlnVoltage', 300))
    contrast = get('rlnAmplitudeContrast', .1)
    if torch.any((contrast < 0) | (contrast >= 1)):
        raise ValueError('Amplitude contrast must be in [0, 1)')
    k3 = torch.asin(contrast)
    axx = -(u*angle.cos().square()+v*angle.sin().square())*math.pi*wavelength
    ayy = -(u*angle.sin().square()+v*angle.cos().square())*math.pi*wavelength
    axy = (v-u)*angle.sin()*angle.cos()*math.pi*wavelength
    return torch.stack((-get('rlnPhaseShift', 0)*math.pi/180-k3, (axx+ayy)/2,
        (axx-ayy)/2, axy, .5*math.pi*get('rlnSphericalAberration', 2.7)*1.e7*wavelength.pow(3),
        get('rlnCtfBfactor', 0), get('rlnCtfScalefactor', 1)), -1), wavelength, k3


def phase_basis(group):
    x, y = group.x.to(torch.float64), group.y.to(torch.float64)
    u2 = x*x+y*y
    return torch.stack((torch.ones_like(x), u2, x*x-y*y, 2*x*y, u2*u2)), u2


def ctf_loss_gradient(coefficients, statistics, phase_terms, even_phase):
    """Per-particle weighted squared error and derivatives w.r.t. seven parameters.

    statistics = [sum(weight*|prediction|^2), weight*Re(pred*conj(obs)),
                  weight*|obs|^2] per Fourier pixel, not radial averages.
    """
    q, r, power = statistics
    gamma = torch.einsum('bc,chw->bhw', coefficients[:, :5], phase_terms)+even_phase
    u2 = phase_terms[1]
    envelope = torch.exp(-coefficients[:, 5, None, None]*u2/4)
    wave = -torch.sin(gamma)
    ctf = coefficients[:, 6, None, None]*envelope*wave
    loss = (q*ctf.square()-2*r*ctf+power).sum((-2, -1))
    dc = 2*(q*ctf-r)
    dgamma = dc*coefficients[:, 6, None, None]*envelope*(-torch.cos(gamma))
    phase_gradient = torch.einsum('bhw,chw->bc', dgamma, phase_terms)
    db = (dc*ctf*(-u2/4)).sum((-2, -1))
    ds = (dc*envelope*wave).sum((-2, -1))
    return loss, torch.cat((phase_gradient, db[:, None], ds[:, None]), -1)


@dataclass
class FitBlock:
    positions: np.ndarray
    group_id: int
    statistics: torch.Tensor | Path

    def load(self, timing=NULL_TIMER):
        if isinstance(self.statistics, Path):
            with timing.section('statistics.disk_read'):
                array = np.load(self.statistics, allow_pickle=False)
            timing.count('statistics_disk_read_bytes', array.nbytes)
            return torch.from_numpy(array)
        return self.statistics


def collect_statistics(data, references, indices, *, prediction_batch, kmin, mode,
                       cache_directory=None, cache_mib=512., progress=None):
    # A path keeps the original direct-call API; a zero-argument factory creates
    # a private spill directory lazily, only after the host cache limit is hit.
    spill_directory = cache_directory
    timer = getattr(data, 'timer', NULL_TIMER)
    position = {int(v): i for i, v in enumerate(indices)}
    initial = torch.empty((len(indices), 7), dtype=torch.float64)
    wavelength, k3 = torch.empty(len(indices), dtype=torch.float64), torch.empty(len(indices), dtype=torch.float64)
    blocks = []
    cached_bytes = 0
    prepared = 0
    for group_id, selected in data.chunks(indices, prediction_batch):
        group = data.model.groups[group_id]
        if progress is not None:
            progress(f'projecting references, prepared {prepared}/{len(indices)} particles')
        pred = references.predict(data, selected, group_id, opposite=False)
        if progress is not None:
            progress(f'reading/transforming images, prepared {prepared}/{len(indices)} particles')
        obs = data.observed(selected, group_id)
        weight = references.weight(group, kmin, multiplicity=True).to(torch.float64)
        with timer.section('statistics.build', cuda=True):
            pred, obs = pred.to(torch.complex128), obs.to(torch.complex128)
            stats = torch.stack((pred.abs().square()*weight, (pred.conj()*obs).real*weight,
                                 obs.abs().square()*weight))
        stats = timer.call('statistics.d2h', stats.cpu, cuda=True,
            nbytes=stats.numel()*stats.element_size() if stats.device.type == 'cuda' else 0)
        positions = np.asarray([position[int(i)] for i in selected])
        coefficients, wl, amplitude_phase = timer.call('metadata.ctf_encode', encode_ctf, data.particles.iloc[selected], group)
        initial[positions] = coefficients
        wavelength[positions], k3[positions] = wl, amplitude_phase
        size = stats.numel()*stats.element_size()
        if cache_directory is not None and cached_bytes+size > cache_mib*1024**2:
            if callable(spill_directory):
                spill_directory = spill_directory()
            path = Path(spill_directory)/f'block_{len(blocks):06d}.npy'
            timer.call('statistics.disk_write', np.save, path, stats.numpy(), allow_pickle=False, nbytes=size)
            stats = path
        else:
            cached_bytes += size
        blocks.append(FitBlock(positions, group_id, stats))
        prepared += len(selected)
    return initial, wavelength, k3, blocks


class CtfProblem:
    def __init__(self, data, initial, blocks, mode, *, gpu_cache_mib=512.):
        self.timer = getattr(data, 'timer', NULL_TIMER)
        self.data, self.initial, self.blocks = data, initial.to(data.device), blocks
        self.modes = expanded_modes(mode)
        frequency = max(.5/g.pixel_size for g in data.model.groups.values())
        self.scales = torch.tensor([1., 1/frequency**2, 1/frequency**2, 1/frequency**2,
                                    1/frequency**4, 4/frequency**2, 1.],
                                   dtype=torch.float64, device=data.device)
        self.terms = {key: phase_basis(group)[0] for key, group in data.model.groups.items()}
        self.offsets = {key: group.even_phase.to(torch.float64) for key, group in data.model.groups.items()}
        self.normalization = torch.zeros(len(initial), device=data.device, dtype=torch.float64)
        for block in blocks:
            self.normalization[torch.as_tensor(block.positions, device=data.device)] = block.load(self.timer)[0].sum((-2, -1)).to(data.device)
        if not bool((self.normalization > 1.e-30).any()):
            raise ValueError('No reference signal in the selected CTF fitting frequencies')
        self.normalization = self.normalization.clamp_min(1.e-30)
        if not math.isfinite(gpu_cache_mib) or gpu_cache_mib < 0:
            raise ValueError('gpu_cache_mib must be finite and nonnegative')
        self.gpu_statistics = {}
        self.gpu_cache_bytes = 0
        budget = min(int(gpu_cache_mib*1024**2), available_cache_bytes(data.device))
        for block in blocks:
            # Disk spill remains bounded by the existing host-cache policy.
            if not isinstance(block.statistics, torch.Tensor):
                continue
            stats = block.statistics
            size = stats.numel()*stats.element_size()
            if self.gpu_cache_bytes+size > budget:
                continue
            try:
                device_stats = self.timer.call('statistics.cache_h2d', stats.to, data.device,
                    cuda=True, nbytes=size)
            except torch.cuda.OutOfMemoryError:
                self.timer.count('statistics_cuda_oom_fallbacks')
                break
            self.gpu_statistics[id(block)] = device_stats
            self.gpu_cache_bytes += size
        self.timer.count('statistics_gpu_cached_bytes', self.gpu_cache_bytes)

    @timed_method('objective.total')
    def loss_gradient(self, coefficients, particle_indices=None):
        self.timer.count('objective_calls')
        self.timer.count('objective_particle_evaluations', len(coefficients))
        value = torch.empty(len(coefficients), dtype=torch.float64, device=self.data.device)
        grad = torch.empty_like(coefficients)
        lookup = None
        if particle_indices is not None:
            with self.timer.section('objective.indices_d2h', cuda=True,
                    nbytes=particle_indices.numel()*particle_indices.element_size() if particle_indices.device.type == 'cuda' else 0):
                host_indices = particle_indices.detach().cpu().numpy()
            with self.timer.section('objective.host_schedule'):
                lookup = np.full(len(self.initial), -1, dtype=np.int64)
                lookup[host_indices] = np.arange(len(coefficients))
        for block in self.blocks:
            if lookup is None:
                pos = torch.as_tensor(block.positions, device=self.data.device)
                statistics = self.gpu_statistics.get(id(block))
                if statistics is None:
                    statistics = block.load(self.timer)
            else:
                with self.timer.section('objective.host_schedule'):
                    destinations = lookup[block.positions]
                    selected = np.flatnonzero(destinations >= 0)
                if not len(selected):
                    continue
                pos = torch.as_tensor(destinations[selected], device=self.data.device)
                # Select where the block resides; completed particles never
                # participate in the objective or require another full transfer.
                statistics = self.gpu_statistics.get(id(block))
                if statistics is None:
                    statistics = block.load(self.timer)
                if len(selected) != len(block.positions):
                    with self.timer.section('statistics.select', cuda=statistics.is_cuda):
                        selection = torch.as_tensor(selected, device=statistics.device)
                        statistics = statistics.index_select(1, selection)
            statistics = self.timer.call('statistics.h2d', statistics.to, self.data.device, cuda=True,
                nbytes=statistics.numel()*statistics.element_size() if self.data.device.type == 'cuda' and not statistics.is_cuda else 0)
            with self.timer.section('objective.ctf_loss_gradient', cuda=True):
                f, g = ctf_loss_gradient(coefficients[pos], statistics,
                                         self.terms[block.group_id], self.offsets[block.group_id])
            self.timer.count('objective_fourier_pixel_evaluations', statistics[0].numel())
            with self.timer.section('objective.scatter', cuda=True):
                value[pos], grad[pos] = f, g
        return value, grad

    def solve(self, *, max_iter, tolerance, progress=None):
        free = [i for i, mode in enumerate(self.modes) if mode != 'f']
        if not free:
            return self.initial.detach().cpu(), {'converged': True, 'iterations': 0}
        if 'm' not in self.modes:
            x0 = self.initial[:, free]/self.scales[free]
            def fg(x):
                coefficients = self.initial.clone()
                coefficients[:, free] = x*self.scales[free]
                f, g = self.loss_gradient(coefficients)
                return f/self.normalization, g[:, free]*self.scales[free]/self.normalization[:, None]
            def selected_fg(x, rows):
                coefficients = self.initial[rows].clone()
                coefficients[:, free] = x*self.scales[free]
                f, g = self.loss_gradient(coefficients, particle_indices=rows)
                norm = self.normalization[rows]
                return f/norm, g[:, free]*self.scales[free]/norm[:, None]
            x, info = self.timer.call('fit.lbfgs', independent_lbfgs, fg, x0, max_iter=max_iter, tolerance=tolerance,
                selected_function_and_gradient=selected_fg, progress=progress)
            final = self.initial.clone()
            final[:, free] = x*self.scales[free]
            return final.cpu(), info
        mapping = torch.full_like(self.initial, -1, dtype=torch.int64)
        values = []
        for column, mode in enumerate(self.modes):
            if mode == 'p':
                mapping[:, column] = torch.arange(len(self.initial), device=self.data.device)+len(values)
                values.extend((self.initial[:, column]/self.scales[column]).tolist())
            elif mode == 'm':
                mapping[:, column] = len(values)
                values.append(float(self.initial[0, column]/self.scales[column]))
        x0 = torch.tensor(values, device=self.data.device, dtype=torch.float64)
        variable = mapping >= 0
        normalization = self.normalization.sum()
        def decode(x):
            expanded = x[mapping.clamp_min(0)]*self.scales
            return torch.where(variable, expanded, self.initial)
        def fg(x):
            f, gradient = self.loss_gradient(decode(x))
            gradient = gradient*self.scales
            result = torch.zeros_like(x)
            result.scatter_add_(0, mapping[variable], gradient[variable])
            return f.sum()/normalization, result/normalization
        class Objective(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x):
                value, gradient = fg(x)
                ctx.save_for_backward(gradient)
                return value
            @staticmethod
            def backward(ctx, upstream):
                return upstream*ctx.saved_tensors[0]
        x, info = self.timer.call('fit.lbfgs', lbfgs, Objective.apply, x0, max_iter=max_iter, tolerance=tolerance, progress=progress)
        return decode(x).detach().cpu(), info


def write_parameters(data, indices, initial, final, wavelength, amplitude_phase, mode):
    modes = expanded_modes(mode)
    modified = []
    if modes[1] != 'f' or modes[2] != 'f':
        modified += ['rlnDefocusU', 'rlnDefocusV']
    if modes[2] != 'f':
        modified.append('rlnDefocusAngle')
    for component, label in [(0, 'rlnPhaseShift'), (4, 'rlnSphericalAberration'), (5, 'rlnCtfBfactor'), (6, 'rlnCtfScalefactor')]:
        if modes[component] != 'f' and label in data.particles:
            modified.append(label)
    for label in modified:
        data.particles[label] = data.particles[label].astype(float)
    rows = data.particles.iloc[indices]
    if modes[2] == 'f' and modes[1] != 'f':
        delta = (-(final[:, 1]-initial[:, 1])/(math.pi*wavelength)).numpy()
        # Preserve the input difference and its angle exactly, even if U < V.
        for name in ('rlnDefocusU', 'rlnDefocusV'):
            data.particles.loc[indices, name] = np.asarray(rows[name], dtype=float)+delta
    elif modes[2] != 'f':
        matrix = torch.stack((final[:, 1]+final[:, 2], final[:, 3], final[:, 3], final[:, 1]-final[:, 2]), -1).reshape(-1, 2, 2)
        matrix = -matrix/(math.pi*wavelength[:, None, None])
        eigenvalues, vectors = torch.linalg.eigh(matrix)
        data.particles.loc[indices, 'rlnDefocusU'] = eigenvalues[:, 1].numpy()
        data.particles.loc[indices, 'rlnDefocusV'] = eigenvalues[:, 0].numpy()
        data.particles.loc[indices, 'rlnDefocusAngle'] = (torch.atan2(vectors[:, 1, 1], vectors[:, 0, 1])*180/math.pi).remainder(180).numpy()
    if modes[0] != 'f':
        data.particles.loc[indices, 'rlnPhaseShift'] = ((-final[:, 0]-amplitude_phase)*180/math.pi).numpy()
    if modes[4] != 'f':
        data.particles.loc[indices, 'rlnSphericalAberration'] = (2*final[:, 4]/(1.e7*math.pi*wavelength.pow(3))).numpy()
    if modes[5] != 'f':
        data.particles.loc[indices, 'rlnCtfBfactor'] = final[:, 5].numpy()
        data.particles.loc[indices, 'rlnCtfScalefactor'] = final[:, 6].numpy()


def refine_parameters(data, references, mode, *, batch_size=256, prediction_batch=8,
                      max_iter=100, tolerance=1.e-8, kmin=30., progress=print,
                      brute_force_range=None, brute_force_step=100., cache_mib=512., cache_directory=None, gpu_cache_mib=512.):
    timer = getattr(data, 'timer', NULL_TIMER)
    results = []
    units = list(data.fitting_units(mode, batch_size))
    def fit_unit(name, indices, temporary, label):
        started = time.perf_counter()
        last_message = started
        def heartbeat(detail):
            nonlocal last_message
            now = time.perf_counter()
            if now-last_message < 10.:
                return
            last_message = now
            if isinstance(detail, dict):
                message = f"optimizing iteration={detail['iteration']}, evaluations={detail['evaluations']}"
                if 'active' in detail:
                    message += f", active={int(detail['active'].sum())}, pending={int(detail['pending'].sum())}, line-search trial={detail['line_search_trial']}"
            else:
                message = detail
            progress(f'{label}: {message}; elapsed={now-started:.1f}s; '+describe_memory(memory_snapshot(data.device)))

        progress(f'{label}: preparing {len(indices)} particles, unit={name}; '+describe_memory(memory_snapshot(data.device)))
        initial, wavelength, k3, blocks = timer.call('fit.prepare_statistics', collect_statistics, data, references, indices,
            prediction_batch=prediction_batch, kmin=kmin, mode=mode,
            cache_directory=temporary, cache_mib=cache_mib, progress=heartbeat)
        cache = dict(cpu_mib=sum(b.statistics.numel()*b.statistics.element_size() for b in blocks
                                if isinstance(b.statistics, torch.Tensor))/1024**2,
                     disk_mib=sum(b.statistics.stat().st_size for b in blocks if isinstance(b.statistics, Path))/1024**2,
                     disk_blocks=sum(isinstance(b.statistics, Path) for b in blocks))
        problem = timer.call('fit.problem_setup', CtfProblem, data, initial, blocks, mode, gpu_cache_mib=gpu_cache_mib, cuda=True)
        cache['gpu_mib'] = problem.gpu_cache_bytes/1024**2
        prepared_seconds = time.perf_counter()-started
        progress(f"{label}: preparation={prepared_seconds:.2f}s; statistics CPU={cache['cpu_mib']:.2f} MiB, disk={cache['disk_mib']:.2f} MiB ({cache['disk_blocks']} blocks), GPU={cache['gpu_mib']:.2f} MiB; optimizing")
        solve_start = time.perf_counter()
        if brute_force_range is not None:
            best_value = torch.full((len(indices),), float('inf'), device=data.device, dtype=torch.float64)
            best = problem.initial.clone()
            for offset in np.arange(-brute_force_range, brute_force_range+brute_force_step*.5, brute_force_step):
                candidate = problem.initial.clone()
                candidate[:, 1] -= math.pi*wavelength.to(data.device)*float(offset)
                value, _ = problem.loss_gradient(candidate)
                improve = value < best_value
                best = torch.where(improve[:, None], candidate, best)
                best_value = torch.minimum(best_value, value)
                heartbeat(f'defocus grid search offset={offset:.1f} Angstrom')
            problem.initial = best
        final, info = timer.call('fit.solve', problem.solve, max_iter=max_iter, tolerance=tolerance, progress=heartbeat)
        solve_seconds = time.perf_counter()-solve_start
        if not torch.isfinite(final).all():
            raise FloatingPointError(f'Non-finite CTF fit for {name}')
        timer.call('fit.write_parameters', write_parameters, data, indices, initial, final, wavelength, k3, mode)
        results.append(dict(unit=name, particles=len(indices), preparation_seconds=prepared_seconds,
                            optimization_seconds=solve_seconds, statistics_cache=cache, **info))

    for number, (name, indices) in enumerate(units, 1):
        # Create a private directory only if this unit actually spills to disk.
        # The stack removes only that directory, on success or an exception.
        # A real micrograph is never split into artificial independent fits.
        with ExitStack() as spill_files:
            def create_spill_directory():
                return spill_files.enter_context(TemporaryDirectory(prefix='ctf_fit_', dir=cache_directory))
            fit_unit(name, indices, create_spill_directory, f'CTF fitting {number}/{len(units)}')
        # Snapshot after the fit unit returns: no CtfProblem or stats blocks are
        # retained by the small, JSON-serializable results list.
        result = results[-1]
        result['memory_after_release'] = memory_snapshot(data.device)
        iteration_max = int(np.max(np.atleast_1d(result.get('iterations', 0))))
        progress(f"CTF fitting {number}/{len(units)}: {len(indices)} particles; done, optimization={result['optimization_seconds']:.2f}s, max iterations={iteration_max}, evaluations={result.get('evaluations', 0)}, particle evaluations={result.get('particle_evaluations', 'joint')}; "+describe_memory(result['memory_after_release']))
        timer.checkpoint('fit_unit', fields=dict(number=number, total=len(units), fit_mode=mode, **result))
    return results
