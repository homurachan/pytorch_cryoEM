"""Independent half-model scheduler after ordinary 3D auto-refine converges."""
from dataclasses import asdict, fields, replace
from pathlib import Path
import copy
import hashlib
import json
import math
import os
import time
import numpy as np
import pandas as pd
import torch
from relion_torch.alignment.core import AlignmentDataset
from relion_torch.io.particle_store import ParticleIOOptions
from relion_torch.io.star import read_star, write_star
from relion_torch.io.mrc import write_mrc
from relion_torch.class3d.runner import validate as validate_3d, PATH_FIELDS, EXECUTION_OVERRIDES
from relion_torch.class3d.optimiser import _primitive
from relion_torch.auto_refine.runner import _particles, assign_halves
from relion_torch.auto_refine.controller import pose_changes
from relion_torch.inference.memory_planning import CudaMemoryController
from relion_torch.inference.permanent_workers import (
    devices, PermanentPool, parallel_halves, configure_coordinator, reconstruct_grid,
)
from relion_torch.reconstruction.half_fsc import (
    backprojector_fsc, mwtcf_backprojector_fsc, solvent_corrected_fsc,
    move_backprojector, merge_backprojectors,
)
from relion_torch.version import __version__
from .config import CombineRefineConfig, FORMAT, JOINT_FIELDS, ANCHOR, ASTIGMATISM, COMBINE_EXECUTION_FIELDS
from .worker import CombineWorker


def read_state(path):
    path = Path(path).expanduser().resolve()
    if path.suffix == '.star':
        refs = [str(v) for f in read_star(path).values() if 'rlnTorchCheckpoint' in f for v in f.rlnTorchCheckpoint]
        if len(refs) != 1: raise ValueError('Expected a checkpoint .pt or its optimiser STAR')
        p = Path(refs[0]); path = p if p.is_absolute() else path.parent/p
    state = torch.load(path, map_location='cpu', weights_only=True)
    if not isinstance(state, dict) or state.get('format') not in (FORMAT, 'relion-torch-auto-refine-v1'):
        raise ValueError('Expected this package\'s auto-refine or combine-refine checkpoint')
    if len(state.get('halves', [])) != 2:
        raise ValueError('Checkpoint must contain two independent half-model states')
    return state, path


def options_from_checkpoint(path, output_root, *, resume=False):
    state, resolved = read_state(path)
    if resume and state['format'] != FORMAT: raise ValueError('--continue requires a combine-refine checkpoint')
    if not resume and state['format'] != 'relion-torch-auto-refine-v1':
        raise ValueError('--from-auto-refine requires an ordinary auto-refine checkpoint')
    options = CombineRefineConfig(None, Path(output_root))
    excluded = set() if resume else JOINT_FIELDS | {
        'iterations', 'combine_refine', 'initial_high_resolution', 'firstiter_cc', 'skip_expected_accuracy', 'timing'}
    for f in fields(options):
        if f.name not in excluded and f.name in state['config']:
            value = state['config'][f.name]
            if f.name in PATH_FIELDS | {'seed_checkpoint'} and value is not None: value = Path(value)
            if f.name in ('references', 'half_order'): value = tuple(value)
            setattr(options, f.name, value)
    options.output_root = Path(output_root)
    options.continue_from = resolved if resume else None
    options.seed_checkpoint = Path(state['config']['seed_checkpoint']) if resume else resolved
    if not resume:
        sampling = state['halves'][0]['sampling']
        options.healpix_order = sampling['healpix_order']
        options.oversampling = max(1, sampling['adaptive_oversampling'])
        options.force_converge = False
        options.current_size = None
        options.low_resol_join_halves = -1.
        options.use_all_data = True
    return options, state


def validate(options, state):
    if options.combine_execution not in ('optimized', 'reference'):
        raise ValueError('combine-execution must be optimized or reference')
    if options.combine_accumulation not in ('auto', 'contracted', 'reference'):
        raise ValueError('combine-accumulation must be auto, contracted or reference')
    if options.combine_defocus_chunk < 1:
        raise ValueError('combine-defocus-chunk must be positive')
    if options.number_of_classes != 1: raise ValueError('Combine refinement requires K=1')
    if not options.combine_refine: raise ValueError('Invalid combine configuration')
    if options.symmetry != state['config']['symmetry']:
        raise ValueError('Combine refinement preserves the input point-group symmetry')
    if options.oversampling < 1: raise ValueError('Six-dimensional fine refinement requires oversampling >= 1')
    if not options.use_ctf or not options.ctf_corrected_ref:
        raise ValueError('Combine refinement requires CTF and CTF-corrected references')
    for name in ('ctf_premultiplied', 'ctf_phase_flipped', 'only_flip_phases', 'intact_first_peak',
                 'skip_align', 'skip_rotate', 'fast_subsets', 'firstiter_cc', 'force_converge'):
        if getattr(options, name): raise ValueError(f'Combine refinement does not support {name}')
    if options.low_resol_join_halves > 0:
        raise ValueError('Combine refinement keeps its half models independent; low-resolution joining is disabled')
    if options.score_highres_angstrom is None:
        raise ValueError('Set --score-highres explicitly; the final auto-refine Nyquist cutoff is not inherited')
    for name in ('score_highres_angstrom', 'maximum_start_resolution', 'defocus_step', 'defocus_sigma',
                 'pose_sigma_factor', 'translation_range_factor'):
        value = getattr(options, name)
        if not math.isfinite(value) or value <= 0: raise ValueError(name+' must be positive and finite')
    for name in ('defocus_range', 'defocus_tolerance', 'angle_tolerance', 'translation_tolerance', 'map_tolerance'):
        value = getattr(options, name)
        if not math.isfinite(value) or value < 0: raise ValueError(name+' must be nonnegative and finite')
    if options.pose_sigma_factor < 1 or options.translation_range_factor < 1:
        raise ValueError('Coarse support broadening factors must be >= 1')
    ratio = options.defocus_range/options.defocus_step
    if not math.isclose(ratio, round(ratio), rel_tol=0, abs_tol=1e-8):
        raise ValueError('defocus-range must be an integer multiple of defocus-step')
    if not options.adaptive_fraction <= options.coarse_fraction <= 1:
        raise ValueError('Require adaptive-fraction <= coarse-fraction <= 1')
    if not 0 <= options.boundary_tolerance < 1: raise ValueError('boundary-tolerance must be in [0,1)')
    if options.minimum_iterations < 1 or options.stable_iterations < 1:
        raise ValueError('Minimum and stable iteration counts must be positive')
    if options.auto_execution not in ('optimized', 'reference'): raise ValueError('Invalid auto-execution')
    if not math.isfinite(options.auto_cache_mib) or (options.auto_cache_mib < 0 and options.auto_cache_mib != -1):
        raise ValueError('auto-cache-mib must be -1, zero, or positive')
    if tuple(sorted(options.half_order)) != (1, 2): raise ValueError('half-order must be 1,2 or 2,1')
    if not math.isfinite(options.mwtcf): raise ValueError('mwtcf must be finite')
    if options.solvent_correct_fsc and options.solvent_mask is None:
        raise ValueError('Solvent-corrected FSC needs a solvent mask')
    if state['format'] != FORMAT:
        if not state.get('controller', {}).get('complete', False):
            raise ValueError('Normal 3D auto-refine must converge before combine refinement')
        resolution = float(state['history'][-1]['resolution_angstrom'])
        if not math.isfinite(resolution) or resolution > options.maximum_start_resolution:
            raise ValueError(f'Input reported resolution {resolution:g} A exceeds the start limit '
                             f'{options.maximum_start_resolution:g} A (default 6 A)')
    else:
        allowed = EXECUTION_OVERRIDES | COMBINE_EXECUTION_FIELDS | {'iterations', 'output_root', 'continue_from'}
        for f in fields(options):
            if f.name not in allowed and _primitive(getattr(options, f.name)) != state['config'].get(f.name):
                raise ValueError('Cannot change scientific setting on combine continuation: '+f.name)
        if options.iterations <= state['iteration']:
            raise ValueError('--iter must exceed the saved combine iteration')


def _atomic_json(path, value):
    path = Path(path); temp = Path(str(path)+'.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    os.replace(temp, path)


def _write_state(options, parent, workers, fsc, history, provenance, stable, converged):
    iteration = len(history)
    root = f'{options.output_root}_it{iteration:03d}'
    particles = _particles(parent, workers)
    data = root+'_data.star'
    write_star({'optics': parent.optics, 'particles': particles}, data)
    for w in workers:
        o = w.optimiser
        path = root+f'_half{w.half_id}_class001.mrc'
        write_mrc(path, o.references[0], pixel_size_angstrom=parent.pixel_size)
        blocks = o._model_blocks([path], log_likelihood=o.last_ll, average_pmax=o.last_pmax)
        blocks['model_class_1']['rlnGoldStandardFsc'] = fsc.numpy()
        write_star(blocks, root+f'_half{w.half_id}_model.star')
    write_star({'fsc': pd.DataFrame({'rlnSpectralIndex': np.arange(len(fsc)),
        'rlnResolution': np.arange(len(fsc))/(parent.box_size*parent.pixel_size),
        'rlnGoldStandardFsc': fsc.numpy()})}, root+'_fsc.star')
    state = dict(format=FORMAT, package_version=__version__, config=_primitive(asdict(options)),
        iteration=iteration, data_star=data, input_star=str(options.input_star),
        half_labels=particles.rlnRandomSubset.to_numpy(dtype=np.int64).tolist(),
        image_names=particles.rlnImageName.astype(str).tolist(),
        particle_numeric={c: torch.from_numpy(particles[c].to_numpy(copy=True))
                          for c in particles if particles[c].dtype.kind in 'biuf'},
        halves=[w.optimiser.snapshot() for w in workers], fsc=fsc.cpu(), history=history,
        stable_count=stable, converged=converged, provenance=provenance)
    destination = Path(root+'_state.pt'); temp = Path(str(destination)+'.tmp')
    torch.save(state, temp); os.replace(temp, destination)
    write_star({'optimiser_general': pd.DataFrame([{'rlnTorchCheckpoint': str(destination),
        'rlnCurrentIteration': iteration, 'rlnDataStarFile': data,
        'rlnDoSplitRandomHalves': 1, 'rlnDoJoinRandomHalves': 0}])}, root+'_optimiser.star')
    return destination, particles


def _fsc_resolution(fsc, n, pixel):
    below = np.flatnonzero(fsc.numpy()[1:] < .143)
    shell = max(1, int(below[0])) if len(below) else n//2
    return n*pixel/shell


@torch.no_grad()
def run_combine_refine(options, *, checkpoint_state=None):
    options = replace(options)
    source = options.continue_from or options.seed_checkpoint
    if source is None: raise ValueError('Provide --from-auto-refine or --continue')
    state = checkpoint_state if checkpoint_state is not None else read_state(source)[0]
    validate(options, state)
    resume = state['format'] == FORMAT
    options.output_root = Path(options.output_root).expanduser().resolve()
    options.output_root.parent.mkdir(parents=True, exist_ok=True)
    # No overwrite of an input run or existing task outputs.
    if any(options.output_root.parent.glob(options.output_root.name+'_it*_state.pt')):
        raise FileExistsError('Output prefix already has checkpoints; choose a new --o prefix')
    inputstar = Path(state['data_star']).expanduser()
    if not inputstar.is_absolute(): inputstar = Path(source).resolve().parent/inputstar
    options.input_star = inputstar.resolve()
    requested_devices = devices(options)
    if requested_devices: options.device = 'cpu'
    device = torch.device(options.device)
    if device.type == 'cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA is unavailable')
    pool = None
    with CudaMemoryController(device, options.gpu_memory_percent, automatic=options.auto_memory) as guard:
        memory = guard if options.auto_memory and guard.enabled else None
        parent = AlignmentDataset(options.input_star, io_options=ParticleIOOptions.from_config(options),
                                  preserve_noise_groups=True)
        try:
            if parent.box_size < 4: raise ValueError('Combine refinement needs an even box >= 4')
            if options.score_highres_angstrom < 2*parent.pixel_size:
                raise ValueError('score-highres cannot exceed the input Nyquist frequency')
            if options.score_highres_angstrom > parent.box_size*parent.pixel_size/2:
                raise ValueError('Scoring cutoff leaves fewer than two nonzero Fourier shells')
            if 'rlnRandomSubset' not in parent.particles: raise ValueError('Input half identities are missing')
            labels = assign_halves(parent.particles, options.random_seed)
            if labels.tolist() != state['half_labels']: raise ValueError('Checkpoint half identities differ')
            if parent.particles.rlnImageName.astype(str).tolist() != state['image_names']:
                raise ValueError('Checkpoint image identities differ from data STAR')
            restored = parent.particles.copy()
            for c, value in state['particle_numeric'].items(): restored[c] = value.numpy().copy()
            for c in ('rlnDefocusU', 'rlnDefocusV', 'rlnDefocusAngle'):
                if c not in restored or not np.isfinite(restored[c].to_numpy()).all():
                    raise ValueError('Finite per-particle '+c+' is required')
            if not resume:
                restored[ANCHOR] = (restored.rlnDefocusU+restored.rlnDefocusV)/2
                restored[ASTIGMATISM] = (restored.rlnDefocusU-restored.rlnDefocusV)/2
            if any(c not in restored for c in (ANCHOR, ASTIGMATISM)):
                raise ValueError('Combine checkpoint is missing immutable defocus anchors')
            parent.replace_particles(restored)
            if any(r.ctf_premultiplied for r in parent._records):
                raise ValueError('CTF-premultiplied input is not supported by combine refinement')
            if 'rlnMtfFileName' in parent.optics:
                from relion_torch.io.particles import parse_image_reference
                parent.optics = parent.optics.copy()
                parent.optics['rlnMtfFileName'] = [str(parse_image_reference(str(v), parent.star_path.parent)[1])
                    if str(v) not in ('None', 'none', 'nan', '?', '.', '') else v for v in parent.optics.rlnMtfFileName]
            options.current_size = parent.box_size
            options.strict_highres_angstrom = options.score_highres_angstrom
            options.initial_high_resolution = None
            options.skip_expected_accuracy = True
            halves = copy.deepcopy(state['halves'])
            if not resume:
                for half in halves:
                    sm = half['sampling']
                    sm['adaptive_oversampling'] = options.oversampling
                    sm['offset_range'] *= options.translation_range_factor
                    half['iteration'] = 0
                    half['history'] = []
                sm = halves[0]['sampling']
                options.offset_range_pixels = sm['offset_range']/parent.pixel_size
                options.offset_step_pixels = sm['offset_step']/parent.pixel_size
                sigma = 2*360/(6*2**(options.healpix_order+options.oversampling))*options.pose_sigma_factor
                options.sigma_ang_deg = -1.
                options.sigma_rot_deg = options.sigma_tilt_deg = options.sigma_psi_deg = sigma
            validate_3d(replace(options, healpix_order=min(options.healpix_order, 6),
                                sampling_work_mib=max(options.sampling_work_mib, 1e9)))
            if options.preread_images: parent.images.preread(shared=bool(requested_devices))
            if memory is not None:
                from relion_torch.class3d.memory import configure_startup
                configure_startup(memory, options, parent.box_size)
            configure_coordinator(options, parent.box_size)
            workers = [CombineWorker(h, parent, options, halves[h-1], device=device) for h in (1, 2)]
            if requested_devices:
                pool = PermanentPool(options)
                for w in workers: pool.bind(w.optimiser, w.half_id, parent)
            history = list(state['history']) if resume else []
            stable = int(state.get('stable_count', 0)) if resume else 0
            provenance = state['provenance'] if resume else dict(
                seed_checkpoint=str(Path(source).resolve()),
                seed_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),
                seed_version=state.get('package_version'), seed_iteration=state['iteration'],
                seed_resolution_angstrom=float(state['history'][-1]['resolution_angstrom']),
                coarse_policy='Recompute broadened 5D local coarse every iteration at current point-estimate CTF',
                posterior='One joint fine posterior; immutable defocus prior anchor; input point group and half identities preserved')
            fsc = state['fsc'].clone()
            converged = False
            checkpoint = None
            for iteration in range(len(history)+1, options.iterations+1):
                start = time.perf_counter(); stages = {}
                old = [w.dataset.particles.copy() for w in workers]
                old_maps = [w.optimiser.references[0] for w in workers]
                print(f'=============================\n3D auto combine refine {iteration}/{options.iterations}: '
                      f'{options.symmetry}, score cutoff {options.score_highres_angstrom:g} A, '
                      f'{2*round(options.defocus_range/options.defocus_step)+1} defocus candidates', flush=True)
                for h, _, elapsed in parallel_halves([workers[h-1] for h in options.half_order], options,
                                                     'expectation', iteration, device, memory):
                    stages[f'half{h}_expectation_and_transfer'] = elapsed
                bps = [w.packet['bps'].objects[0] for w in workers]
                masses = [float(w.packet['mass'].sum()) for w in workers]
                from relion_torch.class3d.memory import volume_payloads
                _, grid_bytes, _ = volume_payloads(parent.box_size, parent.box_size, options.padding_factor)
                if grid_bytes*3 > options.backprojector_host_gib*2**30:
                    raise MemoryError('Independent halves and combined grid exceed backprojector host budget')
                unfiltered = []
                for h, bp in enumerate(bps, 1):
                    result = (pool.reconstruct(h, bp, masses[h-1], options) if pool else
                        reconstruct_grid(bp, device, masses[h-1], dict(preweight_iterations=options.preweight_iterations,
                            skip_gridding=options.skip_gridding, reconstruction_backend=options.reconstruction_backend)))
                    unfiltered.append(result['map'])
                    write_mrc(f'{options.output_root}_it{iteration:03d}_half{h}_class001_unfil.mrc',
                              result['map'], pixel_size_angstrom=parent.pixel_size)
                if options.solvent_correct_fsc:
                    fsc, _ = solvent_corrected_fsc(*unfiltered, workers[0].optimiser._solvent_mask.cpu(),
                        current_size=parent.box_size, seed=options.random_seed+2*iteration)
                    method = 'solvent_corrected'
                elif options.do_mwtcf:
                    fsc = mwtcf_backprojector_fsc(*bps, threshold=options.mwtcf).cpu(); method = 'mwtcf'
                else:
                    fsc = backprojector_fsc(*bps).cpu(); method = 'ordinary'
                # This combined output is never installed in either half slot.
                joined = merge_backprojectors(*bps)
                for h, _, elapsed in parallel_halves(workers, options, 'maximization', iteration, fsc, device, memory):
                    stages[f'half{h}_maximization_and_transfer'] = elapsed
                from relion_torch.reconstruction.sirm import sirm_options_from_config
                merged = (pool.reconstruct(1, joined, sum(masses), options, fsc, workers[0].optimiser.tau2[0]) if pool else
                    reconstruct_grid(joined, device, sum(masses), dict(tau2=workers[0].optimiser.tau2[0],
                        tau2_fudge=options.tau2_fudge, preweight_iterations=options.preweight_iterations,
                        minres_map=options.minres_map, skip_gridding=options.skip_gridding,
                        reconstruction_backend=options.reconstruction_backend,
                        sirm=sirm_options_from_config(options, fsc=fsc)), fsc))
                del joined, bps
                changes = [pose_changes(a, w.dataset.particles, options.symmetry) for a, w in zip(old, workers)]
                count = sum(x['count'] for x in changes)
                angle_change = sum(x['angle_sum'] for x in changes)/count
                trans_change = math.sqrt(sum(x['offset_square_sum'] for x in changes)/(2*count))
                delta = np.concatenate([((w.dataset.particles.rlnDefocusU+w.dataset.particles.rlnDefocusV-
                    a.rlnDefocusU-a.rlnDefocusV)/2).to_numpy() for a, w in zip(old, workers)])
                defocus_change = float(np.sqrt(np.mean(delta**2)))
                map_change = max(float((w.optimiser.references[0]-a).norm()/a.norm().clamp_min(1e-30))
                                 for w, a in zip(workers, old_maps))
                frame = pd.concat([w.dataset.particles for w in workers], ignore_index=True)
                edge_fraction = float((frame.rlnCombineDefocusEdgeMass > options.boundary_tolerance).mean())
                pose_boundary = float(frame.rlnCombinePoseBoundary.mean())
                is_stable = (defocus_change <= options.defocus_tolerance and angle_change <= options.angle_tolerance
                    and trans_change <= options.translation_tolerance and map_change <= options.map_tolerance
                    and edge_fraction <= options.boundary_tolerance and pose_boundary <= options.boundary_tolerance)
                stable = stable+1 if is_stable else 0
                converged = iteration >= options.minimum_iterations and stable >= options.stable_iterations
                entry = dict(iteration=iteration, resolution_angstrom=_fsc_resolution(fsc, parent.box_size, parent.pixel_size),
                    fsc_method=method, score_highres_angstrom=options.score_highres_angstrom,
                    score_size=workers[0].optimiser.sizes.likelihood_image_size(True), reconstruction_size=parent.box_size,
                    defocus_rms_change_angstrom=defocus_change, angle_change_deg=angle_change,
                    translation_rms_change_angstrom=trans_change, map_relative_change=map_change,
                    defocus_boundary_particle_fraction=edge_fraction, pose_boundary_particle_fraction=pose_boundary,
                    mean_defocus_posterior_std_angstrom=float(frame.rlnCombineDefocusStd.mean()),
                    stable_count=stable, converged=converged, stages_seconds=stages,
                    elapsed_seconds=time.perf_counter()-start)
                if pool: entry['devices'] = pool.devices
                history.append(entry)
                checkpoint, particles = _write_state(options, parent, workers, fsc, history, provenance, stable, converged)
                write_mrc(str(options.output_root)+'_class001.mrc', merged['map'], pixel_size_angstrom=parent.pixel_size)
                write_star({'optics': parent.optics, 'particles': particles}, str(options.output_root)+'_data.star')
                for h, image in enumerate(unfiltered, 1):
                    write_mrc(f'{options.output_root}_half{h}_class001_unfil.mrc', image, pixel_size_angstrom=parent.pixel_size)
                _atomic_json(str(options.output_root)+'_combine_report.json', dict(
                    package_version=__version__, converged=converged, checkpoint=str(checkpoint),
                    status='converged' if converged else 'iteration_limit_or_in_progress',
                    provenance=provenance, config=_primitive(asdict(options)), history=history,
                    limitations=['Posterior is restricted to retained 5D coarse support.',
                        'Boundary diagnostics do not exclude unobserved modes outside support.',
                        'Fixed defocus prior is not multiplied by previous-iteration posterior.',
                        'Scoring cutoff and output Nyquist support are different.']))
                if options.timing:
                    with Path(str(options.output_root)+'_combine_timing.jsonl').open('a', encoding='utf-8') as stream:
                        stream.write(json.dumps(entry)+'\n')
                print(f'  defocus change={defocus_change:.4g} A; angle={angle_change:.4g} deg; '
                      f'shift={trans_change:.4g} A; edge fraction={edge_fraction:.3g}; '
                      f'elapsed={entry["elapsed_seconds"]:.2f}s', flush=True)
                if converged: break
            return dict(converged=converged, iteration=len(history), checkpoint=checkpoint,
                        half_maps=[w.optimiser.references[0] for w in workers], fsc=fsc, history=history)
        finally:
            if pool is not None: pool.close()
            parent.close()
