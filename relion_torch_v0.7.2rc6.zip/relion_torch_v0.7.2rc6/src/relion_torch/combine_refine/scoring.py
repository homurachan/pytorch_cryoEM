"""Bounded joint scoring: prepare geometry once, project once per parent tile.

No normalization here. Every original parent/child/defocus slot is scored.
The common Gaussian scorer and physical CTF expression are retained.
"""
from dataclasses import fields, replace
import torch
from relion_torch.inference.execution_policy import candidate_budget
from relion_torch.optics.ctf import compute_ctf
from relion_torch.inference.alignment import AlignmentExpectation
from relion_torch.inference.fine_scoring import gather_active_child_rows
from relion_torch.inference.score_tiles import score_prediction_tile
from .config import ASTIGMATISM


class CandidateCTFs:
    """Batch-local, budgeted full-frequency CTF cache shared by E and wsum.

If all candidates do not fit, generate only requested row/defocus tiles. The
shared optics grid and parameter tensors are prepared once either way. Never
approximate a CTF, divide by an old CTF or reuse this object across batches.
"""
    def __init__(self, owner, prepared, defoci, budget):
        self.owner, self.p, self.defoci = owner, prepared, defoci
        frame = owner.dataset.particles.iloc[prepared.indices]
        self.g = owner.observation.groups[owner.active_optics]
        params = owner.observation.parameters(frame, owner.active_optics)
        self.params = {f.name: torch.as_tensor(getattr(params, f.name), device=owner.device,
            dtype=prepared.like.real.dtype).expand(len(prepared.indices)) for f in fields(params)}
        self.param_type = type(params)
        self.astig = torch.as_tensor(frame[ASTIGMATISM].to_numpy(copy=True), device=owner.device, dtype=defoci.dtype)
        self.n = owner.dataset.box_size
        self.cache = None
        self.reserved_bytes = 0
        self.all_rows = torch.arange(len(prepared.indices), device=owner.device)
        wanted = defoci.numel()*self.n*(self.n//2+1)*prepared.like.real.element_size()
        # Leave room for physical CTF temporaries as well as the final cache.
        render_work = len(prepared.indices)*self.n*(self.n//2+1)*64
        if wanted <= budget//4 and render_work <= budget//2:
            self.cache = torch.empty((*defoci.shape, self.n, self.n//2+1),
                device=owner.device, dtype=prepared.like.real.dtype)
            for d in range(defoci.shape[1]): self.cache[:, d].copy_(self._render(self.all_rows, d))
            self.reserved_bytes = wanted
        c = owner._perf_counters
        c['combine_ctf_cache_peak_bytes'] = max(c.get('combine_ctf_cache_peak_bytes', 0), self.reserved_bytes)
        c['combine_ctf_cached_batches' if self.cache is not None else 'combine_ctf_streamed_batches'] = c.get(
            'combine_ctf_cached_batches' if self.cache is not None else 'combine_ctf_streamed_batches', 0)+1

    def _render(self, rows, d):
        values = {k: v.index_select(0, rows) for k, v in self.params.items()}
        delta = self.astig[rows]
        values.update(defocus_u=self.defoci[rows, d]+delta, defocus_v=self.defoci[rows, d]-delta)
        raw = compute_ctf(self.n, self.g.pixel_size, self.param_type(**values), device=self.owner.device,
            dtype=self.p.like.real.dtype, frequency_grid=self.g.grid, frequency_matrix=self.g.matrix,
            gamma_offset=self.g.even_phase, validate_parameters=False)
        # ObservationModel.parameters validated the fixed voltage/Q0 once;
        # only defocus changes here. Avoid a device-to-host Q0 check per tile.
        self.owner._perf_counters['combine_ctf_rendered_rows'] = self.owner._perf_counters.get(
            'combine_ctf_rendered_rows', 0)+len(rows)
        return raw*self.p.old_scales[rows].to(raw.dtype)[:, None, None]*self.g.mtf

    def get(self, rows, start, stop):
        if self.cache is not None: return self.cache[rows, start:stop]
        return torch.stack([self._render(rows, d) for d in range(start, stop)], 1)

    def for_rows(self, rows):
        """Reuse a tile's particle gather across defocus blocks.

        The streamed path renders each unique particle once per D block,
        even if many retained pose parents refer to that same particle.
        """
        if self.cache is not None:
            return lambda start, stop: self.get(rows, start, stop)
        unique, inverse = torch.unique(rows, sorted=True, return_inverse=True)
        return lambda start, stop: self.get(unique, start, stop).index_select(0, inverse)

    def prepared(self, d):
        ctf = self.get(self.all_rows, d, d+1)[:, 0]
        return replace(self.p, prediction=ctf, numerator=ctf, denominator=ctf.square())


def score_joint(owner, p, engine, coarse, defoci, scores, bank):
    with owner._detail_timer.section('combine.score.geometry'):
        base = engine.run_sparse_adaptive_batch(p.like, p.prediction, p.sigma,
            offset_prior_angstrom=p.centres, orientation_prior_deg=None,
            pixel_size=owner.dataset.pixel_size, coarse=coarse, geometry_only=True)
    g, inp = base.geometry, base.scoring_inputs
    oc, tc, nd = scores.shape[1:]
    dc = min(nd, owner.options.combine_defocus_chunk)
    f, full = inp['active'].numel(), owner.dataset.box_size*(owner.dataset.box_size//2+1)
    # Bound projection/phase gathers, predictions, Gaussian-score scratch and
    # CTF generation even when its batch cache was not admitted.
    per = full*dc*64 + f*(oc*16 + tc*24 + dc*oc*40 + 64)
    work = candidate_budget(owner)-bank.reserved_bytes
    if per > work:
        dc = 1
        per = full*64 + f*(oc*16 + tc*24 + oc*40 + 64)
    if per > work: raise MemoryError('One combine score tile exceeds candidate workspace; increase --candidate-work-mib')
    limit = max(1, min(owner.options.candidate_chunk_size, work//per))
    phase = g['phase_factors'].flatten(-2).index_select(-1, inp['active'])
    for start in range(0, len(scores), limit):
        stop = min(start+limit, len(scores))
        rows = g['parent_particle_indices'][start:stop]
        with owner._detail_timer.section('combine.score.project'):
            refs = gather_active_child_rows(g['projection_blocks'].projections,
                g['parent_projection_block_indices'][start:stop], inp['active'])
        shifted = inp['image'][rows, None]*phase[g['parent_translation_indices'][start:stop]]
        inv, high = inp['invsigma'][rows], base.highres_xi2_half[rows]
        ctf_rows = bank.for_rows(rows)
        for d in range(0, nd, dc):
            end = min(d+dc, nd)
            ctf = AlignmentExpectation._window_rfft(ctf_rows(d, end), inp['size'])[..., inp['mask']]
            prediction = (refs[:, None]*ctf[:, :, None]).flatten(1, 2)
            with owner._detail_timer.section('combine.score.tile'):
                tile = score_prediction_tile(shifted, prediction, inv, high)
            scores[start:stop, ..., d:end] = tile.reshape(len(rows), end-d, oc, tc).permute(0, 2, 3, 1)
            owner._perf_counters['combine_score_tiles'] = owner._perf_counters.get('combine_score_tiles', 0)+1
        owner._perf_counters['combine_score_projection_tiles'] = owner._perf_counters.get('combine_score_projection_tiles', 0)+1
        owner._perf_counters['combine_score_projection_rows'] = owner._perf_counters.get('combine_score_projection_rows', 0)+len(rows)*oc
    base.diff2.copy_(scores[..., 0])
    base.scoring_inputs = None
    owner._perf_counters['combine_fine_geometry_builds'] = owner._perf_counters.get('combine_fine_geometry_builds', 0)+1
    owner._perf_counters['combine_score_workspace_estimated_bytes'] = max(owner._perf_counters.get(
        'combine_score_workspace_estimated_bytes', 0), limit*per+bank.reserved_bytes)
    return base
