from dataclasses import dataclass
from pathlib import Path
from relion_torch.auto_refine.config import AutoRefineConfig


@dataclass
class CombineRefineConfig(AutoRefineConfig):
    combine_refine: bool = True
    seed_checkpoint: Path | None = None
    score_highres_angstrom: float | None = None
    maximum_start_resolution: float = 6.0
    defocus_range: float = 500.0
    defocus_step: float = 50.0
    defocus_sigma: float = 300.0
    coarse_fraction: float = .9999
    pose_sigma_factor: float = 1.5
    translation_range_factor: float = 1.5
    iterations: int = 5
    minimum_iterations: int = 2
    stable_iterations: int = 2
    defocus_tolerance: float = 10.0
    angle_tolerance: float = .1
    translation_tolerance: float = .1
    map_tolerance: float = .01
    boundary_tolerance: float = .05
    # Independent task: scoring cutoff is explicit; no Nyquist controller.
    initial_high_resolution: float | None = None
    skip_expected_accuracy: bool = True
    firstiter_cc: bool = False
    timing: bool = True
    combine_execution: str = 'optimized'
    combine_accumulation: str = 'auto'
    combine_defocus_chunk: int = 4


JOINT_FIELDS = frozenset({
    'seed_checkpoint', 'score_highres_angstrom', 'maximum_start_resolution',
    'defocus_range', 'defocus_step', 'defocus_sigma', 'coarse_fraction',
    'pose_sigma_factor', 'translation_range_factor', 'minimum_iterations',
    'stable_iterations', 'defocus_tolerance', 'angle_tolerance',
    'translation_tolerance', 'map_tolerance', 'boundary_tolerance',
})

ANCHOR = 'rlnCombineDefocusAnchor'
ASTIGMATISM = 'rlnCombineDefocusHalfDifference'
FORMAT = 'relion-torch-combine-refine-v1'

COMBINE_EXECUTION_FIELDS = frozenset({'combine_execution', 'combine_accumulation', 'combine_defocus_chunk'})
