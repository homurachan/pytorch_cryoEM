"""One posterior over all retained pose children and all mean defoci.

Only coarse *priors* enter this calculation. Coarse posterior values determine
support, never multiply a second likelihood of the same observations.
"""
from dataclasses import dataclass
import math
import torch
from relion_torch.inference.alignment import relion_weight_selection_batch


def defocus_grid(anchors, half_range, step, sigma):
    """Fixed, symmetric grid around the immutable input mean defocus, in A.

    Gaussian prior is discretely normalised on this grid. A zero range is a
    supported fixed-defocus control. All pose children use the same grid.
    """
    count = int(round(half_range/step))
    delta = torch.arange(-count, count+1, device=anchors.device, dtype=torch.float64)*step
    prior = -.5*(delta/sigma).square()
    prior = prior-torch.logsumexp(prior, 0)
    return anchors.double()[:, None]+delta[None], prior


@dataclass
class JointSelection:
    posterior: torch.Tensor  # [parent, orientation_child, translation_child, defocus]
    significant: torch.Tensor
    evidence: torch.Tensor
    pmax: torch.Tensor
    count: torch.Tensor
    threshold: torch.Tensor
    class_mass: torch.Tensor
    best_parent: torch.Tensor
    best_orientation: torch.Tensor
    best_translation: torch.Tensor
    best_defocus: torch.Tensor
    defocus_marginal: torch.Tensor
    pose_pmax: torch.Tensor
    retained_mass: torch.Tensor


def select_joint(scores, parent_rows, parent_classes, pose_log_prior, defocus_log_prior,
                 batch_size, classes, fraction, *, weight_dtype=torch.float64, counters=None):
    """RELION weight selection once per real particle, across every dimension.

    Uniform fine children split each coarse prior cell into equal volumes.
    This constant leaves posteriors unchanged and prevents evidence increasing
    solely because a parent has more fine children. Evidence is still restricted
    to the retained support and the legacy local-prior convention.
    """
    p, oc, tc, nd = scores.shape
    counts = torch.bincount(parent_rows, minlength=batch_size)
    if bool((counts == 0).any()):
        raise ValueError('Every particle needs at least one coarse parent')
    offsets = counts.cumsum(0)-counts
    local = torch.arange(p, device=scores.device)-offsets[parent_rows]
    width = oc*tc*nd
    slots = local[:, None]*width+torch.arange(width, device=scores.device)[None]
    rows = parent_rows[:, None]
    packed = torch.full((batch_size, int(counts.max())*width), torch.inf,
                        dtype=scores.dtype, device=scores.device)
    prior = torch.full_like(packed, -torch.inf, dtype=weight_dtype)
    packed[rows, slots] = scores.flatten(1)
    logp = pose_log_prior.to(weight_dtype)[..., None]+defocus_log_prior.to(weight_dtype)
    logp = logp-math.log(oc*tc)
    prior[rows, slots] = logp.expand_as(scores).flatten(1)
    selection = relion_weight_selection_batch(prior, packed, fraction,
        weight_dtype=weight_dtype, compact_positive=True, counters=counters)
    posterior = selection.posterior[rows, slots].reshape_as(scores)
    significant = selection.significant[rows, slots].reshape_as(scores)
    retained = (posterior.double()*significant).sum((1, 2, 3))
    mass = torch.zeros(batch_size*classes, device=scores.device, dtype=torch.float64)
    mass.index_add_(0, parent_rows*classes+parent_classes, retained)
    dm = torch.zeros((batch_size, nd), device=scores.device, dtype=torch.float64)
    dm.index_add_(0, parent_rows, posterior.double().sum((1, 2)))
    pose = selection.posterior64.reshape(batch_size, -1, nd).sum(-1)
    best = selection.best_index
    parent = offsets+best//width
    child = best % width
    return JointSelection(posterior, significant, selection.log_evidence, selection.pmax,
        selection.reported_significant_count, selection.significant_weight,
        mass.reshape(batch_size, classes), parent, child//(tc*nd), child//nd % tc,
        child % nd, dm, pose.max(1).values, mass.reshape(batch_size, classes).sum(1))


@dataclass
class JointExpectation:
    scores: object
    selection: JointSelection
    defoci: torch.Tensor
    reconstruction: object
    joint_diff2: torch.Tensor
    ctf_bank: object | None = None

    @property
    def class_mass(self): return self.selection.class_mass
    @property
    def pmax(self): return self.selection.pmax
    @property
    def significant_count(self): return self.scores.geometry['coarse'].reported_significant_count
    @property
    def log_likelihood_contribution(self): return self.selection.evidence-self.scores.log_sigma2.double()
    @property
    def posterior(self): return self.selection.posterior
    @property
    def significant(self): return self.selection.significant
    @property
    def diff2(self): return self.joint_diff2

    def best_values(self):
        s, g = self.selection, self.scores.geometry
        return (g['parent_class_indices'][s.best_parent],
                g['child_angles_deg'][s.best_parent, s.best_orientation],
                g['child_translations_angstrom'][s.best_parent, s.best_translation],
                g['child_direction_indices'][s.best_parent, s.best_orientation])

    def diagnostics(self):
        s = self.selection
        rows = torch.arange(len(self.defoci), device=self.defoci.device)
        mean = (s.defocus_marginal*self.defoci).sum(1)
        variance = (s.defocus_marginal*(self.defoci-mean[:, None]).square()).sum(1)
        edge = (s.defocus_marginal[:, 0]+s.defocus_marginal[:, -1]
                if self.defoci.shape[1]>1 else torch.zeros_like(mean))
        return dict(rlnCombineDefocusMAP=self.defoci[rows, s.best_defocus],
            rlnCombineDefocusMean=mean, rlnCombineDefocusStd=variance.clamp_min(0).sqrt(),
            rlnCombineDefocusEdgeMass=edge, rlnCombinePosePmax=s.pose_pmax,
            rlnCombineJointPmax=s.pmax, rlnCombineRetainedMass=s.retained_mass,
            rlnCombineFineSamples=s.count.double())
