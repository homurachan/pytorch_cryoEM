"""Six-dimensional E-step using the public optimized SPA fine scorers.

Defocus is streamed through shared projection stores. Images are prepared once,
not cloned into pseudo-particles. Only scalar fine scores/weights acquire a
defocus dimension. Weighted sums use the matching CTF for each slice.
"""
from dataclasses import replace
import numpy as np
import torch
from relion_torch.inference.execution_policy import candidate_budget
from relion_torch.auto_refine.worker import HalfOptimiser, HalfWorker, HalfDataset
from relion_torch.class3d.runner import make_alignment_config
from relion_torch.class3d.expectation import SplitParticleBatch
from relion_torch.class3d.optimiser import Moments3D
from relion_torch.optics.ctf import compute_ctf
from .config import ANCHOR, ASTIGMATISM
from .posterior import defocus_grid, select_joint, JointExpectation


class CombineOptimiser(HalfOptimiser):
    @property
    def combine_optimized(self):
        return self.options.combine_execution == 'optimized'

    def _posterior_batch_limit(self, engine, size):
        if not self.combine_optimized:
            # Retain the reference scheduler's historical feedback for A/B
            # comparisons; the optimized path uses exact current admission.
            observed=getattr(self,'_posterior_per_particle',0)
            capacity=max(1,engine.posterior_bytes//observed) if observed else size
            return min(self._batch_ceiling,capacity)
        # Exact admission is still performed after EVERY coarse pass and before
        # fine allocations. Isolate an outlier by recursive splitting of this
        # batch; a failed padded estimate must not throttle unrelated batches.
        # The persistent ceiling from actual CUDA OOM remains in force.
        self._perf_counters['combine_exact_batch_admissions'] = self._perf_counters.get('combine_exact_batch_admissions', 0)+1
        return min(size, self._batch_ceiling)

    def _factors(self, prepared, defoci):
        """Physical CTF and inherited optics/scale; never divide by old CTF."""
        frame = self.dataset.particles.iloc[prepared.indices]
        g = self.observation.groups[self.active_optics]
        params = self.observation.parameters(frame, self.active_optics)
        astig = torch.as_tensor(frame[ASTIGMATISM].to_numpy(copy=True), device=self.device, dtype=defoci.dtype)
        params = replace(params, defocus_u=defoci+astig, defocus_v=defoci-astig)
        raw = compute_ctf(self.dataset.box_size, g.pixel_size, params, device=self.device,
            dtype=prepared.like.real.dtype, frequency_grid=g.grid,
            frequency_matrix=g.matrix, gamma_offset=g.even_phase)
        # Model scales can be float64 even though Fourier kernels are float32.
        # Follow shared particle preparation at this observation boundary.
        effective = raw*prepared.old_scales.to(raw.dtype)[:, None, None]*g.mtf
        return replace(prepared, prediction=effective, numerator=effective, denominator=effective.square())

    def _score_prepared(self, p, engine, bank, timer, iteration):
        old_fraction = engine.config.adaptive_fraction
        try:
            engine.config.adaptive_fraction = self.options.coarse_fraction
            coarse = timer.call('combine.coarse_5d', engine.run_local_batch,
                p.like, p.prediction, p.sigma, offset_prior_angstrom=p.centres,
                orientation_prior_deg=self._angular_centres(p.indices),
                pixel_size=self.dataset.pixel_size, bank=bank)
        finally:
            engine.config.adaptive_fraction = old_fraction
        frame = self.dataset.particles.iloc[p.indices]
        # pandas Copy-on-Write may expose read-only metadata views. Give torch
        # writable storage without changing the DataFrame's ownership flags.
        anchors = torch.as_tensor(frame[ANCHOR].to_numpy(copy=True), device=self.device, dtype=torch.float64)
        defoci, log_prior_d = defocus_grid(anchors, self.options.defocus_range,
            self.options.defocus_step, self.options.defocus_sigma)
        counts = coarse.significant.flatten(1).sum(1)
        oc, tc, nd = 8**self.config.oversampling, 4**self.config.oversampling, defoci.shape[1]
        # Includes scores, packed joint selection, sorting, posterior, diagnostics
        # and a live score-only call. Candidate pixels have a separate tile cap.
        parents, b, largest = int(counts.sum()), len(p.indices), int(counts.max())
        estimated = parents*(96+oc*48+tc*16+oc*tc*nd*24)+b*largest*oc*tc*nd*144
        for name in ('fine_posterior_estimated_bytes', 'combine_posterior_estimated_bytes'):
            engine.memory_counters[name] = max(engine.memory_counters.get(name, 0), estimated)
        # Keep rejected padded estimates in diagnostic counters, but do not
        # feed them to the next batch or next iteration's memory planner.
        if not self.combine_optimized or estimated <= engine.posterior_bytes:
            engine.memory_counters['posterior_observed_bytes_per_particle'] = max(
                engine.memory_counters.get('posterior_observed_bytes_per_particle', 0), estimated//b)
        if estimated > engine.posterior_bytes:
            raise SplitParticleBatch('six-dimensional posterior exceeds its workspace budget', estimated)
        scores = torch.empty((parents, oc, tc, nd), device=self.device, dtype=p.like.real.dtype)
        base = None; ctf_bank = None
        if self.combine_optimized:
            from .scoring import CandidateCTFs, score_joint
            # Timers surround the complete batch, never individual defoci.
            ctf_bank = timer.call('combine.ctf_candidates', CandidateCTFs,
                self, p, defoci, candidate_budget(self))
            base = timer.call('combine.fine_scores', score_joint,
                self, p, engine, coarse, defoci, scores, ctf_bank)
        else:
            for d in range(nd):
                pd = timer.call('combine.ctf_candidates', self._factors, p, defoci[:, d])
                scored = timer.call('combine.fine_scores', engine.run_sparse_adaptive_batch,
                    p.like, pd.prediction, p.sigma, offset_prior_angstrom=p.centres,
                    orientation_prior_deg=None, pixel_size=self.dataset.pixel_size,
                    coarse=coarse, scores_only=True)
                scores[..., d].copy_(scored.diff2)
                if base is None: base = scored
                del pd, scored
        g = base.geometry
        selection = timer.call('combine.joint_posterior', select_joint, scores,
            g['parent_particle_indices'], g['parent_class_indices'], base.log_prior,
            log_prior_d, b, coarse.bank.number_of_classes, self.options.adaptive_fraction,
            weight_dtype=torch.float32 if self.options.weight_precision=='float32' else torch.float64,
            counters=engine.memory_counters)
        template = base.expectation(selection.posterior[..., 0], selection.significant[..., 0],
            evidence=selection.evidence, significant_count=selection.count, threshold=selection.threshold)
        # Build the current-size view before yielding/committing statistics so
        # scoring allocation failures can use the unchanged inherited retry path.
        template = engine.for_weighted_sums(template, pixel_size=self.dataset.pixel_size)
        self._perf_counters['combine_defocus_candidates'] = nd
        self._perf_counters['coarse_hypotheses'] += coarse.diff2.numel()
        self._perf_counters['fine_parents'] += parents
        self._perf_counters['fine_children'] += scores.numel()
        return JointExpectation(base, selection, defoci, template, scores, ctf_bank)

    def _accumulate(self, p, result, bps, grouper):
        if not isinstance(result, JointExpectation):
            return super()._accumulate(p, result, bps, grouper)
        if self.sizes.current_size != self.dataset.box_size:
            raise RuntimeError('Combine weighted sums require full-box reconstruction support')
        mode = self.options.combine_accumulation
        contracted = self.combine_optimized and (mode == 'contracted' or (mode == 'auto' and self.options.skip_gridding))
        if contracted:
            from .accumulation import accumulate_joint
            total = accumulate_joint(self, p, result, bps)
        else:
            if self.combine_optimized:
                self._perf_counters['combine_reference_statistics_batches'] = self._perf_counters.get('combine_reference_statistics_batches', 0)+1
            total = self._accumulate_slices(p, result, bps, grouper)
        self._record_joint_diagnostics(p, result)
        return total

    def _accumulate_slices(self, p, result, bps, grouper):
        s = result.selection
        rows = result.scores.geometry['parent_particle_indices']
        classes = result.scores.geometry['parent_class_indices']
        total = None
        for d in range(result.defoci.shape[1]):
            weights, keep = s.posterior[..., d], s.significant[..., d]
            if not bool(keep.any()): continue
            mass = (weights.double()*keep).sum((1, 2))
            cm = torch.zeros_like(s.class_mass).flatten()
            cm.index_add_(0, rows*s.class_mass.shape[1]+classes, mass)
            partial = replace(result.reconstruction, posterior=weights, significant=keep,
                parent_mass64=mass, class_mass=cm.reshape_as(s.class_mass))
            prepared = (result.ctf_bank.prepared(d) if result.ctf_bank is not None else
                        self._factors(p, result.defoci[:, d]))
            # The common accumulator contracts translations before insertion;
            # defocus contributions are summed in the same raw Fourier grids.
            # Full-box support means no per-particle highres supplement can be
            # counted repeatedly when streaming these slices.
            moments = super()._accumulate(prepared, partial, bps, grouper)
            if total is None: total = moments
            else:
                for name in Moments3D.__dataclass_fields__:
                    getattr(total, name).add_(getattr(moments, name))
        if total is None: raise RuntimeError('No retained joint posterior mass')
        return total

    def _record_joint_diagnostics(self, p, result):
        diag = result.diagnostics()
        # A proposal-boundary diagnostic; it cannot prove absent modes outside
        # the retained support. Users can test wider sigmas/fraction explicitly.
        _, angles, translations, _ = result.best_values()
        centres = self._angular_centres(p.indices)
        from relion_torch.geometry.euler import relion_euler_matrix
        from relion_torch.geometry.symmetry import angular_axis_distance
        a = relion_euler_matrix(*angles.double().unbind(1))
        c = torch.as_tensor(centres, device=self.device, dtype=torch.float64)
        c = relion_euler_matrix(*c.unbind(1))
        distance = angular_axis_distance(a, c, self.options.symmetry)
        diag['rlnCombineAngularChange'] = distance
        table = result.scores.geometry['child_translations_angstrom']
        limit = table.abs().amax((0, 1)).clamp_min(1e-8)
        diag['rlnCombinePoseBoundary'] = ((distance >= 2.5*min(self.options.angular_sigmas)) |
            (translations.abs() >= .95*limit).any(1)).double()
        values = {key: value.detach().cpu().numpy() for key, value in diag.items()}
        values['rows'] = np.asarray(p.indices, dtype=np.int64)
        self._combine_updates.append(values)

    def expectation_step(self, it):
        self._combine_updates = []
        packet = super().expectation_step(it)
        frame = packet['updated']
        for values in self._combine_updates:
            rows = values['rows']
            for key, value in values.items():
                if key != 'rows': frame.loc[rows, key] = value
            mean = values['rlnCombineDefocusMAP']
            astig = frame.loc[rows, ASTIGMATISM].to_numpy()
            frame.loc[rows, 'rlnDefocusU'] = mean+astig
            frame.loc[rows, 'rlnDefocusV'] = mean-astig
        self._combine_updates = []
        return packet


class CombineWorker(HalfWorker):
    def __init__(self, half_id, parent, options, state, device='cpu'):
        self.half_id = half_id
        self.dataset = HalfDataset(parent, half_id)
        opts = replace(options, device=str(device), output_root=type(options.output_root)(
            str(options.output_root)+f'_half{half_id}'), skip_expected_accuracy=True)
        cfg = make_alignment_config(opts, parent.star_path, device, state['iteration'], False)
        cfg.references = list(options.references)
        self.optimiser = CombineOptimiser(cfg, options=opts, dataset=self.dataset,
            initial_references=state['references'], half_id=half_id, checkpoint_state=state)
        self.optimiser.final_iteration = False
        self.packet = None
        self.park()
