"""Independent post-convergence six-dimensional SPA refinement."""
