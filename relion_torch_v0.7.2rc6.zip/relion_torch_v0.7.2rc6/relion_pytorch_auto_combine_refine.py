from relion_torch.cli.combine_refine import cli_main

if __name__ == '__main__':
    cli_main()
