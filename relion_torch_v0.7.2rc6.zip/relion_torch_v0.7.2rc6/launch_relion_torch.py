#!/usr/bin/env python3
"""Portable source launcher. Uses the selected Python environment's CUDA torch."""
from pathlib import Path
import importlib
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'src'))
COMMANDS = {'relion_pytorch_autopick': 'relion_torch.cli.autopick:main', 'relion_torch_autopick': 'relion_torch.cli.autopick:main', 'relion_torch_auto_combine_refine': 'relion_torch.cli.combine_refine:cli_main', 'relion_pytorch_auto_combine_refine': 'relion_torch.cli.combine_refine:cli_main', 'relion_torch_3d_auto_combine_refine': 'relion_torch.cli.combine_refine:cli_main', 'relion_pytorch_auto_refine': 'relion_torch.cli.auto_refine:cli_main', 'relion_torch_auto_refine': 'relion_torch.cli.auto_refine:cli_main', 'relion_pytorch_refine': 'relion_torch.cli.auto_refine:cli_main', 'relion_pytorch_ctf_refine': 'relion_torch.cli.ctf_refine:main', 'relion_torch_ctf_refine': 'relion_torch.cli.ctf_refine:main', 'relion_torch_class3d': 'relion_torch.cli.class3d:main', 'relion_torch_class2d': 'relion_torch.cli.class2d:main', 'relion_torch_align': 'relion_torch.cli.align:main', 'relion_torch_refine': 'relion_torch.cli.refine:main', 'relion_torch_reconstruct': 'relion_torch.cli.reconstruct:main', 'relion_torch_fixedpose': 'relion_torch.cli.fixed_pose:main', 'relion_torch_inspect': 'relion_torch.cli.inspect_star:main'}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ('-h', '--help'):
        from relion_torch.version import __version__
        print(f'RELION-Torch {__version__} portable Windows/source distribution')
        print('Usage: python launch_relion_torch.py COMMAND [OPTIONS]')
        print('Environment check: python launch_relion_torch.py --check-cuda')
        print('Commands:\n  '+'\n  '.join(COMMANDS))
        return 0
    if argv[0] == '--version':
        from relion_torch.version import __version__
        print(__version__)
        return 0
    if argv[0] == '--check-cuda':
        import torch
        result = dict(python=sys.executable, torch=torch.__version__, cuda_runtime=torch.version.cuda,
                      cuda_available=torch.cuda.is_available(), package_source=str(ROOT/'src'))
        if torch.cuda.is_available():
            x = torch.ones((16, 16), device='cuda')
            torch.fft.rfft2(x)
            torch.cuda.synchronize()
            result['gpus'] = [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]
            result['cuda_fft_check'] = 'passed'
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result['cuda_available'] else 1
    command = argv.pop(0)
    if command not in COMMANDS:
        print('Unknown command: '+command, file=sys.stderr)
        return 2
    if argv == ['--version']:
        from relion_torch.version import __version__
        print(__version__)
        return 0
    module, entry = COMMANDS[command].split(':')
    sys.argv = [command, *argv]
    return getattr(importlib.import_module(module), entry)()


if __name__ == '__main__':
    raise SystemExit(main())
