#!/usr/bin/env python3
"""Run auto-refine directly from this complete source distribution."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from relion_torch.cli.auto_refine import cli_main

if __name__=='__main__':cli_main()
