"""Contract joint defocus/translation weights before shared 3-D insertion.

Linear Fourier numerator/denominator sums are unchanged algebraically. No CTF
at a posterior mean is substituted. Floating-point summation order changes.
All tiles are admitted before committing a Fourier update; insertion failures
are propagated and never retried against a partially updated grid.
"""
import numpy as np
import torch
from dataclasses import replace
from relion_torch.inference.execution_policy import candidate_budget
from relion_torch.class3d.optimiser import Moments3D
from relion_torch.class2d.accumulation_statistics import ParticleNoiseAccumulator
from relion_torch.alignment.model_statistics import accumulate_scale_statistics_
from relion_torch.alignment.core import _euler_matrix
from relion_torch.geometry.grids import signed_fft_indices
from relion_torch.inference.alignment import rounded_shell_indices_2d


class CombineGrid:
    """Insert one class using the full reconstruction grid of this optics batch."""
    def __init__(self, owner, pool):
        self.pool = pool
        self.transform, self.scale = owner.observation.reconstruction_transform(
            owner.active_optics, owner.dataset.box_size, owner.dataset.pixel_size)
        self.chunk = owner.config.backprojector_chunk_size
        self.tiled = owner.options.auto_refine_kernels == 'rc10'
        self.reserved_bytes = 0
        pool.fusion_mode = owner.options.local_gridding
        if not owner.options.skip_gridding:
            # Reuse rc14's rFFT mapping and spherical edge test under preweighting.
            pool.fusion_mode = 'mapped_required' if pool.fusion_mode == 'required' else 'mapped'

    def insert(self, numerator, denominator, angles):
        size = numerator.shape[-2]
        num = numerator.reshape(-1, size, size//2+1)
        den = denominator.reshape_as(num.real)
        rotations = (self.transform @ _euler_matrix(angles.reshape(-1, 3))) * self.scale
        self.pool.add(0, num, rotations, den.new_ones(()).expand_as(den), den,
                      orientation_chunk_size=self.chunk, host_unit_count=True, tiled_gridding=self.tiled)


def device_grid(owner, pool):
    opts = owner.options
    if (owner.device.type == 'cuda' and owner.combine_optimized and owner.optimized
            and opts.combine_accumulation != 'reference' and not opts.sirm and not opts.do_mwtcf
            and opts.local_fusion != 'off' and opts.auto_backprojection == 'device'
            and opts.local_gridding in ('auto', 'required')):
        return CombineGrid(owner, pool)
    return None


def prepare_slice_projections(owner, result, grid):
    """Reuse full-box references across defoci within the current optics batch."""
    r = result.reconstruction
    blocks = r.projection_blocks
    source = blocks.projections
    budget = candidate_budget(owner)
    n = owner.sizes.current_size
    min_tile = n*(n//2+1)*8*(r.translation_children+6*r.orientation_children+12)+256*r.orientation_children*r.translation_children
    scratch = min_tile + min(32*2**20, budget//16)
    bank = result.ctf_bank
    if bank.reserved_bytes and budget-bank.reserved_bytes < scratch:
        bank.cache = None
        bank.reserved_bytes = 0
    grid.reserved_bytes = bank.reserved_bytes
    if torch.is_tensor(source) or result.defoci.shape[1] < 2:
        return r
    remaining = budget-grid.reserved_bytes
    max_bytes = min(128 * 2**20, remaining//8)
    per_block = source.shape[1]*source.shape[2]*source.shape[3]*source.element_size()
    if per_block > max_bytes:
        return r
    retained = result.significant.flatten(1).any(1)
    used = torch.unique(r.parent_projection_block_indices[retained])
    payload = len(used)*per_block
    if not len(used) or payload > max_bytes or remaining-payload < scratch:
        return r
    data = torch.empty((len(used), *source.shape[1:]), dtype=source.dtype, device=source.device)
    chunk = max(1, min(len(used), (16 * 2**20)//per_block))
    for start in range(0, len(used), chunk):
        data[start:start+chunk].copy_(source.index_select(0, used[start:start+chunk]))
    # Unused blocks have zero retained weight at every defocus. _parent_tiles
    # removes these rows before looking up references.
    lookup = torch.zeros(len(blocks.keys), device=used.device, dtype=torch.long)
    lookup[used] = torch.arange(len(used), device=used.device)
    selected = replace(blocks, projections=data, keys=blocks.keys[used], class_indices=blocks.class_indices[used],
                       coarse_orientation_indices=blocks.coarse_orientation_indices[used], angles_deg=blocks.angles_deg[used])
    grid.reserved_bytes += payload
    c = owner._perf_counters
    c['combine_slice_projection_batches'] = c.get('combine_slice_projection_batches', 0) + 1
    c['combine_slice_projection_peak_bytes'] = max(c.get('combine_slice_projection_peak_bytes', 0), payload)
    return replace(r, projection_blocks=selected, parent_projection_block_indices=lookup[r.parent_projection_block_indices])


def accumulate_joint(owner, p, joint, bps):
    r, s, bank = joint.reconstruction, joint.selection, joint.ctf_bank
    n, b, device = owner.dataset.box_size, len(p.indices), owner.device
    oc, tc, nd = joint.posterior.shape[1:]
    stat = torch.float32 if owner.options.accumulation_precision == 'float32' else torch.float64
    pixels = n*(n//2+1)
    shell = rounded_shell_indices_2d(n, device)
    yy = signed_fft_indices(n, device=device)
    active = (shell <= n//2)&~((torch.arange(n//2+1, device=device)[None] == 0)&(yy[:, None] < 0))
    idx, sh = torch.nonzero(active.flatten(), as_tuple=False).flatten(), shell[active]
    noise = torch.zeros(b, n//2+1, device=device, dtype=stat)
    xa = torch.zeros(b, device=device, dtype=stat); aa = torch.zeros_like(xa)
    offset = torch.zeros((), device=device, dtype=stat)
    directions = torch.zeros(1, len(owner.sampling.directions), device=device, dtype=stat)
    work = candidate_budget(owner)-bank.reserved_bytes
    reducer = ParticleNoiseAccumulator(noise, sh, max_pixel_bytes=min(32*2**20, max(0, work//32)), allow_float32=True)
    work -= reducer.reserved_bytes
    dc = min(nd, owner.options.combine_defocus_chunk)
    def cost(d): return pixels*(oc*(96+24*d)+tc*24+d*64+96)+oc*tc*nd*16
    if cost(dc)>work: dc=1
    if cost(dc)>work: raise MemoryError('One contracted combine statistics tile exceeds candidate workspace')
    limit = max(1, min(owner.options.candidate_chunk_size, work//cost(dc)))
    # Sort small parent metadata once; neighboring coarse translations with
    # identical particle/orientation can share one insertion within a tile.
    meta = torch.stack((r.parent_particle_indices, r.parent_orientation_indices,
                        r.parent_projection_block_indices), 1).detach().cpu().numpy()
    keep = joint.significant.flatten(1).any(1).detach().cpu().numpy()
    selected = np.flatnonzero(keep)
    selected = selected[np.lexsort((meta[selected, 1], meta[selected, 0]))]
    inv = torch.where(p.sigma>0, p.sigma.reciprocal(), 0.)[:, shell.clamp_max(n//2)].flatten(1)
    # Use the existing guarded fused insertion when the caller allows it.
    # Auto selection of this whole path is conservative when preweight is on.
    bps.fusion_mode = owner.options.local_gridding
    grid = device_grid(owner, bps)
    for start in range(0, len(selected), limit):
        ids = torch.as_tensor(selected[start:start+limit], device=device)
        rows = r.parent_particle_indices[ids]
        weights = (joint.posterior[ids]*joint.significant[ids]).float()
        with owner._detail_timer.section('combine.contract.project'):
            refs = r.projection_blocks.projections.index_select(0, r.parent_projection_block_indices[ids]).flatten(-2)
        phases = r.phase_factors[r.parent_translation_indices[ids]].flatten(-2)
        a = torch.zeros(len(ids), oc, pixels, device=device, dtype=torch.complex64)
        power_factor = torch.zeros_like(a.real)
        ctf_rows = bank.for_rows(rows)
        token = owner._detail_timer.start('combine.contract.defocus')
        for d in range(0, nd, dc):
            end = min(d+dc, nd)
            ctf = ctf_rows(d, end).flatten(-2)
            w = weights[..., d:end]
            # Contract fine translations first, then the defocus block. The
            # common complex matrix helper retains its established precision.
            phase_sum = owner._batch_matrix_weighted_sum(w.permute(0, 1, 3, 2).flatten(1, 2), phases)
            a.add_((phase_sum.reshape(len(ids), oc, end-d, pixels)*ctf[:, None]).sum(2))
            power_factor.add_(torch.bmm(w.sum(2), ctf.square()))
        owner._detail_timer.stop(token)
        token = owner._detail_timer.start('combine.contract.statistics')
        mass = weights.sum((2, 3))
        x = p.like[rows].flatten(1)
        cross = (refs.conj()*x[:, None]*a).real
        power = refs.abs().square()*power_factor
        residual = (x.abs().square()*mass.sum(1)[:, None]+power.sum(1)-2*cross.sum(1)).clamp_min(0)
        reducer.add(rows, residual.index_select(-1, idx).to(stat))
        if owner.do_scale:
            reliable = owner.data_vs_prior[0][sh][None].expand(len(rows), -1)>3.
            accumulate_scale_statistics_(xa, aa, rows, cross.index_select(-1, idx),
                power.index_select(-1, idx), reliable, p.old_scales[rows])
        d2 = (r.child_translations_angstrom[ids]-p.centres[rows, None]).square().sum(-1)
        offset += (weights.sum((1, 3)).to(stat)*d2.to(stat)).sum()
        di = owner._coarse_direction_indices(r.parent_orientation_indices[ids])
        # Direction statistics preserve the caller's requested precision.
        dm = (joint.posterior[ids].to(stat)*joint.significant[ids]).sum((1, 2, 3))
        directions[0].index_add_(0, di, dm)
        numerator = p.unmasked[rows].flatten(1)[:, None]*a*inv[rows, None]
        denominator = power_factor*inv[rows, None]
        owner._detail_timer.stop(token)
        host = selected[start:start+limit]
        _, first, groups = np.unique(meta[host, :2], axis=0, return_index=True, return_inverse=True)
        if len(first) < len(ids):
            group_ids = torch.as_tensor(groups, device=device)
            ng = numerator.new_zeros((len(first), oc, pixels)); dg = denominator.new_zeros(ng.shape)
            ng.index_add_(0, group_ids, numerator); dg.index_add_(0, group_ids, denominator)
            numerator, denominator = ng, dg
        angles = r.child_angles_deg[ids[torch.as_tensor(first, device=device)]]
        with owner._detail_timer.section('combine.contract.insert'):
            if grid is not None:
                grid.insert(numerator.reshape(-1,n,n//2+1), denominator.reshape(-1,n,n//2+1), angles)
            else:
                rotations = owner.observation.reconstruction_rotations(_euler_matrix(angles.reshape(-1, 3)),
                    owner.active_optics, n, owner.dataset.pixel_size)
                num = numerator.reshape(-1, n, n//2+1); den = denominator.reshape_as(num.real)
                bps.add(0, num, rotations, torch.ones_like(den), den,
                    orientation_chunk_size=owner.config.backprojector_chunk_size)
        c = owner._perf_counters
        c['backprojector_calls'] += 1; c['accumulation_tiles'] += 1
        c['combine_contracted_insert_rows'] = c.get('combine_contracted_insert_rows', 0)+len(first)*oc
        c['combine_contracted_parent_rows'] = c.get('combine_contracted_parent_rows', 0)+len(ids)
        c['combine_contracted_tiles'] = c.get('combine_contracted_tiles', 0)+1
    reducer.finish()
    ids = getattr(owner, '_compact_direction_ids', None)
    if ids is not None:
        expanded = directions.new_zeros((1, owner._full_direction_count))
        expanded[:, torch.as_tensor(ids, device=device)] = directions
        directions = expanded
    owner._perf_counters['combine_statistics_workspace_estimated_bytes'] = max(owner._perf_counters.get(
        'combine_statistics_workspace_estimated_bytes', 0), bank.reserved_bytes+reducer.reserved_bytes+limit*cost(dc))
    return Moments3D(s.class_mass.sum(0).to(stat), directions, offset, noise, xa, aa)
