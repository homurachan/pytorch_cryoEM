"""Shared exact-form Gaussian/CC scoring of bounded SPA observation tiles."""
import torch


def score_prediction_tile(shifted, prediction, invsigma, highres, *, cc=False, image_norm=None):
    """Score [B,T,F] observations against [B,O,F] predictions -> [B,O,T].

    CC evaluates only normalized correlation; it does not evaluate and discard
    a second Gaussian score. CTF/scale must already be in ``prediction``.
    An optional image norm can be per image [B] or per shifted image [B,T].
    """
    weighted = prediction if cc else prediction * invsigma[:, None, :]
    cross = (torch.bmm(shifted.real, weighted.real.transpose(1, 2))
             + torch.bmm(shifted.imag, weighted.imag.transpose(1, 2))).transpose(1, 2)
    power = prediction.real.square() + prediction.imag.square()
    pnorm = power.sum(-1) if cc else (power * invsigma[:, None, :]).sum(-1)
    if image_norm is None:
        xpower = shifted.real.square() + shifted.imag.square()
        xnorm = xpower.sum(-1) if cc else (xpower * invsigma[:, None, :]).sum(-1)
    else:
        xnorm = image_norm[:, None] if image_norm.ndim == 1 else image_norm
    if cc:
        return cross / (pnorm[:, :, None] * xnorm[:, None, :]).clamp_min(torch.finfo(shifted.real.dtype).tiny).sqrt()
    return (.5 * (pnorm[:, :, None] + xnorm[:, None, :] - 2 * cross)).clamp_min(0) + highres[:, None, None]
