"""GPU splat for strict-resolution Combine using the reference coordinates and mask."""
import importlib.util
import warnings

import torch


_ready = set()
_disabled = set()


def _insert(bp, coords, values, weights):
    from .gridding_cuda_kernel import mapped_insert_kernel
    from .fused_projection import _complex_parts
    count = values.numel()
    if count:
        mapped_insert_kernel[((count+255)//256,)](
            bp.numerator_real, bp.numerator_imag, bp.denominator, coords.contiguous(),
            _complex_parts(values), weights.contiguous(), count, P=bp.compact_size, BLOCK=256,
            enable_fp_fusion=False)


def prepare(bp, images, rotations, weights, required=False):
    if (images.device.type != 'cuda' or images.dtype != torch.complex64 or rotations.dtype != torch.float32
            or bp.reference_dim != 3 or bp.denominator.dtype != torch.float32 or weights.dtype != torch.float32
            or importlib.util.find_spec('triton') is None):
        if required:
            raise RuntimeError('Mapped gridding requires Triton and FP32 CUDA 3D inputs')
        return None
    key = (str(images.device), bp.compact_size)
    if key in _ready:
        return _insert
    if key in _disabled and not required:
        return None
    try:
        from relion_torch.fourier.backprojector import FourierBackprojector
        from relion_torch.fourier.interpolation import splat_half_spectrum_
        from .gridding_cuda_kernel import mapped_insert_kernel
        from .fused_projection import _complex_parts
        # Check conjugation, wrapping, half-space edges and colliding points on
        # a private grid. Compile for the live grid size before committing data.
        sample = FourierBackprojector.create(8, padding_factor=1, device=images.device)
        coords = images.real.new_tensor([[1.25, -2.5, .3], [-1.25, 2.5, -.3],
                                         [0., -3., 1.], [4.5, 0., 0.], [6., 0., 0.]])
        values = torch.complex(coords[:,0], coords[:,1])
        w = coords[:,0].abs()+.5
        ref = [torch.zeros_like(sample.denominator) for _ in range(3)]
        splat_half_spectrum_(*ref, coords, values, w)
        _insert(sample, coords, values, w)
        for a,b in zip((sample.numerator_real,sample.numerator_imag,sample.denominator),ref):
            torch.testing.assert_close(a,b,rtol=2e-6,atol=1e-6)
        mapped_insert_kernel.warmup(bp.numerator_real, bp.numerator_imag, bp.denominator, coords,
            _complex_parts(values), w, len(w), P=bp.compact_size, BLOCK=256, enable_fp_fusion=False, grid=(1,))
    except (torch.cuda.OutOfMemoryError, MemoryError):
        raise
    except Exception as exc:
        if required:
            raise
        warnings.warn(f'Mapped gridding preflight failed. Using PyTorch insertion. {exc}', RuntimeWarning)
        _disabled.add(key)
        return None
    _ready.add(key)
    return _insert
