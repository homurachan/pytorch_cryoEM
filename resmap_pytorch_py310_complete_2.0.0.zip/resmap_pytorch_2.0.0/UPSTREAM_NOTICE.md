# Upstream attribution and license notice

This project is a Python 3 / PyTorch port designed to reproduce the behavior of
ResMap 1.1.5 by Alp Kucukelbir and collaborators.

Please cite the original method when using it scientifically:

A. Kucukelbir, F. J. Sigworth, and H. D. Tagare, "Quantifying the local
resolution of cryo-EM density maps," Nature Methods 11, 63-65 (2014).

The public upstream source identifies its license as Creative Commons
Attribution-NonCommercial-NoDerivs 3.0 (CC BY-NC-ND 3.0). That license can
restrict distribution of modified versions. This archive is supplied for
private, non-commercial research, testing, and local migration. Obtain legal
advice or written permission from the original authors before public
redistribution, publication of binaries, or integration into another released
software package.

No warranty is provided. This notice is not legal advice.

## MonoRes integration in 2.0.0

The MonoRes implementation is derived from the user's uploaded monores-master.zip,
SHA-256 ad5ab6da539b91ea16a7fbeca2e2a20c25685e17c89c1b49314d5f55956b75af.
That archive is preserved as source files in upstream/monores-master/ for
attribution and numerical comparisons. Its author information names Jose Luis
Vilas and Carlos Oscar S. Sorzano; upstream code comments cite the corresponding
Xmipp implementation. No new upstream license grant is asserted by this package.

Please cite J. L. Vilas et al., "MonoRes: Automatic and Accurate Estimation of
Local Resolution for Electron Microscopy Maps", Structure 26, 337–344 (2018).
The ResMap redistribution notice above remains in force; integration and file
separation do not remove upstream licensing conditions.
