# Release 2.0.0

## Exact source inputs

- resmap_pytorch_py310_complete_1.1.5.2.zip
  SHA-256: d000604f4cbca6091c0dceaa563ca6aa3749ec57681b4496288a70c4fea0b158
- monores-master.zip
  SHA-256: ad5ab6da539b91ea16a7fbeca2e2a20c25685e17c89c1b49314d5f55956b75af

See SOURCE_INPUTS_SHA256.json. No repository snapshot was substituted.

## Entrypoints

- python ResMap.py --method resmap|monores ...
- resmap-pytorch --method resmap|monores ... (after wheel/source installation)

Both report version 2.0.0. Source target: Python >=3.10. Runtime dependencies
are the same as the ResMap 1.1.5.2 package; no compiled extension was added.

## Contents

Complete source tree, new MonoRes backend, retained ResMap computation modules,
English/Chinese instructions, tests and source references, validation logs,
provenance notices, requirements/environment files, and dist/ wheel.

FILE_SHA256.json lists all shipped files other than itself. External release
artifacts have a separate SHA256SUMS.txt. The optional text upgrade patch contains
source/tests/docs changes only, not a wheel. Apply it from a clean extracted
1.1.5.2 root with `git apply <patch>`; do not install an old wheel remaining under
that old tree's dist/ directory. The complete 2.0.0 ZIP needs no old installation.

## Verification

62 tests passed; two CUDA-only cases skipped because CUDA was unavailable.
Actual isolated-wheel install and both method CLIs passed. See VALIDATION.md for
precise runtime limitations, including the absence of a Python 3.10 runtime and
NVIDIA GPU in the build environment. The GUI class is unchanged but was not
interactively rendered.
