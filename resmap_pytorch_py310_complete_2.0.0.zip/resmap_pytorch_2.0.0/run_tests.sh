#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m compileall -q ResMap.py ResMap_algorithm.py ResMap_torch.py monores_backend
python -m pytest -q "$@"
