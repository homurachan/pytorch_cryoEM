from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import mrcfile
import numpy as np
import pytest
import torch

import ResMap
from monores_backend.algorithm import MonoResConfig, run
from monores_backend.io import input_mask, read_volume
from monores_backend import utils as u
from test_monores_core import uploaded

ROOT = Path(__file__).resolve().parents[1]


def _write(path, data, sampling=1.25):
    with mrcfile.new(path, overwrite=True) as handle:
        handle.set_data(np.asarray(data, dtype=np.float32))
        handle.voxel_size = sampling
        handle.header.origin = (12.5, -7.5, 3.)
        handle.header.nxstart = 3
        handle.header.nystart = 2
        handle.header.nzstart = -1
        handle.header.cellb = (90., 90., 90.)
        handle.header.label[0] = b"spatial metadata test"
        handle.header.nlabl = 1


@pytest.fixture
def inputs(tmp_path):
    n = 32
    z, y, x = np.indices((n,) * 3) - n // 2
    r2 = x*x + y*y + z*z
    signal = 4*np.exp(-r2/(2*3.5**2))*(1+.2*np.cos(2*np.pi*x/5))
    rng = np.random.default_rng(712)
    data = dict(single=signal+rng.normal(0,.1,signal.shape),
                half1=signal+rng.normal(0,.15,signal.shape),
                half2=signal+rng.normal(0,.15,signal.shape),
                mask=(r2 < 9**2), softmask=(r2 < 9**2)*.3)
    for name, vol in data.items():
        _write(tmp_path / (name + ".mrc"), vol)
    return {name: str(tmp_path / (name + ".mrc")) for name in data}


@pytest.mark.parametrize("half", [False, True])
def test_integrated_float64_matches_uploaded_end_to_end(inputs, tmp_path, uploaded, half):
    orig_dir = tmp_path / "original"
    cfg = MonoResConfig(input1=inputs["half1" if half else "single"],
                        input2=inputs["half2"] if half else None,
                        mask_path=inputs["mask"], max_resolution=10,
                        noise_only_in_halves=half, device="cpu", threads=2,
                        cliff="legacy", output_dir=str(tmp_path / "integrated"), create_chimera=False)
    args = uploaded.monores.build_parser().parse_args(
        ["--vol", cfg.input1, "--mask", inputs["mask"], "--sampling_rate", "1.25",
         "--maxRes", "10", "--device", "cpu", "-o", str(orig_dir)] +
        (["--vol2", inputs["half2"], "--noiseonlyinhalves"] if half else []))
    old_threads = torch.get_num_threads()
    torch.set_num_threads(2)
    try:
        uploaded.monores.run(args)
    finally:
        torch.set_num_threads(old_threads)
    result = run(cfg)
    assert not any(row["nyquist_padded"] for row in result["iterations"])
    for name in ("refinedMask.mrc", "monoresResolutionMap.mrc", "monoresResolutionChimera.mrc"):
        with mrcfile.open(orig_dir/name) as old, mrcfile.open(Path(cfg.output_dir)/name) as new:
            np.testing.assert_array_equal(old.data, new.data)
            assert float(new.header.origin.x) == 12.5
            assert int(new.header.nxstart) == 3
    if half:
        with mrcfile.open(Path(cfg.output_dir)/"meanMap.mrc") as new, mrcfile.open(orig_dir/"meanMap.mrc") as old:
            np.testing.assert_array_equal(old.data, new.data)


@pytest.mark.parametrize("dtype", ["float64", "float32"])
def test_fast_vs_legacy_final_maps_and_thresholds(inputs, tmp_path, dtype):
    cfg = MonoResConfig(input1=inputs["single"], mask_path=inputs["mask"],
                        max_resolution=10, device="cpu", threads=2,
                        dtype=dtype, create_chimera=False)
    original = run(replace(cfg, cliff="legacy"), write_output=False)
    fast = run(replace(cfg, cliff="fast", cliff_chunk=7), write_output=False)
    assert original["noise_radius"] == fast["noise_radius"]
    np.testing.assert_array_equal(original["raw_resolution_map"], fast["raw_resolution_map"])
    np.testing.assert_array_equal(original["resolution_map"], fast["resolution_map"])
    assert [r["threshold"] for r in original["iterations"]] == [r["threshold"] for r in fast["iterations"]]


@pytest.mark.parametrize("dtype", ["float64", "float32"])
def test_half_maps_dtype_soft_mask_and_explicit_min(inputs, tmp_path, dtype):
    cfg = MonoResConfig(input1=inputs["half1"], input2=inputs["half2"],
                        mask_path=inputs["softmask"], min_resolution=4,
                        max_resolution=10, dtype=dtype, device="cpu", threads=2,
                        noise_only_in_halves=True, output_dir=str(tmp_path/dtype))
    result = run(cfg)
    assert result["dtype"] == dtype
    assert result["raw_resolution_map"].dtype == np.dtype(dtype)
    assert result["resolution_map"].dtype == np.dtype(dtype)
    assert all(4 <= r["resolution"] <= 10 for r in result["iterations"])
    assert result["iterations"][-1]["resolution"] == 4
    assert np.all(result["resolution_map"][result["mask"]] >= 4)
    raw = read_volume(inputs["mask"]).matrix
    with mrcfile.open(tmp_path/dtype/"inputMask.mrc") as h:
        np.testing.assert_array_equal(h.data, raw)
    for name, path in result["outputs"].items():
        if not str(path).endswith(".mrc"):
            continue
        with mrcfile.open(path) as h:
            np.testing.assert_allclose([h.header.origin.x,h.header.origin.y,h.header.origin.z], [12.5,-7.5,3])
            assert int(h.header.nxstart) == 3 and int(h.header.nystart) == 2 and int(h.header.nzstart) == -1
            np.testing.assert_allclose(float(h.voxel_size.x), 1.25)
            assert h.data.dtype == np.float32
            assert np.isfinite(h.data).all()
    report = json.loads((tmp_path/dtype/"monores_run.json").read_text())
    assert report["pVal_used"] is False
    assert report["significance"] == .95
    assert report["half_maps"] is True
    script = (tmp_path/dtype/"monores_chimera.cmd").read_text()
    assert "meanMap.mrc" in script and "monoresResolutionChimera.mrc" in script
    assert "_resmap" not in script


def test_soft_mask_nonzero_including_negative(inputs):
    obj = read_volume(inputs["mask"])
    soft = read_volume(inputs["softmask"])
    np.testing.assert_array_equal(input_mask(inputs["softmask"], obj.matrix), obj.matrix.astype(bool))
    soft.matrix[0,0,0] = -0.000001
    _write(inputs["softmask"], soft.matrix)
    assert input_mask(inputs["softmask"], obj.matrix)[0,0,0]


def test_automatic_mask_and_original_sort_in_gaussian_mode(inputs, tmp_path, monkeypatch):
    count = []
    original = torch.sort
    def tracked(*a, **kw):
        count.append(True)
        return original(*a, **kw)
    monkeypatch.setattr(torch, "sort", tracked)
    cfg = MonoResConfig(input1=inputs["single"], max_resolution=10,
                        device="cpu", threads=2, gaussian=True,
                        output_dir=str(tmp_path / "auto"), create_chimera=False)
    result = run(cfg)
    assert count and np.isfinite(result["resolution_map"]).all()
    assert (tmp_path/"auto"/"inputMask.mrc").exists()


def test_nyquist_reached_in_full_pipeline(tmp_path):
    # Strong spatially confined high-frequency signal remains above small
    # independent half-map noise through the endpoint.
    n = 16
    z,y,x = np.indices((n,)*3)-n//2
    mask = (x*x+y*y+z*z) < 5**2
    rng = np.random.default_rng(892)
    signal = rng.normal(size=mask.shape) * mask * 10
    paths = []
    for i in range(2):
        path=tmp_path/("h%d.mrc" % i)
        _write(path, signal+rng.normal(size=mask.shape)*.005, sampling=1)
        paths.append(str(path))
    mask_path=tmp_path/"mask.mrc"
    _write(mask_path, mask, sampling=1)
    result = run(MonoResConfig(input1=paths[0], input2=paths[1], mask_path=str(mask_path),
                              max_resolution=4, device="cpu", threads=2,
                              noise_only_in_halves=True, output_dir=str(tmp_path/"nyq"),
                              create_chimera=False))
    final = result["iterations"][-1]
    assert final["frequency"] == .5 and final["nyquist_padded"]
    assert final["evaluation_frequency"] == 7/16
    assert np.isfinite(result["resolution_map"]).all()
    assert np.isfinite(result["raw_resolution_map"]).all()


def test_cli_pval_is_not_forwarded_and_dispatch_is_early(monkeypatch):
    from monores_backend import algorithm
    configs = []
    monkeypatch.setattr(algorithm, "run", lambda config, **kw: configs.append(config))
    monkeypatch.setattr(ResMap, "ResMap_algorithm", lambda **kw: pytest.fail("ResMap ran on MonoRes input"))
    for pval in ("0.05", "0.0001", "999", "nan"):
        assert ResMap.main(["--method","monores","--noguiSingle","missing.mrc", "--pVal",pval,
                           "--minRes","4","--maxRes","10"]) == 0
    assert all(c.significance == .95 for c in configs)
    assert all(c.min_resolution == 4 for c in configs)
    assert not hasattr(configs[0], "p_value")


def test_real_cli_pval_does_not_change_results(inputs, tmp_path):
    results = []
    for value in (".05", "7"):
        output = tmp_path / ("pv"+value)
        assert ResMap.main(["--method","monores", "--noguiSingle",inputs["single"],
                           "--maskVol",inputs["mask"], "--maxRes","10", "--device","cpu",
                           "--pVal",value,"--noChimeraScript", "-o",str(output)]) == 0
        with mrcfile.open(output/"monoresResolutionMap.mrc") as h:
            results.append(h.data.copy())
    np.testing.assert_array_equal(*results)


def test_default_resmap_cli_arguments_are_unchanged(inputs, monkeypatch):
    captured=[]
    monkeypatch.setattr(ResMap,"ResMap_algorithm",lambda **kw: captured.append(kw))
    assert ResMap.main(["--noguiSingle",inputs["single"]]) == 0
    assert captured[0]["minRes"] == 0
    assert captured[0]["maxRes"] == 0
    assert captured[0]["stepRes"] == 1
    assert captured[0]["pValue"] == .05
    assert captured[0]["prewhiten"] == "auto"
    assert captured[0]["kernelMode"] == "legacy-python2"


def test_monores_cli_does_not_import_resmap_algorithm():
    code = ("import sys, ResMap; "
            "from monores_backend import algorithm; "
            "algorithm.run=lambda *a,**k: None; "
            "ResMap.main(['--method','monores','--noguiSingle','unused.mrc']); "
            "assert 'ResMap_algorithm' not in sys.modules; "
            "assert 'ResMap_spectrumTools' not in sys.modules")
    subprocess.run([sys.executable,"-c",code], cwd=ROOT, check=True, capture_output=True)


def test_invalid_inputs_and_modes(inputs, tmp_path):
    with pytest.raises(SystemExit) as exc:
        ResMap.main(["--method","monores"])
    assert exc.value.code == 2
    with pytest.raises(ValueError,match="requires two half"):
        run(MonoResConfig(input1=inputs["single"],noise_only_in_halves=True))
    bad = read_volume(inputs["single"]).matrix
    bad[0,0,0] = np.nan
    path = tmp_path/"nan.mrc"
    with pytest.warns(RuntimeWarning, match="NaN"):
        _write(path,bad)
    with pytest.raises(ValueError,match="NaN"):
        run(MonoResConfig(input1=str(path)))


def test_half_geometry_mismatch(inputs):
    with mrcfile.open(inputs["half2"], mode="r+") as h:
        h.header.origin.x += 10
    with pytest.raises(ValueError,match="origins disagree"):
        run(MonoResConfig(input1=inputs["half1"],input2=inputs["half2"],device="cpu"))


def test_input_is_not_overwritten(inputs, tmp_path):
    path = tmp_path/"meanMap.mrc"
    path.write_bytes(Path(inputs["single"]).read_bytes())
    with pytest.raises(ValueError,match="overwrite an input"):
        run(MonoResConfig(input1=str(path),output_dir=str(tmp_path),device="cpu"))


def test_noncubic_input_is_rejected(tmp_path):
    path = tmp_path/"noncubic.mrc"
    _write(path,np.ones((8,9,10)))
    with pytest.raises(ValueError,match="cubic"):
        run(MonoResConfig(input1=str(path),device="cpu"))
