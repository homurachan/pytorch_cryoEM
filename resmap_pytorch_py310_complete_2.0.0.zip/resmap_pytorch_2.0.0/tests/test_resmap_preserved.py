import hashlib
import json
from pathlib import Path


def test_resmap_1152_calculation_and_io_files_are_byte_identical():
    root = Path(__file__).resolve().parents[1]
    hashes = json.loads((root/"tests"/"resmap_1152_core_sha256.json").read_text())
    for name, expected in hashes.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest() == expected, name
