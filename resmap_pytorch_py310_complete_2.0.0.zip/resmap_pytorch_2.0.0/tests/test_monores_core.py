from __future__ import annotations

import ast
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pytest
import torch

from monores_backend import utils as u
from monores_backend.algorithm import MonoResConfig, resolution_limits

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def uploaded():
    """Load the unmodified uploaded modules under private names for comparison."""
    folder = ROOT / "upstream" / "monores-master"
    saved = {name: sys.modules.get(name) for name in ("c_functions", "input_output", "utils")}
    modules = {}
    for name in ("c_functions", "input_output", "utils", "monores"):
        spec = importlib.util.spec_from_file_location("_uploaded_" + name, folder / (name + ".py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        modules[name] = mod
        if name != "monores":
            sys.modules[name] = mod
    for name, value in saved.items():
        if value is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = value
    return SimpleNamespace(**modules)


@pytest.fixture(autouse=True)
def few_threads():
    old = torch.get_num_threads()
    torch.set_num_threads(2)
    yield
    torch.set_num_threads(old)


@pytest.mark.parametrize("n", [15, 16, 24])
def test_frequency_grid_and_fullband_match_upload(n, uploaded):
    shape = (n, n, n)
    grid = u.fourier_freqs_3d(shape, "cpu")
    old = uploaded.utils.fourier_freqs_3d(shape, "cpu")
    for a, b in zip(grid, old):
        torch.testing.assert_close(a, b, rtol=0, atol=0)
    vol = torch.randn(shape, dtype=torch.float64, generator=torch.Generator().manual_seed(n)) + .125
    spectrum = torch.fft.rfftn(vol)
    torch.testing.assert_close(u.monogenic_amplitude_3d_fourier(spectrum, *grid, shape),
                               uploaded.utils.monogenic_amplitude_3d_fourier(spectrum, *old, shape), rtol=0, atol=0)


@pytest.mark.parametrize("freq", [.125, .25, .49])
def test_nonboundary_amplitude_and_gaussian_bitwise_equal_to_upload(freq, uploaded):
    shape = (16, 16, 16)
    vol = torch.randn(shape, dtype=torch.float64, generator=torch.Generator().manual_seed(1))
    spec = torch.fft.rfftn(vol)
    grid = u.fourier_freqs_3d(shape, "cpu")
    args = (spec, freq, max(0, freq - .02), min(.5, freq + .02), *grid, shape)
    torch.testing.assert_close(u.amplitude_mono_sig_3d_lpf(*args),
                               uploaded.utils.amplitude_mono_sig_3d_lpf(*args), rtol=0, atol=0)
    torch.testing.assert_close(u.real_gaussian_filter(vol, 3), uploaded.utils.real_gaussian_filter(vol, 3), rtol=0, atol=0)


@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_nyquist_is_exact_previous_bin_extension(dtype):
    n = 16
    shape = (n,) * 3
    grid = u.fourier_freqs_3d(shape, "cpu", dtype)
    spec = torch.fft.rfftn(torch.randn(shape, dtype=dtype, generator=torch.Generator().manual_seed(2)))
    freq = (n // 2 - 1) / n
    boundary = u.amplitude_mono_sig_3d_lpf(spec, .5, .48, .5, *grid, shape)
    previous = u.amplitude_mono_sig_3d_lpf(spec, freq, max(0, freq - .02), min(.5, freq + .02), *grid, shape)
    assert torch.isfinite(boundary).all()
    torch.testing.assert_close(boundary, previous, rtol=0, atol=0)


def test_uploaded_nyquist_bug_is_reproduced_in_reference(uploaded):
    shape = (16,) * 3
    grid = uploaded.utils.fourier_freqs_3d(shape, "cpu")
    spec = torch.fft.rfftn(torch.ones(shape, dtype=torch.float64))
    result = uploaded.utils.amplitude_mono_sig_3d_lpf(spec, .5, .48, .5, *grid, shape)
    assert torch.isnan(result).all()


@pytest.mark.parametrize("n", [8, 32])
def test_float32_does_not_promote_and_does_not_overflow_dc(n):
    shape = (n,) * 3
    vol = torch.ones(shape, dtype=torch.float32) * 17
    grid = u.fourier_freqs_3d(shape, "cpu", torch.float32)
    assert all(t.dtype == torch.float32 for t in grid)
    spec = torch.fft.rfftn(vol)
    result = u.monogenic_amplitude_3d_fourier(spec, *grid, shape)
    assert result.dtype == torch.float32 and torch.isfinite(result).all()
    smooth = u.real_gaussian_filter(result, 3)
    assert smooth.dtype == torch.float32 and torch.isfinite(smooth).all()
    torch.testing.assert_close(result, torch.full_like(result, 17), rtol=1e-5, atol=1e-5)


def test_float32_matches_float64_on_random_nonboundary():
    shape = (24,) * 3
    v = torch.randn(shape, dtype=torch.float64, generator=torch.Generator().manual_seed(20)) + .4
    outputs = []
    for dt in (torch.float64, torch.float32):
        grid = u.fourier_freqs_3d(shape, "cpu", dt)
        outputs.append(u.amplitude_mono_sig_3d_lpf(torch.fft.rfftn(v.to(dt)), .25, .23, .27, *grid, shape))
    torch.testing.assert_close(outputs[0], outputs[1].double(), rtol=2e-6, atol=5e-7)


@pytest.mark.parametrize("n", [31, 32])
@pytest.mark.parametrize("drop", [False, True])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_fast_and_legacy_cliffs_choose_identical_boundary(n, drop, dtype):
    shape = (n,) * 3
    r2 = u.xmipp_centered_radius2(shape, "cpu")
    vol = torch.randn(shape, dtype=dtype, generator=torch.Generator().manual_seed(n))
    if drop:
        vol[r2 >= 11 ** 2] = 0
    masks = [(r2 < 5 ** 2).to(torch.int64) for _ in range(2)]
    old_limit = u.find_cliff_value(vol, 4, masks[0])
    new_limit = u.find_cliff_value_fast(vol, 4, masks[1], z_chunk=7)
    assert old_limit == new_limit
    assert torch.equal(*masks)
    assert old_limit == (10 if drop else n // 2)


def test_grouped_shell_statistics_against_direct_shell_reductions():
    n = 33
    shape = (n,) * 3
    volume = torch.randn(shape, dtype=torch.float64, generator=torch.Generator().manual_seed(9))
    r2 = u.xmipp_centered_radius2(shape, "cpu")
    counts, sums, squares = u.grouped_shell_statistics(volume, z_chunk=3)
    for rad in range(n // 2):
        vals = volume[(r2 >= rad ** 2) & (r2 < (rad + 1) ** 2)]
        assert int(counts[rad]) == vals.numel()
        torch.testing.assert_close(sums[rad], vals.sum(), rtol=1e-12, atol=1e-10)
        torch.testing.assert_close(squares[rad], (vals * vals).sum(), rtol=1e-12, atol=1e-10)


def test_zero_volume_and_protein_outside_inscribed_sphere_cliff():
    shape = (16,) * 3
    volume = torch.zeros(shape, dtype=torch.float64)
    for radius in (0, 9, 14):
        first = torch.ones(shape, dtype=torch.int64)
        second = first.clone()
        assert u.find_cliff_value(volume, radius, first) == u.find_cliff_value_fast(volume, radius, second)
        assert torch.equal(first, second)


def test_legacy_cliff_function_source_is_unchanged(uploaded):
    import inspect
    assert inspect.getsource(u.find_cliff_value) == inspect.getsource(uploaded.utils.find_cliff_value)


def test_full_sort_and_statistics_are_unchanged(uploaded, monkeypatch):
    for name in ("_mean_var", "_nearest_rank", "statistics_in_binary_mask", "statistics_in_out_binary_mask"):
        import inspect
        assert inspect.getsource(getattr(u, name)) == inspect.getsource(getattr(uploaded.utils, name))
    calls = []
    original = torch.sort
    def tracked(*a, **kw):
        calls.append(True)
        return original(*a, **kw)
    monkeypatch.setattr(torch, "sort", tracked)
    vals = torch.tensor([8., 1., 2., 5., 3., 4., 6., 7.], dtype=torch.float64)
    assert u._nearest_rank(vals, .5) == 5
    assert calls


@pytest.mark.parametrize("half", [False, True])
def test_actual_two_failure_state_machine(half, uploaded):
    a = torch.tensor([0.], dtype=torch.float64)
    mask = torch.tensor([1], dtype=torch.int64)
    res = torch.tensor([0.], dtype=torch.float64)
    u.set_local_resolution(a, mask, res, 1., 5., 8., half)
    assert mask.item() == 2
    u.set_local_resolution(a, mask, res, 1., 4., 6., half)
    assert mask.item() == (0 if half else -1)
    assert res.item() == 6.


def test_resolution_limits_explicit_min_and_omitted_min():
    config = MonoResConfig(input1="unused", max_resolution=10)
    minimum, _, _, schedule = resolution_limits(config, 1.25, 32)
    assert minimum == 2.5 and schedule[-1][1] == .5
    config.min_resolution = 4
    minimum, _, _, schedule = resolution_limits(config, 1.25, 32)
    assert minimum == 4 and schedule[-1][0] == 4
    assert all(4 <= r <= 10 for r, _, _ in schedule)
    config.min_resolution = 0
    with pytest.raises(ValueError, match="omit it"):
        resolution_limits(config, 1.25, 32)


@pytest.mark.parametrize("minimum,maximum,step", [(1., 10., .25), (5., 4., .25), (2.5, 10, .1), (float('nan'), 10, .25)])
def test_invalid_resolution_limits_fail(minimum, maximum, step):
    with pytest.raises(ValueError):
        resolution_limits(MonoResConfig(input1="unused", min_resolution=minimum,
                            max_resolution=maximum, step_resolution=step), 1.25, 32)


def test_bounded_grid_duplicates_and_odd_box():
    seq = list(u.bounded_resolution2eval(.25, 1., 2., 10., 31))
    freqs = [f for _, f, _ in seq]
    assert len(set(freqs)) == len(freqs)
    assert freqs == sorted(freqs)
    assert max(freqs) == 15/31
    assert all(2 <= r <= 10 for r, _, _ in seq)
    with pytest.raises(ValueError, match="no Fourier bin"):
        list(u.bounded_resolution2eval(.25, 1., 3.1, 3.12, 16))


def test_all_runtime_sources_parse_as_python310():
    for path in list(ROOT.glob("ResMap*.py")) + list((ROOT / "monores_backend").glob("*.py")):
        ast.parse(path.read_text(), filename=str(path), feature_version=(3, 10))


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is not available in this test environment")
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_cuda_fft_core_matches_cpu(dtype):
    shape = (32,) * 3
    volume = torch.randn(shape, dtype=dtype, generator=torch.Generator().manual_seed(9))
    outputs = []
    for dev in ("cpu", "cuda:0"):
        grid = u.fourier_freqs_3d(shape, dev, dtype)
        spec = torch.fft.rfftn(volume.to(dev))
        outputs.append(u.amplitude_mono_sig_3d_lpf(spec, .5, .48, .5, *grid, shape).cpu())
    torch.testing.assert_close(*outputs, rtol=2e-5 if dtype == torch.float32 else 1e-11,
                              atol=1e-5 if dtype == torch.float32 else 1e-11)
