# Validation of ResMap / MonoRes PyTorch 2.0.0

## Actual environment

Tests ran with Python 3.13.5, PyTorch 2.10.0+cpu, NumPy 2.3.5, SciPy 1.17.0,
mrcfile 1.5.4 and pytest 9.0.2. See BUILD_ENVIRONMENT.txt for complete metadata.
All runtime Python files also parsed successfully with Python 3.10 grammar.
An actual Python 3.10 interpreter was unavailable in this execution environment;
3.10 runtime execution was not verified. No NVIDIA GPU was available.

## Automated tests

```
62 passed, 2 skipped
```

The two skips are explicitly conditional CUDA amplitude comparisons (float32 and
float64). They were not reported as passing CPU tests. The original 11 ResMap
tests remain included and pass. Test output is in validation_logs/pytest_final.txt.

Additional coverage includes:

- All nine preserved ResMap computation/I/O/visualization helper modules checked
  against their original 1.1.5.2 SHA-256 values.
- Float64 frequency grids, full-band Riesz amplitude, non-boundary filtered
  amplitude and Gaussian filter exactly equal to the supplied MonoRes functions
  on tested small cubic volumes, including odd/even sizes.
- Single-map and half-map full workflows compared to the unmodified uploaded
  MonoRes, using binary masks and legacy cliff mode. Final maps, visualization
  maps and final masks were elementwise identical on these synthetic tests.
- Original Nyquist NaN reproduced in the isolated reference implementation;
  new float32/64 boundary operators exactly equal their preceding-bin operators.
- A strong-signal half-map end-to-end case reaches Nyquist with finite results
  and explicit boundary-extension entries in its JSON log.
- Float32 frequency, FFT, amplitude, Gaussian and returned-array dtype checks;
  nonzero DC test avoids intermediate sentinel overflow.
- Fast and legacy cliff methods choose the same noise radius/mask on tested
  odd/even, float32/64, noise, artificially masked, zero and outside-sphere cases.
  Grouped shell counts/sums/squared sums agree with direct reductions.
- The legacy cliff function and full-sort statistical functions are compared
  directly against the uploaded function source.
- Full sorting remains exercised in the Gaussian-threshold pipeline.
- Actual two-failure state transitions, nonzero soft masks, automatic initial
  masks, explicit minRes, omitted minRes, invalid bounds and duplicate bins.
- Input/header mismatch, nonfinite input and input/output collision rejection.
- All MonoRes MRC outputs retain voxel size, origin and start indices.
- MonoRes pVal is neither forwarded nor mapped to significance; different pVal
  inputs yield identical tested output maps, even when invalid for ResMap.
- Dispatch does not load ResMap_algorithm or ResMap_spectrumTools for MonoRes.

These are implementation/regression tests, not evidence that synthetic maps are
biologically valid or that both algorithms give the same scientific estimates.

## Actual CLI and installed-wheel checks

The wheel was built without dependency resolution, installed into an isolated
target directory, and run outside the source tree. Both the ResMap and MonoRes
CLI workflows ran to completion. Metadata, command entry, --help and --version
report 2.0.0. The installed MonoRes run used float32, two half maps, a soft mask,
explicit minRes, mask-only noise and an ignored pVal=999.

A real ResMap CLI run from the 1.1.5.2 base and a real CLI run from 2.0.0 (including
the isolated wheel) produced identical output arrays AND MRC headers for the
synthetic comparison. The ResMapApp GUI class AST is unchanged; interactive GUI
rendering and launching Chimera were not tested in this headless environment.

## 256-cubed CPU smoke test

The final code also processed a synthetic 256^3 single map, float32, one selected
frequency (5 A), with fast cliff detection and MRC output. All outputs were finite
and spatial metadata was retained. This is a **one-frequency** test, not a complete
broad-resolution scan and not a real experimental map. Recorded in
validation_logs/large_smoke_summary.json and large_smoke.log. Timings vary with
CPU load and must not be interpreted as GPU or complete-analysis timings.

## Isolated shell-detection measurements

Illustrative, single measurements on CPU, four Torch threads, float64 noise input:

| Box | Original repeated scan | Grouped shells | Boundary/mask equality |
|---|---:|---:|---|
| 128^3 | 0.2557 s | 0.0415 s | identical |
| 256^3 | 6.1141 s | 0.3310 s | identical |

These measurements isolate cliff detection; they do not include FFTs, sorting,
I/O or the complete MonoRes algorithm. The fast path excludes outside-sphere
voxels rather than putting them in one contended CUDA histogram bucket. CUDA
performance and exact reduction-order effects remain unmeasured.

## Not tested / not claimed

- Actual Python 3.10 interpreter execution (grammar/package compatibility checked).
- CUDA execution, cuFFT behavior on the user's GPU, GPU peak memory or speedup.
- Full 256-448^3 experimental datasets or a 448^3 memory/performance run.
- Bitwise reproducibility between float32/64, CPU/CUDA, or fast/legacy reductions
  for arbitrary real data near statistical decision boundaries.
- Independent agreement with a separately built Xmipp C++ executable. The direct
  MonoRes parity reference for this task is the supplied Python/PyTorch archive.

The release logs requested/effective Nyquist frequencies rather than claiming the
boundary extension independently measures Nyquist resolution.
