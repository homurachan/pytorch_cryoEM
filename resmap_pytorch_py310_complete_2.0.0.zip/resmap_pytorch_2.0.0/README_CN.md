# ResMap / MonoRes PyTorch 2.0.0

这是在用户提供的 `resmap_pytorch_py310_complete_1.1.5.2.zip` 上整合
`monores-master.zip` 的完整版本。以 Python 3.10+ 为目标，支持 PyTorch CPU / CUDA。

## 安装与版本确认

已有 ResMap 1.1.5.2 环境可直接复用，不需要更换已经工作的 PyTorch/CUDA。
建议解压到**新目录**，避免与旧源码混放：

```bash
cd resmap_pytorch_2.0.0
python ResMap.py --version
# 2.0.0
python ResMap.py --help
```

安装附带的 wheel 后可直接使用命令 `resmap-pytorch`：

```bash
python -m pip install --upgrade dist/resmap_pytorch_py310-2.0.0-py3-none-any.whl --no-deps
resmap-pytorch --version
```

也可以从源码安装：

```bash
python -m pip install . --no-deps --no-build-isolation
```

运行依赖仍是 numpy、scipy、matplotlib、mrcfile、torch。没有新增 Xmipp、Scipion、
C++ 扩展等运行依赖。构建源码 wheel 需要 setuptools 和 wheel。新建环境时先安装这些
运行依赖及适合目标机器的 PyTorch，再安装本程序。GUI 的 Tkinter 需求仅属于 ResMap；
MonoRes 命令行不加载 Tkinter。

## 一条命令切换方法

```bash
python ResMap.py --method resmap \
    --noguiSingle input.mrc --maskVol mask.mrc \
    --vxSize 1.34 --minRes 4 --maxRes 12 --stepRes 0.5 --device cuda:0

python ResMap.py --method monores \
    --noguiSingle input.mrc --maskVol mask.mrc \
    --vxSize 1.34 --minRes 4 --maxRes 12 --stepRes 0.5 --device cuda:0
```

省略 `--method` 时仍是 ResMap。原有 ResMap GUI 和算法不变。

MonoRes 两个 half map 示例：

```bash
python ResMap.py --method monores \
    --noguiSplit half1.mrc half2.mrc \
    --maskVol mask.mrc --vxSize 1.34 \
    --maxRes 25 --stepRes 0.25 \
    --noiseonlyinhalves \
    --monores-dtype float64 --monores-cliff fast \
    --device cuda:0 --output-dir MonoResOut
```

这里**没有给 minRes**，因此 MonoRes 使用 Nyquist（`2 * vxSize`）作为高分辨率端。
`--vxSize` 省略或为 0 时从 MRC header 读取。程序只接受正方体、各向同性采样的体积。

## 参数含义

| 参数 | 行为 |
|---|---|
| `--method resmap/monores` | 默认 resmap；MonoRes 只提供命令行 |
| `--minRes` | 较小的 Å 值，即高分辨率端；显式值在 MonoRes 中真正生效 |
| `--maxRes` | 较大的 Å 值，即低分辨率端 |
| `--stepRes` | 正的 Å 步长；ResMap 默认 1.0，MonoRes 默认 0.25，最小 0.25 |
| `--pVal` | **只对 ResMap 生效，MonoRes 完全忽略，不会换算 significance** |
| `--monores-significance` / `--significance` | MonoRes 独立置信度，默认 0.95 |
| `--monores-dtype float64/float32` | 默认 float64；仅改变 MonoRes FFT/幅值路径 |
| `--monores-cliff fast/legacy` | 默认 fast；legacy 是上传源码的逐球壳重复扫描函数 |
| `--monores-cliff-chunk` | fast 的球壳统计 Z 分块，默认 16；不是 FFT 分块 |
| `--monores-gaussian` / `--gaussian` | 使用原版 Gaussian 阈值分支；仍保留原版排序流程 |
| `--monores-noise-in-mask` / `--noiseonlyinhalves` | 两个 half map 时只使用 mask 内差值噪声，默认关闭 |
| `--monores-mask-excl` / `--maskExcl` | 排除 mask；保留上传版在不同模式下的应用规则 |
| `--threads` | MonoRes 的 CPU 线程数，默认 4 |
| `--output-dir` / `-o` | MonoRes 输出目录；默认 `<第一张输入图文件名去扩展名>_monores/` |

MonoRes 未提供 maxRes，或 maxRes=0 时，采用 ResMap 1.1.5.2 的自动粗端公式：
`round(4*vxSize/0.5)*0.5`；明确给出 maxRes 更便于控制扫描范围。
**只有省略 minRes 才在 MonoRes 自动使用 Nyquist**；显式 minRes=0 是输入错误。
小于 Nyquist 的 minRes、倒置的范围、非有限参数和不含可用 Fourier bin 的范围会报错。

MonoRes 从大 Å 值向小 Å 值扫描。内部仍将候选频率取整到实际 Fourier 网格、跳过重复
bin；首尾可访问的 bin 会包括在内，因此实际扫描的 Å 值不一定等间隔，也不一定恰好
等于用户输入的端点。每轮实际值写入日志。不会将分辨率标签写到指定区间之外。

`--prewhiten`、`--kernelMode`、`--zChunk`、`--convChannels`、`--allowTF32`、
`--deterministic`、`--skipLPFTest`、`--noiseDiag` 是 ResMap 专属选项，MonoRes 忽略它们。
显式给出的不适用选项会有提示。`--output-dir` 是 MonoRes 专属；ResMap 保留原输出位置。

## Nyquist 边界：上一频率 bin 延拓

原版在 `freq = freqL = 0.5` 时零宽余弦过渡带产生 NaN。2.0.0 不使用硬截止替代整个模型，
也不把 NaN 静默置零，而是采用用户指定的邻点方案：

- 对偶数 N，Nyquist bin 是 N/2，边界幅值使用 `(N/2 - 1)/N` 的完整幅值算子。
- 信号和 half-difference 噪声使用同一个替代频率。
- “减 1”是**减一个 Fourier 索引**，不是 1 Å，也不是 1 cycle/pixel。
- 最终边界标签仍可为 `2*vxSize`，但这是延拓值，**不代表额外独立测得了 Nyquist 处信号**。
- `monores_run.json` 的 `nyquist_padded`、`evaluation_frequency`、`evaluation_resolution`
  会明确区分标签频率和实际用于幅值计算的频率。

非边界 float64 幅值的运算顺序保持上传实现。显式 minRes 比 Nyquist 更粗时，扫描不会
进入这个边界。奇数 N 没有恰好 0.5 的可访问 bin，使用其实际最细 Fourier bin。

## mask 与 MRC 空间信息

使用 ResMap 的 `MRC_Data` 和 `write_mrc2000_grid_data`；不会调用 ResMap 的均值扣除、
预白化、低通检测、下采样或固定 9-voxel 边界逻辑处理 MonoRes 输入。

提供的 soft mask 采用 `mask != 0`，非零值（包括负值）均视为内部。输入仍会继续接受
MonoRes 自己的 cliff/refinement 处理；非零 mask 的初始区域不等于最终有效区域。
没有 mask 时，以 SciPy Gaussian (`sigma = 0.02*N`) 和最大值 5% 阈值生成初始 mask，
不是先运行完整 ResMap 预处理。`inputMask.mrc` 可用于检查实际的初始二值 mask。
若整个 soft mask 都有微小非零值，单图会缺少背景噪声区；程序会报错，不会擅自选阈值。

输出保留参考图的 origin、start indices、轴映射、voxel size 等空间信息。两个 half map
必须有相同尺寸和空间坐标；显式 vxSize 可覆盖采样值，但不会平移或重采样它们。
所有 MRC 结果仍使用 float32 存储，即使内部计算使用 float64。

half map 的信号为 `(H1+H2)/2`，噪声为 `(H1-H2)/2`；不会被 ResMap 的 float32 输入运算
提前舍入。通常已有实验 mask 更适合做精确对照。

## 精度与噪声边界切换

对照上传的 MonoRes，使用：

```bash
--monores-dtype float64 --monores-cliff legacy
```

希望减少内存/显存，手动选择：

```bash
--monores-dtype float32 --monores-cliff fast
```

float32 分支先构造有界的 Riesz 方向乘子，再乘频谱，避免 `F(DC)*1e38` 在后续抵消前
溢出；不是将 DC 粗暴置零，也没有把整个计算偷偷提升回 float64。频率数组、FFT、幅值和
Gaussian 路径均使用所选精度。fast 球壳统计使用 float64 累加作为局部稳定化。
两种精度不保证逐位或逐体素相同；阈值附近体素可能改变停止轮次。

完整排序取分位数、mask refinement 排序和后处理中位数排序均按上传方式保留；没有改
为 kthvalue、partition 或插值分位数。连续失败状态机按实际代码保留：初始 1，失败到 2，
第二次失败到 3 时退出；单图/half-map 的退出标记仍不同。

fast cliff 将每个体素按整数半径归入球壳，一次性累计各球壳的数量、和及平方和，再按
原版 `<0.01` 方差比判断边界。几何条件和停止规则不变，但浮点归约顺序不同；CUDA 上
也不承诺逐位可重复。legacy 函数是原上传函数，保留用于对照。Z 分块仅减少球壳统计的
临时内存，**不能**把 MonoRes 的全局 FFT 切成 ResMap 式局部卷积。

## 输出

MonoRes 默认输出到独立目录，不覆盖 ResMap 的 `*_resmap.mrc`。

| 文件 | 内容 |
|---|---|
| `meanMap.mrc` | half-map 平均图，仅 split 模式 |
| `inputMask.mrc` | 非零规则/自动规则得到的初始二值 mask |
| `analysisMask.mrc` | MonoRes 初始处理后 mask；含 -1 排除区、0 背景、1 信号 |
| `monoresResolutionRaw.mrc` | 统计扫描后的原始局部分辨率，未做显示平滑 |
| `refinedMask.mrc` | 最终有结果区域 |
| `monoresResolutionMap.mrc` | 原版方式后处理的局部分辨率，mask 外为 0 |
| `monoresResolutionChimera.mrc` | mask 外使用填充值的显示图 |
| `monores_chimera.cmd` | 可选 Chimera 着色脚本，使用实际结果路径 |
| `monores_run.json` | 参数、实际频率、噪声阈值、停止原因、边界延拓标志、时间 |

`--noChimeraScript` 禁用脚本，`--vis2D` 显示结果切片和直方图，`--launchChimera` 尝试
启动本机 Chimera。没有新增 MonoRes 参数 GUI。输入路径与输出路径冲突时会拒绝覆盖输入。

## 测试、范围与来源

```bash
python -m pytest -q
# 或 bash run_tests.sh
```

`VALIDATION.md` 记录实际测试环境和限制。GPU 不可用时 CUDA 测试会明确 skip。
`upstream/monores-master/` 保留用户上传源码，测试会直接载入它作参考，不属于运行依赖。
九个 ResMap 计算/I/O/可视化辅助模块与 1.1.5.2 字节完全相同；仅入口接入方法分派。
原 GUI 类保持不变，只显示新版本号。

参考文献与上游说明见 `UPSTREAM_NOTICE.md`。历史 1.1.5.2 文档在 `docs/history/1.1.5.2/`，
不要将其中旧版本的测试数字或用法当成 2.0.0 的发布说明。
