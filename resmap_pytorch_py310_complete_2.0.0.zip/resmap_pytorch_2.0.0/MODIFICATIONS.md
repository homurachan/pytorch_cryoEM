# 2.0.0 changes from the supplied ResMap 1.1.5.2 and MonoRes archives

## ResMap preserved

`ResMap_algorithm.py`, `ResMap_torch.py`, `ResMap_fileIO.py`, `ResMap_blocks.py`,
`ResMap_helpers.py`, both spherical-profile modules, `ResMap_spectrumTools.py`,
and `ResMap_toChimera.py` are byte-identical to the supplied 1.1.5.2 tree.
The existing `ResMapApp` GUI class is unchanged. `ResMap.py` gains lazy dispatch,
method-specific argument defaults and a version change to 2.0.0. Omitted method
is ResMap; its effective argument defaults and numerical pipeline are preserved.

## Added isolated MonoRes backend

`monores_backend/algorithm.py`: driver adapted from uploaded monores.py, with
configuration, validation, bounded frequency scanning, original stop/assignment
logic, optional array results, timing and per-iteration JSON records.

`monores_backend/utils.py`: uploaded kernels/statistics and legacy cliff function,
with relative imports, explicit dtype propagation, safe float32 sentinel
multiplication, previous-bin Nyquist extension, finite checks, I/O-independent
postprocessing, bounded sweep, and optional grouped-shell statistics.

`monores_backend/c_functions.py`: same scalar helpers; tensor frequency conversion
accepts an explicit dtype (float64 remains the default).

`monores_backend/io.py`: uses ResMap's mrcfile layer, header-preserving writes,
nonzero masks, optional initial automatic mask, source-file overwrite protection
and half-map geometry validation. It does not call ResMap algorithm preprocessors.

`monores_backend/presentation.py`: optional plots and correctly named Chimera
commands without changing the existing ResMap plotting/Chimera code.

## Deliberate behaviour differences from the supplied MonoRes

1. Explicit minRes is honored; no aliasing beyond Nyquist. Rounding/deduplication
   is retained; accessible end bins are included, even if a coarse step misses one.
   A range containing no Fourier bin fails clearly. minRes omitted uses Nyquist;
   maxRes omitted/0 uses ResMap's automatic coarse-end formula.
2. pVal is ignored entirely, not converted to significance. An independent
   significance option remains, default 0.95.
3. Exactly-Nyquist amplitude uses the preceding Fourier-bin amplitude operator;
   both signal and noise are extended, and logs mark the boundary substitution.
4. Supplied mask values are converted by nonzero, not truncation. Missing masks
   may use an explicitly logged/saved automatic initial mask.
5. Output retains spatial MRC metadata and uses a separate default output folder.
6. float32 is optional; forming the cancelling frequency factors first prevents
   intermediate DC overflow. Full precision remains the default.
7. fast cliff is optional and default, with original legacy function unchanged.
   Floating summation order changes in fast mode; no bitwise CUDA claim is made.
8. Tiny negative variances caused by cancellation are clipped to zero; materially
   negative variances, undefined Z, NaN/Inf input/amplitude/output, empty masks,
   invalid sampling/bounds and incompatible half-map grids fail clearly.
9. Explicit minRes is also the finest permitted postprocessed value; the old
   median/Gaussian/revert operations and full sort are otherwise retained.

No replacement of sort by selection was made. No change from two consecutive
failures to three was made; only the misleading comment was corrected.
No torch.fft -> local-convolution approximation, FP16, whitening, resampling,
multi-GPU process launch, or new MonoRes parameter GUI was introduced.

## Upstream preservation

The exact uploaded MonoRes files are under `upstream/monores-master/`. They are
used for runtime parity tests but not imported by the installed implementation.
Historical 1.1.5.2 documents are retained under `docs/history/1.1.5.2/`.
