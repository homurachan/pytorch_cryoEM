#!/usr/bin/env python3
"""ResMap and MonoRes local-resolution analysis, Python 3.10 + PyTorch edition.

The historical command-line spellings are retained::

    python ResMap.py --noguiSingle INPUT.mrc [options]
    python ResMap.py --noguiSplit HALF1.mrc HALF2.mrc [options]

Run without either mode to open the Tkinter GUI.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Optional, Sequence

from ResMap_fileIO import MRC_Data

VERSION = "2.0.0"


def ResMap_algorithm(**kwargs):
    """Lazy compatibility wrapper: MonoRes/help do not import ResMap preprocessors."""
    from ResMap_algorithm import ResMap_algorithm as algorithm
    return algorithm(**kwargs)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ResMap.py",
        description="Cryo-EM local resolution: ResMap conv3d or MonoRes FFT (PyTorch CPU/CUDA).",
    )
    parser.add_argument("--method", choices=("resmap", "monores"), default="resmap",
                        help="analysis method (default: resmap; MonoRes is CLI-only)")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument(
        "--noguiSingle",
        metavar="INPUT",
        help="run a single-volume analysis without the Tk GUI",
    )
    modes.add_argument(
        "--noguiSplit",
        nargs=2,
        metavar=("INPUT1", "INPUT2"),
        help="run a split-half analysis without the Tk GUI",
    )
    parser.add_argument(
        "--vxSize",
        type=float,
        default=0.0,
        help="voxel size in Angstrom; 0 reads the MRC header (default: 0)",
    )
    parser.add_argument(
        "--pVal",
        type=float,
        default=0.05,
        help="ResMap-only LRS/FDR p-value in (0, 0.05]; completely ignored by MonoRes",
    )
    parser.add_argument("--minRes", type=float, default=None,
                        help="smaller Angstrom bound; omitted: ResMap auto, MonoRes Nyquist")
    parser.add_argument("--maxRes", type=float, default=None,
                        help="larger Angstrom bound; omitted/0: approximately 4*voxel-size")
    parser.add_argument("--stepRes", type=float, default=None,
                        help="Angstrom step >=0.25; default: ResMap 1.0, MonoRes 0.25")
    parser.add_argument("--maskVol", default=None, help="optional MRC mask")
    parser.add_argument("--vis2D", action="store_true", help="show result plots")
    parser.add_argument(
        "--launchChimera", action="store_true", help="try to launch UCSF Chimera"
    )
    parser.add_argument(
        "--noiseDiag",
        action="store_true",
        help="retain the legacy diagnostics option (currently informational)",
    )
    parser.add_argument(
        "--device",
        default="auto",
        help="PyTorch device: auto, cpu, cuda, or cuda:N (default: auto)",
    )
    parser.add_argument(
        "--zChunk",
        type=int,
        default=32,
        help="number of valid Z planes per LRS CUDA slab (default: 32)",
    )
    parser.add_argument(
        "--convChannels",
        type=int,
        default=4,
        help="low-rank filters evaluated together (default: 4)",
    )
    parser.add_argument(
        "--prewhiten",
        choices=("auto", "interactive", "off"),
        default="auto",
        help="pre-whitening mode; CLI default is noninteractive auto",
    )
    parser.add_argument(
        "--kernelMode",
        choices=("legacy-python2", "intended-half"),
        default="legacy-python2",
        help=(
            "Gaussian exponent convention: reproduce the actual Python 2 "
            "source behavior or use exp(-0.5*r^2) (default: legacy-python2)"
        ),
    )
    parser.add_argument(
        "--allowTF32",
        action="store_true",
        help="allow TF32 in CUDA conv3d (disabled by default for comparison)",
    )
    parser.add_argument(
        "--deterministic",
        action="store_true",
        help="ask cuDNN for deterministic convolution algorithms",
    )
    parser.add_argument(
        "--skipLPFTest",
        action="store_true",
        help="expert/testing option: skip automatic low-pass detection",
    )
    parser.add_argument(
        "--noChimeraScript",
        action="store_true",
        help="do not write the classic Chimera command file",
    )
    mono = parser.add_argument_group("MonoRes options (not used by ResMap)")
    mono.add_argument("--monores-dtype", choices=("float64", "float32"), default="float64",
                      help="FFT/amplitude precision (default: float64)")
    mono.add_argument("--monores-cliff", choices=("fast", "legacy"), default="fast",
                      help="noise-boundary search: grouped shells or original repeated scans")
    mono.add_argument("--monores-cliff-chunk", type=int, default=16,
                      help="Z planes per grouped-shell batch, NOT FFT tiling (default: 16)")
    mono.add_argument("--monores-significance", "--significance", type=float, default=0.95,
                      dest="monores_significance", help="MonoRes confidence level, independent of --pVal")
    mono.add_argument("--monores-gaussian", "--gaussian", action="store_true",
                      dest="monores_gaussian", help="use original Gaussian threshold option (sorting retained)")
    mono.add_argument("--monores-noise-in-mask", "--noiseonlyinhalves", action="store_true",
                      dest="monores_noise_in_mask", help="half maps only: noise within protein mask")
    mono.add_argument("--monores-mask-excl", "--maskExcl", default=None,
                      dest="monores_mask_excl", help="optional nonzero exclusion mask")
    mono.add_argument("--output-dir", "-o", dest="output_dir", default=None,
                      help="MonoRes output directory; default <input-stem>_monores/")
    mono.add_argument("--threads", type=int, default=4,
                      help="MonoRes CPU thread count (default: 4)")
    parser.add_argument("--version", action="version", version=VERSION)
    return parser


def _header_voxel_size(mrc: MRC_Data) -> float:
    value = float(mrc.data_step[0])
    if value <= 0.0:
        raise ValueError(
            "voxel size is absent/invalid in the MRC header; supply --vxSize"
        )
    return value


def _run_cli(args: argparse.Namespace) -> int:
    # Dispatch BEFORE reading through either algorithm's input/preprocessing path.
    if getattr(args, "method", "resmap") == "monores":
        return _run_monores_cli(args)
    if getattr(args, "output_dir", None):
        raise ValueError("--output-dir/-o is MonoRes-only; ResMap retains its original output naming")
    explicit = getattr(args, "_explicit_options", set())
    unused = sorted(x for x in explicit if x.startswith("--monores-") or x in
                    {"--significance", "--gaussian", "--noiseonlyinhalves", "--maskExcl", "--threads"})
    if unused:
        print("Note: ResMap ignores MonoRes options: " + ", ".join(unused), file=sys.stderr)
    data_mask = 0 if args.maskVol is None else MRC_Data(args.maskVol, "ccp4")
    common = dict(
        pValue=args.pVal,
        minRes=0.0 if args.minRes is None else args.minRes,
        maxRes=0.0 if args.maxRes is None else args.maxRes,
        stepRes=1.0 if args.stepRes is None else args.stepRes,
        dataMask=data_mask,
        graphicalOutput=args.vis2D,
        chimeraLaunch=args.launchChimera,
        noiseDiagnostics=args.noiseDiag,
        device=args.device,
        zChunk=args.zChunk,
        convChannels=args.convChannels,
        prewhiten=args.prewhiten,
        kernelMode=args.kernelMode,
        allowTF32=args.allowTF32,
        deterministic=args.deterministic,
        skipLPFTest=args.skipLPFTest,
        createChimera=not args.noChimeraScript,
    )

    if args.noguiSingle:
        input_path = os.path.abspath(os.path.expanduser(args.noguiSingle))
        data = MRC_Data(input_path, "ccp4")
        voxel_size = args.vxSize if args.vxSize > 0.0 else _header_voxel_size(data)
        ResMap_algorithm(
            inputFileName=input_path,
            data=data,
            vxSize=voxel_size,
            **common,
        )
        return 0

    if args.noguiSplit:
        input_path_1 = os.path.abspath(os.path.expanduser(args.noguiSplit[0]))
        input_path_2 = os.path.abspath(os.path.expanduser(args.noguiSplit[1]))
        data_1 = MRC_Data(input_path_1, "ccp4")
        data_2 = MRC_Data(input_path_2, "ccp4")
        voxel_size = args.vxSize if args.vxSize > 0.0 else _header_voxel_size(data_1)
        ResMap_algorithm(
            inputFileName1=input_path_1,
            inputFileName2=input_path_2,
            data1=data_1,
            data2=data_2,
            vxSize=voxel_size,
            **common,
        )
        return 0

    return _run_gui()


def _run_monores_cli(args: argparse.Namespace) -> int:
    if not (args.noguiSingle or args.noguiSplit):
        raise ValueError("MonoRes is CLI-only: supply --noguiSingle INPUT or --noguiSplit HALF1 HALF2")
    # pVal is not mapped to significance and is not validated for MonoRes.
    # Log explicitly supplied, unused ResMap parameters to avoid ambiguity.
    explicit = getattr(args, "_explicit_options", set())
    resmap_only = {"--pVal", "--prewhiten", "--kernelMode", "--zChunk", "--convChannels",
                   "--allowTF32", "--deterministic", "--skipLPFTest", "--noiseDiag"}
    unused = sorted(explicit & resmap_only)
    if unused:
        print("Note: MonoRes ignores ResMap options: " + ", ".join(unused), file=sys.stderr)
    from monores_backend.algorithm import MonoResConfig, run
    config = MonoResConfig(
        input1=args.noguiSingle if args.noguiSingle else args.noguiSplit[0],
        input2=None if args.noguiSingle else args.noguiSplit[1],
        mask_path=args.maskVol, exclusion_mask=args.monores_mask_excl,
        voxel_size=args.vxSize, min_resolution=args.minRes,
        max_resolution=args.maxRes,
        step_resolution=0.25 if args.stepRes is None else args.stepRes,
        significance=args.monores_significance, gaussian=args.monores_gaussian,
        noise_only_in_halves=args.monores_noise_in_mask,
        dtype=args.monores_dtype, cliff=args.monores_cliff,
        cliff_chunk=args.monores_cliff_chunk, device=args.device, threads=args.threads,
        output_dir=args.output_dir, create_chimera=not args.noChimeraScript,
        launch_chimera=args.launchChimera, show_plots=args.vis2D,
    )
    run(config, return_arrays=False)
    return 0


class ResMapApp:
    """Compact Python 3 Tkinter front end retaining single/split workflows."""

    def __init__(self, parent: object) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.parent = parent
        parent.title("ResMap (Local Resolution) " + VERSION)
        parent.option_add("*tearOff", False)

        self.single_path = tk.StringVar()
        self.half1_path = tk.StringVar()
        self.half2_path = tk.StringVar()
        self.mask_path = tk.StringVar()
        self.voxel_size = tk.StringVar(value="Auto")
        self.p_value = tk.StringVar(value="0.05")
        self.min_res = tk.StringVar(value="0.0")
        self.max_res = tk.StringVar(value="0.0")
        self.step_res = tk.StringVar(value="1.0")
        self.device = tk.StringVar(value="auto")
        self.prewhiten = tk.StringVar(value="interactive")
        self.kernel_mode = tk.StringVar(value="legacy-python2")
        self.z_chunk = tk.StringVar(value="32")
        self.conv_channels = tk.StringVar(value="4")
        self.show_plots = tk.BooleanVar(value=True)
        self.launch_chimera = tk.BooleanVar(value=False)
        self.allow_tf32 = tk.BooleanVar(value=False)
        self.deterministic = tk.BooleanVar(value=False)

        outer = ttk.Frame(parent, padding=10)
        outer.pack(fill=tk.BOTH, expand=True)
        self.notebook = ttk.Notebook(outer)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        self.single_frame = ttk.Frame(self.notebook, padding=10)
        self.split_frame = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(self.single_frame, text="Single Volume Input")
        self.notebook.add(self.split_frame, text="Split Volume Input")
        self._build_single_tab()
        self._build_split_tab()

        options = ttk.LabelFrame(outer, text="Analysis and GPU options", padding=10)
        options.pack(fill=tk.X, pady=(10, 0))
        self._build_options(options)
        ttk.Button(
            outer,
            text="Check Inputs and RUN",
            command=self.check_inputs_and_run,
        ).pack(anchor=tk.E, pady=(10, 0))

    def _browse(self, variable: object) -> None:
        from tkinter.filedialog import askopenfilename

        selected = askopenfilename(
            title="ResMap - Select MRC/CCP4 file",
            filetypes=(("MRC/CCP4 maps", "*.mrc *.map *.mrcs"), ("All files", "*")),
        )
        if selected:
            variable.set(selected)

    def _file_row(self, frame: object, row: int, label: str, variable: object) -> None:
        ttk = self.ttk
        sticky = self.tk
        ttk.Label(frame, text=label).grid(row=row, column=0, sticky=sticky.E, padx=4, pady=4)
        ttk.Entry(frame, textvariable=variable, width=80).grid(
            row=row, column=1, sticky=(sticky.W, sticky.E), padx=4, pady=4
        )
        ttk.Button(frame, text="Load", command=lambda: self._browse(variable)).grid(
            row=row, column=2, sticky=sticky.W, padx=4, pady=4
        )
        frame.columnconfigure(1, weight=1)

    def _build_single_tab(self) -> None:
        self._file_row(self.single_frame, 0, "Volume:", self.single_path)

    def _build_split_tab(self) -> None:
        self._file_row(self.split_frame, 0, "Split Volume 1:", self.half1_path)
        self._file_row(self.split_frame, 1, "Split Volume 2:", self.half2_path)

    def _build_options(self, frame: object) -> None:
        tk, ttk = self.tk, self.ttk
        fields = (
            ("Voxel size (A; Auto=header):", self.voxel_size),
            ("P-value:", self.p_value),
            ("Min resolution (A):", self.min_res),
            ("Max resolution (A):", self.max_res),
            ("Step size (A):", self.step_res),
            ("Z chunk:", self.z_chunk),
            ("Conv channels:", self.conv_channels),
        )
        for row, (label, variable) in enumerate(fields):
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky=tk.E, padx=4, pady=3)
            ttk.Entry(frame, textvariable=variable, width=12).grid(
                row=row, column=1, sticky=tk.W, padx=4, pady=3
            )

        ttk.Label(frame, text="Device:").grid(row=0, column=2, sticky=tk.E, padx=4)
        ttk.Combobox(
            frame,
            textvariable=self.device,
            values=("auto", "cuda:0", "cpu"),
            width=12,
        ).grid(row=0, column=3, sticky=tk.W, padx=4)
        ttk.Label(frame, text="Pre-whitening:").grid(row=1, column=2, sticky=tk.E, padx=4)
        ttk.Combobox(
            frame,
            textvariable=self.prewhiten,
            values=("interactive", "auto", "off"),
            width=12,
            state="readonly",
        ).grid(row=1, column=3, sticky=tk.W, padx=4)

        ttk.Label(frame, text="Kernel mode:").grid(row=2, column=2, sticky=tk.E, padx=4)
        ttk.Combobox(
            frame,
            textvariable=self.kernel_mode,
            values=("legacy-python2", "intended-half"),
            width=16,
            state="readonly",
        ).grid(row=2, column=3, sticky=tk.W, padx=4)

        ttk.Label(frame, text="Mask volume:").grid(row=3, column=2, sticky=tk.E, padx=4)
        ttk.Entry(frame, textvariable=self.mask_path, width=45).grid(
            row=3, column=3, sticky=(tk.W, tk.E), padx=4
        )
        ttk.Button(frame, text="Load", command=lambda: self._browse(self.mask_path)).grid(
            row=3, column=4, sticky=tk.W
        )
        ttk.Checkbutton(frame, text="2D result visualization", variable=self.show_plots).grid(
            row=4, column=2, columnspan=2, sticky=tk.W, padx=4
        )
        ttk.Checkbutton(frame, text="Launch UCSF Chimera", variable=self.launch_chimera).grid(
            row=5, column=2, columnspan=2, sticky=tk.W, padx=4
        )
        ttk.Checkbutton(frame, text="Allow TF32", variable=self.allow_tf32).grid(
            row=6, column=2, columnspan=2, sticky=tk.W, padx=4
        )
        ttk.Checkbutton(frame, text="Deterministic cuDNN", variable=self.deterministic).grid(
            row=7, column=2, columnspan=2, sticky=tk.W, padx=4
        )
        frame.columnconfigure(3, weight=1)

    def _number(self, variable: object, name: str, minimum: Optional[float] = None) -> float:
        from tkinter.messagebox import showerror

        try:
            value = float(variable.get())
        except ValueError:
            showerror("Check Inputs", "%s is not a valid number." % name)
            raise
        if minimum is not None and value < minimum:
            showerror("Check Inputs", "%s must be at least %s." % (name, minimum))
            raise ValueError(name)
        return value

    def check_inputs_and_run(self) -> None:
        from tkinter.messagebox import showerror, showinfo

        try:
            split = self.notebook.index(self.notebook.select()) == 1
            if split:
                if not self.half1_path.get() or not self.half2_path.get():
                    raise ValueError("select both split volumes")
                data1 = MRC_Data(self.half1_path.get(), "ccp4")
                data2 = MRC_Data(self.half2_path.get(), "ccp4")
                reference = data1
            else:
                if not self.single_path.get():
                    raise ValueError("select an input volume")
                data = MRC_Data(self.single_path.get(), "ccp4")
                reference = data

            if self.voxel_size.get().strip().lower() == "auto":
                voxel_size = _header_voxel_size(reference)
            else:
                voxel_size = self._number(self.voxel_size, "Voxel size", 0.0)
                if voxel_size <= 0.0:
                    raise ValueError("voxel size must be positive")
            p_value = self._number(self.p_value, "P-value", 0.0)
            if p_value <= 0.0 or p_value > 0.05:
                raise ValueError("P-value must be in (0, 0.05]")
            min_res = self._number(self.min_res, "Min resolution", 0.0)
            max_res = self._number(self.max_res, "Max resolution", 0.0)
            step_res = self._number(self.step_res, "Step size", 0.25)
            z_chunk = int(self._number(self.z_chunk, "Z chunk", 1.0))
            conv_channels = int(self._number(self.conv_channels, "Conv channels", 1.0))
            data_mask = MRC_Data(self.mask_path.get(), "ccp4") if self.mask_path.get() else 0

            common = dict(
                vxSize=voxel_size,
                pValue=p_value,
                minRes=min_res,
                maxRes=max_res,
                stepRes=step_res,
                dataMask=data_mask,
                graphicalOutput=self.show_plots.get(),
                chimeraLaunch=self.launch_chimera.get(),
                device=self.device.get(),
                zChunk=z_chunk,
                convChannels=conv_channels,
                prewhiten=self.prewhiten.get(),
                kernelMode=self.kernel_mode.get(),
                allowTF32=self.allow_tf32.get(),
                deterministic=self.deterministic.get(),
            )
            if split:
                result = ResMap_algorithm(
                    inputFileName1=self.half1_path.get(),
                    inputFileName2=self.half2_path.get(),
                    data1=data1,
                    data2=data2,
                    **common,
                )
            else:
                result = ResMap_algorithm(
                    inputFileName=self.single_path.get(), data=data, **common
                )
            showinfo("ResMap complete", "Result written to:\n%s" % result["output_path"])
        except Exception as exc:
            showerror("ResMap error", str(exc))


def _run_gui() -> int:
    try:
        import tkinter as tk
    except ImportError as exc:
        raise RuntimeError(
            "Tkinter is unavailable. Install the Python Tk package or use a --nogui mode."
        ) from exc
    root = tk.Tk()
    ResMapApp(root)
    root.mainloop()
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = _parser()
    tokens = list(sys.argv[1:] if argv is None else argv)
    args = parser.parse_args(tokens)
    args._explicit_options = {token.split("=", 1)[0] for token in tokens if token.startswith("-")}
    try:
        return _run_cli(args)
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return 130
    except Exception as exc:
        parser.exit(2, "%s error: %s\n" % (args.method, exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
