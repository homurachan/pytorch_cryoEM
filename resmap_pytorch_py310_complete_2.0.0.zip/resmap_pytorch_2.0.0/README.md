# ResMap + MonoRes PyTorch 2.0.0

Python 3.10+ local-resolution analysis with two independently dispatched methods:
ResMap's low-rank `conv3d` implementation and the user-supplied MonoRes PyTorch FFT
implementation. CPU and CUDA backends are available. No Xmipp/Scipion runtime or
compiled extension is required. See **README_CN.md** for the full Chinese guide.

## Install

Reuse your working ResMap 1.1.5.2 environment and CUDA-enabled PyTorch:

```bash
python -m pip install --upgrade dist/resmap_pytorch_py310-2.0.0-py3-none-any.whl --no-deps
resmap-pytorch --version
```

Or run from this new source directory (`python ResMap.py --help`) / install with
`python -m pip install . --no-deps --no-build-isolation`. Do not run an old local
`ResMap.py` and expect a newly installed wheel to override that local file.
Runtime dependencies remain NumPy, SciPy, matplotlib, mrcfile, and PyTorch.
Tkinter is needed only for the existing ResMap GUI.

## Usage

```bash
# Default method: unchanged ResMap
python ResMap.py --noguiSingle input.mrc --device cuda:0

# Only the method flag needs changing for common parameters
python ResMap.py --method monores --noguiSingle input.mrc --maskVol mask.mrc \
    --vxSize 1.34 --minRes 4 --maxRes 12 --stepRes 0.5 --device cuda:0

# Independent half maps; omitting minRes uses Nyquist for MonoRes
python ResMap.py --method monores --noguiSplit half1.mrc half2.mrc \
    --maskVol mask.mrc --maxRes 25 --stepRes 0.25 --noiseonlyinhalves \
    --monores-dtype float64 --monores-cliff fast --device cuda:0 -o MonoResOut
```

Both methods use the numerical Angstrom meanings: minRes is the smaller/finer
bound, maxRes the larger/coarser bound. MonoRes evaluates coarse to fine and
honors an explicitly supplied minRes; only omission selects Nyquist. An explicit
zero minRes is invalid for MonoRes. maxRes omitted/0 follows ResMap's automatic
coarse-end expression `round(4*vxSize/0.5)*0.5`; explicitly selecting maxRes is
recommended. MonoRes retains Fourier-bin rounding/deduplication and includes the
accessible endpoint bins. Actual reported resolution labels stay within bounds.
Default stepRes is 1 A for ResMap and 0.25 A for MonoRes, minimum 0.25 A.

**pVal is completely ignored by MonoRes**, not mapped to a confidence level. Its
independent `--monores-significance` / `--significance` defaults to 0.95.
`--monores-gaussian` / `--gaussian` and
`--monores-noise-in-mask` / `--noiseonlyinhalves` retain the uploaded modes.
The latter requires two half maps. `--monores-mask-excl` / `--maskExcl` retains the
uploaded exclusion rules, including its no-op for half maps without mask-only
noise (now warned about).

## Precision, boundary and mask handling

* Default `--monores-dtype float64`; manually select float32 to reduce FFT memory.
  Single precision forms bounded Riesz multipliers before multiplying the FFT,
  avoiding overflow of the intermediate DC sentinel product. Double precision
  keeps the uploaded non-boundary operation order. Threshold-edge assignments
  can differ between precisions.
* Default `--monores-cliff fast` groups voxels by integer spherical shell; legacy
  retains the uploaded repeated whole-volume shell scans. Shell geometry and the
  variance-ratio rule are the same; accumulation order differs. The fast path
  accumulates shell sums in float64, also for float32 input. CUDA bitwise
  reproducibility is not promised. `--monores-cliff-chunk` defaults to 16 Z planes.
* Full sorting is retained for empirical thresholds, refinement and postprocess
  medians, including the original sorting work in Gaussian mode. No kthvalue or
  approximate/interpolated quantile is substituted.
* At exactly Nyquist, the **entire amplitude operator from the preceding Fourier
  bin** supplies a constant boundary extension. For even N its frequency is
  `(N/2-1)/N`. This is one index, not one Angstrom. Signal and noise use the same
  substitute. The output can still label the boundary as `2*voxel_size`, but that
  is an extension, not independent evidence at Nyquist. The JSON log records the
  requested and evaluated frequencies and `nyquist_padded`.
* Supplied masks use **nonzero = inside**, matching ResMap, not integer truncation.
  Absent masks use ResMap's initial SciPy Gaussian/5%-maximum rule only. MonoRes
  still applies its own subsequent refinement and boundary detection. A fully
  nonzero soft mask may leave no single-map noise background and is rejected.
* MRC I/O uses the existing ResMap mrcfile-based header-preserving implementation.
  No ResMap mean subtraction, prewhitening, downsampling, or fixed 9-voxel backoff
  is applied to MonoRes. Mean and difference maps are formed in the selected
  precision as `(H1+H2)/2` and `(H1-H2)/2`.

`--zChunk` and `--convChannels` do NOT tile MonoRes's global FFTs. They and other
ResMap-specific flags are ignored with a notice when explicitly passed. There is
no silent downsampling on OOM. Use float32 or the CPU backend when needed.

## Outputs

MonoRes writes to `<input-stem>_monores/`, or `--output-dir` / `-o`:
`meanMap.mrc` (halves only), `inputMask.mrc`, `analysisMask.mrc`,
`monoresResolutionRaw.mrc`, `refinedMask.mrc`, `monoresResolutionMap.mrc`,
`monoresResolutionChimera.mrc`, optional `monores_chimera.cmd`, and
`monores_run.json`. MRC storage is float32 regardless of computation precision;
origin, start indices, axis mapping and sampling are retained. Input files are
protected against output-path collisions. The final smoothing cannot report a
value finer than the requested high-resolution bound.

ResMap keeps its original output naming and GUI. MonoRes is CLI-only, with
optional result plots (`--vis2D`) and Chimera script/launch. `--output-dir` is
MonoRes-only. `--noChimeraScript` disables script output.

## Validation and provenance

Run `bash run_tests.sh` or `python -m pytest -q`. See `VALIDATION.md` for the actual
runtime, tests, CPU smoke measurements and untested GPU/large-experimental-map
limits. Nine ResMap modules are byte-identical to 1.1.5.2 and checked by SHA-256.
The original MonoRes files are kept under `upstream/monores-master/` for tests and
attribution; they are not an installed runtime dependency. Historical ResMap
1.1.5.2 documentation is archived under `docs/history/1.1.5.2/`.

Sources are the two supplied archives, not a substituted GitHub snapshot.
Original papers:

A. Kucukelbir, F. J. Sigworth and H. D. Tagare, *Quantifying the local resolution
of cryo-EM density maps*, Nature Methods 11, 63–65 (2014).

J. L. Vilas et al., *MonoRes: Automatic and Accurate Estimation of Local
Resolution for Electron Microscopy Maps*, Structure 26, 337–344 (2018).

Original attribution and upstream redistribution notices are retained in
`UPSTREAM_NOTICE.md`; this release does not grant new rights to upstream code.
