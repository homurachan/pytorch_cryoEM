"""MonoRes driver derived from the user-supplied monores-master.zip.

Original MonoRes authors: Jose Luis Vilas and Carlos Oscar S. Sorzano.
Reference: Vilas et al., Structure 26, 337-344 (2018).

Shared I/O stops before method-specific preprocessing. The uploaded empirical
sort, two-failure state machine, noise regions and global stop tests are kept.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import math
from pathlib import Path
from time import perf_counter
from typing import Optional
import warnings

import numpy as np
import torch

from ResMap_torch import resolve_torch_device
from .c_functions import DBL_MIN, icdf_gauss, _c_div, _c_sqrt
from .io import OutputWriter, check_half_geometry, input_mask, read_volume, voxel_size
from .utils import (
    amplitude_mono_sig_3d_lpf, bounded_resolution2eval, evaluation_frequency,
    exclude_area, find_cliff_value, find_cliff_value_fast, fourier_freqs_3d,
    post_process_local_resolutions, protein_radius_and_volume, refine_mask,
    require_finite, set_local_resolution, statistics_in_binary_mask,
    statistics_in_out_binary_mask,
)


@dataclass
class MonoResConfig:
    input1: str
    input2: Optional[str] = None
    mask_path: Optional[str] = None
    exclusion_mask: Optional[str] = None
    voxel_size: float = 0.0
    min_resolution: Optional[float] = None
    max_resolution: Optional[float] = None
    step_resolution: float = 0.25
    significance: float = 0.95
    gaussian: bool = False
    noise_only_in_halves: bool = False
    dtype: str = "float64"
    cliff: str = "fast"
    cliff_chunk: int = 16
    device: str = "auto"
    threads: int = 4
    output_dir: Optional[str] = None
    create_chimera: bool = True
    launch_chimera: bool = False
    show_plots: bool = False


def resolution_limits(config: MonoResConfig, sampling: float, size: int):
    """Only an omitted minRes selects Nyquist in MonoRes."""
    minimum = 2.0 * sampling if config.min_resolution is None else float(config.min_resolution)
    maximum = 0.0 if config.max_resolution is None else float(config.max_resolution)
    if maximum == 0.0:
        # Same automatic coarse-end expression as ResMap 1.1.5.2 (no downsampling).
        maximum = round((4.0 * sampling) / 0.5) * 0.5
        if maximum == 0.0:
            maximum = 4.0 * sampling
    step = float(config.step_resolution)
    if not all(math.isfinite(v) for v in (minimum, maximum, step)):
        raise ValueError("minRes, maxRes and stepRes must be finite")
    if config.min_resolution is not None and minimum <= 0:
        raise ValueError("MonoRes minRes must be positive when supplied; omit it to use Nyquist")
    # Accommodate MRC float32 voxel metadata and decimal CLI values at Nyquist.
    if abs(minimum - 2 * sampling) <= 1e-6 * sampling:
        minimum = 2 * sampling
    if minimum < 2 * sampling:
        raise ValueError("minRes %.8g A is finer than Nyquist %.8g A" % (minimum, 2 * sampling))
    if maximum < minimum:
        raise ValueError("maxRes %.8g A is below minRes %.8g A; set the larger Angstrom limit" % (maximum, minimum))
    if step < 0.25:
        raise ValueError("stepRes must be at least 0.25 Angstrom")
    schedule = list(bounded_resolution2eval(step, sampling, minimum, maximum, size))
    return minimum, maximum, step, schedule


def _validate(config: MonoResConfig) -> None:
    if not config.input1:
        raise ValueError("provide --noguiSingle or --noguiSplit")
    if config.dtype not in ("float32", "float64"):
        raise ValueError("monores-dtype must be float32 or float64")
    if config.cliff not in ("fast", "legacy"):
        raise ValueError("monores-cliff must be fast or legacy")
    if config.cliff_chunk < 1 or config.threads < 1:
        raise ValueError("cliff chunk and threads must be positive")
    if not math.isfinite(config.significance) or not 0 < config.significance < 1:
        raise ValueError("monores-significance must be strictly between 0 and 1")
    if config.noise_only_in_halves and not config.input2:
        raise ValueError("--noiseonlyinhalves / --monores-noise-in-mask requires two half maps")


def _json_safe(value):
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return value


def _nonnegative_variance(variance: float, mean: float, dtype: torch.dtype) -> float:
    if variance >= 0:
        return variance
    # The uploaded sum(x^2)/N-mean^2 can cancel in either precision. Do not let
    # a tiny negative variance cause a NaN threshold. Large negatives are errors.
    tolerance = 16 * torch.finfo(dtype).eps * max(mean * mean, 1e-30)
    if variance >= -tolerance:
        return 0.0
    raise RuntimeError("negative noise/signal variance; check input or use --monores-dtype float64")


def run(config: MonoResConfig, *, write_output: bool = True,
        return_arrays: bool = True) -> dict:
    """Execute a full analysis. Does not invoke any ResMap preprocessor."""
    _validate(config)
    old_threads = torch.get_num_threads()
    try:
        torch.set_num_threads(config.threads)
        with torch.no_grad():
            return _run(config, write_output=write_output, return_arrays=return_arrays)
    except torch.OutOfMemoryError as exc:
        raise RuntimeError(
            "MonoRes ran out of device memory. Try --monores-dtype float32 or "
            "--device cpu. ResMap --zChunk does not tile MonoRes's global FFTs; "
            "no downsampling or approximation was performed."
        ) from exc
    finally:
        torch.set_num_threads(old_threads)


def _run(config: MonoResConfig, *, write_output: bool, return_arrays: bool) -> dict:
    start = perf_counter()
    device = resolve_torch_device(config.device)
    if device.type not in ("cpu", "cuda"):
        raise ValueError("MonoRes supports CPU and CUDA devices")
    dt = torch.float64 if config.dtype == "float64" else torch.float32
    np_dtype = np.float64 if dt == torch.float64 else np.float32
    print("== MonoRes 2.0.0 ==")
    print("Device: %s; dtype: %s; cliff: %s; noise percentile: %.6g" %
          (device, config.dtype, config.cliff, config.significance))
    print("ResMap prewhitening, LPF downsampling and pVal are NOT used.")

    reference = read_volume(config.input1, "input volume")
    sampling = voxel_size(reference, config.voxel_size)
    shape = tuple(reference.matrix.shape)
    size = shape[-1]
    min_res, max_res, step, schedule = resolution_limits(config, sampling, size)
    print("Resolution bounds: %.8g to %.8g A; sweep: coarse -> fine; step %.6g A" %
          (min_res, max_res, step))
    out_dir = (Path(config.output_dir).expanduser() if config.output_dir else
               Path(reference.path).with_suffix("").with_name(Path(reference.path).stem + "_monores"))
    writer = OutputWriter(reference, str(out_dir), sampling, enabled=write_output)
    # Never overwrite any source map, including one named like a MonoRes output.
    output_names = ("meanMap.mrc", "inputMask.mrc", "analysisMask.mrc", "refinedMask.mrc",
                    "monoresResolutionRaw.mrc", "monoresResolutionMap.mrc", "monoresResolutionChimera.mrc")
    source_paths = {Path(p).expanduser().resolve() for p in
                    (config.input1, config.input2, config.mask_path, config.exclusion_mask) if p}
    if write_output and any((writer.directory / name).resolve() in source_paths for name in output_names):
        raise ValueError("output directory would overwrite an input; choose a different --output-dir")

    first_cpu = np.asarray(reference.matrix, dtype=np_dtype, order="C")
    first = torch.as_tensor(first_cpu, device=device, dtype=dt)
    half_maps_given = bool(config.input2)
    fftN = None
    if half_maps_given:
        second_mrc = read_volume(config.input2, "second half map")
        check_half_geometry(reference, second_mrc, config.voxel_size > 0)
        second = torch.as_tensor(np.asarray(second_mrc.matrix, dtype=np_dtype, order="C"), device=device, dtype=dt)
        signal = 0.5 * (first + second)
        noise = (first - second) / 2.0
        require_finite(signal, "half-map mean")
        require_finite(noise, "half-map difference")
        writer.write("meanMap.mrc", signal)
        fftN = torch.fft.rfftn(noise, dim=(-3, -2, -1))
        del second, second_mrc, noise
    else:
        signal = first
    del first, first_cpu
    # The volume stored by MRC_Data is never mean-subtracted or downsampled.
    # Only headers are needed after transfer; drop the original CPU array.
    reference.matrix = np.empty((0, 0, 0), dtype=np.float32)
    del reference
    if config.mask_path:
        # Shape-only object: the supplied-mask branch doesn't need signal data.
        empty = np.broadcast_to(np.array(0, dtype=np_dtype), shape)
        mask_cpu = input_mask(config.mask_path, empty)
    else:
        mask_cpu = input_mask(None, signal.detach().cpu().numpy())
        print("Automatic initial mask: SciPy Gaussian (0.02*N), 5% of maximum.")
    writer.write("inputMask.mrc", mask_cpu)
    mask = torch.as_tensor(mask_cpu.astype(np.int64), dtype=torch.int64, device=device)
    del mask_cpu

    prep_start = perf_counter()
    radius, original_count = protein_radius_and_volume(mask)
    cliff_start = perf_counter()
    if config.cliff == "legacy":
        radiuslimit = find_cliff_value(signal, radius, mask, 0.0)
    else:
        radiuslimit = find_cliff_value_fast(signal, radius, mask, 0.0, config.cliff_chunk)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    cliff_seconds = perf_counter() - cliff_start
    print("Noise-boundary detection: %.4f s (%s)" % (cliff_seconds, config.cliff))

    if config.exclusion_mask:
        obj = read_volume(config.exclusion_mask, "exclusion mask")
        if obj.matrix.shape != shape:
            raise ValueError("exclusion mask and map shapes differ")
        exclusion = torch.as_tensor((obj.matrix != 0).astype(np.int64), device=device)
        if half_maps_given and not config.noise_only_in_halves:
            warnings.warn("maskExcl is ignored in half-map mode without noiseonlyinhalves, as in the uploaded MonoRes")
        exclude_area(mask, exclusion, half_maps_given, config.noise_only_in_halves)
        del exclusion, obj
    elif half_maps_given and config.noise_only_in_halves:
        mask[mask < 1] = -1

    fftV = torch.fft.rfftn(signal, dim=(-3, -2, -1))
    del signal
    require_finite(fftV, "input spectrum")
    if fftN is not None:
        require_finite(fftN, "noise spectrum")
    iu, fx, fy, fz = fourier_freqs_3d(shape, device, dtype=dt)
    if not config.noise_only_in_halves:
        original_count = refine_mask(fftV, iu, fx, fy, fz, mask, shape)
    if original_count == 0 or not bool((mask > 0).any().item()):
        raise RuntimeError("mask contains no signal voxels after MonoRes mask preparation")
    writer.write("analysisMask.mrc", mask)
    prep_seconds = perf_counter() - prep_start

    critical_z = icdf_gauss(config.significance)
    max_meanS = -DBL_MIN
    resolution_map = torch.zeros(shape, dtype=dt, device=device)
    list_res = []
    details = []
    stop_reason = "resolution_range_completed"
    scan_start = perf_counter()

    for iteration, (resolution, freq, _) in enumerate(schedule):
        level_start = perf_counter()
        eval_freq = evaluation_frequency(freq, size)
        padded = eval_freq != freq
        print("resolution = %.10g A; Fourier bin = %d%s" %
              (resolution, int(round(freq * size)), " (Nyquist: previous-bin extension)" if padded else ""))
        list_res.append(resolution)
        resolution_2 = list_res[0] if iteration < 2 else list_res[iteration - 2]
        freqL, freqH = min(freq + 0.02, 0.5), max(freq - 0.02, 0.0)
        amplitudeS = amplitude_mono_sig_3d_lpf(fftV, freq, freqH, freqL, iu, fx, fy, fz, shape)
        require_finite(amplitudeS, "signal amplitude at %.8g A" % resolution)
        if half_maps_given:
            amplitudeN = amplitude_mono_sig_3d_lpf(fftN, freq, freqH, freqL, iu, fx, fy, fz, shape)
            require_finite(amplitudeN, "noise amplitude at %.8g A" % resolution)
            values = statistics_in_binary_mask(amplitudeS, amplitudeN, mask, config.significance)
            del amplitudeN
        else:
            values = statistics_in_out_binary_mask(amplitudeS, mask, config.significance)
        meanS, sdS2, meanN, sdN2, thr95, NS, NN = values
        if not all(math.isfinite(v) for v in values):
            raise RuntimeError("non-finite MonoRes statistics; check input or use float64")
        row = dict(iteration=iteration + 1, resolution=resolution,
                   frequency=freq, fourier_index=int(round(freq * size)),
                   evaluation_frequency=eval_freq, evaluation_resolution=sampling / eval_freq,
                   nyquist_padded=padded, mean_signal=meanS, variance_signal=sdS2,
                   mean_noise=meanN, variance_noise=sdN2, noise_quantile=thr95,
                   signal_count=int(NS), noise_count=int(NN), threshold=None,
                   z=None, remaining_count=int(NS), stop_reason=None)
        stop = None
        if NS / original_count < 0.025:
            stop = "remaining_mask_below_2.5_percent"
        elif NS == 0:
            stop = "empty_signal_mask"
        else:
            sdS2 = _nonnegative_variance(sdS2, meanS, dt)
            sdN2 = _nonnegative_variance(sdN2, meanN, dt)
            threshold = meanN + critical_z * _c_sqrt(sdN2) if config.gaussian else thr95
            row["threshold"] = threshold
            # Full empirical sorting was deliberately performed above even for
            # gaussian=True, matching the uploaded source as requested.
            if meanS > max_meanS:
                max_meanS = meanS
            if meanS < 0.001 * max_meanS:
                stop = "signal_below_0.001_peak"
            else:
                set_local_resolution(amplitudeS, mask, resolution_map, threshold,
                                     resolution, resolution_2, half_maps_given)
                z = _c_div(meanS - meanN, _c_sqrt(sdS2 / NS + sdN2 / NN))
                # A zero/zero Z is uninformative, not evidence to continue.
                if math.isnan(z):
                    raise RuntimeError("undefined signal/noise Z statistic (zero variance); check independent half maps/background")
                row["z"] = z
                if z < critical_z:
                    stop = "global_signal_noise_test"
                row["remaining_count"] = int((mask > 0).sum().item())
        del amplitudeS
        row["elapsed_seconds"] = perf_counter() - level_start
        row["stop_reason"] = stop
        details.append(row)
        print("  signal=%d noise=%d threshold=%s remaining=%d" %
              (int(NS), int(NN), "n/a" if row["threshold"] is None else "%.10g" % row["threshold"], row["remaining_count"]))
        if stop:
            stop_reason = stop
            print("Search stopped: %s" % stop)
            break
    scan_seconds = perf_counter() - scan_start
    del fftV, fftN, iu, fx, fy, fz
    if not list_res:
        raise RuntimeError("no frequencies could be evaluated")
    mask[resolution_map == 0] = 0
    mask[resolution_map != 0] = 1
    writer.write("monoresResolutionRaw.mrc", resolution_map)
    post_start = perf_counter()
    final_map, chimera_map = post_process_local_resolutions(
        resolution_map.clone(), resolution_map, list_res, mask, sampling,
        writer=writer, minimum_resolution=min_res)
    post_seconds = perf_counter() - post_start
    valid = final_map[mask > 0]
    if valid.numel() == 0:
        raise RuntimeError("MonoRes produced no valid resolution voxels")
    summary = dict(mean_resolution=float(valid.mean().item()),
                   min_resolution=float(valid.min().item()), max_resolution=float(valid.max().item()),
                   valid_voxels=int(valid.numel()))
    del valid
    result = dict(version="2.0.0", method="monores", device=str(device), dtype=config.dtype,
                  config=asdict(config), voxel_size=sampling, shape=list(shape),
                  min_resolution=min_res, max_resolution=max_res, step_resolution=step,
                  half_maps=half_maps_given, pVal_used=False, significance=config.significance,
                  cliff_method=config.cliff, noise_radius=radiuslimit,
                  original_mask_count=original_count, nyquist_policy="previous_fourier_bin",
                  stop_reason=stop_reason, iterations=details, summary=summary,
                  timings=dict(mask_preparation_seconds=prep_seconds,
                               cliff_seconds=cliff_seconds, scan_seconds=scan_seconds,
                               postprocess_seconds=post_seconds, total_seconds=perf_counter() - start),
                  output_path=writer.paths.get("monoresResolutionMap.mrc"), outputs=dict(writer.paths))
    if write_output:
        if config.create_chimera or config.launch_chimera or config.show_plots:
            from .presentation import present
            result["outputs"].update(present(config, writer, summary, shape, sampling))
        report_path = writer.directory / "monores_run.json"
        with report_path.open("w", encoding="utf-8") as handle:
            json.dump(_json_safe(result), handle, indent=2, allow_nan=False)
            handle.write("\n")
        result["outputs"]["run_report"] = str(report_path)
        print("RESULT WRITTEN: %s" % result["output_path"])
        print("Iteration report: %s" % report_path)
    if return_arrays:
        result.update(resolution_map=final_map.cpu().numpy(),
                      raw_resolution_map=resolution_map.cpu().numpy(),
                      mask=(mask > 0).cpu().numpy())
    print("MonoRes completed in %.3f s" % (perf_counter() - start))
    return result
