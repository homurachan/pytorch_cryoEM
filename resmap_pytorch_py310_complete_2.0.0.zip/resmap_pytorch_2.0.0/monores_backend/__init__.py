"""Independent MonoRes backend integrated into ResMap-PyTorch 2.0.0.

Only light metadata is imported here; the heavy backend is loaded on demand.
"""
__version__ = "2.0.0"
