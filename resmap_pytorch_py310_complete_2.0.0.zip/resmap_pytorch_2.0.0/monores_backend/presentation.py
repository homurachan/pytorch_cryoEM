"""Optional MonoRes output display; no Tkinter parameter GUI is introduced."""
from __future__ import annotations

import json
from pathlib import Path
import warnings

import numpy as np
from ResMap_fileIO import MRC_Data
from ResMap_toChimera import try_alternatives


def present(config, writer, summary, shape, sampling) -> dict:
    outputs = {}
    density_path = writer.paths.get("meanMap.mrc", str(Path(config.input1).expanduser().resolve()))
    resolution_path = writer.paths["monoresResolutionChimera.mrc"]
    if config.create_chimera or config.launch_chimera:
        script = writer.directory / "monores_chimera.cmd"
        colors = ("blue", "cyan", "green", "yellow", "orange", "red")
        high = summary["max_resolution"]
        if high <= summary["min_resolution"]:
            high = summary["min_resolution"] + 0.01
        values = np.linspace(summary["min_resolution"], high, len(colors))
        cmap = ":".join("%.5g,%s" % (v, c) for v, c in zip(values, colors))
        script.write_text(
            "# MonoRes 2.0.0: color density by the postprocessed resolution map.\n"
            "set bg_color white\n"
            "open #0 %s\nopen #1 %s\nvolume #1 hide\n"
            "scolor #0 volume #1 cmap %s\n" %
            (json.dumps(density_path), json.dumps(resolution_path), cmap), encoding="utf-8")
        outputs["chimera_script"] = str(script)
        if config.launch_chimera:
            try:
                try_alternatives("chimera", ["", "/usr/bin", "/usr/local/bin",
                    "/Applications/Chimera.app/Contents/MacOS"], [str(script)])
            except OSError as exc:
                warnings.warn("Chimera could not be launched; command file retained: %s" % exc)
    if config.show_plots:
        import matplotlib.pyplot as plt
        result = MRC_Data(writer.paths["monoresResolutionMap.mrc"]).matrix
        valid = result[result > 0]
        figure = plt.figure()
        axis = figure.add_subplot(111)
        artist = axis.imshow(np.ma.masked_where(result[shape[0] // 2] <= 0, result[shape[0] // 2]))
        figure.colorbar(artist, ax=axis, label="Local resolution (Angstrom)")
        axis.set_title("MonoRes: central slice")
        figure2 = plt.figure()
        axis2 = figure2.add_subplot(111)
        axis2.hist(valid, bins=min(100, max(10, len(valid) // 100)))
        axis2.set_xlabel("Local resolution (Angstrom)")
        axis2.set_ylabel("Voxel count")
        axis2.set_title("MonoRes: resolution distribution")
        plt.show()
    return outputs
