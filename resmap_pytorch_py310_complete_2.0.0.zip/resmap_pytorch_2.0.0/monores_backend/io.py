"""Common mrcfile-based input/output, without ResMap-specific preprocessing."""
from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from scipy import ndimage

from ResMap_fileIO import MRC_Data, write_mrc2000_grid_data


def read_volume(path: str, label: str = "volume") -> MRC_Data:
    obj = MRC_Data(path)
    data = obj.matrix
    if data.ndim != 3 or len(set(data.shape)) != 1 or data.shape[0] < 4:
        raise ValueError("%s must be a cubic 3-D volume with side >= 4; got %r" % (label, data.shape))
    if not np.issubdtype(data.dtype, np.number) or np.iscomplexobj(data):
        raise ValueError("%s must contain real numeric values" % label)
    for begin in range(0, data.shape[0], 16):
        if not np.isfinite(data[begin:begin + 16]).all():
            raise ValueError("%s contains NaN or Inf" % label)
    return obj


def voxel_size(reference: MRC_Data, explicit: float) -> float:
    if not np.isfinite(explicit) or explicit < 0:
        raise ValueError("vxSize must be finite and nonnegative; 0 reads the MRC header")
    if explicit > 0:
        return float(explicit)
    values = np.asarray(reference.data_step, dtype=float)
    if not np.isfinite(values).all() or np.any(values <= 0):
        raise ValueError("MRC voxel size is absent/invalid; supply --vxSize")
    if not np.allclose(values, values[0], rtol=1e-5, atol=1e-7):
        raise ValueError("MonoRes assumes isotropic voxels; the MRC header is anisotropic")
    return float(values[0])


def check_half_geometry(first: MRC_Data, second: MRC_Data, explicit_voxel: bool) -> None:
    if first.matrix.shape != second.matrix.shape:
        raise ValueError("half maps must have identical shapes")
    if not explicit_voxel and not np.allclose(first.data_step, second.data_step, rtol=1e-5, atol=1e-7):
        raise ValueError("half-map voxel sizes disagree")
    for field in ("nxstart", "nystart", "nzstart", "mapc", "mapr", "maps"):
        if int(first.header[field]) != int(second.header[field]):
            raise ValueError("half-map spatial headers disagree on %s" % field)
    origin1 = [float(getattr(first.header.origin, a)) for a in ("x", "y", "z")]
    origin2 = [float(getattr(second.header.origin, a)) for a in ("x", "y", "z")]
    if not np.allclose(origin1, origin2, rtol=1e-6, atol=1e-5):
        raise ValueError("half-map origins disagree; align the input grids first")


def input_mask(path: Optional[str], signal: np.ndarray) -> np.ndarray:
    """Match ResMap's nonzero mask rule; no legacy 9-voxel edge backoff.

    Without a supplied mask, use the same Gaussian/5%-of-maximum initial mask
    rule as ResMap. MonoRes still performs its own cliff detection/refinement.
    """
    if path:
        obj = read_volume(path, "mask")
        if obj.matrix.shape != signal.shape:
            raise ValueError("mask and map shapes differ")
        mask = np.asarray(obj.matrix, dtype=bool)
    else:
        blurred = ndimage.gaussian_filter(signal, float(signal.shape[0]) * 0.02)
        maximum = float(np.max(blurred))
        if maximum <= 0:
            raise ValueError("automatic mask needs positive density; provide --maskVol")
        mask = blurred > maximum * 5e-2
    if not np.any(mask):
        raise ValueError("input mask is empty")
    return np.asarray(mask, dtype=bool, order="C")


class OutputWriter:
    """Derived maps retain the input's spatial header, using ResMap's writer."""

    def __init__(self, reference: MRC_Data, directory: str, sampling: float, enabled: bool = True):
        self.directory = Path(directory).expanduser().resolve()
        self.enabled = enabled
        self.paths: dict[str, str] = {}
        # Do not copy/retain an entire input volume just to preserve its header.
        self.template = copy.copy(reference)
        self.template.header = reference.header.copy()
        self.template.matrix = np.empty((0, 0, 0), dtype=np.float32)
        self.template.data_step = (sampling, sampling, sampling)
        if enabled:
            self.directory.mkdir(parents=True, exist_ok=True)

    def write(self, name: str, values) -> Optional[str]:
        if not self.enabled:
            return None
        if Path(name).name != name:
            raise ValueError("output filename must not contain a directory")
        if isinstance(values, torch.Tensor):
            values = values.detach().to(device="cpu", dtype=torch.float32).numpy()
        obj = copy.copy(self.template)
        obj.matrix = np.asarray(values, dtype=np.float32, order="C")
        if not np.isfinite(obj.matrix).all():
            raise RuntimeError("refusing to write a non-finite map: %s" % name)
        path = write_mrc2000_grid_data(obj, str(self.directory / name))
        self.paths[name] = path
        return path
