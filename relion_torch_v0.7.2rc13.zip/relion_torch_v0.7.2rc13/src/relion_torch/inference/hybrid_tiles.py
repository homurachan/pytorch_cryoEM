"""Batch-local projection reuse for partial global fine banks."""
from contextlib import nullcontext

import numpy as np
import torch

from relion_torch.reconstruction.volume_fusion import _failed, _ready

_validated = set()


def score_tiled_parents(source, active, image, ctf, noise, phases, high, rows, blocks,
                        translations, output, work_bytes, mode, *, direct=False, timer=None):
    if (not hasattr(source, 'gather_active_host') or phases.shape[1] > 16
            or any(t.dtype != torch.float32 for t in (ctf, noise, high))
            or image.dtype != torch.complex64 or phases.dtype != torch.complex64
            or not _ready(output, mode, 'hybrid_tiles')):
        return None
    nblocks, children, height, width = source.shape
    pixels, shifts = active.numel(), phases.shape[1]
    # Include the compact phases, observation copies, sort/permutation and validation
    # scratch. The persistent backing store is charged to the projection grant.
    fixed = (phases.shape[0] * shifts * pixels * 8 + image.numel() * 24
             + rows.numel() * 64 + 4 * pixels * (shifts + children) * 40)
    block_bytes = children * (4 * height * width + 4 * pixels) * 8
    store = getattr(source, 'store', None)
    # FineProjectionStore orders the unique (class, orientation) pairs. Only
    # this single-class full-plane store supports direct scoring.
    direct = (direct and hasattr(store, 'score_slots') and store.capacity >= children
              and source.host_classes.size and np.all(source.host_classes == source.host_classes[0])
              and _ready(output, mode, 'hybrid_slab'))
    usable = min((512 if direct else 128) * 2**20, work_bytes - fixed)
    tile = min(nblocks, usable // max(1, block_bytes))
    if direct:
        tile = min(tile, store.capacity // children)
    if tile < 1 or not rows.numel():
        return None
    try:
        import triton
        from .global_kernels import cached_fine_kernel
        from .score_tiles import score_prediction_tile

        def section(name):
            return timer.section('fine.hybrid.' + name, full=True) if timer is not None and timer.enabled else nullcontext()

        with section('schedule'):
            starts = np.arange(0, nblocks, tile)
            perm = None
            if len(starts) > 1:
                host = blocks.detach().cpu().numpy()
                order = np.argsort(host, kind='stable')
                edges = np.searchsorted(host[order], np.append(starts, nblocks))
                perm = torch.as_tensor(order, device=rows.device, dtype=torch.long)
        if store is not None and not hasattr(store, 'counter_prefix'):
            store = getattr(store, 'store', None)
        counters = getattr(store, 'counters', {})
        prefix = getattr(store, 'counter_prefix', '') + '_lifetime_'
        before = {name: counters.get(prefix + name, 0) for name in ('projected_rows', 'hits', 'misses')}
        tile_count = projection_rows = 0
        with section('prepare_inputs'):
            phase = phases.flatten(-2).index_select(-1, active).contiguous()
            obs, factors, inv, high = (t.contiguous() for t in (image, ctf, noise, high))
            rows, blocks, translations = (t.contiguous() for t in (rows, blocks, translations))
        for i, first in enumerate(starts):
            last = min(int(first) + tile, nblocks)
            ids = None if perm is None else perm[edges[i]:edges[i+1]]
            count = rows.numel() if ids is None else ids.numel()
            if not count:
                continue
            tile_count += 1
            projection_rows += (last - int(first)) * children
            with section('reference_rows'):
                if direct:
                    child_ids = (source.host_orientations[first:last, None] * children
                                 + np.arange(children)).reshape(-1)
                    slots = store.score_slots(int(source.host_classes[0]), child_ids)
                    refs = store.values
                else:
                    slots = None
                    refs = source.gather_active_host(np.arange(first, last), active).contiguous()
            with section('score_kernel'):
                cached_fine_kernel[(count * children,)](
                    torch.view_as_real(refs), torch.view_as_real(obs), factors, inv,
                    torch.view_as_real(phase), high, rows, blocks, translations, output,
                    F=pixels, OC=children, TC=shifts, BF=256, BT=triton.next_power_of_2(shifts),
                    PARENT_IDS=ids, FIRST_BLOCK=int(first), SLOTS=slots, ACTIVE=active if direct else None,
                    PLANE=height*width if direct else 0, enable_fp_fusion=False)
            key = (str(output.device), pixels, children, shifts, bool(first), bool(direct))
            if key not in _validated:
                check = slice(0, 4) if ids is None else ids[:4]
                r, b, t = rows[check], blocks[check] - int(first), translations[check]
                if direct:
                    check_slots = slots.view(-1, children)[b]
                    check_refs = refs.flatten(-2)[check_slots[..., None], active]
                else:
                    check_refs = refs[b]
                expected = score_prediction_tile(obs[r,None] * phase[t], check_refs * factors[r,None],
                                                 inv[r], high[r])
                torch.testing.assert_close(output[check], expected, rtol=3e-4, atol=2e-4)
                _validated.add(key)
            del refs
    except Exception as exc:
        # Only the private diff2 array has been written. The original scorer
        # overwrites it in full before any normalization or additive update.
        if direct:
            _failed('hybrid_slab', mode, exc)
            return score_tiled_parents(source, active, image, ctf, noise, phases, high, rows,
                                       blocks, translations, output, work_bytes, mode, timer=timer)
        _failed('hybrid_tiles', mode, exc)
        return None
    cache_delta = {'fine_hybrid_score_' + name: counters[prefix + name] - value
                   for name, value in before.items() if prefix + name in counters}
    return dict(fine_hybrid_tile_batches=1, fine_hybrid_tiles=tile_count,
                fine_hybrid_projection_rows=projection_rows,
                fine_hybrid_parent_rows=rows.numel()*children,
                fine_hybrid_gathered_complex_values=0 if direct else projection_rows*pixels,
                fine_hybrid_slab_rows=projection_rows if direct else 0,
                fine_workspace_estimate_bytes=fixed + tile*block_bytes,
                fine_sparse_tiles=tile_count, fine_sparse_batches=1, fine_dense_batches=0, **cache_delta)
