"""Preflight guarded insertion. Never replay a possibly committed atomic update."""
import importlib.util
from contextlib import nullcontext
import warnings
import torch

_validated=set()
_disabled=False
_tiled_disabled=set()
_warned=False


def _arguments(bp,images,weights,inverse):
    from .fused_projection import _complex_parts
    args=(bp.numerator_real,bp.numerator_imag,bp.denominator,
          _complex_parts(images),weights.contiguous(),inverse.contiguous(),images.numel())
    size=images.shape[-2]
    meta=dict(S=size,P=bp.compact_size,RADIUS2=min(bp.r_max,size/2.)**2,
              MAPPED_RADIUS2=bp.max_r2_padded,BLOCK=256,enable_fp_fusion=False)
    return args,meta


def _launch_grid(n, meta, group):
    import triton
    blocks = triton.cdiv(n, meta['BLOCK'])
    if group > 1:
        side = meta['S']
        stride = group * triton.cdiv(side * (side // 2 + 1), meta['BLOCK'])
        blocks = triton.cdiv(blocks, stride) * stride
    return (blocks,)


def _self_check(device, group=1):
    from .gridding_cuda_kernel import insert_kernel
    from relion_torch.fourier.backprojector import FourierBackprojector
    from relion_torch.alignment.core import _euler_matrix
    g=torch.Generator(device=device).manual_seed(511)
    size = 24 if group > 1 else 8
    rows = 11 if group > 1 else 3
    images=torch.randn((rows,size,size//2+1),device=device,dtype=torch.complex64,generator=g)
    weights=torch.rand(images.shape,device=device,generator=g)
    angles=torch.tensor([[0.,0.,0.],[53.,128.,-19.],[182.,91.,74.]],device=device)
    rotations=_euler_matrix(angles.repeat((rows+2)//3,1)[:rows])
    ref=FourierBackprojector.create(size,padding_factor=1.5,device=device)
    out=FourierBackprojector.create(size,padding_factor=1.5,device=device)
    inverse=torch.linalg.inv(rotations)*out.padding_factor
    if group == 1:
        ref.accumulate(images,rotations,weights)
    else:
        ref_args, ref_meta = _arguments(ref, images, weights, inverse)
        insert_kernel[_launch_grid(images.numel(), ref_meta, 1)](*ref_args, **ref_meta)
    args,meta=_arguments(out,images,weights,inverse)
    insert_kernel[_launch_grid(images.numel(), meta, group)](*args, ROW_GROUP=group, **meta)
    for name in ('numerator_real','numerator_imag','denominator'):
        torch.testing.assert_close(getattr(out,name),getattr(ref,name),rtol=4e-4,atol=3e-5)


def accumulate(bp,images,rotations,weights,*,mode='auto',counters=None,timer=None,tiled=False):
    global _disabled,_warned
    if mode=='off':return False
    supported=(bp.reference_dim==3 and images.device.type=='cuda' and images.dtype==torch.complex64
               and bp.denominator.dtype==torch.float32 and rotations.dtype==torch.float32
               and weights.dtype==torch.float32 and rotations.shape[-2:]==(3,3))
    ready=supported and not _disabled and importlib.util.find_spec('triton') is not None
    if not ready:
        if mode=='required':raise RuntimeError('Fused gridding needs CUDA, Triton and FP32 3D inputs')
        return False
    if not images.numel():return True
    # Pad=1 and short batches retained no benefit in real-input timing.
    tiled = (tiled and str(images.device) not in _tiled_disabled and bp.padding_factor >= 1.5
             and images.shape[-2] >= 128 and images.shape[0] >= 8)
    group = 8 if tiled else 1
    # Compile/validate before writing the caller's live sufficient statistics.
    try:
        from .gridding_cuda_kernel import insert_kernel
        key=(str(images.device),group)
        if key not in _validated:
            _self_check(images.device,group);_validated.add(key)
            if counters is not None:counters['fused_gridding_self_checks']=counters.get('fused_gridding_self_checks',0)+1
        with (timer.section('backprojection.grid_prepare',full=True) if timer is not None else nullcontext()):
            inverse=(torch.linalg.inv(rotations)*bp.padding_factor).contiguous()
            args,meta=_arguments(bp,images,weights,inverse)
            grid=_launch_grid(images.numel(),meta,group)
            meta["ROW_GROUP"]=group
            insert_kernel.warmup(*args,grid=grid,**meta)
    except Exception as exc:
        if isinstance(exc,(torch.cuda.OutOfMemoryError,MemoryError)) or mode=='required':raise
        if tiled:
            _tiled_disabled.add(str(images.device))
            warnings.warn('Tiled gridding preflight failed; using rc9 insertion: '+str(exc),RuntimeWarning)
            return accumulate(bp,images,rotations,weights,mode=mode,counters=counters,timer=timer)
        _disabled=True
        if not _warned:
            warnings.warn('Fused gridding preflight failed; using PyTorch insertion: '+str(exc),RuntimeWarning)
            _warned=True
        return False
    # DO NOT catch this launch and retry: an atomic update might have committed.
    with (timer.section('backprojection.grid_kernel',full=True) if timer is not None else nullcontext()):
        insert_kernel[grid](*args,**meta)
    if counters is not None:
        if group > 1:
            counters['fused_gridding_tiled_calls'] = counters.get('fused_gridding_tiled_calls',0)+1
            counters['fused_gridding_tiled_pixels'] = counters.get('fused_gridding_tiled_pixels',0)+images.numel()
        counters['fused_gridding_calls']=counters.get('fused_gridding_calls',0)+1
        counters['fused_gridding_input_pixels']=counters.get('fused_gridding_input_pixels',0)+images.numel()
    return True
