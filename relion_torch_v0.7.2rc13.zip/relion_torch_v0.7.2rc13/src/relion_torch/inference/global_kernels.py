"""Global-search epilogues. GEMMs, reductions and sorting retain PyTorch semantics."""
import triton
import triton.language as tl


@triton.jit
def cached_fine_kernel(REF, IMAGE, CTF, NOISE, PHASE, HIGH, ROW, BLOCK_ID, TRANS, OUT,
                       F: tl.constexpr, OC: tl.constexpr, TC: tl.constexpr,
                       BF: tl.constexpr, BT: tl.constexpr, PARENT_IDS=None, FIRST_BLOCK=0,
                       SLOTS=None, ACTIVE=None, PLANE: tl.constexpr=0):
    q = tl.program_id(0)
    parent = q // OC
    if PARENT_IDS is not None:
        parent = tl.load(PARENT_IDS + parent)
    row = tl.load(ROW + parent)
    ref = (tl.load(BLOCK_ID + parent) - FIRST_BLOCK) * OC + q % OC
    if SLOTS is not None:
        ref = tl.load(SLOTS + ref).to(tl.int64)
    trans = tl.load(TRANS + parent)
    ts = tl.arange(0, BT)
    pn = tl.full((), 0, tl.float32)
    xn = tl.full((BT,), 0, tl.float32)
    cross = tl.full((BT,), 0, tl.float32)
    for start in range(tl.cdiv(F, BF)):
        f = start * BF + tl.arange(0, BF)
        valid = f < F
        factor = tl.load(CTF + row * F + f, valid, 0)
        inv = tl.load(NOISE + row * F + f, valid, 0)
        if SLOTS is not None:
            offset = ref * PLANE + tl.load(ACTIVE + f, valid, 0)
        else:
            offset = ref * F + f
        pr = tl.load(REF + 2 * offset, valid, 0) * factor
        pi = tl.load(REF + 2 * offset + 1, valid, 0) * factor
        xr = tl.load(IMAGE + 2 * (row * F + f), valid, 0)
        xi = tl.load(IMAGE + 2 * (row * F + f) + 1, valid, 0)
        at = 2 * ((trans * TC + ts[:, None]) * F + f[None, :])
        use = (ts[:, None] < TC) & valid[None, :]
        ar = tl.load(PHASE + at, use, 0)
        ai = tl.load(PHASE + at + 1, use, 0)
        sr = xr[None, :] * ar - xi[None, :] * ai
        si = xr[None, :] * ai + xi[None, :] * ar
        cross += tl.sum(sr * (pr * inv)[None, :] + si * (pi * inv)[None, :], 1)
        xn += tl.sum((sr * sr + si * si) * inv[None, :], 1)
        pn += tl.sum((pr * pr + pi * pi) * inv, 0)
    value = tl.maximum(0.5 * (pn + xn - 2.0 * cross), 0.0,
                       propagate_nan=tl.PropagateNan.ALL) + tl.load(HIGH + row)
    tl.store(OUT + (parent.to(tl.int64) * OC + q % OC) * TC + ts, value, ts < TC)
from triton.language.extra.cuda import libdevice


@triton.jit
def score_epilogue_kernel(R, I, PN, XN, HIGH, OUT, N,
                          O: tl.constexpr, T: tl.constexpr, BLOCK: tl.constexpr):
    j = tl.program_id(0).to(tl.int64)*BLOCK+tl.arange(0, BLOCK)
    valid = j < N
    t, o, b = j % T, (j//T) % O, j//(T*O)
    src = (b*T+t)*O+o
    cross = tl.load(R+src, valid, 0)+tl.load(I+src, valid, 0)
    pn = tl.load(PN+b*O+o, valid, 0)
    xn = tl.load(XN+b, valid, 0)
    high = tl.load(HIGH+b, valid, 0)
    value = 0.5*((pn+xn)-2.0*cross)
    tl.store(OUT+j, tl.maximum(value, 0.0, propagate_nan=tl.PropagateNan.ALL)+high, valid)


@triton.jit
def raw_weights_kernel(SCORE, VALID, SHIFT, OUT, N, H: tl.constexpr, BLOCK: tl.constexpr):
    j = tl.program_id(0).to(tl.int64)*BLOCK+tl.arange(0, BLOCK)
    ok = j < N
    score = tl.load(SCORE+j, ok, -float('inf'))
    valid = tl.load(VALID+j, ok, 0)
    exponent = score+tl.load(SHIFT+j//H, ok, 0)
    # CUDA expf, not fast exp2; cutoff and the subsequent scan/sort stay unchanged.
    raw = tl.where(valid & (exponent >= -88.0), libdevice.exp(exponent), 0.0)
    tl.store(OUT+j, raw, ok)
