"""Score retained Gaussian parents against shared, cached Fourier projections."""
import numpy as np
import torch
from relion_torch.reconstruction.volume_fusion import _ready, _failed

_validated = set()


def score(source, active, image, ctf, noise, phases, high, rows, blocks, translations,
          output, work_bytes, mode):
    # The input store packs unique (class, coarse orientation) blocks. Gather
    # those blocks once, in their original order. Large banks retain rc6 tiling.
    if (any(t.dtype != torch.float32 for t in (ctf, noise, high))
            or image.dtype != torch.complex64 or phases.dtype != torch.complex64
            or not hasattr(source, 'gather_active_host') or phases.shape[1] > 16
            or not _ready(output, mode, 'cached_fine')):
        return None
    nblock, oc, side, width = source.shape
    f, tc = active.numel(), phases.shape[1]
    # Bound source full-plane gathers, multi-class output, and contiguous
    # observation/phase/index buffers. The persistent store is budgeted separately.
    needed = nblock * oc * (side * width + 3 * f) * 8
    needed += phases.shape[0] * tc * f * 8 + image.numel() * 16 + rows.numel() * 24
    if needed > work_bytes or not nblock:
        return None
    try:
        import triton
        from .global_kernels import cached_fine_kernel
        refs = source.gather_active_host(np.arange(nblock, dtype=np.int64), active).contiguous()
        phase = phases.flatten(-2).index_select(-1, active).contiguous()
        cached_fine_kernel[(rows.numel() * oc,)](
            torch.view_as_real(refs), torch.view_as_real(image.contiguous()), ctf.contiguous(),
            noise.contiguous(), torch.view_as_real(phase), high.contiguous(),
            rows.contiguous(), blocks.contiguous(), translations.contiguous(), output,
            F=f, OC=oc, TC=tc, BF=256, BT=triton.next_power_of_2(tc), enable_fp_fusion=False)
        key = (str(image.device), f, oc, tc)
        if key not in _validated:
            from .score_tiles import score_prediction_tile
            take = torch.arange(min(len(rows), 4), device=rows.device)
            r, b, t = rows[take], blocks[take], translations[take]
            expected = score_prediction_tile(image[r, None] * phase[t], refs[b] * ctf[r, None],
                                               noise[r], high[r])
            torch.testing.assert_close(output[take], expected, rtol=3e-4, atol=2e-4)
            _validated.add(key)
    except Exception as exc:
        _failed('cached_fine', mode, exc)
        return None
    return dict(fine_cached_score_batches=1, fine_cached_projection_blocks=nblock,
                fine_sparse_tiles=1, fine_sparse_batches=1, fine_dense_batches=0,
                fine_workspace_estimate_bytes=needed)
