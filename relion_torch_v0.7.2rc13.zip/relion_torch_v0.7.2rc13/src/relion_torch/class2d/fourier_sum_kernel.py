"""Fourier statistics for one already selected Class2D orientation supertile."""
import triton
import triton.language as tl
from triton.language.extra.cuda import libdevice


@triton.jit
def fourier_sum_kernel(REDUCED, REF, IMAGE, UNMASKED, PRED, NF, DF, INV, ROWS, ACTIVE, REL,
                       RES, NUM, DEN, XA, AA, F: tl.constexpr, A: tl.constexpr,
                       STRIDE: tl.constexpr, HAS_SCALE: tl.constexpr, BLOCK: tl.constexpr):
    row = tl.program_id(0)
    tile = tl.program_id(1)
    i = tile * BLOCK + tl.arange(0, BLOCK)
    particle = tl.load(ROWS + row)
    reduced = REDUCED + row * STRIDE
    mass = tl.load(reduced + 2 * F + A)

    # Full RFFT plane for insertion. Preserve the original multiplication order.
    pf = particle * F + i
    sr = tl.load(reduced + i, i < F, 0)
    si = tl.load(reduced + F + i, i < F, 0)
    ur = tl.load(UNMASKED + 2 * pf, i < F, 0)
    ui = tl.load(UNMASKED + 2 * pf + 1, i < F, 0)
    inv = tl.load(INV + pf, i < F, 0)
    nf = tl.load(NF + pf, i < F, 0) * inv
    df = tl.load(DF + pf, i < F, 0) * inv
    out = row * F + i
    tl.store(NUM + 2 * out, (sr * ur - si * ui) * nf, i < F)
    tl.store(NUM + 2 * out + 1, (sr * ui + si * ur) * nf, i < F)
    tl.store(DEN + out, mass * df, i < F)

    # Noise and scale statistics only use the independent active coefficients.
    valid = i < A
    pixel = tl.load(ACTIVE + i, valid, 0)
    sr = tl.load(reduced + pixel, valid, 0)
    si = tl.load(reduced + F + pixel, valid, 0)
    weight = tl.load(reduced + 2 * F + i, valid, 0)
    pa = particle * A + i
    xr = tl.load(IMAGE + 2 * pa, valid, 0)
    xi = tl.load(IMAGE + 2 * pa + 1, valid, 0)
    ctf = tl.load(PRED + pa, valid, 0)
    pr = tl.load(REF + 2 * (row * F + pixel), valid, 0) * ctf
    pi = tl.load(REF + 2 * (row * F + pixel) + 1, valid, 0) * ctf
    xabs = libdevice.hypot(xr, xi)
    pabs = libdevice.hypot(pr, pi)
    power = mass * (pabs * pabs)
    cross = pr * (xr * sr - xi * si) + pi * (xr * si + xi * sr)
    residual = tl.maximum(xabs * xabs * weight + power - 2.0 * cross, 0.0,
                          propagate_nan=tl.PropagateNan.ALL)
    tl.store(RES + row * A + i, residual, valid)
    if HAS_SCALE:
        reliable = tl.load(REL + i, valid, 0)
        partial = row * tl.cdiv(F, BLOCK) + tile
        tl.store(XA + partial, tl.sum(tl.where(reliable, cross, 0.0), 0))
        tl.store(AA + partial, tl.sum(tl.where(reliable, power, 0.0), 0))
